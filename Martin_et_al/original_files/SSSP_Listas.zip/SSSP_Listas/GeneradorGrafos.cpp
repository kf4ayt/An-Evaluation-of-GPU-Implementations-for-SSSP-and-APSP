#include "GeneradorGrafos.h"


//generaci�n de n�meros aleatorios
#define _CRT_RAND_S

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>  //buscar otro fichero .h que haga lo corresponde
using namespace std;

#include <cutil.h>
#include "tools.h"
#include "template_gold.h"

#include <limits.h>

#include "Lista.h"
#include "Arco.h"
#include "Nodo.h"


// export C interface
//#include "GeneradorGrafos1.h"


//////////////////////IMPLEMENTATION

//MOSTRAR LISTA DE ADYACENCIA

unsigned int RangedRand( unsigned int range_min, unsigned int range_max){
   // Generate random numbers in the closed interval
   // [range_min, range_max]. In other words,
   // range_min <= random number <= range_max

	unsigned int n;

	errno_t err = rand_s(&n);
    if (err != 0) printf("\n\nThe rand_s function failed!\n\n");
	unsigned int u= unsigned int (((double) n/ (double) UINT_MAX) * (range_max +1 - range_min)) + range_min;
 
	while((u<range_min)||(u>range_max)){
		printf("\n\nFallo en la generaci�n: %u\t%u\n\n", n, u);
		err = rand_s(&n);
		if (err != 0) printf("\n\nThe rand_s function failed!\n\n");
 		u= unsigned int (((double) n/ (double) UINT_MAX) * (range_max +1 - range_min)) + range_min;
	}

	return u;
}


void generaGrafo( unsigned int nv, const unsigned int degree, 
				   const unsigned int topeW,  unsigned int&  mem_size_V,
		     	   unsigned int& na, unsigned int& mem_size_A,
				   unsigned int*& v, unsigned int*& a, unsigned int*& w){
	na= nv*degree;
	mem_size_A= na* sizeof(unsigned int);
	
	mem_size_V= (nv+1)* sizeof(unsigned int);

	v= (unsigned int*) malloc(mem_size_V);
	a= (unsigned int*) malloc(mem_size_A);
	w= (unsigned int*) malloc(mem_size_A);

	unsigned int nodo;
	unsigned int d;
	unsigned int k;
	unsigned int i;
	bool enc;
	for(i=0; i<nv; i++){
		v[i]= i*degree;
		d=0;
		while(d<(int)degree){
			nodo= RangedRand(0,nv-1);
			if(d==0) enc= false;
			else{//d>0
				k= 0;
				enc= (a[i*degree + k]==nodo);
				while((k<(d-1)) && (!enc)) {
					k++;
					enc= (a[i*degree + k]==nodo);
				}//while
			}//else
			if(!enc){
				a[i*degree + d]= nodo;
				w[i*degree + d]= RangedRand(1,topeW);
				d++;
			}//if
		}//while
	}//for

	//incluir tap�n
	v[nv]= na;
/*
#ifdef _DEBUG
		printf("nv= %i\n", nv);
		printf("na= %i\n", na);
		printf("mem_size_V= %i\n", mem_size_V);
		printf("mem_size_A= %i\n", mem_size_A);
		mostrarUI(v,nv+1,"v");
		mostrarUI(a,na,"a");
#endif //_DEBUG
*/

}


//Formato de fichero BINARIO
void guardaGrafo_FicheroB(const char* filename, const unsigned int nv, const unsigned int na,
						  const unsigned int mem_size_V, const unsigned int mem_size_A,
						  const unsigned int* v, const unsigned int* a, const unsigned int* w){
	ofstream salida;
	salida.open(filename, ios::binary);
	if(salida.fail()) printf("\nProblemas con el archivo\n");
    else{
		salida.write((char*)& nv, sizeof(unsigned int));
		salida.write((char*)& na, sizeof(unsigned int));
		salida.write((char*)v, mem_size_V);
		salida.write((char*)a, mem_size_A);
		salida.write((char*)w, mem_size_A);
		salida.close();
    }//else
}

//Formato de fichero BINARIO espec�fico para evitar la construcci�n de la matriz de adyacencia
void leeGrafo_FicheroB(const char* filename, 
				      unsigned int& nv, unsigned int& na, 
					  unsigned int& mem_size_V, unsigned int& mem_size_A,
					  unsigned int*& v, unsigned int*& a, unsigned int*& w){
	v= NULL;
	a= NULL;
	w= NULL;
	ifstream entrada;
    entrada.open(filename, ios::binary);
	if(entrada.fail()) printf("\nProblemas con el archivo\n");
    else{
		entrada.read((char*)& nv, sizeof(unsigned int));
		entrada.read((char*)& na, sizeof(unsigned int));
		mem_size_V= nv* sizeof(unsigned int);
		mem_size_A= na* sizeof(unsigned int);

		v= (unsigned int*) malloc(mem_size_V);
		a= (unsigned int*) malloc(mem_size_A);
		w= (unsigned int*) malloc(mem_size_A);	

		// perror("ERROR MEMORIA");
		if (v==(unsigned int*)NULL) exit ( NOT_ENOUGH_MEM );
		if (a==(unsigned int*)NULL) exit ( NOT_ENOUGH_MEM );
		if (w==(unsigned int*)NULL) exit ( NOT_ENOUGH_MEM );

		entrada.read((char*)v, mem_size_V);
		entrada.read((char*)a, mem_size_A);
		entrada.read((char*)w, mem_size_A);
		entrada.close();
    }
}


////////////////////////////////////////////////////////////
//INVERSION DE GRAFOS REPRESENTADOS POR LISTAS DE ADYACENCIA
////////////////////////////////////////////////////////////

//Invertir un grafo
void invertir_Grafo(const unsigned int nv1, const unsigned int na1, 
					const unsigned int mem_size_V1, const unsigned int mem_size_A1,
					const unsigned int* v1, const unsigned int* a1, const unsigned int* w1,
					unsigned int& nv2, unsigned int& na2, 
					unsigned int& mem_size_V2, unsigned int& mem_size_A2,
					unsigned int*& v2, unsigned int*& a2, unsigned int*& w2){


    //RECUERDA: mem_size_V1= (nv1+1)*sizeof(int)

	nv2= nv1;
	na2= na1;
	mem_size_V2= mem_size_V1;
	mem_size_A2= mem_size_A1;

	v2= (unsigned int*) malloc(mem_size_V2);
	a2= (unsigned int*) malloc(mem_size_A2);
	w2= (unsigned int*) malloc(mem_size_A2);

	for(unsigned int i= 0; i<nv2; i++){
		v2[i]= 0;
	}//for

	unsigned int origen;
	for(unsigned int destino= 0; destino<nv1; destino++){
		for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
			//arista destino <- a1[d]
			origen= a1[d];
			v2[origen]= v2[origen]+1;
		}//for d
	}//for destino


	unsigned int* index= (unsigned int*) malloc(nv2* sizeof(unsigned int));

	unsigned int aux;
	unsigned int cont= 0;
	for(unsigned int i= 0; i<nv2; i++){
		aux= v2[i];
		v2[i]= cont;
		cont= cont + aux;
		index[i]= v2[i];
	}//for

	//incluir tap�n
	v2[nv2]= na2;

	unsigned int peso;
	for(unsigned int destino= 0; destino<nv1; destino++){
		for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
			//arista destino <- a1[d]
			//peso w1[d]
			origen= a1[d];
			peso= w1[d];

			a2[index[origen]]= destino;
			w2[index[origen]]= peso;

			index[origen]= index[origen]+1;
		}//for d
	}//for o


	free(index);



#ifdef _DEBUG
		printf("nv1= %i\n", nv1);
		printf("na1= %i\n", na1);
		printf("mem_size_V1= %i\n", mem_size_V1);
		printf("mem_size_A1= %i\n", mem_size_A1);
		mostrarUI(v1,nv1+1,"v1");
		mostrarUI(a1,na1,"a1");

		printf("\n\n\n");
		printf("nv2= %i\n", nv2);
		printf("na2= %i\n", na2);
		printf("mem_size_V2= %i\n", mem_size_V2);
		printf("mem_size_A2= %i\n", mem_size_A2);
		mostrarUI(v2,nv2+1,"v2");
		mostrarUI(a2,na2,"a2");
#endif //_DEBUG

}


//Invertir todos los grafos
void invertir_Grafos(const unsigned int n_Megas, const unsigned int n_Grafos){
	//lISTA DE PRECDECESORES
    unsigned int* v1; //array de v�rtices host
    unsigned int nv1; //n�mero de v�rtices 
    unsigned int mem_size_V1; //memoria del array con tapon

    unsigned int* a1; //array de aristas host
    unsigned int na1; //n�mero de aristas
    unsigned int mem_size_A1; //memoria del array

    unsigned int* w1; //array de pesos host

    //lISTA DE SUCESORES
    unsigned int* v2; //array de v�rtices host
    unsigned int nv2; //n�mero de v�rtices 
    unsigned int mem_size_V2; //memoria del array con tapon

    unsigned int* a2; //array de aristas host
    unsigned int na2; //n�mero de aristas
    unsigned int mem_size_A2; //memoria del array

    unsigned int* w2; //array de pesos host

    char s1[100];
    char s2[100];
    
    //DEPURACION
    printf("Invirtiendo los grafos\n\n");


	for(unsigned int m=12; m<=n_Megas; m++){

		printf("\n\nMegas= %d\n\n", m);
		printf("Grafo\t Lectura\t Inversion\t Escritura\n\n");
		for(unsigned int i =2; i<=n_Grafos; i++){

			printf("%i\t", i);
			if(i<10) sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo%d.gr", m, i);

			if(i<10) sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo%d.gr", m, i);


            unsigned int  timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

			//Leer grafo
			leeGrafo_FicheroB(s1, nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1);
			nv1= nv1-1; //descontar el tapon


    	    CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

			//Invertir grafo
			invertir_Grafo( nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1,
							nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2);


			CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


			timer = 0;
			CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
	
	        guardaGrafo_FicheroB(s2, nv2+1, na2, mem_size_V2, mem_size_A2, v2, a2, w2);

	        CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\n", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


	        printf( "%\n");

			// cleanup memory
			free( v1);
			free( a1);
			free( w1);

			// cleanup memory
			free( v2);
			free( a2);
			free( w2);

		}//for i

	}//for m

}

//Invertir un grafo usando arrays de listas, en lugar de un �nico array,
//para no precisar memoria RAM contigua
void invertir_Grafo2(const unsigned int nv1, const unsigned int na1, 
					const unsigned int mem_size_V1, const unsigned int mem_size_A1,
					unsigned int* v1, unsigned int* a1, unsigned int* w1,
					unsigned int& nv2, unsigned int& na2, 
					unsigned int& mem_size_V2, unsigned int& mem_size_A2,
					unsigned int*& v2, unsigned int*& a2, unsigned int*& w2){




	Lista<Arco>** grafo_invertido= new Lista<Arco>* [nv1];
	unsigned int l;
	for(l=0; l<nv1; l++){
		grafo_invertido[l]= new Lista<Arco>();
	}
	
	unsigned int origen;
	unsigned int destino;
	unsigned int peso;
	Arco* a;
	for(destino= 0; destino<nv1; destino++){
		for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
			//arista destino <- a1[d]
			origen= a1[d];
			peso= w1[d];
			a= new Arco(destino,peso);
			grafo_invertido[origen]->insertaFinal(a);
		}//for d
	}//for destino

	
	// cleanup memory, antes de construir v2, a2 y w2
	free( v1);
	free( a1);
	free( w1);

	//RECUERDA: mem_size_V1= (nv1+1)*sizeof(int)
	nv2= nv1;
	na2= na1;
	mem_size_V2= mem_size_V1;
	mem_size_A2= mem_size_A1;

	v2= (unsigned int*) malloc(mem_size_V2);
	a2= (unsigned int*) malloc(mem_size_A2);
	w2= (unsigned int*) malloc(mem_size_A2);

	//incluir tap�n
	v2[nv2]= na2;

	unsigned int cont= 0;
	Lista<Arco>* lista;
	for(origen= 0; origen<nv2; origen++){
		v2[origen]= cont;
		lista= grafo_invertido[origen];
		lista->inicia();
		while(!lista->final()){
			a= lista->getActual();
			lista->avanza();

			destino= a->getDestino();
			peso= a->getPeso();

			a2[cont]= destino;
			w2[cont]= peso;

			cont++;
		}//while

		//Aprovechamos para ir limpiando
		delete lista;
	}//for o

/*
#ifdef _DEBUG
		printf("\n\n\n");
		printf("nv2= %i\n", nv2);
		printf("na2= %i\n", na2);
		printf("mem_size_V2= %i\n", mem_size_V2);
		printf("mem_size_A2= %i\n", mem_size_A2);
		mostrarUI(v2,nv2+1,"v2");
		mostrarUI(a2,na2,"a2");
#endif //_DEBUG
*/
	// cleanup memory
	//for(l=0; l<nv1; l++) delete	grafo_invertido[l];
	delete[] grafo_invertido;

}
//Invertir todos los grafos: v1, a1 y w1 se eliminan antes de construir v2, a2 y w2
void invertir_Grafos2(const unsigned int n_Megas, const unsigned int n_Grafos){

	//lISTA DE PRECDECESORES
    unsigned int* v1; //array de v�rtices host
    unsigned int nv1; //n�mero de v�rtices 
    unsigned int mem_size_V1; //memoria del array con tapon

    unsigned int* a1; //array de aristas host
    unsigned int na1; //n�mero de aristas
    unsigned int mem_size_A1; //memoria del array

    unsigned int* w1; //array de pesos host

    //lISTA DE SUCESORES
    unsigned int* v2; //array de v�rtices host
    unsigned int nv2; //n�mero de v�rtices 
    unsigned int mem_size_V2; //memoria del array con tapon

    unsigned int* a2; //array de aristas host
    unsigned int na2; //n�mero de aristas
    unsigned int mem_size_A2; //memoria del array

    unsigned int* w2; //array de pesos host

    char s1[100];
    char s2[100];
    
    //DEPURACION
    printf("Invirtiendo los grafos\n\n");


	for(unsigned int m=12; m<=n_Megas; m++){

		printf("\n\nMegas= %d\n\n", m);
		printf("Grafo\t Lectura\t Inversion\t Escritura\n\n");
		for(unsigned int i =2; i<=n_Grafos; i++){

			printf("%i\t", i);
			if(i<10) sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo%d.gr", m, i);

			if(i<10) sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo%d.gr", m, i);


            unsigned int  timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

			//Leer grafo
			leeGrafo_FicheroB(s1, nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1);
			nv1= nv1-1; //descontar el tapon


    	    CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
/*
			#ifdef _DEBUG
					printf("nv1= %i\n", nv1);
					printf("na1= %i\n", na1);
					printf("mem_size_V1= %i\n", mem_size_V1);
					printf("mem_size_A1= %i\n", mem_size_A1);
					mostrarUI(v1,nv1+1,"v1");
					mostrarUI(a1,na1,"a1");
			#endif //_DEBUG
*/

			//Invertir grafo: OJO v1, a1 y w1 se destruyen!
			invertir_Grafo2( nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1,
							nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2);


			CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


			timer = 0;
			CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
	
	        guardaGrafo_FicheroB(s2, nv2+1, na2, mem_size_V2, mem_size_A2, v2, a2, w2);

	        CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\n", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


	        printf( "%\n");

			// cleanup memory
			free( v2);
			free( a2);
			free( w2);

		}//for i

	}//for m

}


//Invertir un grafo usando la clase Nodo para ahorrar memoria
void invertir_Grafo3(const unsigned int nv1, const unsigned int na1, 
					const unsigned int mem_size_V1, const unsigned int mem_size_A1,
					unsigned int* v1, unsigned int* a1, unsigned int* w1,
					unsigned int& nv2, unsigned int& na2, 
					unsigned int& mem_size_V2, unsigned int& mem_size_A2,
					unsigned int*& v2, unsigned int*& a2, unsigned int*& w2){




	Nodo** grafo_invertido= new Nodo* [nv1];
	unsigned int l;
	for(l=0; l<nv1; l++){
		grafo_invertido[l]= NULL;
	}
	
	unsigned int origen;
	unsigned int destino;
	unsigned int peso;
	Nodo* aux;
	for(destino= 0; destino<nv1/2; destino++){
		for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
			//arista destino <- a1[d]
			origen= a1[d];
			peso= w1[d];
			aux= grafo_invertido[origen];
			grafo_invertido[origen]= new Nodo(destino,peso,aux);
		}//for d
	}//for destino

	
	// cleanup memory, antes de construir v2, a2 y w2
	free( v1);
	free( a1);
	free( w1);

	//RECUERDA: mem_size_V1= (nv1+1)*sizeof(int)
	nv2= nv1;
	na2= na1;
	mem_size_V2= mem_size_V1;
	mem_size_A2= mem_size_A1;

	v2= (unsigned int*) malloc(mem_size_V2);
	a2= (unsigned int*) malloc(mem_size_A2);
	w2= (unsigned int*) malloc(mem_size_A2);

	//incluir tap�n
	v2[nv2]= na2;

	unsigned int cont= 0;
	Nodo* lista;
	for(origen= 0; origen<nv2; origen++){
		v2[origen]= cont;
		lista= grafo_invertido[origen];
		while(lista!=NULL){
			destino= lista->getDestino();
			peso= lista->getPeso();

			a2[cont]= destino;
			w2[cont]= peso;

			aux= lista->getSig();
			delete lista; //vamos lilberando memoria
			lista= aux;

			cont++;
		}//while

	}//for o

/*
#ifdef _DEBUG
		printf("\n\n\n");
		printf("nv2= %i\n", nv2);
		printf("na2= %i\n", na2);
		printf("mem_size_V2= %i\n", mem_size_V2);
		printf("mem_size_A2= %i\n", mem_size_A2);
		mostrarUI(v2,nv2+1,"v2");
		mostrarUI(a2,na2,"a2");
#endif //_DEBUG
*/
	// cleanup memory
	//for(l=0; l<nv1; l++) delete	grafo_invertido[l];
	delete[] grafo_invertido;

}
//Invertir todos los grafos: v1, a1 y w1 se eliminan antes de construir v2, a2 y w2
void invertir_Grafos3(const unsigned int n_Megas, const unsigned int n_Grafos){

	//lISTA DE PRECDECESORES
    unsigned int* v1; //array de v�rtices host
    unsigned int nv1; //n�mero de v�rtices 
    unsigned int mem_size_V1; //memoria del array con tapon

    unsigned int* a1; //array de aristas host
    unsigned int na1; //n�mero de aristas
    unsigned int mem_size_A1; //memoria del array

    unsigned int* w1; //array de pesos host

    //lISTA DE SUCESORES
    unsigned int* v2; //array de v�rtices host
    unsigned int nv2; //n�mero de v�rtices 
    unsigned int mem_size_V2; //memoria del array con tapon

    unsigned int* a2; //array de aristas host
    unsigned int na2; //n�mero de aristas
    unsigned int mem_size_A2; //memoria del array

    unsigned int* w2; //array de pesos host

    char s1[100];
    char s2[100];
    
    //DEPURACION
    printf("Invirtiendo los grafos\n\n");


	for(unsigned int m=12; m<=n_Megas; m++){

		printf("\n\nMegas= %d\n\n", m);
		printf("Grafo\t Lectura\t Inversion\t Escritura\n\n");
		for(unsigned int i =2; i<=n_Grafos; i++){

			printf("%i\t", i);
			if(i<10) sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo%d.gr", m, i);

			if(i<10) sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo%d.gr", m, i);


            unsigned int  timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

			//Leer grafo
			leeGrafo_FicheroB(s1, nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1);
			nv1= nv1-1; //descontar el tapon


    	    CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
/*
			#ifdef _DEBUG
					printf("nv1= %i\n", nv1);
					printf("na1= %i\n", na1);
					printf("mem_size_V1= %i\n", mem_size_V1);
					printf("mem_size_A1= %i\n", mem_size_A1);
					mostrarUI(v1,nv1+1,"v1");
					mostrarUI(a1,na1,"a1");
			#endif //_DEBUG
*/

			//Invertir grafo: OJO v1, a1 y w1 se destruyen!
			invertir_Grafo3( nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1,
							nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2);


			CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


			timer = 0;
			CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
	
	        guardaGrafo_FicheroB(s2, nv2+1, na2, mem_size_V2, mem_size_A2, v2, a2, w2);

	        CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\n", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


	        printf( "%\n");

			// cleanup memory
			free( v2);
			free( a2);
			free( w2);

		}//for i

	}//for m

}

//Leer un trozo
void leerTrozo(const char* filename, 
			   const unsigned int mem_size_trozo_V, const unsigned int mem_size_trozo_A, 
			   const unsigned int offsetV, const unsigned int offsetA, 
			   unsigned int*& v, unsigned int*& a, unsigned int*& w){
	    		
	ifstream entrada;
	entrada.open(filename, ios::binary);
	unsigned int* aux;
	if(entrada.fail()) printf("\nProblemas con el archivo\n");
	else{
		aux= &v[offsetV];
		entrada.read((char*)aux, mem_size_trozo_V);
		aux= &a[offsetA];
		entrada.read((char*)aux, mem_size_trozo_A);
		aux= &w[offsetA];
		entrada.read((char*)aux, mem_size_trozo_A);
		entrada.close();
	}	
}
//Guardar un trozo
void guardarTrozo(const char* filename, 
			      const unsigned int mem_size_trozo_V, const unsigned int mem_size_trozo_A, 
			      const unsigned int* v, const unsigned int* a, const unsigned int* w){
	    		
	ofstream salida;
	salida.open(filename, ios::binary);
	if(salida.fail()) printf("\nProblemas con el archivo\n");
    else{
		salida.write((char*)v, mem_size_trozo_V);
		salida.write((char*)a, mem_size_trozo_A);
		salida.write((char*)w, mem_size_trozo_A);
		salida.close();
    }//else
}
//Invertir un grafo troceando los arrays a2 y w2
void invertir_Grafo4(const unsigned int nv1, const unsigned int na1, 
					const unsigned int mem_size_V1, const unsigned int mem_size_A1,
					unsigned int* v1, unsigned int* a1, unsigned int* w1,
					const unsigned int nTrozos, const unsigned int degree,
					unsigned int& nv2, unsigned int& na2, 
					unsigned int& mem_size_V2, unsigned int& mem_size_A2,
					unsigned int*& v2, unsigned int*& a2, unsigned int*& w2){



	unsigned int trozo;
	//Se supone que nv1 es m�ltiplo de nTrozos
	unsigned int tam= nv1/nTrozos; 

	unsigned int offsetV;
	unsigned int offsetA;
	unsigned int sup;
	unsigned int i;

	char s[100];
	unsigned int* aristas= (unsigned int*) malloc(nTrozos*sizeof(unsigned int));
	
	unsigned int* index= (unsigned int*) malloc(tam*sizeof(unsigned int));

	unsigned int mem_size_trozo_V= tam*sizeof(unsigned int);
	v2= (unsigned int*) malloc(mem_size_trozo_V);

	unsigned int mem_size_trozo_A;
	
	unsigned int origen;
	unsigned int destino;
	unsigned int peso;

	unsigned int cont;
	unsigned int aux;

	offsetA= 0;
	for(trozo=0; trozo<nTrozos; trozo++){
		offsetV= trozo*tam;
		sup= offsetV+tam;

		//Inicializamos index
		for(i= 0; i<tam; i++) index[i]= 0;

		//Contamos el n�mero de adyacentes
		for(destino= 0; destino<nv1; destino++){
			for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
				//arista destino <- a1[d]
				origen= a1[d];
				if((offsetV<=origen)&&(origen<sup)){
					origen= origen-offsetV;
					index[origen]= index[origen]+1;
				}//if
			}//for d
		}//for destino

		//calculamos v2 
		cont= 0;
		for(i= 0; i<tam; i++){
			v2[i]= offsetA+cont;
			aux= index[i];
			index[i]= cont;
			cont= cont+aux;
		}

		//anotamos el numero de aristas del trozo y actualizamos offsetA
		aristas[trozo]= cont;
		offsetA= offsetA+aristas[trozo];
		
		//reservamos espacio para a y w2
		mem_size_trozo_A= aristas[trozo]*sizeof(unsigned int);
	    a2= (unsigned int*) malloc(mem_size_trozo_A);
	    w2= (unsigned int*) malloc(mem_size_trozo_A);


		//Invertimos parte del grafo
		for(destino= 0; destino<nv1; destino++){
			for(unsigned int d= v1[destino]; d<v1[destino+1]; d++){
				//arista destino <- a1[d]
				origen= a1[d];
				if((offsetV<=origen)&&(origen<sup)){
					origen= origen-offsetV;
					peso= w1[d];
					a2[index[origen]]= destino;
					w2[index[origen]]= peso;
					index[origen]= index[origen]+1;
				}//if
			}//for d
		}//for destino

		//Grabar el trozo en fichero 
		if(trozo<10) sprintf_s(s,"./temp/trozo0%d.gr", trozo);
		else sprintf_s(s,"./temp/trozo%d.gr", trozo);
	    guardarTrozo(s, mem_size_trozo_V, mem_size_trozo_A, v2, a2, w2);

		free( a2);
	    free( w2);

	}//for trozo
	
	// cleanup memory, antes de construir v2, a2 y w2
	free( v1);
	free( a1);
	free( w1);

	free(index);
	free( v2);


	//JUNTANDO LOS TROZOS

	//RECUERDA: mem_size_V1= (nv1+1)*sizeof(int)
	nv2= nv1;
	na2= na1;
	mem_size_V2= mem_size_V1;
	mem_size_A2= mem_size_A1;

	v2= (unsigned int*) malloc(mem_size_V2);
	a2= (unsigned int*) malloc(mem_size_A2);
	w2= (unsigned int*) malloc(mem_size_A2);

	//incluir tap�n
	v2[nv2]= na2;

	offsetA= 0;
	for(trozo=0; trozo<nTrozos; trozo++){
		offsetV= trozo*tam;
		mem_size_trozo_A= aristas[trozo]*sizeof(unsigned int);

		//leer trozo
		if(trozo<10) sprintf_s(s,"./temp/trozo0%d.gr", trozo);
		else sprintf_s(s,"./temp/trozo%d.gr", trozo);
		leerTrozo(s, mem_size_trozo_V, mem_size_trozo_A, offsetV, offsetA, v2, a2, w2);

		offsetA= offsetA + aristas[trozo];

	}//for trozo

	free(aristas);


/*
#ifdef _DEBUG
		printf("\n\n\n");
		printf("nv2= %i\n", nv2);
		printf("na2= %i\n", na2);
		printf("mem_size_V2= %i\n", mem_size_V2);
		printf("mem_size_A2= %i\n", mem_size_A2);
		mostrarUI(v2,nv2+1,"v2");
		mostrarUI(a2,na2,"a2");
#endif //_DEBUG
*/

}
//Invertir todos los grafos: v1, a1 y w1 se eliminan antes de construir v2, a2 y w2
void invertir_Grafos4(const unsigned int n_Megas, const unsigned int n_Grafos,
					  const unsigned int nTrozos, const unsigned int degree){

	//lISTA DE PRECDECESORES
    unsigned int* v1; //array de v�rtices host
    unsigned int nv1; //n�mero de v�rtices 
    unsigned int mem_size_V1; //memoria del array con tapon

    unsigned int* a1; //array de aristas host
    unsigned int na1; //n�mero de aristas
    unsigned int mem_size_A1; //memoria del array

    unsigned int* w1; //array de pesos host

    //lISTA DE SUCESORES
    unsigned int* v2; //array de v�rtices host
    unsigned int nv2; //n�mero de v�rtices 
    unsigned int mem_size_V2; //memoria del array con tapon

    unsigned int* a2; //array de aristas host
    unsigned int na2; //n�mero de aristas
    unsigned int mem_size_A2; //memoria del array

    unsigned int* w2; //array de pesos host

    char s1[100];
    char s2[100];
    
    //DEPURACION
    printf("Invirtiendo los grafos\n\n");

	for(unsigned int m=12; m<=n_Megas; m++){

		printf("\n\nMegas= %d\n\n", m);
		printf("Grafo\t Lectura\t Inversion\t Escritura\n\n");
		for(unsigned int i =2; i<=n_Grafos; i++){

			printf("%i\t", i);
			if(i<10) sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s1,"E:/Chus/DATA/GRAFOS/%d/grafo%d.gr", m, i);

			if(i<10) sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s2,"E:/Chus/DATA/GRAFOS INVERTIDOS/%d/grafo%d.gr", m, i);


            unsigned int  timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

			//Leer grafo
			leeGrafo_FicheroB(s1, nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1);
			nv1= nv1-1; //descontar el tapon


    	    CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
/*
			#ifdef _DEBUG
					printf("nv1= %i\n", nv1);
					printf("na1= %i\n", na1);
					printf("mem_size_V1= %i\n", mem_size_V1);
					printf("mem_size_A1= %i\n", mem_size_A1);
					mostrarUI(v1,nv1+1,"v1");
					mostrarUI(a1,na1,"a1");
			#endif //_DEBUG
*/

			//Invertir grafo: OJO v1, a1 y w1 se destruyen!
			invertir_Grafo4( nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1, nTrozos, degree,
							 nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2);


			CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


			timer = 0;
			CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
	
	        guardaGrafo_FicheroB(s2, nv2+1, na2, mem_size_V2, mem_size_A2, v2, a2, w2);

	        CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\n", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));


	        printf( "%\n");

			// cleanup memory
			free( v2);
			free( a2);
			free( w2);

		}//for i

	}//for m

}

//Imprimir degrees de un grafo//Imprimir degrees de un grafo
void imprimir_Degrees( const unsigned int nv, const unsigned int* v){
	int maximo= v[1]-v[0];
	unsigned int i_max= 0;
	int minimo= v[1]-v[0];
	unsigned int i_min= 0;

	int d;
	for(unsigned int i=1; i<nv; i++){ 
		d= v[i+1]-v[i];
		//printf("%d\t", d);
		if(maximo<d){
			maximo= d;
			i_max= i;
		}
		if(minimo>d){
			minimo= d;
			i_min= i;
		}
	}
	//printf("\n\n");
	//printf("Minimo= %d\t\tMaximo= %d\n\n", minimo, maximo);
	printf("%d\t%d\t%d\t%d\t%d\t%d", minimo, i_min, v[i_min], maximo, i_max, v[i_max]);

}

//Imprimir degrees de todos los grafos
void imprimir_Degrees_Grafos( const unsigned int n_Megas, const unsigned int n_Grafos){
    //lISTA DE ADYACENTES
    unsigned int* v; //array de v�rtices host
    unsigned int nv; //n�mero de v�rtices 
    unsigned int mem_size_V; //memoria del array con tapon

    unsigned int* a; //array de aristas host
    unsigned int na; //n�mero de aristas
    unsigned int mem_size_A; //memoria del array

    unsigned int* w; //array de pesos host


    char s[100];
    
    //DEPURACION
    printf("DEGREE DE LOS GRAFOS INVERTIDOS\n\n");


	for(unsigned int m=1; m<=n_Megas; m++){

		printf("\n\nMegas= %d\n\n", m);
		printf("Grafo\tMinimo\ti_min\v[ti_min]\tMaximo\ti_max\tv[ti_max]\n");

		for(unsigned int i=1; i<=n_Grafos; i++){
			printf("%i\t",i);

			if(i<10) sprintf_s(s,"E:/chus/DATA/GRAFOS INVERTIDOS/%d/grafo0%d.gr", m, i);
			else sprintf_s(s,"E:/chus/DATA/GRAFOS INVERTIDOS/%d/grafo%d.gr", m, i);


			//Leer grafo
			leeGrafo_FicheroB(s, nv, na, mem_size_V, mem_size_A, v, a, w);
			nv= nv-1; //descontar el tapon
			mostrarUI(v,nv+1,"v");

			//Imprimir degrees
			imprimir_Degrees( nv, v);

		    printf("\n");

			// cleanup memory
			free( v);
			free( a);
			free( w);

		}//for i

	}//for m

}

//Test para probar operaciones sobre grafos
void test_Grafos(const unsigned int nv, const unsigned int degree, const unsigned int topeW){
	unsigned int* v1; //array de v�rtices host
    unsigned int nv1= nv;
	unsigned int mem_size_V1; //memoria del array con tapon

    unsigned int* a1; //array de aristas host
    unsigned int na1; //n�mero de aristas
    unsigned int mem_size_A1; //memoria del array

    unsigned int* w1; //array de pesos host
/*
	unsigned int* v2; //array de v�rtices host
    unsigned int nv2;
    unsigned int mem_size_V2; //memoria del array con tapon

    unsigned int* a2; //array de aristas host
    unsigned int na2; //n�mero de aristas
    unsigned int mem_size_A2; //memoria del array

    unsigned int* w2; //array de pesos host

	unsigned int* v3; //array de v�rtices host
    unsigned int nv3;
    unsigned int mem_size_V3; //memoria del array con tapon

    unsigned int* a3; //array de aristas host
    unsigned int na3; //n�mero de aristas
    unsigned int mem_size_A3; //memoria del array

    unsigned int* w3; //array de pesos host
	
	unsigned int* v4; //array de v�rtices host
    unsigned int nv4;
    unsigned int mem_size_V4; //memoria del array con tapon

    unsigned int* a4; //array de aristas host
    unsigned int na4; //n�mero de aristas
    unsigned int mem_size_A4; //memoria del array

    unsigned int* w4; //array de pesos host


	unsigned int* v5; //array de v�rtices host
    unsigned int nv5;
    unsigned int mem_size_V5; //memoria del array con tapon

    unsigned int* a5; //array de aristas host
    unsigned int na5; //n�mero de aristas
    unsigned int mem_size_A5; //memoria del array

    unsigned int* w5; //array de pesos host

	unsigned int* reference1;
	unsigned int* reference2;
	unsigned int* reference3;
	unsigned int* reference4;
	unsigned int* reference5;
*/
	unsigned int infinito= nv*topeW;


    //DEPURACION
    printf("Generando Grafo\n\n");

    generaGrafo( nv1, degree, topeW, mem_size_V1, na1, mem_size_A1, v1, a1, w1);
/*
    // compute reference solution
    reference1= (unsigned int*) malloc( nv1* sizeof(unsigned int)); 
    computeGold_SSSP3( reference1, nv1, v1, na1, a1, w1, infinito);

	printf("\n\n");

    //guardaGrafo_FicheroB(s, nv+1, na, mem_size_V, mem_size_A, v, a, w);

    invertir_Grafo(nv1, na1, mem_size_V1, mem_size_A1, v1, a1, w1,
				   nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2);

    // compute reference solution
    reference2= (unsigned int*) malloc( nv2* sizeof(unsigned int)); 
    computeGold_SSSP8( reference2, nv2, v2, na2, a2, w2, infinito);


	printf("\n\n");


    invertir_Grafo( nv2, na2, mem_size_V2, mem_size_A2, v2, a2, w2,
	                nv3, na3, mem_size_V3, mem_size_A3, v3, a3, w3);

	// compute reference solution
    reference3= (unsigned int*) malloc( nv3* sizeof(unsigned int)); 
    computeGold_SSSP3( reference3, nv3, v3, na3, a3, w3, infinito);

	printf("\n\n");


    invertir_Grafo( nv3, na3, mem_size_V3, mem_size_A3, v3, a3, w3,
			        nv4, na4, mem_size_V4, mem_size_A4, v4, a4, w4);

	// compute reference solution
    reference4= (unsigned int*) malloc( nv4* sizeof(unsigned int)); 
    computeGold_SSSP8( reference4, nv4, v4, na4, a4, w4, infinito);

	printf("\n\n");

	invertir_Grafo( nv4, na4, mem_size_V4, mem_size_A4, v4, a4, w4,
					nv5, na5, mem_size_V5, mem_size_A5, v5, a5, w5);

	// compute reference solution
    reference5= (unsigned int*) malloc( nv5* sizeof(unsigned int)); 
    computeGold_SSSP3( reference5, nv5, v5, na5, a5, w5, infinito);

	printf("\n\n");

    printf("Minimo\ti_min\tv[ti_min]\tMaximo\ti_max\tv[ti_max]\n");
	imprimir_Degrees( nv1, v1);
	printf("\n");
	imprimir_Degrees( nv2, v2);
	printf("\n");
	imprimir_Degrees( nv3, v3);
	printf("\n");
	imprimir_Degrees( nv4, v4);
	printf("\n");
	imprimir_Degrees( nv5, v5);

	printf("\n\n");

	//comprobando invesi�n
    CUTBoolean res = cutComparei( (int*)reference1, (int*)reference2, nv);
    printf( "reference1 vs reference2 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)reference2, (int*)reference3, nv);
    printf( "reference2 vs reference3 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)reference3, (int*)reference4, nv);
    printf( "reference3 vs reference4 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)reference4, (int*)reference5, nv);
    printf( "reference4 vs reference5 %s\n", (1 == res) ? "OK" : "FAILED");

	printf("\n\n");
    res = cutComparei( (int*)v2, (int*)v4, nv);
    printf( "v2 vs v4 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)a2, (int*)a4, nv);
    printf( "a2 vs a4 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)w2, (int*)w4, nv);
    printf( "w2 vs w4 %s\n", (1 == res) ? "OK" : "FAILED");

	printf("\n\n");
    res = cutComparei( (int*)v3, (int*)v5, nv);
    printf( "v3 vs v5 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)a3, (int*)a5, nv);
    printf( "a3 vs a5 %s\n", (1 == res) ? "OK" : "FAILED");
    res = cutComparei( (int*)w3, (int*)w5, nv);
    printf( "w3 vs w5 %s\n", (1 == res) ? "OK" : "FAILED");
*/

	// cleanup memory
    free( v1);
    free( a1);
    free( w1);

/*
	free( v2);
    free( a2);
    free( w2);


	free( v3);
    free( a3);
    free( w3);

    free( v4);
    free( a4);
    free( w4);

	free( v5);
    free( a5);
    free( w5);

	free(reference1);
	free(reference2);
	free(reference3);
	free(reference4);
	free(reference5);
*/
}

//Generaci�n de grafos
void generar_Grafos(const unsigned int n_Megas, const unsigned int n_Grafos,
					unsigned int degree, unsigned int topeW){


	unsigned int* v; //array de v�rtices host
    unsigned int nv; //n�mero de v�rtices 
    unsigned int mem_size_V; //memoria del array con tapon

    unsigned int* a; //array de aristas host
    unsigned int na; //n�mero de aristas
    unsigned int mem_size_A; //memoria del array

    unsigned int* w; //array de pesos host

    char s[100];

    unsigned int timer;

    //DEPURACION
    printf("Generando y Guardando Grafos\n\n");

    for(unsigned int m=9; m<=14; m++){

        printf("\n\nMegas= %d\n", m);
		nv= m*1024*1024;
        printf("Grafo\t Generar\t Salvar\n");
       	for(unsigned int i =1; i<=25; i++){

            printf("%i\t", i);
			if(i<10) sprintf_s(s,"E:/chus/DATA/GRAFOS/%d/grafo0%d.gr", m, i);
            else sprintf_s(s,"E:/chus/DATA/GRAFOS/%d/grafo%d.gr", m, i);


            //generar grafo
            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));

            generaGrafo( nv, degree, topeW, mem_size_V, na, mem_size_A, v, a, w);

    	    CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\t", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));
    	
            timer = 0;
            CUT_SAFE_CALL( cutCreateTimer( &timer));
            CUT_SAFE_CALL( cutStartTimer( timer));
	
	        guardaGrafo_FicheroB(s, nv+1, na, mem_size_V, mem_size_A, v, a, w);

	        CUT_SAFE_CALL( cutStopTimer( timer));
	        printf( "%f\n", cutGetTimerValue( timer));
            CUT_SAFE_CALL( cutDeleteTimer( timer));

            // cleanup memory
            free( v);
            free( a);
            free( w);

        }//for

    }//for

}


