// export C interface

extern "C" 
void genera_M_Adyacencia( const unsigned int nv, const unsigned int degree, 
						  const unsigned int topeW, const unsigned int infinito,
						  unsigned int& mem_size_M, unsigned int* &m);


extern "C" 
void guardaMatriz_FicheroB(const char* filename, const unsigned int nv, 
						   const unsigned int mem_size_M, const unsigned int* m);


extern "C" 
void leeMatriz_FicheroB(const char* filename, unsigned int& nv,
						unsigned int& mem_size_M, unsigned int*& m);

extern "C" 
unsigned int RangedRand( unsigned int range_min, unsigned int range_max);
