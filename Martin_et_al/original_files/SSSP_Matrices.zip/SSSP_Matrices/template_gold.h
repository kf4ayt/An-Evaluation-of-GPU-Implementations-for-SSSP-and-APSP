#ifndef _TEMPLATE_GOLD
#define _TEMPLATE_GOLD


void computeGold_CPU7( unsigned int* reference, 
					   const unsigned int nv, const unsigned int* m, 
   					   const unsigned int infinito);


void computeGold_CPU9( unsigned int* reference, 
					   const unsigned int nv, const unsigned int* m, 
   					   const unsigned int infinito);


#endif // #ifndef _TEMPLATE_GOLD