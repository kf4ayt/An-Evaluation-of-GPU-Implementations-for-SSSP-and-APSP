#ifdef _WIN32
#pragma warning(disable:4164 4003)
#endif 
#line 1 "template.cudafe1.gpu"
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef unsigned size_t;
#include "crt/host_runtime.h"
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
typedef long clock_t;
void *memcpy(void*, const void*, size_t); void *memset(void*, int, size_t);
#line 47 "template.cu"
__loc_sc__(__text__,) __i1texture textura_m;
#line 51 "template.cu"
__loc_sc__(__text__,) __i1texture textura_p;
#line 52 "template.cu"
__loc_sc__(__text__,) __i1texture textura_f;
#include "template.cudafe2.stub.h"

#include "template.cudafe2.stub.c"
