#if defined(__cplusplus)
extern "C" {
#endif
#include "template.fatbin.c"
#include "crt/host_runtime.h"
struct __T20;
struct __T21;
struct __T22;
struct __T23;
struct __T24;
struct __T25;
struct __T26;
struct __T27;
struct __T20 {char *__par0;char *__par1;const unsigned *__par2;unsigned __par3;int __dummy_field;};
struct __T21 {const char *__par0;const unsigned *__par1;unsigned __par2;unsigned *__par3;int __dummy_field;};
struct __T22 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T23 {unsigned __par0;unsigned *__par1;int __dummy_field;};
struct __T24 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T25 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T26 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T27 {unsigned __par0;unsigned *__par1;int __dummy_field;};
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z7kernel3PbS_PKjj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z17kernel_minimizar1PKbPKjjPj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z15kernel1_SSSP7_TjPj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(char *);
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z16kernel1_SSSP7_RTjPj(char *);
#endif
static void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void);
#pragma section(".CRT$XCU",read,write)
__declspec(allocate(".CRT$XCU"))static void (__cdecl *__dummy_static_init__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973[])(void) = {__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973};
void __device_stub___globfunc__Z7kernel3PbS_PKjj(bool *__par0, bool *__par1, const unsigned *__par2, const unsigned __par3){auto struct __T20 __T28;
__cudaSetupArg(__par0, __T28);__cudaSetupArg(__par1, __T28);__cudaSetupArg(__par2, __T28);__cudaSetupArg(__par3, __T28);__cudaLaunch(((char *)__device_stub___globfunc__Z7kernel3PbS_PKjj));}
void __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(const bool *__par0, const unsigned *__par1, const unsigned __par2, unsigned *__par3){auto struct __T21 __T29;
__cudaSetupArg(__par0, __T29);__cudaSetupArg(__par1, __T29);__cudaSetupArg(__par2, __T29);__cudaSetupArg(__par3, __T29);__cudaLaunch(((char *)__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj));}
void __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T22 __T210;
__cudaSetupArg(__par0, __T210);__cudaSetupArg(__par1, __T210);__cudaSetupArg(__par2, __T210);__cudaSetupArg(__par3, __T210);__cudaSetupArg(__par4, __T210);__cudaLaunch(((char *)__device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj));}
void __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(const unsigned __par0, unsigned *__par1){auto struct __T23 __T211;
__cudaSetupArg(__par0, __T211);__cudaSetupArg(__par1, __T211);__cudaLaunch(((char *)__device_stub___globfunc__Z15kernel1_SSSP7_TjPj));}
void __device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T24 __T212;
__cudaSetupArg(__par0, __T212);__cudaSetupArg(__par1, __T212);__cudaSetupArg(__par2, __T212);__cudaSetupArg(__par3, __T212);__cudaSetupArg(__par4, __T212);__cudaLaunch(((char *)__device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj));}
void __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T25 __T213;
__cudaSetupArg(__par0, __T213);__cudaSetupArg(__par1, __T213);__cudaSetupArg(__par2, __T213);__cudaSetupArg(__par3, __T213);__cudaSetupArg(__par4, __T213);__cudaLaunch(((char *)__device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj));}
void __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T26 __T214;
__cudaSetupArg(__par0, __T214);__cudaSetupArg(__par1, __T214);__cudaSetupArg(__par2, __T214);__cudaSetupArg(__par3, __T214);__cudaSetupArg(__par4, __T214);__cudaLaunch(((char *)__device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj));}
void __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(const unsigned __par0, unsigned *__par1){auto struct __T27 __T215;
__cudaSetupArg(__par0, __T215);__cudaSetupArg(__par1, __T215);__cudaLaunch(((char *)__device_stub___globfunc__Z16kernel1_SSSP7_RTjPj));}
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z7kernel3PbS_PKjj(char *__T221){__globfunc__Z7kernel3PbS_PKjj((((*((struct __T20 *)__T221)).__par0)), (((*((struct __T20 *)__T221)).__par1)), (((*((struct __T20 *)__T221)).__par2)), (((*((struct __T20 *)__T221)).__par3)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z17kernel_minimizar1PKbPKjjPj(char *__T224){__globfunc__Z17kernel_minimizar1PKbPKjjPj((((*((struct __T21 *)__T224)).__par0)), (((*((struct __T21 *)__T224)).__par1)), (((*((struct __T21 *)__T224)).__par2)), (((*((struct __T21 *)__T224)).__par3)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(char *__T226){__globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj((((*((struct __T22 *)__T226)).__par0)), (((*((struct __T22 *)__T226)).__par1)), (((*((struct __T22 *)__T226)).__par2)), (((*((struct __T22 *)__T226)).__par3)), (((*((struct __T22 *)__T226)).__par4)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z15kernel1_SSSP7_TjPj(char *__T247){__globfunc__Z15kernel1_SSSP7_TjPj((((*((struct __T23 *)__T247)).__par0)), (((*((struct __T23 *)__T247)).__par1)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(char *__T249){__globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj((((*((struct __T24 *)__T249)).__par0)), (((*((struct __T24 *)__T249)).__par1)), (((*((struct __T24 *)__T249)).__par2)), (((*((struct __T24 *)__T249)).__par3)), (((*((struct __T24 *)__T249)).__par4)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(char *__T252){__globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj((((*((struct __T25 *)__T252)).__par0)), (((*((struct __T25 *)__T252)).__par1)), (((*((struct __T25 *)__T252)).__par2)), (((*((struct __T25 *)__T252)).__par3)), (((*((struct __T25 *)__T252)).__par4)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(char *__T253){__globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj((((*((struct __T26 *)__T253)).__par0)), (((*((struct __T26 *)__T253)).__par1)), (((*((struct __T26 *)__T253)).__par2)), (((*((struct __T26 *)__T253)).__par3)), (((*((struct __T26 *)__T253)).__par4)));}
#endif
#if defined(__device_emulation)
static void __device_wrapper___globfunc__Z16kernel1_SSSP7_RTjPj(char *__T274){__globfunc__Z16kernel1_SSSP7_RTjPj((((*((struct __T27 *)__T274)).__par0)), (((*((struct __T27 *)__T274)).__par1)));}
#endif
static void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void){__cudaRegisterBinary();__cudaRegisterEntry(__globfunc__Z16kernel1_SSSP7_RTjPj, (-1));__cudaRegisterEntry(__globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj, (-1));__cudaRegisterEntry(__globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj, (-1));__cudaRegisterEntry(__globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj, (-1));__cudaRegisterEntry(__globfunc__Z15kernel1_SSSP7_TjPj, (-1));__cudaRegisterEntry(__globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj, (-1));__cudaRegisterEntry(__globfunc__Z17kernel_minimizar1PKbPKjjPj, (-1));__cudaRegisterEntry(__globfunc__Z7kernel3PbS_PKjj, (-1));__cudaRegisterGlobalTexture(textura_m, 1, 0, 0);__cudaRegisterGlobalTexture(textura_p, 1, 0, 0);__cudaRegisterGlobalTexture(textura_f, 1, 0, 0);__cudaRegisterUnsizedShared(sdata);__cudaRegisterUnsizedShared(sdata1);__cudaRegisterUnsizedShared(sdataP);}
#if defined(__cplusplus)
}
#endif
