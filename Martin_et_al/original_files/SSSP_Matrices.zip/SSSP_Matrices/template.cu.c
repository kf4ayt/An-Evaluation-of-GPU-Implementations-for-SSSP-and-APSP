#line 1 "template.cudafe1.c"

#pragma warning(disable:4164 4003)
#line 4 "template.cudafe1.c"
#line 1 "template.cu"
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(push)
#pragma warning(disable:4996)
#line 60 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(pop)
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable:4141)
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 815 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable: 4141)
#line 825 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\use_ansi.h"
#pragma comment(lib,"libcpmt")
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)

#pragma warning(push)
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)
#line 337 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)


#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)


#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4141 4996 4793)


#pragma warning(pop)
#line 34 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
#line 45 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4412 )




#pragma warning( pop )
#line 58 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
#line 69 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4412 )




#pragma warning( pop )


#pragma warning( push )
#pragma warning( disable : 4996 )

#pragma warning( push )
#pragma warning( disable : 4793 4141 )
#line 93 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4141 )




#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4793 4141 )
#line 113 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4141 )




#pragma warning( pop )

#pragma warning( pop )
#line 140 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
#pragma warning(push)
#pragma warning(disable:4609 6059)


#pragma warning(pop)
#line 37 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
#pragma warning( disable : 4996 )
#line 525 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma warning(push)
#pragma warning(disable:4412)
#line 761 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma warning(pop)
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li2EL19cudaTextureReadMode1EE;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode1EE;
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
struct _iobuf;
#line 65 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
enum CUTBoolean {

CUTFalse,
CUTTrue};
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef unsigned size_t;
#line 1 "C:\\CUDA\\include\\crt/host_runtime.h"























































typedef char bool;

#line 59 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 1 "C:\\CUDA\\include\\cuda_runtime_api.h"















































#line 1 "c:\\cuda\\include\\host_defines.h"










































#line 44 "c:\\cuda\\include\\host_defines.h"















#line 60 "c:\\cuda\\include\\host_defines.h"


















#line 79 "c:\\cuda\\include\\host_defines.h"








#line 88 "c:\\cuda\\include\\host_defines.h"




#line 93 "c:\\cuda\\include\\host_defines.h"














#line 108 "c:\\cuda\\include\\host_defines.h"
#line 49 "C:\\CUDA\\include\\cuda_runtime_api.h"
#line 1 "c:\\cuda\\include\\builtin_types.h"









































#line 1 "c:\\cuda\\include\\device_types.h"













































enum cudaRoundMode
{
  cudaRoundNearest,
  cudaRoundZero,
  cudaRoundPosInf,
  cudaRoundMinInf
};

#line 55 "c:\\cuda\\include\\device_types.h"
#line 43 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\driver_types.h"

















































#line 52 "c:\\cuda\\include\\driver_types.h"








enum cudaError
{
  cudaSuccess = 0,
  cudaErrorMissingConfiguration,
  cudaErrorMemoryAllocation,
  cudaErrorInitializationError,
  cudaErrorLaunchFailure,
  cudaErrorPriorLaunchFailure,
  cudaErrorLaunchTimeout,
  cudaErrorLaunchOutOfResources,
  cudaErrorInvalidDeviceFunction,
  cudaErrorInvalidConfiguration,
  cudaErrorInvalidDevice,
  cudaErrorInvalidValue,
  cudaErrorInvalidPitchValue,
  cudaErrorInvalidSymbol,
  cudaErrorMapBufferObjectFailed,
  cudaErrorUnmapBufferObjectFailed,
  cudaErrorInvalidHostPointer,
  cudaErrorInvalidDevicePointer,
  cudaErrorInvalidTexture,
  cudaErrorInvalidTextureBinding,
  cudaErrorInvalidChannelDescriptor,
  cudaErrorInvalidMemcpyDirection,
  cudaErrorAddressOfConstant,
  cudaErrorTextureFetchFailed,
  cudaErrorTextureNotBound,
  cudaErrorSynchronizationError,
  cudaErrorInvalidFilterSetting,
  cudaErrorInvalidNormSetting,
  cudaErrorMixedDeviceExecution,
  cudaErrorCudartUnloading,
  cudaErrorUnknown,
  cudaErrorNotYetImplemented,
  cudaErrorMemoryValueTooLarge,
  cudaErrorInvalidResourceHandle,
  cudaErrorNotReady,
  cudaErrorStartupFailure = 0x7f,
  cudaErrorApiFailureBase = 10000
};


enum cudaMemcpyKind
{
  cudaMemcpyHostToHost = 0,
  cudaMemcpyHostToDevice,
  cudaMemcpyDeviceToHost,
  cudaMemcpyDeviceToDevice
};


struct cudaDeviceProp
{
  char   name[256];
  size_t totalGlobalMem;
  size_t sharedMemPerBlock;
  int    regsPerBlock;
  int    warpSize;
  size_t memPitch;
  int    maxThreadsPerBlock;
  int    maxThreadsDim[3];
  int    maxGridSize[3]; 
  size_t totalConstMem; 
  int    major;
  int    minor;
  int    clockRate;
  size_t textureAlignment;
};


























typedef enum cudaError cudaError_t;


typedef int cudaStream_t;


typedef int cudaEvent_t;

#line 163 "c:\\cuda\\include\\driver_types.h"
#line 44 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\texture_types.h"













































struct cudaArray;


enum cudaChannelFormatKind
{
  cudaChannelFormatKindSigned,
  cudaChannelFormatKindUnsigned,
  cudaChannelFormatKindFloat
};


struct cudaChannelFormatDesc
{
  int                        x;
  int                        y;
  int                        z;
  int                        w;
  enum cudaChannelFormatKind f;
};


enum cudaTextureAddressMode
{
  cudaAddressModeWrap,
  cudaAddressModeClamp
};


enum cudaTextureFilterMode
{
  cudaFilterModePoint,
  cudaFilterModeLinear
};


enum cudaTextureReadMode
{
  cudaReadModeElementType,
  cudaReadModeNormalizedFloat
};


struct textureReference
{
  int                           normalized;
  enum cudaTextureFilterMode    filterMode;
  enum cudaTextureAddressMode   addressMode[2];
  struct cudaChannelFormatDesc  channelDesc;
};














































#line 142 "c:\\cuda\\include\\texture_types.h"

#line 144 "c:\\cuda\\include\\texture_types.h"
#line 45 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\vector_types.h"












































#line 1 "c:\\cuda\\include\\host_defines.h"










































































































#line 108 "c:\\cuda\\include\\host_defines.h"
#line 46 "c:\\cuda\\include\\vector_types.h"








struct char1
{
  signed char x;
};


struct uchar1 
{
  unsigned char x;
};


struct  char2
{
  signed char x, y;
};


struct  uchar2
{
  unsigned char x, y;
};


struct char3
{
  signed char x, y, z;
};


struct uchar3
{
  unsigned char x, y, z;
};


struct  char4
{
  signed char x, y, z, w;
};


struct  uchar4
{
  unsigned char x, y, z, w;
};


struct short1
{
  short x;
};


struct ushort1
{
  unsigned short x;
};


struct  short2
{
  short x, y;
};


struct  ushort2
{
  unsigned short x, y;
};


struct short3
{
  short x, y, z;
};


struct ushort3
{
  unsigned short x, y, z;
};


struct  short4
{
  short x, y, z, w;
};


struct  ushort4
{
  unsigned short x, y, z, w;
};


struct int1
{
  int x;
};


struct uint1
{
  unsigned int x;
};


struct  int2
{
  int x, y;
};


struct  uint2
{
  unsigned int x, y;
};


struct int3
{
  int x, y, z;
};


struct uint3
{
  unsigned int x, y, z;
};


struct  int4
{
  int x, y, z, w;
};


struct  uint4
{
  unsigned int x, y, z, w;
};


struct long1
{
  long x;
};


struct ulong1
{
  unsigned long x;
};


struct  long2
{
  long x, y;
};


struct  ulong2
{
  unsigned long x, y;
};


struct long3
{
  long x, y, z;
};


struct ulong3
{
  unsigned long x, y, z;
};


struct  long4
{
  long x, y, z, w;
};


struct  ulong4
{
  unsigned long x, y, z, w;
};


struct float1
{
  float x;
};


struct  float2
{
  float x, y;
};


struct float3
{
  float x, y, z;
};


struct  float4
{
  float x, y, z, w;
};


struct  double2
{
  double x, y;
};








typedef struct char1 char1;

typedef struct uchar1 uchar1;

typedef struct char2 char2;

typedef struct uchar2 uchar2;

typedef struct char3 char3;

typedef struct uchar3 uchar3;

typedef struct char4 char4;

typedef struct uchar4 uchar4;

typedef struct short1 short1;

typedef struct ushort1 ushort1;

typedef struct short2 short2;

typedef struct ushort2 ushort2;

typedef struct short3 short3;

typedef struct ushort3 ushort3;

typedef struct short4 short4;

typedef struct ushort4 ushort4;

typedef struct int1 int1;

typedef struct uint1 uint1;

typedef struct int2 int2;

typedef struct uint2 uint2;

typedef struct int3 int3;

typedef struct uint3 uint3;

typedef struct int4 int4;

typedef struct uint4 uint4;

typedef struct long1 long1;

typedef struct ulong1 ulong1;

typedef struct long2 long2;

typedef struct ulong2 ulong2;

typedef struct long3 long3;

typedef struct ulong3 ulong3;

typedef struct long4 long4;

typedef struct ulong4 ulong4;

typedef struct float1 float1;

typedef struct float2 float2;

typedef struct float3 float3;

typedef struct float4 float4;

typedef struct double2 double2;








typedef struct dim3 dim3;


struct dim3
{
    unsigned int x, y, z;




#line 374 "c:\\cuda\\include\\vector_types.h"
};

#line 377 "c:\\cuda\\include\\vector_types.h"
#line 46 "c:\\cuda\\include\\builtin_types.h"
#line 50 "C:\\CUDA\\include\\cuda_runtime_api.h"














#line 65 "C:\\CUDA\\include\\cuda_runtime_api.h"









#line 75 "C:\\CUDA\\include\\cuda_runtime_api.h"







extern  cudaError_t __stdcall cudaMalloc(void **devPtr, size_t size);
extern  cudaError_t __stdcall cudaMallocHost(void **ptr, size_t size);
extern  cudaError_t __stdcall cudaMallocPitch(void **devPtr, size_t *pitch, size_t width, size_t height);
extern  cudaError_t __stdcall cudaMallocArray(struct cudaArray **array, const struct cudaChannelFormatDesc *desc, size_t width, size_t height );
extern  cudaError_t __stdcall cudaFree(void *devPtr);
extern  cudaError_t __stdcall cudaFreeHost(void *ptr);
extern  cudaError_t __stdcall cudaFreeArray(struct cudaArray *array);








extern  cudaError_t __stdcall cudaMemcpy(void *dst, const void *src, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyToArray(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyFromArray(void *dst, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyArrayToArray(struct cudaArray *dst, size_t wOffsetDst, size_t hOffsetDst, const struct cudaArray *src, size_t wOffsetSrc, size_t hOffsetSrc, size_t count, enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpy2D(void *dst, size_t dpitch, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DToArray(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DFromArray(void *dst, size_t dpitch, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DArrayToArray(struct cudaArray *dst, size_t wOffsetDst, size_t hOffsetDst, const struct cudaArray *src, size_t wOffsetSrc, size_t hOffsetSrc, size_t width, size_t height, enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpyToSymbol(const char *symbol, const void *src, size_t count, size_t offset , enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpyFromSymbol(void *dst, const char *symbol, size_t count, size_t offset , enum cudaMemcpyKind kind );







extern  cudaError_t __stdcall cudaMemcpyAsync(void *dst, const void *src, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyToArrayAsync(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyFromArrayAsync(void *dst, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DAsync(void *dst, size_t dpitch, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DToArrayAsync(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DFromArrayAsync(void *dst, size_t dpitch, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);







extern  cudaError_t __stdcall cudaMemset(void *mem, int c, size_t count);
extern  cudaError_t __stdcall cudaMemset2D(void *mem, size_t pitch, int c, size_t width, size_t height);







extern  cudaError_t __stdcall cudaGetSymbolAddress(void **devPtr, const char *symbol);
extern  cudaError_t __stdcall cudaGetSymbolSize(size_t *size, const char *symbol);







extern  cudaError_t __stdcall cudaGetDeviceCount(int *count);
extern  cudaError_t __stdcall cudaGetDeviceProperties(struct cudaDeviceProp *prop, int device);
extern  cudaError_t __stdcall cudaChooseDevice(int *device, const struct cudaDeviceProp *prop);
extern  cudaError_t __stdcall cudaSetDevice(int device);
extern  cudaError_t __stdcall cudaGetDevice(int *device);







extern  cudaError_t __stdcall cudaBindTexture(size_t *offset, const struct textureReference *texref, const void *devPtr, const struct cudaChannelFormatDesc *desc, size_t size );
extern  cudaError_t __stdcall cudaBindTextureToArray(const struct textureReference *texref, const struct cudaArray *array, const struct cudaChannelFormatDesc *desc);
extern  cudaError_t __stdcall cudaUnbindTexture(const struct textureReference *texref);
extern  cudaError_t __stdcall cudaGetTextureAlignmentOffset(size_t *offset, const struct textureReference *texref);
extern  cudaError_t __stdcall cudaGetTextureReference(const struct textureReference **texref, const char *symbol);







extern  cudaError_t __stdcall cudaGetChannelDesc(struct cudaChannelFormatDesc *desc, const struct cudaArray *array);
extern  struct cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int x, int y, int z, int w, enum cudaChannelFormatKind f);







extern  cudaError_t __stdcall cudaGetLastError(void);
extern  const char* __stdcall cudaGetErrorString(cudaError_t error);







extern  cudaError_t __stdcall cudaConfigureCall(dim3 gridDim, dim3 blockDim, size_t sharedMem , cudaStream_t stream );
extern  cudaError_t __stdcall cudaSetupArgument(const void *arg, size_t size, size_t offset);
extern  cudaError_t __stdcall cudaLaunch(const char *symbol);







extern  cudaError_t __stdcall cudaStreamCreate(cudaStream_t *stream);
extern  cudaError_t __stdcall cudaStreamDestroy(cudaStream_t stream);
extern  cudaError_t __stdcall cudaStreamSynchronize(cudaStream_t stream);
extern  cudaError_t __stdcall cudaStreamQuery(cudaStream_t stream);







extern  cudaError_t __stdcall cudaEventCreate(cudaEvent_t *event);
extern  cudaError_t __stdcall cudaEventRecord(cudaEvent_t event, cudaStream_t stream);
extern  cudaError_t __stdcall cudaEventQuery(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventSynchronize(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventDestroy(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventElapsedTime(float *ms, cudaEvent_t start, cudaEvent_t end);







extern  cudaError_t __stdcall cudaThreadExit(void);
extern  cudaError_t __stdcall cudaThreadSynchronize(void);



#line 227 "C:\\CUDA\\include\\cuda_runtime_api.h"



#line 231 "C:\\CUDA\\include\\cuda_runtime_api.h"
#line 61 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 1 "c:\\cuda\\include\\crt\\storage_class.h"










































































#line 76 "c:\\cuda\\include\\crt\\storage_class.h"
#line 62 "C:\\CUDA\\include\\crt/host_runtime.h"























































































































































#line 214 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 434 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
typedef char *va_list;
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef __int64 __time64_t;
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef __time64_t time_t;
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
typedef long clock_t;
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong3Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#line 115 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#pragma pack(8)
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
struct _iobuf {
char *_ptr;
int _cnt;
char *_base;
int _flag;
int _file;
int _charbuf;
int _bufsiz;
char *_tmpfname;};
#pragma pack()
typedef struct _iobuf FILE;
void *memcpy(void*, const void*, size_t); void *memset(void*, int, size_t);
#line 82 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaMalloc(void **, size_t);



extern cudaError_t __stdcall cudaFree(void *);
#line 97 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaMemcpy(void *, const void *, size_t, enum cudaMemcpyKind);
#line 145 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaGetDeviceCount(int *);
extern cudaError_t __stdcall cudaGetDeviceProperties(struct cudaDeviceProp *, int);

extern cudaError_t __stdcall cudaSetDevice(int);
#line 157 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaBindTexture(size_t *, const struct textureReference *, const void *, const struct cudaChannelFormatDesc *, size_t);

extern cudaError_t __stdcall cudaUnbindTexture(const struct textureReference *);
#line 170 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern struct cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int, int, int, int, enum cudaChannelFormatKind);
#line 178 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaGetLastError(void);
extern const char *__stdcall cudaGetErrorString(cudaError_t);
#line 187 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaConfigureCall(dim3, dim3, size_t, cudaStream_t);
#line 222 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaThreadSynchronize(void);
#line 176 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern clock_t __cdecl clock(void);
#line 220 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern __time64_t __cdecl _time64(__time64_t *);
#line 58 "c:\\cuda\\include\\common_functions.h"
extern void *__cdecl memset(void *, int, size_t);
#line 65 "c:\\cuda\\include\\math_functions.h"
extern int __cdecl abs(int);

extern long __cdecl labs(long);

extern __int64 llabs(__int64);

extern double __cdecl fabs(double);




extern int min(int, int);

extern unsigned umin(unsigned, unsigned);

extern float fminf(float, float);

extern double fmin(double, double);


extern int max(int, int);

extern unsigned umax(unsigned, unsigned);

extern float fmaxf(float, float);

extern double fmax(double, double);


extern double __cdecl sin(double);




extern double __cdecl cos(double);




extern void sincos(double, double *, double *);

extern void sincosf(float, float *, float *);


extern double __cdecl tan(double);




extern double __cdecl sqrt(double);




extern double rsqrt(double);

extern float rsqrtf(float);


extern double exp2(double);

extern float exp2f(float);


extern double exp10(double);

extern float exp10f(float);


extern double expm1(double);

extern float expm1f(float);


extern double log2(double);

extern float log2f(float);


extern double __cdecl log10(double);




extern double __cdecl log(double);




extern double log1p(double);

extern float log1pf(float);


extern double __cdecl floor(double);




extern double __cdecl exp(double);




extern double __cdecl cosh(double);




extern double __cdecl sinh(double);




extern double __cdecl tanh(double);




extern double acosh(double);

extern float acoshf(float);


extern double asinh(double);

extern float asinhf(float);


extern double atanh(double);

extern float atanhf(float);


extern double __cdecl ldexp(double, int);




extern double logb(double);

extern float logbf(float);


extern int ilogb(double);

extern int ilogbf(float);


extern double scalbn(double, int);

extern float scalbnf(float, int);


extern double scalbln(double, long);

extern float scalblnf(float, long);


extern double __cdecl frexp(double, int *);




extern double round(double);

extern float roundf(float);


extern long lround(double);

extern long lroundf(float);


extern __int64 llround(double);

extern __int64 llroundf(float);


extern double rint(double);

extern float rintf(float);


extern long lrint(double);

extern long lrintf(float);


extern __int64 llrint(double);

extern __int64 llrintf(float);


extern double nearbyint(double);

extern float nearbyintf(float);


extern double __cdecl ceil(double);




extern double trunc(double);

extern float truncf(float);


extern double fdim(double, double);

extern float fdimf(float, float);


extern double __cdecl atan2(double, double);




extern double __cdecl atan(double);




extern double __cdecl asin(double);




extern double __cdecl acos(double);




extern double __cdecl hypot(double, double);

extern float hypotf(float, float);


extern double cbrt(double);

extern float cbrtf(float);


extern double __cdecl pow(double, double);




extern double __cdecl modf(double, double *);




extern double __cdecl fmod(double, double);




extern double remainder(double, double);

extern float remainderf(float, float);


extern double remquo(double, double, int *);

extern float remquof(float, float, int *);


extern double erf(double);

extern float erff(float);


extern double erfc(double);

extern float erfcf(float);


extern double lgamma(double);

extern float lgammaf(float);


extern double tgamma(double);

extern float tgammaf(float);


extern double copysign(double, double);

extern float copysignf(float, float);


extern double nextafter(double, double);

extern float nextafterf(float, float);


extern double nan(const char *);

extern float nanf(const char *);


extern int __signbit(double);

extern int __signbitf(float);


extern int __isinf(double);

extern int __isinff(float);


extern int __isnan(double);

extern int __isnanf(float);


extern int __finite(double);

extern int __finitef(float);


extern double fma(double, double, double);

extern float fmaf(float, float, float);
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern   float frexpf(float, int *);



extern   float fabsf(float);

extern   float ldexpf(float, int);


extern   float acosf(float);

extern   float asinf(float);

extern   float atanf(float);

extern   float atan2f(float, float);

extern   float ceilf(float);

extern   float cosf(float);

extern   float coshf(float);

extern   float expf(float);

extern   float floorf(float);

extern   float fmodf(float, float);

extern   float logf(float);

extern   float log10f(float);

extern   float modff(float, float *);



extern   float powf(float, float);

extern   float sinf(float);

extern   float sinhf(float);

extern   float sqrtf(float);

extern   float tanf(float);

extern   float tanhf(float);
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern __declspec( noreturn ) void __cdecl exit(int);
#line 540 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern void __cdecl srand(unsigned);
#line 593 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern __declspec( noalias ) void __cdecl free(void *);
extern __declspec( restrict noalias ) void *__cdecl malloc(size_t);
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern FILE *__cdecl __iob_func(void);
#line 210 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl fflush(FILE *);
#line 238 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl fprintf(FILE *, const char *, ...);
#line 264 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl getchar(void);
#line 278 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl printf(const char *, ...);
#line 341 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl vsprintf_s(char *, size_t, const char *, va_list);
#line 462 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutCheckCmdLineFlag(const int, const char **, const char *);
#line 558 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutComparei(const int *, const int *, const unsigned);
#line 613 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutCreateTimer(unsigned *);
#line 622 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutDeleteTimer(unsigned);
#line 630 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutStartTimer(const unsigned);
#line 638 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutStopTimer(const unsigned);
#line 655 "c:\\Archivos de programa\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) float __stdcall cutGetTimerValue(const unsigned);
#line 8 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
extern void _Z8mostrarBPKbjPKc(const bool *, const unsigned, const char *);
#line 15 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
extern void _Z8mostrarIPKijPKc(const int *, const unsigned, const char *);
#line 22 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
extern void _Z9mostrarUIPKjjPKc(const unsigned *, const unsigned, const char *);
#line 31 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
extern unsigned _Z6minimojj(const unsigned, const unsigned);





extern void _Z22mostrarUI_M_AdyacenciaPKjjPKc(const unsigned *, const unsigned, const char *);
#line 13 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z9copiarH2DPvPKvj(void *, const void *, const unsigned);




extern void _Z9copiarD2HPvPKvj(void *, const void *, const unsigned);




extern void _Z25inicializar_Matriz_DevicePKjjRPj(const unsigned *, const unsigned, unsigned **);
#line 31 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z15inicializar_SolRPjS0_jjj(unsigned **, unsigned **, const unsigned, const unsigned, const unsigned);
#line 51 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z22inicializar_PendientesRPbS0_jj(bool **, bool **, const unsigned, const unsigned);
#line 70 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z20inicializar_FronteraRPbS0_jj(bool **, bool **, const unsigned, const unsigned);
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
extern bool _Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, bool *, bool *, unsigned *, unsigned *, const unsigned *, bool *, bool *, unsigned *, unsigned *);
#line 131 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
extern void _Z15testGraph_SSSP7jjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 19 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
extern bool _Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, bool *, bool *, unsigned *, unsigned *, const unsigned *, bool *, bool *, unsigned *, unsigned *);
#line 133 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
extern void _Z17testGraph_SSSP7_TjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 239 "C:\\CUDA\\include\\cuda_runtime.h"
extern   __inline cudaError_t _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(size_t *, const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *, const void *, size_t);
#line 239 "C:\\CUDA\\include\\cuda_runtime.h"
extern   __inline cudaError_t _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(size_t *, const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *, const void *, size_t);
#line 278 "C:\\CUDA\\include\\cuda_runtime.h"
extern   __inline cudaError_t _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *);
#line 278 "C:\\CUDA\\include\\cuda_runtime.h"
extern   __inline cudaError_t _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *);
#line 19 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
extern bool _Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, bool *, bool *, unsigned *, unsigned *, const unsigned *, bool *, bool *, unsigned *, unsigned *);
#line 133 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
extern void _Z18testGraph_SSSP7_RTjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
extern bool _Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, bool *, bool *, unsigned *, unsigned *, const unsigned *, bool *, bool *, unsigned *, unsigned *);
#line 130 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
extern void _Z15testGraph_SSSP9jjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
extern bool _Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, bool *, bool *, unsigned *, unsigned *, const unsigned *, bool *, bool *, unsigned *, unsigned *);
#line 131 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
extern void _Z22testGraph_SSSP9_AtomicjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 26 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
extern bool _Z22ejecutarIteracion_CPU7jPjjPKjjPbS2_(const unsigned, unsigned *, const unsigned, const unsigned *, const unsigned, bool *, bool *);
#line 78 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
extern void _Z16computeGold_CPU7PjjPKjj(unsigned *, const unsigned, const unsigned *, const unsigned);
#line 119 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
extern bool _Z22ejecutarIteracion_CPU9jPjjPKjjPbS2_(const unsigned, unsigned *, const unsigned, const unsigned *, const unsigned, bool *, bool *);
#line 171 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
extern void _Z16computeGold_CPU9PjjPKjj(unsigned *, const unsigned, const unsigned *, const unsigned);
#line 4 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos1.h"
extern void genera_M_Adyacencia(const unsigned, const unsigned, const unsigned, const unsigned, unsigned *, unsigned **);





extern void guardaMatriz_FicheroB(const char *, const unsigned, const unsigned, const unsigned *);
#line 84 "template.cu"
extern int __cdecl main(int, char **);
#line 115 "template.cu"
extern void _Z27generar_Matrices_Adyacenciav(void);
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern   int __cdecl _Z9sprintf_sILj100EEiRAT__cPKcz(char (*)[100], const char *, ...);
#line 181 "template.cu"
extern void _Z7runTestv(void);
extern void __sti___16_template_cpp1_ii_a6b7a973(void);
#pragma section(".CRT$XCU",read,write)
__declspec(allocate(".CRT$XCU"))static void (__cdecl *__dummy_static_init__sti___16_template_cpp1_ii_a6b7a973[])(void) = {__sti___16_template_cpp1_ii_a6b7a973};
#line 30 "template.cu"
extern unsigned NUM_THREADS_IN_BLOCK;
#line 47 "template.cu"
static  struct _Z7textureIiLi1EL19cudaTextureReadMode0EE textura_m;



static  struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE textura_p;
static  struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE textura_f;
#line 1 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 4 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z7kernel3PbS_PKjj(bool *, bool *, const unsigned *, const unsigned);
#line 7 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z17kernel_minimizar1PKbPKjjPj(const bool *, const unsigned *, const unsigned, unsigned *);
#line 10 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 13 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z15kernel1_SSSP7_TjPj(const unsigned, unsigned *);
#line 16 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 19 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 22 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 25 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub__Z16kernel1_SSSP7_RTjPj(const unsigned, unsigned *);
#line 28 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 31 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 54 "template.cu"
#line 30 "template.cu"
unsigned NUM_THREADS_IN_BLOCK = 256U;
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
  __inline float frexpf( float _X,  int *_Y)
{ return (float)(frexp(((double)_X), _Y)); }


  __inline float fabsf( float _X)
{ return (float)(fabs(((double)_X))); }
  __inline float ldexpf( float _X,  int _Y)
{ return (float)(ldexp(((double)_X), _Y)); }

  __inline float acosf( float _X)
{ return (float)(acos(((double)_X))); }
  __inline float asinf( float _X)
{ return (float)(asin(((double)_X))); }
  __inline float atanf( float _X)
{ return (float)(atan(((double)_X))); }
  __inline float atan2f( float _X,  float _Y)
{ return (float)(atan2(((double)_X), ((double)_Y))); }
  __inline float ceilf( float _X)
{ return (float)(ceil(((double)_X))); }
  __inline float cosf( float _X)
{ return (float)(cos(((double)_X))); }
  __inline float coshf( float _X)
{ return (float)(cosh(((double)_X))); }
  __inline float expf( float _X)
{ return (float)(exp(((double)_X))); }
  __inline float floorf( float _X)
{ return (float)(floor(((double)_X))); }
  __inline float fmodf( float _X,  float _Y)
{ return (float)(fmod(((double)_X), ((double)_Y))); }
  __inline float logf( float _X)
{ return (float)(log(((double)_X))); }
  __inline float log10f( float _X)
{ return (float)(log10(((double)_X))); }
  __inline float modff( float _X,  float *_Y)
{ auto double _Di;
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
auto double _Df;
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_Df = (modf(((double)_X), (&_Di)));
(*_Y) = ((float)_Di);
return (float)_Df; }
  __inline float powf( float _X,  float _Y)
{ return (float)(pow(((double)_X), ((double)_Y))); }
  __inline float sinf( float _X)
{ return (float)(sin(((double)_X))); }
  __inline float sinhf( float _X)
{ return (float)(sinh(((double)_X))); }
  __inline float sqrtf( float _X)
{ return (float)(sqrt(((double)_X))); }
  __inline float tanf( float _X)
{ return (float)(tan(((double)_X))); }
  __inline float tanhf( float _X)
{ return (float)(tanh(((double)_X))); }
#line 8 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
void _Z8mostrarBPKbjPKc( const bool *v,  const unsigned n,  const char *vs) {
printf("\n%s[0..%i]\n", vs, (n - 1U)); {
auto unsigned i;
#line 10 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
i = 0U; for (; (i < n); i++) {
printf("%i\t", ((int)(v[i])));
} }
printf("\n\n"); 
}
void _Z8mostrarIPKijPKc( const int *v,  const unsigned n,  const char *vs) {
printf("\n%s[0..%i]\n", vs, (n - 1U)); {
auto unsigned i;
#line 17 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
i = 0U; for (; (i < n); i++) {
printf("%i\t", (v[i]));
} }
printf("\n\n"); 
}
void _Z9mostrarUIPKjjPKc( const unsigned *v,  const unsigned n,  const char *vs) {
printf("\n%s[0..%i]\n", vs, (n - 1U)); {
auto unsigned i;
#line 24 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
i = 0U; for (; (i < n); i++) {
printf("%i\t", (v[i]));
} }
printf("\n\n"); 
}


unsigned _Z6minimojj( const unsigned a,  const unsigned b) {
if (a < b) { return a; }
return b;
}


void _Z22mostrarUI_M_AdyacenciaPKjjPKc( const unsigned *m,  const unsigned nv,  const char *ms) {
printf("\n%s[0..%i]\n", ms, ((nv * nv) - 1U)); {
auto unsigned i;
#line 39 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
i = 0U; for (; (i < nv); i++) { {
auto unsigned j;
#line 40 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.cpp"
j = 0U; for (; (j < nv); j++) {
printf("%i\t", (m[((i * nv) + j)]));
} }
printf("\n\n\n");
} }

printf("\n"); 
}
#line 13 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void _Z9copiarH2DPvPKvj( void *v_d,  const void *v_h,  const unsigned mem_size) {
cudaMemcpy(v_d, v_h, mem_size, cudaMemcpyHostToDevice); 
}


void _Z9copiarD2HPvPKvj( void *v_h,  const void *v_d,  const unsigned mem_size) {
cudaMemcpy(v_h, v_d, mem_size, cudaMemcpyDeviceToHost); 
}


void _Z25inicializar_Matriz_DevicePKjjRPj( const unsigned *m_h,  const unsigned mem_size_M, 
unsigned **m_d) {

cudaMalloc(((void **)m_d), mem_size_M);
_Z9copiarH2DPvPKvj(((void *)((*m_d))), ((const void *)m_h), mem_size_M); 
}


void _Z15inicializar_SolRPjS0_jjj( unsigned **c_h,  unsigned **c_d, 
const unsigned nv,  const unsigned mem_size_V, 
const unsigned infinito) {

(*c_h) = ((unsigned *)(malloc(mem_size_V)));

(((*c_h))[0]) = 0U; {
auto unsigned i;
#line 38 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*c_h))[i]) = infinito; } }


cudaMalloc(((void **)c_d), mem_size_V);

_Z9copiarH2DPvPKvj(((void *)((*c_d))), ((const void *)((void *)((*c_h)))), mem_size_V); 



}



void _Z22inicializar_PendientesRPbS0_jj( bool **p_h,  bool **p_d, 
const unsigned nv,  const unsigned mem_size_F) {

(*p_h) = ((bool *)(malloc(mem_size_F)));

(((*p_h))[0]) = ((bool)0); {
auto unsigned i;
#line 57 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*p_h))[i]) = ((bool)1); } }


cudaMalloc(((void **)p_d), mem_size_F);

_Z9copiarH2DPvPKvj(((void *)((*p_d))), ((const void *)((void *)((*p_h)))), mem_size_F); 




}


void _Z20inicializar_FronteraRPbS0_jj( bool **f_h,  bool **f_d, 
const unsigned nv,  const unsigned mem_size_F) {

(*f_h) = ((bool *)(malloc(mem_size_F)));

(((*f_h))[0]) = ((bool)1); {
auto unsigned i;
#line 76 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*f_h))[i]) = ((bool)0); } }


cudaMalloc(((void **)f_d), mem_size_F);

_Z9copiarH2DPvPKvj(((void *)((*f_d))), ((const void *)((void *)((*f_h)))), mem_size_F); 
#line 87 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
}
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
bool _Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
bool *p_h,  bool *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
bool *p_d,  bool *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 47 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned shared_mem;
#line 79 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned min;
#line 47 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
shared_mem = (((threads.x)) * 5U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub__Z13kernel1_SSSP7jPKjPKbS2_Pj(nv, m_d, ((const bool *)p_d), ((const bool *)f_d), c_d));


cudaThreadSynchronize();
#line 72 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub__Z17kernel_minimizar1PKbPKjjPj(((const bool *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 90 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned i;
#line 90 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 111 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 127 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
return (bool)(min == infinito);
}


void _Z15testGraph_SSSP7jjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T216;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto bool *f_h;
auto bool *f_d;
auto unsigned mem_size_F;


auto bool *p_h;
auto bool *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 181 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned timer;





auto bool ultima;
auto unsigned i;
#line 225 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto enum CUTBoolean res;
#line 139 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T216 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T216; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 165 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 181 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 201 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 19 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
bool _Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
bool *p_h,  bool *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
bool *p_d,  bool *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 48 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned shared_mem;
#line 81 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned min;
#line 48 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
shared_mem = (((threads.x)) * 5U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub__Z15kernel1_SSSP7_TjPj(nv, c_d));



cudaThreadSynchronize();
#line 74 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub__Z17kernel_minimizar1PKbPKjjPj(((const bool *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 92 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned i;
#line 92 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 113 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 129 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
return (bool)(min == infinito);
}


void _Z17testGraph_SSSP7_TjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T217;

auto unsigned *m_d;
#line 145 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto bool *f_h;
auto bool *f_d;
auto unsigned mem_size_F;


auto bool *p_h;
auto bool *p_d;
#line 166 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 190 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned timer;





auto bool ultima;
auto unsigned i;
#line 242 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto enum CUTBoolean res;
#line 140 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));


_Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)), ((const void *)m_d), mem_size_M);



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)), ((const void *)p_d), mem_size_F);
_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)), ((const void *)f_d), mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T217 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T217; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 174 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 190 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 211 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);


_Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)));


cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));



_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)));
_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));


free(((void *)c_h)); 

}
#line 239 "C:\\CUDA\\include\\cuda_runtime.h"
  __inline cudaError_t _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(
size_t *offset, 
const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *tex, 
const void *devPtr, 
size_t size)

{
return cudaBindTexture(offset, (&tex->__b_16textureReference), devPtr, (&(tex->__b_16textureReference).channelDesc), size);
}
#line 239 "C:\\CUDA\\include\\cuda_runtime.h"
  __inline cudaError_t _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(
size_t *offset, 
const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *tex, 
const void *devPtr, 
size_t size)

{
return cudaBindTexture(offset, (&tex->__b_16textureReference), devPtr, (&(tex->__b_16textureReference).channelDesc), size);
}
#line 278 "C:\\CUDA\\include\\cuda_runtime.h"
  __inline cudaError_t _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(
const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *tex)

{
return cudaUnbindTexture((&tex->__b_16textureReference));
}
#line 278 "C:\\CUDA\\include\\cuda_runtime.h"
  __inline cudaError_t _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(
const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *tex)

{
return cudaUnbindTexture((&tex->__b_16textureReference));
}
#line 19 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
bool _Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
bool *p_h,  bool *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
bool *p_d,  bool *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 48 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned shared_mem;
#line 81 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned min;
#line 48 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
shared_mem = (((threads.x)) * 21U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub__Z16kernel1_SSSP7_RTjPj(nv, c_d));



cudaThreadSynchronize();
#line 74 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub__Z17kernel_minimizar1PKbPKjjPj(((const bool *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 92 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned i;
#line 92 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 113 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 129 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
return (bool)(min == infinito);
}


void _Z18testGraph_SSSP7_RTjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T218;

auto unsigned *m_d;
#line 145 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto bool *f_h;
auto bool *f_d;
auto unsigned mem_size_F;


auto bool *p_h;
auto bool *p_d;
#line 166 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 190 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned timer;





auto bool ultima;
auto unsigned i;
#line 242 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto enum CUTBoolean res;
#line 140 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));


_Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)), ((const void *)m_d), mem_size_M);



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)), ((const void *)p_d), mem_size_F);
_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)), ((const void *)f_d), mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T218 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T218; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 174 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 190 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 211 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);


_Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)));


cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));



_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)));
_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));


free(((void *)c_h)); 

}
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
bool _Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
bool *p_h,  bool *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
bool *p_d,  bool *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 78 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned min;
#line 47 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), (((threads.x)) * 1U), 0))) ? ((void)0) : (__device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj(nv, m_d, ((const bool *)p_d), ((const bool *)f_d), c_d));


cudaThreadSynchronize();
#line 71 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub__Z17kernel_minimizar1PKbPKjjPj(((const bool *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned i;
#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 110 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 126 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
return (bool)(min == infinito);
}


void _Z15testGraph_SSSP9jjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T219;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto bool *f_h;
auto bool *f_d;
auto unsigned mem_size_F;


auto bool *p_h;
auto bool *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 180 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned timer;





auto bool ultima;
auto unsigned i;
#line 224 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto enum CUTBoolean res;
#line 138 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T219 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T219; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 164 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 180 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 200 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 18 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
bool _Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
bool *p_h,  bool *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
bool *p_d,  bool *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 78 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned min;
#line 47 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), (((threads.x)) * 1U), 0))) ? ((void)0) : (__device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj(nv, m_d, ((const bool *)p_d), ((const bool *)f_d), c_d));


cudaThreadSynchronize();
#line 71 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub__Z17kernel_minimizar1PKbPKjjPj(((const bool *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned i;
#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 110 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 126 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
return (bool)(min == infinito);
}



void _Z22testGraph_SSSP9_AtomicjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T220;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto bool *f_h;
auto bool *f_d;
auto unsigned mem_size_F;


auto bool *p_h;
auto bool *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 181 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned timer;





auto bool ultima;
auto unsigned i;
#line 225 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto enum CUTBoolean res;
#line 139 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T220 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T220; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 165 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 181 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 201 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 26 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
bool _Z22ejecutarIteracion_CPU7jPjjPKjjPbS2_( const unsigned nVuelta, 
unsigned *reference, 
const unsigned nv,  const unsigned *m, 
const unsigned infinito, 
bool *f,  bool *p) {
#line 41 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned tid;
auto unsigned pid;
#line 58 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned minimo;
#line 45 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
for (tid = 0U; (tid < nv); tid++) {
if ((int)(p[tid])) {
for (pid = 0U; (pid < nv); pid++) {
if ((int)(f[pid])) {
(reference[tid]) = (_Z6minimojj(((reference[pid]) + (m[((pid * nv) + tid)])), (reference[tid])));
}
}
}

}



minimo = infinito;
for (tid = 0U; (tid < nv); tid++) {
if (((int)(p[tid])) && (minimo > (reference[tid]))) {
minimo = (reference[tid]);
}
}


for (tid = 0U; (tid < nv); tid++) {
(f[tid]) = ((bool)0);
if (((int)(p[tid])) && ((reference[tid]) == minimo)) {
(f[tid]) = ((bool)1);
(p[tid]) = ((bool)0);
}
}

return (bool)(minimo == infinito);

}

void _Z16computeGold_CPU7PjjPKjj( unsigned *reference, 
const unsigned nv,  const unsigned *m, 
const unsigned infinito) {

auto unsigned mem_size_F;
auto bool *p;
auto bool *f;
#line 95 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned timer;



auto bool ultima;
auto unsigned i;
#line 82 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
mem_size_F = (1U * nv);
p = ((bool *)(malloc(mem_size_F)));
f = ((bool *)(malloc(mem_size_F)));

(reference[0]) = 0U;
(p[0]) = ((bool)0);
(f[0]) = ((bool)1); {
auto unsigned i;
#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
i = 1U; for (; (i < nv); i++) {
(reference[i]) = infinito;
(p[i]) = ((bool)1);
(f[i]) = ((bool)0);
} }

timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z22ejecutarIteracion_CPU7jPjjPKjjPbS2_(i, reference, nv, m, infinito, f, p));


}


cutStopTimer(timer);
printf("%f\t %d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);


free(((void *)p));
free(((void *)f)); 
}


bool _Z22ejecutarIteracion_CPU9jPjjPKjjPbS2_( const unsigned nVuelta, 
unsigned *reference, 
const unsigned nv,  const unsigned *m, 
const unsigned infinito, 
bool *f,  bool *p) {
#line 134 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned tid;
auto unsigned sid;
#line 151 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned minimo;
#line 138 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
for (tid = 0U; (tid < nv); tid++) {
if ((int)(f[tid])) {
for (sid = 0U; (sid < nv); sid++) {
if ((int)(p[sid])) {
(reference[sid]) = (_Z6minimojj((reference[sid]), ((m[((tid * nv) + sid)]) + (reference[tid]))));
}
}
}

}



minimo = infinito;
for (tid = 0U; (tid < nv); tid++) {
if (((int)(p[tid])) && (minimo > (reference[tid]))) {
minimo = (reference[tid]);
}
}


for (tid = 0U; (tid < nv); tid++) {
(f[tid]) = ((bool)0);
if (((int)(p[tid])) && ((reference[tid]) == minimo)) {
(f[tid]) = ((bool)1);
(p[tid]) = ((bool)0);
}
}

return (bool)(minimo == infinito);

}

void _Z16computeGold_CPU9PjjPKjj( unsigned *reference, 
const unsigned nv,  const unsigned *m, 
const unsigned infinito) {

auto unsigned mem_size_F;
auto bool *p;
auto bool *f;
#line 188 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
auto unsigned timer;



auto bool ultima;
auto unsigned i;
#line 175 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
mem_size_F = (1U * nv);
p = ((bool *)(malloc(mem_size_F)));
f = ((bool *)(malloc(mem_size_F)));

(reference[0]) = 0U;
(p[0]) = ((bool)0);
(f[0]) = ((bool)1); {
auto unsigned i;
#line 182 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.cpp"
i = 1U; for (; (i < nv); i++) {
(reference[i]) = infinito;
(p[i]) = ((bool)1);
(f[i]) = ((bool)0);
} }

timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

ultima = ((bool)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z22ejecutarIteracion_CPU9jPjjPKjjPbS2_(i, reference, nv, m, infinito, f, p));


}


cutStopTimer(timer);
printf("%f\t %d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);


free(((void *)p));
free(((void *)f)); 
}
#line 84 "template.cu"
int __cdecl main( int argc,  char **argv)
{
srand(((unsigned)(_time64(((time_t *)0)))));


_Z7runTestv();
#line 104 "template.cu"
printf("\n\n");
printf((cudaGetErrorString((cudaGetLastError()))));
printf("\n\n");

if (!((int)(cutCheckCmdLineFlag(argc, ((const char **)argv), "noprompt")))) { printf("\nPress ENTER to exit...\n"); fflush(((__iob_func()) + 1)); fflush(((__iob_func()) + 2)); getchar(); } exit(0); return 0;

}




void _Z27generar_Matrices_Adyacenciav(void) {

auto unsigned nv;
auto unsigned *m;
auto unsigned mem_size_M;

auto unsigned degree;
auto unsigned topeW;
auto unsigned infinito;


auto char s[100];

auto unsigned timer;
#line 122 "template.cu"
topeW = 10U;
#line 130 "template.cu"
printf("Generando y Guardando Matrices de Adyacencia\n"); {

auto unsigned k;
#line 132 "template.cu"
k = 8U; for (; (k <= 11U); k++) {
nv = (k * 1024U);
degree = (nv / 5U);
infinito = (nv * 10U);
printf("\n\nNODOS= %d * 1024\n", k);
printf("topeW= %i\n", 10);
printf("degree= nv/%i= %i\n", 5, degree);
printf("infinito= nv*%i= %i\n\n", 10, infinito);

printf("Matriz\t Generar\t Guardar\n"); {
auto unsigned i;
#line 142 "template.cu"
i = 1U; for (; (i <= 1U); i++) {

printf("%i\t", i);

if (i < 10U) { _Z9sprintf_sILj100EEiRAT__cPKcz((&s), "../DATA/MATRICES/%d/matriz0%d.gr", k, i); } else  {
_Z9sprintf_sILj100EEiRAT__cPKcz((&s), "../DATA/MATRICES/%d/matriz%d.gr", k, i); }



timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

genera_M_Adyacencia(nv, degree, topeW, infinito, (&mem_size_M), (&m));

cutStopTimer(timer);
printf("%f\t", ((double)(cutGetTimerValue(timer))));
cutDeleteTimer(timer);

timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

guardaMatriz_FicheroB(((const char *)((char *)s)), nv, mem_size_M, ((const unsigned *)m));

cutStopTimer(timer);
printf("%f\n", ((double)(cutGetTimerValue(timer))));
cutDeleteTimer(timer);


free(((void *)m));

} }

} } 

}
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
  __inline int __cdecl _Z9sprintf_sILj100EEiRAT__cPKcz( char (*_Dest)[100],  const char *_Format, ...) { auto va_list _ArgList;
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
_ArgList = (((va_list)((const char *)(&_Format))) + 4U); return vsprintf_s(((char *)_Dest), 100U, _Format, _ArgList); }
#line 181 "template.cu"
void _Z7runTestv(void) {



auto unsigned nv;
auto unsigned *m;
auto unsigned mem_size_M;

auto unsigned topeW;
auto unsigned infinito;


auto unsigned *reference1;
auto unsigned *reference2;
#line 203 "template.cu"
auto char s[100];
#line 183 "template.cu"
do { auto int deviceCount;
#line 183 "template.cu"
auto int dev;
#line 183 "template.cu"
cudaGetDeviceCount((&deviceCount)); if (deviceCount == 0) { fprintf(((__iob_func()) + 2), "There is no device.\n"); exit(1); } for (dev = 0; (dev < deviceCount); ++dev) { auto struct cudaDeviceProp deviceProp;
#line 183 "template.cu"
cudaGetDeviceProperties((&deviceProp), dev); if (((deviceProp.major)) >= 1) { goto __T221; } } __T221:; if (dev == deviceCount) { fprintf(((__iob_func()) + 2), "There is no device supporting CUDA.\n"); exit(1); } else  { cudaSetDevice(dev); } } while (0);
#line 189 "template.cu"
topeW = 10U;
#line 198 "template.cu"
printf("TEST SSSP7, SSSP9\n\n");
printf("degree= nv/%i\n", 5);
printf("topeW= %i\n", topeW); {




auto unsigned t;
#line 205 "template.cu"
t = 1U; for (; (t <= 1U); t++) {

printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); {

auto unsigned k;
#line 209 "template.cu"
k = 4U; for (; (k <= 4U); k++) {
printf("\n\nNODOS= %i * 1024\n\n", k);
printf("Grafo\t CPU7\t\t\t CPU9\t\t\t SSSP7\t\t\t SSSP7_T\t\t\t SSSP7_RT\t\t\t SSSP9\n\n");
nv = (k * 1024U);
infinito = (nv * 10U); {

auto int i;
#line 215 "template.cu"
i = 1; for (; (i <= 1); i++) {
#line 236 "template.cu"
auto enum CUTBoolean res;
#line 217 "template.cu"
printf("%i\t", i);

if (i < 10) { _Z9sprintf_sILj100EEiRAT__cPKcz((&s), "../DATA/MATRICES/%d/matriz0%d.gr", k, i); } else  {
_Z9sprintf_sILj100EEiRAT__cPKcz((&s), "../DATA/MATRICES/%d/matriz%d.gr", k, i); }


genera_M_Adyacencia(nv, (nv / 5U), topeW, infinito, (&mem_size_M), (&m));
#line 229 "template.cu"
reference1 = ((unsigned *)(malloc((nv * 4U))));
_Z16computeGold_CPU7PjjPKjj(reference1, nv, ((const unsigned *)m), infinito);

reference2 = ((unsigned *)(malloc((nv * 4U))));
_Z16computeGold_CPU9PjjPKjj(reference2, nv, ((const unsigned *)m), infinito);


res = (cutComparei(((const int *)((int *)reference1)), ((const int *)((int *)reference2)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));

free(((void *)reference2));


_Z15testGraph_SSSP7jjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z17testGraph_SSSP7_TjjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z18testGraph_SSSP7_RTjjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z15testGraph_SSSP9jjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));




printf("\n");


free(((void *)m));
free(((void *)reference1));

} }

} }

NUM_THREADS_IN_BLOCK = (NUM_THREADS_IN_BLOCK * 2U);

} } 
}
void __sti___16_template_cpp1_ii_a6b7a973(void) { auto int __T278;
auto int __T279;
auto int __T280;
#line 47 "template.cu"
{ ((textura_m.__b_16textureReference).normalized) = 0; ((textura_m.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_m.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_m.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; ((textura_m.__b_16textureReference).channelDesc) = ((__T278 = 32) , (cudaCreateChannelDesc(__T278, 0, 0, 0, cudaChannelFormatKindSigned))); }



{ ((textura_p.__b_16textureReference).normalized) = 0; ((textura_p.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_p.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_p.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; ((textura_p.__b_16textureReference).channelDesc) = ((__T279 = 8) , (cudaCreateChannelDesc(__T279, 0, 0, 0, cudaChannelFormatKindSigned))); }
{ ((textura_f.__b_16textureReference).normalized) = 0; ((textura_f.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_f.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_f.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; ((textura_f.__b_16textureReference).channelDesc) = ((__T280 = 8) , (cudaCreateChannelDesc(__T280, 0, 0, 0, cudaChannelFormatKindSigned))); }  }
#line 1 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 4 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 1 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"
#line 1 "C:\\CUDA\\include\\__cudaFatFormat.h"
































































































typedef struct {
    char*            gpuProfileName;
    char*            cubin;
} __cudaFatCubinEntry;












typedef struct {
    char*            gpuProfileName;            
    char*            ptx;
} __cudaFatPtxEntry;








typedef struct {
    char*            gpuProfileName;            
    char*            debug;
} __cudaFatDebugEntry;


typedef enum {
      __cudaFatDontSearchFlag = (1 << 0),
      __cudaFatDontCacheFlag  = (1 << 1)
} __cudaFatCudaBinaryFlag;










typedef struct {
    unsigned long     magic;
    unsigned long     version;
    unsigned long     gpuInfoVersion;
    char*            key;
    char*            ident;
    char*            usageMode;
    __cudaFatPtxEntry      *ptx;
    __cudaFatCubinEntry    *cubin;
    __cudaFatDebugEntry    *debug;
    void*           debugInfo;
    unsigned int            flags;
} __cudaFatCudaBinary;































void fatGetCubinForGpu( __cudaFatCudaBinary *binary, char* gpuName, char* *cubin, char* *dbgInfoFile );






#line 197 "C:\\CUDA\\include\\__cudaFatFormat.h"
#line 2 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"







static const unsigned char __deviceText[] = {
0x61,0x72,0x63,0x68,0x69,0x74,0x65,0x63,0x74,0x75,0x72,0x65,0x20,0x7b,0x73,0x6d,
0x5f,0x31,0x30,0x7d,0x0d,0x0a,0x61,0x62,0x69,0x76,0x65,0x72,0x73,0x69,0x6f,0x6e,
0x20,0x7b,0x30,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,0x72,
0x61,0x5f,0x66,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,0x20,
0x32,0x0d,0x0a,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,0x72,
0x61,0x5f,0x70,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,0x20,
0x31,0x0d,0x0a,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,0x72,
0x61,0x5f,0x6d,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,0x20,
0x30,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,
0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5a,0x37,0x6b,0x65,0x72,0x6e,0x65,0x6c,
0x33,0x50,0x62,0x53,0x5f,0x50,0x4b,0x6a,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,
0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,
0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x62,0x61,0x72,
0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,
0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,
0x30,0x34,0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x32,0x33,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x34,0x30,0x35,0x20,
0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x31,0x30,
0x30,0x32,0x63,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x32,0x30,0x34,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x63,0x61,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x31,0x20,
0x30,0x78,0x61,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x63,0x38,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x36,0x30,0x31,0x20,
0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x38,
0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x30,0x38,0x37,0x63,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x63,0x66,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x32,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x33,0x30,0x30,
0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x31,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x61,0x30,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x36,0x30,0x31,0x20,0x30,0x78,0x61,0x30,0x32,0x30,0x30,0x37,0x38,0x31,
0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,
0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,
0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,
0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,
0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,
0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,
0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5a,0x31,0x37,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x5f,
0x6d,0x69,0x6e,0x69,0x6d,0x69,0x7a,0x61,0x72,0x31,0x50,0x4b,0x62,0x50,0x4b,0x6a,
0x6a,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,0x0a,
0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,0x09,0x72,0x65,0x67,
0x20,0x3d,0x20,0x37,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,
0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x33,
0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x30,0x34,0x63,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x30,0x30,0x30,0x30,0x34,0x30,0x39,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x30,0x30,0x63,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x34,0x30,0x39,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x32,0x38,0x36,0x31,0x38,0x20,0x30,0x78,0x32,0x31,0x30,0x36,
0x65,0x38,0x30,0x38,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x39,0x20,
0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x30,
0x38,0x37,0x63,0x38,0x20,0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x63,0x31,0x30,0x20,
0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x63,0x31,0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x63,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x39,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x38,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x31,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,
0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x63,0x31,0x38,0x20,
0x30,0x78,0x32,0x31,0x30,0x36,0x65,0x38,0x30,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x39,0x66,0x64,0x20,
0x30,0x78,0x36,0x38,0x34,0x30,0x38,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x63,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x39,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x38,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x31,0x35,0x20,0x30,0x78,0x38,0x30,0x63,0x30,
0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x35,0x30,0x38,0x30,0x39,0x20,
0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x32,0x30,0x36,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x34,0x32,0x30,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x34,0x31,0x30,0x30,0x37,0x63,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x32,0x32,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x33,0x30,0x31,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x30,0x30,0x63,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x30,0x30,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x63,0x35,0x30,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x34,0x30,0x39,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x38,0x30,0x30,0x64,0x30,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x33,
0x63,0x35,0x30,0x30,0x20,0x30,0x78,0x33,0x34,0x30,0x32,0x64,0x30,0x30,0x39,0x20,
0x30,0x78,0x61,0x34,0x32,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x38,0x35,0x30,0x30,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x31,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x31,0x30,
0x30,0x37,0x63,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x39,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x37,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x34,0x31,
0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x31,0x30,0x30,0x66,0x30,0x30,0x30,0x20,
0x30,0x78,0x32,0x31,0x30,0x31,0x65,0x65,0x30,0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x61,0x30,0x63,0x30,
0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,
0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,
0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,
0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,
0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,
0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,
0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5a,0x31,0x33,0x6b,0x65,0x72,
0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x37,0x6a,0x50,0x4b,0x6a,0x50,0x4b,
0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,
0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x34,0x38,0x0d,0x0a,0x09,
0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x37,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,
0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,
0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,
0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x34,0x30,0x35,0x20,0x30,0x78,
0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x31,0x30,0x30,0x32,
0x63,0x30,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x32,0x38,0x32,0x30,0x63,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x30,0x39,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,
0x34,0x30,0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x36,0x31,0x31,0x20,0x30,0x78,
0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x64,
0x30,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x31,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x38,0x31,0x35,0x20,0x30,0x78,
0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,
0x38,0x31,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x64,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x30,0x31,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x33,0x30,0x38,0x65,0x32,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,
0x32,0x32,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x39,0x66,0x64,0x20,0x30,0x78,
0x36,0x38,0x34,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,
0x32,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x32,0x30,0x35,0x20,0x30,0x78,
0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x38,
0x30,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x65,0x32,0x39,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x32,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x33,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x64,
0x30,0x32,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x36,0x30,0x39,0x20,0x30,0x78,
0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x31,
0x34,0x30,0x35,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x38,0x30,0x31,0x20,0x30,0x78,
0x65,0x34,0x32,0x30,0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x38,0x30,0x30,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x34,0x30,0x38,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x33,0x36,
0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x36,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x38,0x30,0x30,
0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x34,0x30,0x38,0x37,0x64,0x38,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x36,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x39,
0x30,0x33,0x34,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x39,0x30,0x33,0x38,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x33,0x64,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,
0x61,0x30,0x64,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x63,0x30,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,
0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x61,0x30,0x30,0x33,0x31,
0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x31,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x66,0x39,
0x32,0x30,0x38,0x20,0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x38,0x30,0x34,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x35,0x30,0x34,0x34,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,0x30,
0x36,0x34,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x32,0x30,0x34,0x31,0x20,0x30,0x78,
0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,0x30,
0x34,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x32,0x30,0x35,0x20,0x30,0x78,
0x30,0x34,0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x32,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x35,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,
0x32,0x30,0x35,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x32,0x31,0x65,0x30,0x64,0x20,0x30,0x78,
0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x63,0x30,0x30,0x64,
0x38,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x61,0x31,0x35,0x20,0x30,0x78,
0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x61,0x33,0x35,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x65,0x31,
0x62,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x65,0x33,0x64,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,0x30,0x32,0x31,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,
0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,
0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x38,0x33,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,
0x30,0x32,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x38,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x63,0x30,0x64,0x66,0x64,0x20,0x30,0x78,
0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x37,0x39,
0x36,0x32,0x63,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x39,0x32,0x32,0x34,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x31,0x36,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,
0x38,0x31,0x35,0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,
0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,
0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,
0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,
0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,
0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,
0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,
0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,
0x20,0x3d,0x20,0x5f,0x5a,0x31,0x35,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,
0x53,0x53,0x50,0x37,0x5f,0x54,0x6a,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,
0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,
0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x37,0x0d,0x0a,0x09,0x62,0x61,
0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,
0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x35,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x30,0x30,0x32,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x32,0x32,0x63,0x30,0x30,
0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x39,0x36,0x30,0x38,0x20,0x30,0x78,0x33,0x30,
0x30,0x32,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x31,0x39,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,
0x30,0x30,0x63,0x61,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x31,0x64,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,0x20,0x30,0x78,0x64,0x30,
0x30,0x65,0x30,0x38,0x31,0x35,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x34,0x30,0x31,
0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,
0x30,0x32,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,
0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x65,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,
0x30,0x32,0x30,0x32,0x32,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x32,0x30,0x39,0x30,0x32,0x35,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x63,0x30,0x31,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x31,0x36,0x30,0x64,
0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,
0x38,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x63,0x34,0x31,0x34,0x37,0x63,
0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x36,0x30,0x39,
0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,
0x30,0x32,0x31,0x36,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x31,0x36,0x30,0x31,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x30,0x38,0x30,0x32,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x33,0x31,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,
0x30,0x65,0x31,0x38,0x30,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x31,0x36,0x30,0x31,
0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,
0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x33,0x30,0x34,0x30,0x34,0x30,0x31,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x63,0x30,0x31,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x36,0x63,0x34,0x31,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x32,0x38,0x30,0x31,0x34,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x38,0x36,
0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x33,0x37,0x30,0x30,0x33,
0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x33,0x37,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x33,0x66,0x64,
0x20,0x30,0x78,0x36,0x34,0x34,0x30,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x31,0x30,
0x30,0x30,0x38,0x30,0x33,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x37,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x30,0x39,0x32,0x33,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x32,0x33,
0x63,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x63,0x30,0x64,
0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x63,
0x30,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,
0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x33,0x32,0x30,0x30,0x33,
0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x33,0x32,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x64,0x39,0x34,0x30,0x63,
0x20,0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x38,0x30,0x30,0x20,0x30,0x78,0x34,0x30,
0x30,0x37,0x30,0x30,0x34,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x36,0x30,0x32,0x34,0x31,
0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,
0x31,0x30,0x32,0x30,0x34,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x36,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,
0x30,0x30,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x32,0x31,0x61,0x30,0x64,
0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,
0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x63,0x30,0x30,0x64,0x30,0x30,0x31,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,
0x30,0x30,0x30,0x61,0x31,0x35,0x20,0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x32,0x30,
0x30,0x31,0x39,0x63,0x33,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x66,0x31,0x64,0x66,0x64,
0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,
0x30,0x31,0x39,0x61,0x33,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x34,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x66,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,
0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,
0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x32,0x30,
0x30,0x31,0x38,0x63,0x31,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x32,0x32,0x64,
0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,
0x30,0x36,0x30,0x66,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,
0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x38,0x39,0x38,0x33,0x30,
0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x34,0x32,0x38,0x20,0x30,0x78,0x31,0x30,
0x30,0x31,0x35,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x38,0x31,0x35,
0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,
0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,
0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,
0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,
0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,
0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,
0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,
0x5f,0x5a,0x31,0x35,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,
0x37,0x5f,0x31,0x6a,0x50,0x4b,0x6a,0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,
0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,
0x6d,0x20,0x3d,0x20,0x34,0x38,0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,
0x31,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,
0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,
0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x31,0x20,0x30,0x78,0x30,
0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,
0x30,0x30,0x30,0x34,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x34,0x31,0x30,0x30,0x32,0x63,0x30,0x38,0x20,0x30,0x78,0x32,
0x30,0x30,0x31,0x38,0x34,0x31,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,
0x30,0x32,0x30,0x38,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x64,0x30,0x31,0x35,0x20,0x30,0x78,0x30,
0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,
0x30,0x30,0x34,0x38,0x31,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,
0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x61,0x31,0x39,0x20,0x30,0x78,0x38,
0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x33,0x31,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,
0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x30,0x35,0x20,0x30,0x78,0x30,
0x34,0x32,0x31,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,
0x30,0x65,0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x35,0x66,0x64,0x20,0x30,0x78,0x36,
0x38,0x34,0x31,0x34,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x30,0x38,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x30,0x78,0x61,0x30,0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,
0x30,0x20,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,
0x34,0x34,0x30,0x38,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x30,0x78,0x34,0x30,0x30,0x31,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x30,
0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,
0x30,0x30,0x30,0x36,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x38,0x37,0x38,
0x30,0x20,0x30,0x78,0x33,0x30,0x31,0x30,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x63,
0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,
0x30,0x30,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x38,0x37,0x38,
0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x34,0x30,0x63,0x20,0x30,0x78,0x32,
0x31,0x30,0x32,0x65,0x65,0x32,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,
0x30,0x30,0x63,0x65,0x32,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x63,0x37,0x38,
0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x30,0x30,0x64,0x20,0x30,0x78,0x38,
0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,
0x38,0x30,0x30,0x64,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x30,0x38,0x37,0x64,
0x38,0x20,0x30,0x78,0x61,0x30,0x30,0x32,0x38,0x30,0x30,0x33,0x20,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x32,0x38,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x63,0x38,0x30,0x64,0x20,0x30,0x78,0x30,
0x34,0x32,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,
0x30,0x35,0x30,0x63,0x32,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,0x30,0x65,0x32,0x39,0x20,0x30,0x78,0x30,
0x30,0x30,0x32,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,
0x31,0x30,0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,0x30,0x63,0x30,0x64,0x20,0x30,0x78,0x30,
0x30,0x30,0x32,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,
0x30,0x30,0x30,0x36,0x32,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x34,0x30,0x64,0x20,0x30,0x78,0x63,
0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,
0x30,0x32,0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x32,0x31,0x30,0x33,0x66,0x30,0x30,0x63,0x20,0x30,0x78,0x32,
0x31,0x30,0x61,0x65,0x61,0x32,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,
0x30,0x65,0x30,0x36,0x30,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,
0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x38,
0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,
0x30,0x30,0x31,0x34,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x63,0x37,0x38,
0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x33,0x30,0x63,0x31,0x39,0x20,0x30,0x78,0x61,
0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,
0x32,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x30,0x32,0x31,0x20,0x30,0x78,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,
0x30,0x39,0x31,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,
0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x34,0x30,0x39,0x20,0x30,0x78,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x31,0x37,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,
0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,
0x30,0x31,0x38,0x32,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x66,0x66,0x64,0x20,0x30,0x78,0x36,
0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,
0x30,0x30,0x64,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x61,0x31,0x39,0x20,0x30,0x78,0x61,
0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,
0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,
0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,
0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,
0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,
0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,
0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,
0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5a,0x31,0x33,
0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x39,0x6a,0x50,0x4b,
0x6a,0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,
0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x34,0x38,
0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x33,0x0d,0x0a,0x09,0x62,0x61,
0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,
0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x35,
0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x34,0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x34,0x31,0x35,
0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x31,
0x30,0x30,0x32,0x63,0x30,0x34,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x61,0x30,
0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x65,0x30,0x39,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,
0x30,0x65,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x32,0x30,0x64,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,
0x30,0x30,0x64,0x30,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x36,0x30,0x64,
0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,
0x30,0x30,0x34,0x38,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x32,0x30,
0x33,0x30,0x38,0x61,0x31,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x39,0x66,0x64,
0x20,0x30,0x78,0x36,0x38,0x34,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x63,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x31,0x39,
0x20,0x30,0x78,0x30,0x34,0x32,0x31,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x30,0x38,0x30,0x31,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x31,0x64,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x64,0x30,
0x30,0x65,0x30,0x63,0x30,0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x30,0x34,0x31,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x38,0x36,
0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x33,0x32,0x30,0x30,0x33,
0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x33,0x32,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,
0x20,0x30,0x78,0x36,0x34,0x34,0x30,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x31,0x30,
0x30,0x33,0x32,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x33,0x30,0x38,0x30,0x32,0x31,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,
0x33,0x30,0x38,0x30,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x32,0x39,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x31,0x30,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x38,0x30,0x30,0x30,0x31,0x66,0x64,
0x20,0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x61,0x30,
0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x64,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x31,0x30,
0x30,0x30,0x63,0x38,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x33,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x33,0x30,0x38,0x32,0x64,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,
0x30,0x32,0x30,0x61,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x31,0x36,0x32,0x64,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,
0x30,0x32,0x30,0x38,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x35,0x39,0x34,0x30,0x38,
0x20,0x30,0x78,0x32,0x30,0x30,0x32,0x39,0x36,0x30,0x38,0x20,0x30,0x78,0x33,0x30,
0x30,0x32,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x31,0x34,0x32,0x64,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x31,
0x30,0x32,0x65,0x61,0x30,0x38,0x20,0x30,0x78,0x32,0x31,0x30,0x62,0x66,0x30,0x33,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x39,
0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,
0x30,0x65,0x31,0x38,0x32,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x34,0x30,0x39,
0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,
0x30,0x32,0x31,0x36,0x30,0x39,0x20,0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x38,0x30,0x39,
0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,
0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x30,0x32,0x31,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,
0x30,0x39,0x31,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,
0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x34,0x32,0x39,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,
0x30,0x31,0x62,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x38,0x36,
0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x65,0x31,0x64,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,
0x30,0x37,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,
0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x36,0x38,0x30,0x31,0x38,
0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x61,0x31,0x34,0x20,0x30,0x78,0x31,0x30,
0x30,0x31,0x31,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,
0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x0d,0x0a,0x09,0x7d,
0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,
0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,
0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,
0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,
0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,
0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,
0x5f,0x5a,0x32,0x30,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,
0x39,0x5f,0x41,0x74,0x6f,0x6d,0x69,0x63,0x6a,0x50,0x4b,0x6a,0x50,0x4b,0x62,0x53,
0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,
0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x34,0x38,0x0d,0x0a,0x09,0x72,0x65,
0x67,0x20,0x3d,0x20,0x31,0x33,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,
0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x34,
0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,
0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x34,0x31,0x35,0x20,0x30,0x78,0x30,0x34,
0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x31,0x30,0x30,0x32,0x63,0x30,
0x34,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x61,0x30,0x34,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x65,0x30,0x39,0x20,0x30,0x78,0x30,0x34,
0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,
0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x32,0x30,0x64,0x20,0x30,0x78,0x63,0x34,
0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x64,0x30,0x30,
0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x36,0x30,0x64,0x20,0x30,0x78,0x38,0x30,
0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x31,
0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x33,0x30,0x38,0x61,0x31,
0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x38,
0x34,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x63,0x30,
0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x31,0x39,0x20,0x30,0x78,0x30,0x34,
0x32,0x31,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x31,
0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x31,0x64,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x63,0x30,
0x39,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,
0x34,0x31,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,
0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x61,0x30,0x30,0x33,0x32,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x32,0x30,0x30,
0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,
0x34,0x30,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x32,0x30,0x30,
0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x33,0x30,0x38,0x30,0x32,0x31,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x33,0x30,0x38,0x30,0x32,
0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x32,0x39,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x30,0x30,
0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x61,0x38,0x30,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x30,0x38,
0x32,0x31,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x61,0x30,0x30,0x32,0x64,0x30,0x30,
0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x63,0x38,0x30,
0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x34,0x30,0x30,0x33,0x30,0x38,0x32,0x64,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x61,0x32,
0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x31,0x36,0x32,0x64,0x20,0x30,0x78,0x63,0x34,
0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x38,0x32,
0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x35,0x39,0x34,0x30,0x38,0x20,0x30,0x78,0x32,0x30,
0x30,0x32,0x39,0x36,0x30,0x38,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x34,0x30,
0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x31,0x34,0x32,0x64,0x20,0x30,0x78,0x63,0x34,
0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x31,0x30,0x32,0x65,0x61,0x30,
0x38,0x20,0x30,0x78,0x32,0x31,0x30,0x62,0x66,0x30,0x33,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x38,0x30,
0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x38,0x32,
0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x34,0x30,0x39,0x20,0x30,0x78,0x30,0x34,
0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x31,0x36,0x30,
0x39,0x20,0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x38,0x30,0x39,0x20,0x30,0x78,0x61,0x30,
0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,
0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x30,0x32,0x31,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x39,0x31,0x31,0x66,
0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x34,0x32,0x39,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x62,0x30,0x30,
0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,
0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,
0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x65,0x31,0x64,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x37,0x30,0x39,0x66,
0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x36,0x38,0x30,0x31,0x38,0x20,0x30,0x78,0x32,0x30,
0x30,0x30,0x38,0x61,0x31,0x34,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x31,0x30,0x30,
0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,
0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,
0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,
0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,
0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,
0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,
0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,
0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5a,0x31,0x36,0x6b,
0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x37,0x5f,0x52,0x54,0x6a,
0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,
0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,
0x3d,0x20,0x31,0x35,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,
0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x64,0x20,
0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x31,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x32,0x30,0x39,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x30,0x36,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x32,0x30,0x38,0x34,0x31,0x64,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x37,0x38,0x32,0x32,0x30,0x20,
0x30,0x78,0x32,0x30,0x30,0x30,0x39,0x30,0x32,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x34,0x30,0x30,0x32,0x34,0x63,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x30,0x36,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x34,0x30,0x39,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x38,0x30,0x31,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x32,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x30,0x37,0x63,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x31,0x35,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x61,0x31,0x39,0x20,
0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x30,0x30,0x38,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x33,
0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,0x30,0x32,0x30,0x32,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x35,0x63,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x36,0x32,0x64,0x20,
0x30,0x78,0x30,0x34,0x30,0x30,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x63,0x30,0x31,
0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x31,0x36,0x32,0x64,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x63,0x34,0x31,
0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x38,0x39,0x36,0x30,0x30,0x20,
0x30,0x78,0x32,0x30,0x30,0x37,0x38,0x36,0x33,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x36,0x32,0x64,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x34,0x30,0x30,0x33,0x30,0x38,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x61,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x31,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x38,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x30,0x30,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x34,0x30,0x39,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x36,0x30,0x39,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x38,0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x34,0x30,0x30,0x63,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x66,0x33,0x30,0x34,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x63,0x30,0x31,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x36,0x63,0x34,0x31,
0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x32,0x38,0x30,0x31,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x30,0x31,0x38,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x35,0x35,0x30,0x30,0x33,0x20,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x35,0x35,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x36,0x30,0x38,0x31,0x30,0x32,0x30,0x31,0x20,
0x30,0x78,0x36,0x30,0x34,0x30,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x31,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x33,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x34,0x30,
0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x30,0x38,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,0x30,0x35,0x35,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x30,0x31,0x36,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x32,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x34,0x30,0x64,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x35,0x34,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x32,0x34,0x30,0x30,0x63,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x63,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x38,0x30,0x30,0x63,0x30,0x30,0x39,0x20,
0x30,0x78,0x30,0x34,0x32,0x31,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x34,0x31,0x31,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x31,0x66,0x64,0x20,
0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x63,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x61,0x30,0x30,0x34,0x66,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x38,0x30,0x30,0x63,0x30,0x33,0x35,0x20,
0x30,0x78,0x30,0x34,0x32,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x31,0x30,0x30,0x34,0x66,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x63,0x38,0x30,0x39,0x20,
0x30,0x78,0x30,0x34,0x32,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x34,0x30,0x30,0x31,0x30,0x38,0x33,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x30,0x30,0x61,0x33,0x39,0x20,
0x30,0x78,0x30,0x30,0x30,0x33,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x31,0x30,0x31,0x63,0x33,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x30,0x30,0x38,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x33,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x30,0x30,0x32,0x31,0x61,0x31,0x31,0x20,0x30,0x78,0x63,0x30,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x38,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x66,0x33,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x64,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x33,0x30,0x30,0x30,0x30,0x63,0x31,0x39,0x20,0x30,0x78,0x61,0x34,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x30,0x30,0x31,0x39,0x61,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x31,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x30,0x30,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x64,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,
0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x34,0x30,0x39,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x32,0x39,0x30,0x31,0x65,0x30,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x39,0x30,0x35,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x30,0x30,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,
0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x63,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x61,0x31,0x39,0x20,0x30,0x78,0x61,0x30,0x63,0x30,
0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,
0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,
0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,
0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,
0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x38,
0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,
0x7d,0x0d,0x0a,0x00
};





static __cudaFatPtxEntry   __ptxEntries  [] = {{0,0}};
static __cudaFatCubinEntry __cubinEntries[] = {{"sm_10",(char*)__deviceText},{0,0}};
static __cudaFatDebugEntry __debugEntries[] = {{0,0}};
static __cudaFatCudaBinary __fatDeviceText= {0x1ee55a01,0x00000002,0x840b5bca,"ce74c42d76b13d28","template.cu","",__ptxEntries,__cubinEntries,__debugEntries,0,0};

#line 5 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 1 "C:\\CUDA\\include\\crt/host_runtime.h"






























































#line 64 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 1 "C:\\CUDA\\include\\host_defines.h"










































































































#line 108 "C:\\CUDA\\include\\host_defines.h"
#line 66 "C:\\CUDA\\include\\crt/host_runtime.h"




















#line 87 "C:\\CUDA\\include\\crt/host_runtime.h"

extern void** __stdcall __cudaRegisterFatBinary(
  void *fatCubin
);

extern void __stdcall __cudaUnregisterFatBinary(
  void **fatCubinHandle
);

extern void __stdcall __cudaRegisterVar(
        void **fatCubinHandle,
        char  *hostVar,
        char  *deviceAddress,
  const char  *deviceName,
        int    ext,
        int    size,
        int    constant,
        int    global
);

extern void __stdcall __cudaRegisterTexture(
        void                    **fatCubinHandle,
  const struct textureReference  *hostVar,
  const void                    **deviceAddress,
  const char                     *deviceName,
        int                       dim,       
        int                       norm,      
        int                       ext        
);

extern void __stdcall __cudaRegisterShared(
  void **fatCubinHandle,
  void **devicePtr
);

extern void __stdcall __cudaRegisterFunction(
        void   **fatCubinHandle,
  const char    *hostFun,
        char    *deviceFun,
  const char    *deviceName,
        int      thread_limit,
        uint3   *tid,
        uint3   *bid,
        dim3    *bDim,
        dim3    *gDim
);



#line 137 "C:\\CUDA\\include\\crt/host_runtime.h"

static void **__cudaFatCubinHandle;

static void __cudaUnregisterBinaryUtil(void)
{
  __cudaUnregisterFatBinary(__cudaFatCubinHandle);
}








#line 153 "C:\\CUDA\\include\\crt/host_runtime.h"





#line 159 "C:\\CUDA\\include\\crt/host_runtime.h"

#pragma section(".CRT$XPU")

#line 163 "C:\\CUDA\\include\\crt/host_runtime.h"

__declspec(allocate(".CRT$XPU"))
static void (__cdecl *__cudaUnregister[])(void) = {__cudaUnregisterBinaryUtil};

#line 168 "C:\\CUDA\\include\\crt/host_runtime.h"














#line 183 "C:\\CUDA\\include\\crt/host_runtime.h"












#line 1 "C:\\CUDA\\include\\common_functions.h"





























































#line 63 "C:\\CUDA\\include\\common_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"













































#line 47 "c:\\cuda\\include\\crt/func_macro.h"






#line 54 "c:\\cuda\\include\\crt/func_macro.h"






#line 61 "c:\\cuda\\include\\crt/func_macro.h"

#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 65 "C:\\CUDA\\include\\common_functions.h"

static long __cuda_clock(void)
{
  return clock();
}

static void *__cuda_memset(void *s, int c, size_t n)
{
  char *p = (char*)s;
  
  while (n--) *p++ = (char)c;

  return s;
}

#line 81 "C:\\CUDA\\include\\common_functions.h"







#line 1 "c:\\cuda\\include\\math_functions.h"














































































































































































































































































































































































































































































































































































































































































































































































































#line 784 "c:\\cuda\\include\\math_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"





























































#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 786 "c:\\cuda\\include\\math_functions.h"













#line 800 "c:\\cuda\\include\\math_functions.h"





static double log2(double a)
{
  return log(a) / log(2.0);
}

static float log2f(float a)
{
  return (float)log2((double)a);
}

static double exp2(double a)
{
  return pow(2.0, a);
}

static float exp2f(float a)
{
  return (float)exp2((double)a);
}

static long long int llabs(long long int a)
{
  return a < 0ll ? -a : a;
}

#line 831 "c:\\cuda\\include\\math_functions.h"

#line 833 "c:\\cuda\\include\\math_functions.h"

static int __cuda_abs(int a)
{
  return abs(a);
}

static float __cuda_fabsf(float a)
{
  return fabsf(a);
}

static long long int __cuda_llabs(long long int a)
{


#line 849 "c:\\cuda\\include\\math_functions.h"
  return llabs(a);
#line 851 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_exp2f(float a)
{
  return exp2f(a);
}

#line 1 "c:\\cuda\\include\\device_functions.h"




























































































































































































































































































































#line 318 "c:\\cuda\\include\\device_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"





























































#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 320 "c:\\cuda\\include\\device_functions.h"

#line 1 "c:\\cuda\\include\\host_defines.h"










































































































#line 108 "c:\\cuda\\include\\host_defines.h"
#line 322 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\math_constants.h"





































































































#line 103 "c:\\cuda\\include\\math_constants.h"
#line 323 "c:\\cuda\\include\\device_functions.h"



       static int __cuda___isnan(double a);
       static int __cuda___isnanf(float a);
static int __double2int_rz(double);
static unsigned int __double2uint_rz(double);
static long long int __double2ll_rz(double);
static unsigned long long int __double2ull_rz(double);













static int __mulhi(int a, int b)
{
  long long int c = (long long int)a * (long long int)b;

  return (int)(c >> 32);
}

static unsigned int __umulhi(unsigned int a, unsigned int b)
{
  unsigned long long int c = (unsigned long long int)a * (unsigned long long int)b;

  return (unsigned int)(c >> 32);
}

static unsigned long long int __umul64hi(unsigned long long int a, unsigned long long int b)
{
  unsigned int           a_lo = (unsigned int)a;
  unsigned long long int a_hi = a >> 32;
  unsigned int           b_lo = (unsigned int)b;
  unsigned long long int b_hi = b >> 32;
  unsigned long long int m1 = a_lo * b_hi;
  unsigned long long int m2 = a_hi * b_lo;
  unsigned int           carry;

  carry = (0ULL + __umulhi(a_lo, b_lo) + (unsigned int)m1 + (unsigned int)m2) >> 32;

  return a_hi * b_hi + (m1 >> 32) + (m2 >> 32) + carry;
}

static long long int __mul64hi(long long int a, long long int b)
{
  return __umul64hi(a, b) - (a < 0LL ? b : 0LL) - (b < 0LL ? a : 0LL);
}

static float __saturatef(float a)
{
  return a >= 1.0f ? 1.0f : a <= 0.0f ? 0.0f : a;
}

static unsigned int __sad(int a, int b, unsigned int c)
{
  long long int diff = (long long int)a - (long long int)b;

  return (unsigned int)(__cuda_llabs(diff) + (long long int)c);
}

static unsigned int __usad(unsigned int a, unsigned int b, unsigned int c)
{
  long long int diff = (long long int)a - (long long int)b;

  return (unsigned int)(__cuda_llabs(diff) + (long long int)c);
}

static int __mul24(int a, int b)
{
  a &= 0xffffff;
  a = (a & 0x800000) != 0 ? a | ~0xffffff : a;
  b &= 0xffffff;
  b = (b & 0x800000) != 0 ? b | ~0xffffff : b;

  return a * b;
}

static unsigned int __umul24(unsigned int a, unsigned int b)
{
  a &= 0xffffff;
  b &= 0xffffff;

  return a * b;
}

static float __int_as_float(int a)
{
  union {int a; float b;} u;

  u.a = a;

  return u.b;
}

static int __float_as_int(float a)
{
  union {float a; int b;} u;

  u.a = a;

  return u.b;
}

static long long int __internal_float2ll_kernel(float a, long long int max, long long int min, long long int nan, enum cudaRoundMode rndMode)
{
  unsigned long long int res, t = 0ULL;
  int shift;
  unsigned int ia;

  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= min) return min;
  ia = __float_as_int(a);
  shift = 189 - ((ia >> 23) & 0xff);
  res = (unsigned long long int)(((ia << 8) | 0x80000000) >> 1) << 32;
  if (shift >= 64) {
    t = res;
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (rndMode == cudaRoundNearest && (long long int)t < 0LL) {
    res += t == 0x8000000000000000ULL ? res & 1ULL : 1ULL;
  }
  else if (rndMode == cudaRoundMinInf && t != 0ULL && ia > 0x80000000) {
    res++;
  }
  else if (rndMode == cudaRoundPosInf && t != 0ULL && (int)ia > 0) {
    res++;
  }
  if ((int)ia < 0) res = (unsigned long long int)-(long long int)res;
  return (long long int)res;
}

static int __internal_float2int(float a, enum cudaRoundMode rndMode)
{
  return (int)__internal_float2ll_kernel(a, 2147483647LL, -2147483648LL, 0LL, rndMode);
}

static int __float2int_rz(float a)
{
  return __internal_float2int(a, cudaRoundZero);
}

static int __float2int_ru(float a)
{
  return __internal_float2int(a, cudaRoundPosInf);
}

static int __float2int_rd(float a)
{
  return __internal_float2int(a, cudaRoundMinInf);
}

static int __float2int_rn(float a)
{
  return __internal_float2int(a, cudaRoundNearest);
}

static long long int __internal_float2ll(float a, enum cudaRoundMode rndMode)
{
  return __internal_float2ll_kernel(a, 9223372036854775807LL, -9223372036854775807LL -1LL, -9223372036854775807LL -1LL, rndMode);
}

static long long int __float2ll_rz(float a)
{
  return __internal_float2ll(a, cudaRoundZero);
}

static long long int __float2ll_ru(float a)
{
  return __internal_float2ll(a, cudaRoundPosInf);
}

static long long int __float2ll_rd(float a)
{
  return __internal_float2ll(a, cudaRoundMinInf);
}

static long long int __float2ll_rn(float a)
{
  return __internal_float2ll(a, cudaRoundNearest);
}

static unsigned long long int __internal_float2ull_kernel(float a, unsigned long long int max, unsigned long long int nan, enum cudaRoundMode rndMode)
{
  unsigned long long int res, t = 0ULL;
  int shift;
  unsigned int ia;

  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= 0LL) return 0LL;
  ia = __float_as_int(a);
  shift = 190 - ((ia >> 23) & 0xff);
  res = (unsigned long long int)((ia << 8) | 0x80000000) << 32;
  if (shift >= 64) {
    t = res >> (int)(shift > 64);
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (rndMode == cudaRoundNearest && (long long int)t < 0LL) {
    res += t == 0x8000000000000000ULL ? res & 1ULL : 1ULL;
  }
  else if (rndMode == cudaRoundPosInf && t != 0ULL) {
    res++;
  }
  return res;
}

static unsigned int __internal_float2uint(float a, enum cudaRoundMode rndMode)
{
  return (unsigned int)__internal_float2ull_kernel(a, 4294967295U, 0U, rndMode);
}

static unsigned int __float2uint_rz(float a)
{
  return __internal_float2uint(a, cudaRoundZero);
}

static unsigned int __float2uint_ru(float a)
{
  return __internal_float2uint(a, cudaRoundPosInf);
}

static unsigned int __float2uint_rd(float a)
{
  return __internal_float2uint(a, cudaRoundMinInf);
}

static unsigned int __float2uint_rn(float a)
{
  return __internal_float2uint(a, cudaRoundNearest);
}

static unsigned long long int __internal_float2ull(float a, enum cudaRoundMode rndMode)
{
  return __internal_float2ull_kernel(a, 18446744073709551615ULL, 9223372036854775808ULL, rndMode);
}

static unsigned long long int __float2ull_rz(float a)
{
  return __internal_float2ull(a, cudaRoundZero);
}

static unsigned long long int __float2ull_ru(float a)
{
  return __internal_float2ull(a, cudaRoundPosInf);
}

static unsigned long long int __float2ull_rd(float a)
{
  return __internal_float2ull(a, cudaRoundMinInf);
}

static unsigned long long int __float2ull_rn(float a)
{
  return __internal_float2ull(a, cudaRoundNearest);
}

static int __internal_normalize64(unsigned long long int *a)
{
  int lz = 0;

  if ((*a & 0xffffffff00000000ULL) == 0ULL) {
    *a <<= 32;
    lz += 32;
  }
  if ((*a & 0xffff000000000000ULL) == 0ULL) {
    *a <<= 16;
    lz += 16;
  }
  if ((*a & 0xff00000000000000ULL) == 0ULL) {
    *a <<= 8;
    lz += 8;
  }
  if ((*a & 0xf000000000000000ULL) == 0ULL) {
    *a <<= 4;
    lz += 4;
  }
  if ((*a & 0xC000000000000000ULL) == 0ULL) {
    *a <<= 2;
    lz += 2;
  }
  if ((*a & 0x8000000000000000ULL) == 0ULL) {
    *a <<= 1;
    lz += 1;
  }
  return lz;
}

static int __internal_normalize(unsigned int *a)
{
  unsigned long long int t = (unsigned long long int)*a;
  int lz = __internal_normalize64(&t);
  
  *a = (unsigned int)(t >> 32);

  return lz - 32;
}

static float __internal_int2float_kernel(int a, enum cudaRoundMode rndMode)
{
  volatile union {
    float f;
    unsigned int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.f;
  if (a < 0) res.i = (unsigned int)-a;
  shift = __internal_normalize((unsigned int*)&res.i);
  t = res.i << 24;
  res.i = (res.i >> 8);
  res.i += (127 + 30 - shift) << 23;
  if (a < 0) res.i |= 0x80000000;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : (t >> 31);
  }
  else if ((rndMode == cudaRoundMinInf) && t && (a < 0)) {
    res.i++;
  }
  else if ((rndMode == cudaRoundPosInf) && t && (a > 0)) {
    res.i++;
  }
  return res.f;
}

static float __int2float_rz(int a)
{
  return __internal_int2float_kernel(a, cudaRoundZero);
}

static float __int2float_ru(int a)
{
  return __internal_int2float_kernel(a, cudaRoundPosInf);
}

static float __int2float_rd(int a)
{
  return __internal_int2float_kernel(a, cudaRoundMinInf);
}

static float __int2float_rn(int a)
{
  return __internal_int2float_kernel(a, cudaRoundNearest);
}

static float __internal_uint2float_kernel(unsigned int a, enum cudaRoundMode rndMode)
{
  volatile union {
    float f;
    unsigned int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.f;
  shift = __internal_normalize((unsigned int*)&res.i);
  t = res.i << 24;
  res.i = (res.i >> 8);
  res.i += (127 + 30 - shift) << 23;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : (t >> 31);
  }
  else if ((rndMode == cudaRoundPosInf) && t) {
    res.i++;
  }
  return res.f;
}

static float __uint2float_rz(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundZero);
}

static float __uint2float_ru(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundPosInf);
}

static float __uint2float_rd(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundMinInf);
}

static float __uint2float_rn(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundNearest);
}

static float __ll2float_rn(long long int a)
{
  return (float)a;
}      

static float __ull2float_rn(unsigned long long int a)
{
  unsigned long long int temp;
  unsigned int res, t;
  int shift;
  if (a == 0ULL) return 0.0f;
  temp = a;
  shift = __internal_normalize64(&temp);
  temp = (temp >> 8) | ((temp & 0xffULL) ? 1ULL : 0ULL);
  res = (unsigned int)(temp >> 32);
  t = (unsigned int)temp;
  res += (127 + 62 - shift) << 23; 
  res += t == 0x80000000 ? res & 1 : t >> 31;
  return __int_as_float(res);
}      

static float __internal_fmul_kernel(float a, float b, int rndNearest)
{
  unsigned long long product;
  volatile union {
    float f;
    unsigned int i;
  } xx, yy;
  unsigned expo_x, expo_y;
    
  xx.f = a;
  yy.f = b;

  expo_y = 0xFF;
  expo_x = expo_y & (xx.i >> 23);
  expo_x = expo_x - 1;
  expo_y = expo_y & (yy.i >> 23);
  expo_y = expo_y - 1;
    
  if ((expo_x <= 0xFD) && 
      (expo_y <= 0xFD)) {
multiply:
    expo_x = expo_x + expo_y;
    expo_y = xx.i ^ yy.i;
    xx.i = xx.i & 0x00ffffff;
    yy.i = yy.i << 8;
    xx.i = xx.i | 0x00800000;
    yy.i = yy.i | 0x80000000;
    
    product = ((unsigned long long)xx.i) * yy.i;
    expo_x = expo_x - 127 + 2;
    expo_y = expo_y & 0x80000000;
    xx.i = (unsigned int)(product >> 32);
    yy.i = (unsigned int)(product & 0xffffffff);
    
    if (xx.i < 0x00800000) {
      xx.i = (xx.i << 1) | (yy.i >> 31);
      yy.i = (yy.i << 1);
      expo_x--;
    }
    if (expo_x <= 0xFD) {
      xx.i = xx.i | expo_y;          
      xx.i = xx.i + (expo_x << 23);  
      
      if (yy.i < 0x80000000) return xx.f;
      xx.i += (((yy.i == 0x80000000) ? (xx.i & 1) : (yy.i >> 31)) 
               && rndNearest);
      return xx.f;
    } else if ((int)expo_x >= 254) {
      
      xx.i = (expo_y | 0x7F800000) - (!rndNearest);
      return xx.f;
    } else {
      
      expo_x = ((unsigned int)-((int)expo_x));
      if (expo_x > 25) {
        
        xx.i = expo_y;
        return xx.f;
      } else {
        yy.i = (xx.i << (32 - expo_x)) | ((yy.i) ? 1 : 0);
        xx.i = expo_y + (xx.i >> expo_x);
        xx.i += (((yy.i == 0x80000000) ? (xx.i & 1) : (yy.i >> 31)) 
                 && rndNearest);
        return xx.f;
      }
    }
  } else {
    product = xx.i ^ yy.i;
    product = product & 0x80000000;
    if (!(xx.i & 0x7fffffff)) {
      if (expo_y != 254) {
        xx.i = (unsigned int)product;
        return xx.f;
      }
      expo_y = yy.i << 1;
      if (expo_y == 0xFF000000) {
        xx.i = expo_y | 0x00C00000;
      } else {
        xx.i = yy.i | 0x00400000;
      }
      return xx.f;
    }
    if (!(yy.i & 0x7fffffff)) {
      if (expo_x != 254) {
        xx.i = (unsigned int)product;
        return xx.f;
      }
      expo_x = xx.i << 1;
      if (expo_x == 0xFF000000) {
        xx.i = expo_x | 0x00C00000;
      } else {
        xx.i = xx.i | 0x00400000;
      }
      return xx.f;
    }
    if ((expo_y != 254) && (expo_x != 254)) {
      expo_y++;
      expo_x++;
      if (expo_x == 0) {
        expo_y |= xx.i & 0x80000000;
        



        xx.i = xx.i << 8;
        while (!(xx.i & 0x80000000)) {
          xx.i <<= 1;
          expo_x--;
        }
        xx.i = (xx.i >> 8) | (expo_y & 0x80000000);
        expo_y &= ~0x80000000;
        expo_y--;
        goto multiply;
      }
      if (expo_y == 0) {
        expo_x |= yy.i & 0x80000000;
        yy.i = yy.i << 8;
        while (!(yy.i & 0x80000000)) {
          yy.i <<= 1;
          expo_y--;
        }
        yy.i = (yy.i >> 8) | (expo_x & 0x80000000);
        expo_x &= ~0x80000000;
        expo_x--;
        goto multiply;
      }
    }
    expo_x = xx.i << 1;
    expo_y = yy.i << 1;
    
    if (expo_x > 0xFF000000) {
      
      xx.i = xx.i | 0x00400000;
      return xx.f;
    }
    
    if (expo_y > 0xFF000000) {
      
      xx.i = yy.i | 0x00400000;
      return xx.f;
    } 
    xx.i = (unsigned int)product | 0x7f800000;
    return xx.f;
  }
}

static float __internal_fadd_kernel(float a, float b, int rndNearest)
{
  volatile union {
    float f;
    unsigned int i;
  } xx, yy;
  unsigned int expo_x;
  unsigned int expo_y;
  unsigned int temp;

  xx.f = a;
  yy.f = b;

  
  expo_y = yy.i << 1;
  if (expo_y > (xx.i << 1)) {
    expo_y = xx.i;
    xx.i   = yy.i;
    yy.i   = expo_y;
  }
    
  temp = 0xff;
  expo_x = temp & (xx.i >> 23);
  expo_x = expo_x - 1;
  expo_y = temp & (yy.i >> 23);
  expo_y = expo_y - 1;
    
  if ((expo_x <= 0xFD) && 
      (expo_y <= 0xFD)) {
        
add:
    expo_y = expo_x - expo_y;
    if (expo_y > 25) {
      expo_y = 31;
    }
    temp = xx.i ^ yy.i;
    xx.i = xx.i & ~0x7f000000;
    xx.i = xx.i |  0x00800000;
    yy.i = yy.i & ~0xff000000;
    yy.i = yy.i |  0x00800000;
        
    if ((int)temp < 0) {
      
      temp = 32 - expo_y;
      temp = (expo_y) ? (yy.i << temp) : 0;
      temp = (unsigned int)(-((int)temp));
      xx.i = xx.i - (yy.i >> expo_y) - (temp ? 1 : 0);
      if (xx.i & 0x00800000) {
        if (expo_x <= 0xFD) {
          xx.i = xx.i & ~0x00800000; 
          xx.i = (xx.i + (expo_x << 23)) + 0x00800000;
          if (temp < 0x80000000) return xx.f;
          xx.i += (((temp == 0x80000000) ? (xx.i & 1) : (temp >> 31))
                   && rndNearest);
          return xx.f;
        }
      } else {
        if ((temp | (xx.i << 1)) == 0) {
          
          xx.i = 0;
          return xx.f;
        }
        
        yy.i = xx.i & 0x80000000;
        do {
          xx.i = (xx.i << 1) | (temp >> 31);
          temp <<= 1;
          expo_x--;
        } while (!(xx.i & 0x00800000));
        xx.i = xx.i | yy.i;
      }
    } else {
      
      temp = 32 - expo_y;
      temp = (expo_y) ? (yy.i << temp) : 0;
      xx.i = xx.i + (yy.i >> expo_y);
      if (!(xx.i & 0x01000000)) {
        if (expo_x <= 0xFD) {
          expo_y = xx.i & 1;
          xx.i = xx.i + (expo_x << 23);
          if (temp < 0x80000000) return xx.f;
          xx.i += (((temp == 0x80000000) ? expo_y : (temp >> 31)) 
                   && rndNearest);
          return xx.f;
        }
      } else {
        
        temp = (xx.i << 31) | (temp >> 1);
        
        xx.i = ((xx.i & 0x80000000) | (xx.i >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
    if (expo_x <= 0xFD) {
      expo_y = xx.i & 1;
      xx.i += (((temp == 0x80000000) ? expo_y : (temp >> 31)) 
               && rndNearest);
      xx.i = xx.i + (expo_x << 23);
      return xx.f;
    }
    if ((int)expo_x >= 254) {
      
        xx.i = ((xx.i & 0x80000000) | 0x7f800000) - (!rndNearest);
        return xx.f;
    }
    
    expo_y = expo_x + 32;
    yy.i = xx.i &  0x80000000;
    xx.i = xx.i & ~0xff000000;
        
    expo_x = (unsigned int)(-((int)expo_x));
    temp = xx.i << expo_y | ((temp) ? 1 : 0);
    xx.i = yy.i | (xx.i >> expo_x);
    xx.i += (((temp == 0x80000000) ? (xx.i & 1) : (temp >> 31)) 
             && rndNearest);
    return xx.f;
  } else {
    
    if (!(yy.i << 1)) {
      if (xx.i == 0x80000000) {
        xx.i = yy.i;
      }
      return xx.f;
    }
    if ((expo_y != 254) && (expo_x != 254)) {
      
      if (expo_x == (unsigned int) -1) {
        temp = xx.i & 0x80000000;
        xx.i = xx.i << 8;
        while (!(xx.i & 0x80000000)) {
          xx.i <<= 1;
          expo_x--;
        }
        expo_x++;
        xx.i = (xx.i >> 8) | temp;
      }
      if (expo_y == (unsigned int) -1) {
        temp = yy.i & 0x80000000;
        yy.i = yy.i << 8;
        while (!(yy.i & 0x80000000)) {
          yy.i <<= 1;
          expo_y--;
        }
        expo_y++;
        yy.i = (yy.i >> 8) | temp;
      }
      goto add;
    }
    expo_x = xx.i << 1;
    expo_y = yy.i << 1;
    
    if (expo_x > 0xff000000) {
      
      xx.i = xx.i | 0x00400000;
      return xx.f;
    }
    
    if (expo_y > 0xff000000) {
      
      xx.i = yy.i | 0x00400000;
      return xx.f;
    }
    if ((expo_x == 0xff000000) && (expo_y == 0xff000000)) {
      



      expo_x = xx.i ^ yy.i;
      xx.i = xx.i | ((expo_x) ? 0xffc00000 : 0);
      return xx.f;
    }
    
    if (expo_y == 0xff000000) {
      xx.i = yy.i;
    }
    return xx.f;
  }
}

static float __fadd_rz(float a, float b)
{
  return __internal_fadd_kernel(a, b, 0);
}

static float __fmul_rz(float a, float b)
{
  return __internal_fmul_kernel(a, b, 0);
}

static float __fdividef(float a, float b)
{
  
  if (__cuda_fabsf(b) > 8.507059173e37f) {
    if (__cuda_fabsf(a) <= 3.402823466e38f) {
      return ((a / b) / 3.402823466e38f) / 3.402823466e38f;
    } else {
      return __int_as_float(0x7fffffff);
    }
  } else {
    return a / b;
  }
}

static void __brkpt(int c)
{
  
}

extern int __stdcall __cudaSynchronizeThreads(void**, void*);














#line 1113 "c:\\cuda\\include\\device_functions.h"




static void __trap(void)
{
  __debugbreak();
}

#line 1123 "c:\\cuda\\include\\device_functions.h"








#line 1132 "c:\\cuda\\include\\device_functions.h"







static float __sinf(float a)
{
  return sinf(a);
}

static float __cosf(float a)
{
  return cosf(a);
}

static float __log2f(float a)
{
  return log2f(a);
}







static float __internal_accurate_fdividef(float a, float b)
{
  if (__cuda_fabsf(b) > 8.507059173e37f) {
    a *= .25f;
    b *= .25f;
  }
  return __fdividef(a, b);
}

static float __tanf(float a)
{
  return __sinf(a) / __cosf(a);
}

static void __sincosf(float a, float *sptr, float *cptr)
{
  *sptr = __sinf(a);
  *cptr = __cosf(a);
}

static float __expf(float a)
{
  return __cuda_exp2f(a * 1.442695041f);
}

static float __exp10f(float a)
{
  return __cuda_exp2f(a * 3.321928094f);
}

static float __log10f(float a)
{
  return 0.301029996f * __log2f(a);
}

static float __logf(float a)
{
  return 0.693147181f * __log2f(a);
}

static float __powf(float a, float b)
{
  return __cuda_exp2f(b * __log2f(a));
}

static float fdividef(float a, float b)
{


#line 1210 "c:\\cuda\\include\\device_functions.h"
  return __internal_accurate_fdividef(a, b);
#line 1212 "c:\\cuda\\include\\device_functions.h"
}

static int __clz(int a)
{
  return (a)?(158-(__float_as_int(__uint2float_rz((unsigned int)a))>>23)):32;
}

static int __ffs(int a)
{
  return 32 - __clz (a & -a);
}

static int __clzll(long long int a)
{
  int ahi = ((int)(a >> 32));
  int alo = ((int)(a & 0xffffffffULL));
  int res;
  if (ahi) {
      res = 0;
  } else {
      res = 32;
      ahi = alo;
  }
  res = res + __clz(ahi);
  return res;
}

static int __ffsll(long long int a)
{
  return 64 - __clzll (a & -a);
}





#line 1249 "c:\\cuda\\include\\device_functions.h"



static double fdivide(double a, double b)
{
  return (double)fdividef((float)a, (float)b);
}



static int __double2int_rz(double a)
{
  return __float2int_rz((float)a);
}

static unsigned int __double2uint_rz(double a)
{
  return __float2uint_rz((float)a);
}

static long long int __double2ll_rz(double a)
{
  return __float2ll_rz((float)a);
}

static unsigned long long int __double2ull_rz(double a)
{
  return __float2ull_rz((float)a);
}

#line 1280 "c:\\cuda\\include\\device_functions.h"

#line 1282 "c:\\cuda\\include\\device_functions.h"

#line 1284 "c:\\cuda\\include\\device_functions.h"







#line 1 "c:\\cuda\\include\\sm_11_atomic_functions.h"















































































































































































































#line 209 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"





























































#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 211 "c:\\cuda\\include\\sm_11_atomic_functions.h"



static int __iAtomicAdd(int *address, int val)
{
  int old = *address;

  *address = old + val;

  return old;
}

static unsigned int __uAtomicAdd(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old + val;

  return old;
}

static int __iAtomicExch(int *address, int val)
{
  int old = *address;

  *address = val;

  return old;
}

static unsigned int __uAtomicExch(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = val;

  return old;
}

static float __fAtomicExch(float *address, float val)
{
  float old = *address;

  *address = val;

  return old;
}

static int __iAtomicMin(int *address, int val)
{
  int old = *address;

  *address = old < val ? old : val;

  return old;
}

static unsigned int __uAtomicMin(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old < val ? old : val;

  return old;
}

static int __iAtomicMax(int *address, int val)
{
  int old = *address;

  *address = old > val ? old : val;

  return old;
}

static unsigned int __uAtomicMax(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old > val ? old : val;

  return old;
}

static unsigned int __uAtomicInc(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = (old >= val) ? 0 : old + 1;

  return old;
}

static unsigned int __uAtomicDec(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = ((old == 0) | (old > val)) ? val : (old - 1);

  return old;
}

static int __iAtomicAnd(int *address, int val)
{
  int old = *address;

  *address = old & val;

  return old;
}

static unsigned int __uAtomicAnd(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old & val;

  return old;
}

static int __iAtomicOr(int *address, int val)
{
  int old = *address;

  *address = old | val;

  return old;
}

static unsigned int __uAtomicOr(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old | val;

  return old;
}

static int __iAtomicXor(int *address, int val)
{
  int old = *address;

  *address = old ^ val;

  return old;
}

static unsigned int __uAtomicXor(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old ^ val;

  return old;
}

static int __iAtomicCAS(int *address, int compare, int val)
{
  int old = *address;

  *address = old == compare ? val : old;

  return old;
}

static unsigned int __uAtomicCAS(unsigned int *address, unsigned int compare, unsigned int val)
{
  unsigned int old = *address;

  *address = old == compare ? val : old;

  return old;
}

#line 386 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 388 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 390 "c:\\cuda\\include\\sm_11_atomic_functions.h"
#line 1292 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\texture_fetch_functions.h"






















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































#line 1976 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1 "c:\\cuda\\include\\host_defines.h"










































































































#line 108 "c:\\cuda\\include\\host_defines.h"
#line 1978 "c:\\cuda\\include\\texture_fetch_functions.h"
#line 1 "c:\\cuda\\include\\crt/func_macro.h"





























































#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 1979 "c:\\cuda\\include\\texture_fetch_functions.h"


























#line 2006 "c:\\cuda\\include\\texture_fetch_functions.h"

extern void __stdcall __cudaTextureFetch(const void *tex, void *index, int integer, void *val);

static int4 __itexfetchi(const void *tex, int4 index)
{
  int4 val;

  __cudaTextureFetch(tex, &index, 1, &val);

  return val;
}

static uint4 __utexfetchi(const void *tex, int4 index)
{
  uint4 val;

  __cudaTextureFetch(tex, &index, 1, &val);

  return val;
}

static float4 __ftexfetchi(const void *tex, int4 index)
{
  float4 val;

  __cudaTextureFetch(tex, &index, 1, &val);

  return val;
}

static int4 __itexfetch(const void *tex, float4 index, int dim)
{
  int4 val;

  __cudaTextureFetch(tex, &index, 0, &val);

  return val;
}

static uint4 __utexfetch(const void *tex, float4 index, int dim)
{
  uint4 val;

  __cudaTextureFetch(tex, &index, 0, &val);

  return val;
}

static float4 __ftexfetch(const void *tex, float4 index, int dim)
{
  float4 val;

  __cudaTextureFetch(tex, &index, 0, &val);

  return val;
}

#line 2064 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 2066 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 2068 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1293 "c:\\cuda\\include\\device_functions.h"

#line 1295 "c:\\cuda\\include\\device_functions.h"

#line 859 "c:\\cuda\\include\\math_functions.h"
#line 1 "c:\\cuda\\include\\math_constants.h"





































































































#line 103 "c:\\cuda\\include\\math_constants.h"
#line 860 "c:\\cuda\\include\\math_functions.h"

static int __cuda___signbitf(float a)
{
  return (int)((unsigned int)__float_as_int(a) >> 31);
}




static float __cuda_copysignf(float a, float b)
{
  return __int_as_float((__float_as_int(b) &  0x80000000) | 
                        (__float_as_int(a) & ~0x80000000));
}









static int min(int a, int b)
{
  return a < b ? a : b;
}

static unsigned int umin(unsigned int a, unsigned int b)
{
  return a < b ? a : b;
}

static int max(int a, int b)
{
  return a > b ? a : b;
}

static unsigned int umax(unsigned int a, unsigned int b)
{
  return a > b ? a : b;
}



static double fmax(double a, double b)
{
  return a > b ? a : b;
}

static double fmin(double a, double b)
{
  return a < b ? a : b;
}

static float fmaxf(float a, float b)
{
  return (float)fmax((double)a, (double)b);
}

static float fminf(float a, float b)
{
  return (float)fmin((double)a, (double)b);
}

static int __signbit(double a)
{
  union {
    double               d;
    signed long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l < 0ll;
}

static double copysign(double a, double b)
{
  union {
    double d;
    unsigned long long int l;
  } cvta, cvtb;
  cvta.d = a;
  cvtb.d = b;
  cvta.l = (cvta.l & 0x7fffffffffffffffULL) | (cvtb.l & 0x8000000000000000ULL);
  return cvta.d;
}

static int __signbitf(float a)
{
  return __cuda___signbitf(a);
}

static float copysignf(float a, float b)
{
  return __cuda_copysignf(a, b);
}

#line 960 "c:\\cuda\\include\\math_functions.h"







static float __internal_nearbyintf(float a)
{
  float fa = fabsf(a);

  if (fa >= 8388608.0f) {
    return a;
  } else {
    volatile float u = 8388608.0f + fa;

    u = u - 8388608.0f;
    return copysignf(u, a);
  }
}

static float __internal_fminf(float a, float b)
{
  volatile union {
    float        f;
    unsigned int i;
  } cvta, cvtb;

  cvta.f = a;
  cvtb.f = b;
  if ((cvta.i << 1) > 0xff000000) return b;
  if ((cvtb.i << 1) > 0xff000000) return a;
  if ((cvta.i | cvtb.i) == 0x80000000) {
    return __int_as_float(0x80000000);
  }
  return a < b ? a : b;
}

static float __internal_fmaxf(float a, float b)
{
  volatile union {
    float        f;
    unsigned int i;
  } cvta, cvtb;

  cvta.f = a;
  cvtb.f = b;
  if ((cvta.i << 1) > 0xff000000) return b;
  if ((cvtb.i << 1) > 0xff000000) return a;
  if ((cvta.f == 0.0f) && (cvtb.f == 0.0f)) {
    cvta.i &= cvtb.i;
    return cvta.f;
  }
  return a > b ? a : b;
}



static double trunc(double a)
{
  return a < 0.0 ? ceil(a) : floor(a);
}

static double nearbyint(double a)
{
  double fa = fabs(a);
  if (fa >= 4503599627370496.0) {
    return a;
  } else {
    double u = 4503599627370496.0 + fa;
    u = u - 4503599627370496.0;
    return copysign(u, a);
  }
}

static float truncf(float a)
{
  return (float)trunc((double)a);
}

static float nearbyintf(float a)
{
  return __internal_nearbyintf(a);
}

#line 1046 "c:\\cuda\\include\\math_functions.h"

#line 1048 "c:\\cuda\\include\\math_functions.h"







static long int __cuda_labs(long int a)
{
  return labs(a);
}

static float __cuda_ceilf(float a)
{
  return ceilf(a);
}

static float __cuda_floorf(float a)
{
  return floorf(a);
}

static float __cuda_sqrtf(float a)
{
   return sqrtf(a);
}

static float __cuda_rsqrtf(float a)
{
   return 1.0f / sqrtf(a);
}

static float __cuda_truncf(float a)
{
  return truncf(a);
}

static int __cuda_max(int a, int b)
{
  return max(a, b);
}

static int __cuda_min(int a, int b)
{
  return min(a, b);
}

static unsigned int __cuda_umax(unsigned int a, unsigned int b)
{
  return umax(a, b);
}

static unsigned int __cuda_umin(unsigned int a, unsigned int b)
{
  return umin(a, b);
}

static long long int __cuda_llrintf(float a)
{
  return __float2ll_rn(a);
}

static long int __cuda_lrintf(float a)
{


#line 1115 "c:\\cuda\\include\\math_functions.h"
  return (long int)__float2int_rn(a);
#line 1117 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_nearbyintf(float a)
{


#line 1124 "c:\\cuda\\include\\math_functions.h"
  return __internal_nearbyintf(a);
#line 1126 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fmaxf(float a, float b)
{


#line 1133 "c:\\cuda\\include\\math_functions.h"
  return __internal_fmaxf(a, b);
#line 1135 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fminf(float a, float b)
{


#line 1142 "c:\\cuda\\include\\math_functions.h"
  return __internal_fminf(a, b);
#line 1144 "c:\\cuda\\include\\math_functions.h"
}

















static int __cuda___finitef(float a)
{
  return __cuda_fabsf(a) < __int_as_float(0x7f800000);
}

static int __cuda___isinff(float a)
{
  return __cuda_fabsf(a) == __int_as_float(0x7f800000);
}

static int __cuda___isnanf(float a)
{
  return !(__cuda_fabsf(a) <= __int_as_float(0x7f800000));
}

static float __cuda_nextafterf(float a, float b)
{
  unsigned int ia;
  unsigned int ib;
  ia = __float_as_int(a);
  ib = __float_as_int(b);



#line 1187 "c:\\cuda\\include\\math_functions.h"
  if (__cuda___isnanf(a) || __cuda___isnanf(b)) return a + b; 
  if (__int_as_float (ia | ib) == 0.0f) return b;




#line 1194 "c:\\cuda\\include\\math_functions.h"
  if (__int_as_float(ia) == 0.0f) {
    return __cuda_copysignf(__int_as_float(0x00000001), b); 
  }
#line 1198 "c:\\cuda\\include\\math_functions.h"
  if ((a < b) && (a < 0.0f)) ia--;
  if ((a < b) && (a > 0.0f)) ia++;
  if ((a > b) && (a < 0.0f)) ia++;
  if ((a > b) && (a > 0.0f)) ia--;
  a = __int_as_float(ia);




#line 1208 "c:\\cuda\\include\\math_functions.h"
  return a;
}

static float __cuda_nanf(const char *tagp)
{
  
  return __int_as_float(0x7fffffff);
}


static float __internal_atanhf_kernel(float a_1, float a_2)
{
  float a, a2, t;

  a = a_1 + a_2;
  a2 = a * a;    
  t =          1.566305595598990E-001f/64.0f;
  t = t * a2 + 1.995081856004762E-001f/16.0f;
  t = t * a2 + 3.333382699617026E-001f/4.0f;
  t = t * a2;
  t = t * a + a_2;
  t = t + a_1;
  return t;
}  




static float __internal_atanf_kernel(float a)
{
  float t4, t0, t1;

  t4 = a * a;
  t0 =         - 5.674867153f;
  t0 = t4 *    - 0.823362947f + t0;
  t0 = t0 * t4 - 6.565555096f;
  t0 = t0 * t4;
  t0 = t0 * a;
  t1 = t4      + 11.33538818f;
  t1 = t1 * t4 + 28.84246826f;
  t1 = t1 * t4 + 19.69667053f;
  t1 = 1.0f / t1;
  a = t0 * t1 + a;
  return a;
}


static float __internal_tan_kernel(float a)
{
  float a2, s, t;

  a2 = a * a;
  t  = 4.114678393115178E-003f * a2 - 8.231194034909670E-001f;
  s  = a2 - 2.469348886157666E+000f;
  s  = 1.0f / s;
  t  = t * s;
  t  = t * a2;
  t  = t * a + a;
  return t;
}

static float __internal_accurate_logf(float a)
{
  float t;
  float z;
  float m;
  int ia, e;
  ia = __float_as_int(a);
  
  if ((ia < 0x00800000) || (ia > 0x7f7fffff)) {
    return __logf(a);
  }
  
  m = __int_as_float((ia & 0x807fffff) | 0x3f800000);
  e = ((unsigned)ia >> 23) - 127;
  if (m > 1.414213562f) {
    m = m * 0.5f;
    e = e + 1;
  }      
  t = m - 1.0f;
  z = m + 1.0f;
  z = t / z;
  z = -t * z;
  z = __internal_atanhf_kernel(t, z);
  z = (float)e * 0.693147181f + z;
  return z;
}  

static float __internal_accurate_log2f(float a)
{
  return 1.442695041f * __internal_accurate_logf(a);
}


static  unsigned int __cudart_i2opi_f [] = {
  0x3c439041,
  0xdb629599,
  0xf534ddc0,
  0xfc2757d1,
  0x4e441529,
  0xa2f9836e,
};


static float __internal_trig_reduction_kernel(float a, int *quadrant)
{
  float j;
  int q;
  if (__cuda_fabsf(a) > 48039.0f) {
    
    unsigned int ia = __float_as_int(a);
    unsigned int s = ia & 0x80000000;
    unsigned int result[7];
    unsigned int phi, plo;
    unsigned int hi, lo;
    unsigned int e;
    int idx;
    e = ((ia >> 23) & 0xff) - 128;
    ia = (ia << 8) | 0x80000000;
    
    idx = 4 - (e >> 5);
    hi = 0;


#line 1333 "c:\\cuda\\include\\math_functions.h"
    for (q = 0; q < 6; q++) {
      plo = __cudart_i2opi_f[q] * ia;
      phi = __umulhi (__cudart_i2opi_f[q], ia);
      lo = hi + plo;
      hi = phi + (lo < plo);
      result[q] = lo;
    }
    result[q] = hi;
    e = e & 31;
    


    hi = result[idx+2];
    lo = result[idx+1];
    if (e) {
      q = 32 - e;
      hi = (hi << e) | (lo >> q);
      lo = (lo << e) | (result[idx] >> q);
    }
    q = hi >> 30;
    
    hi = (hi << 2) | (lo >> 30);
    lo = (lo << 2);
    e = (hi + (lo > 0)) > 0x80000000; 
    q += e;
    if (s) q = -q;
    if (e) {
      unsigned int t;
      hi = ~hi;
      lo = -(int)lo;
      t = (lo == 0);
      hi += t;
      s = s ^ 0x80000000;
    }
    *quadrant = q;
    
    e = 0;
    while ((int)hi > 0) {
      hi = (hi << 1) | (lo >> 31);
      lo = (lo << 1);
      e--;
    }
    lo = hi * 0xc90fdaa2;
    hi = __umulhi(hi, 0xc90fdaa2);
    if ((int)hi > 0) {
      hi = (hi << 1) | (lo >> 31);
      lo = (lo << 1);
      e--;
    }
    hi = hi + (lo > 0);
    ia = s | (((e + 126) << 23) + (hi >> 8) + ((hi << 24) >= 0x80000000));
    return __int_as_float(ia);
  }
  q = __float2int_rn(a * 0.636619772f);
  j = (float)q;
  a = a - j * 1.5703125000000000e+000f;
  a = a - j * 4.8351287841796875e-004f;
  a = a - j * 3.1385570764541626e-007f;
  a = a - j * 6.0771005065061922e-011f;
  *quadrant = q;
  return a;
}










static float __internal_expf_kernel(float a, float scale)
{
  float j, z;

  j = __cuda_truncf(a * 1.442695041f);
  z = a - j * 0.6931457519f;
  z = z - j * 1.4286067653e-6f;
  z = z * 1.442695041f;
  z = __cuda_exp2f(z) * __cuda_exp2f(j + scale);
  return z;
}

static float __internal_accurate_expf(float a)
{
  float z;
  z = __internal_expf_kernel(a, 0.0f);
  if (a < -105.0f) z = 0.0f;
  if (a >  105.0f) z = __int_as_float(0x7f800000);
  return z;
}

static float __internal_accurate_exp10f(float a)
{
  float j, z;
  j = __cuda_truncf(a * 3.321928094f);
  z = a - j * 3.0102920532226563e-001f;
  z = z - j * 7.9034171557301747e-007f;
  z = z * 3.321928094f;
  z = __cuda_exp2f(z) * __cuda_exp2f(j);
  if (a < -46.0f) z = 0.0f;
  if (a >  46.0f) z = __int_as_float(0x7f800000);
  return z;
}

static float __internal_lgammaf_pos(float a)
{
  float sum;
  float s, t;

  if (__cuda___isinff(a)) {
    return a;
  }
  if (a >= 3.0f) {
    if (a >= 7.8f) {
      


      s = 1.0f / a;
      t = s * s;
      sum =           0.77783067e-3f;
      sum = sum * t - 0.2777655457e-2f;
      sum = sum * t + 0.83333273853e-1f;
      sum = sum * s + 0.918938533204672f;
      s = 0.5f * __internal_accurate_logf(a);
      t = a - 0.5f;
      s = s * t;
      t = s - a;
      s = s + sum;
      t = t + s;
      return t;
    } else {
      a = a - 3.0f;
      s =       - 7.488903254816711E+002f;
      s = s * a - 1.234974215949363E+004f;
      s = s * a - 4.106137688064877E+004f;
      s = s * a - 4.831066242492429E+004f;
      s = s * a - 1.430333998207429E+005f;
      t =     a - 2.592509840117874E+002f;
      t = t * a - 1.077717972228532E+004f;
      t = t * a - 9.268505031444956E+004f;
      t = t * a - 2.063535768623558E+005f;
      t = s / t;
      t = t + a;
      return t;
    }
  } else if (a >= 1.5f) {
    a = a - 2.0f;
    t =       + 4.959849168282574E-005f;
    t = t * a - 2.208948403848352E-004f;
    t = t * a + 5.413142447864599E-004f;
    t = t * a - 1.204516976842832E-003f;
    t = t * a + 2.884251838546602E-003f;
    t = t * a - 7.382757963931180E-003f;
    t = t * a + 2.058131963026755E-002f;
    t = t * a - 6.735248600734503E-002f;
    t = t * a + 3.224670187176319E-001f;
    t = t * a + 4.227843368636472E-001f;
    t = t * a;
    return t;
  } else if (a >= 0.7f) {
    a = 1.0f - a;
    t =       + 4.588266515364258E-002f;
    t = t * a + 1.037396712740616E-001f;
    t = t * a + 1.228036339653591E-001f;
    t = t * a + 1.275242157462838E-001f;
    t = t * a + 1.432166835245778E-001f;
    t = t * a + 1.693435824224152E-001f;
    t = t * a + 2.074079329483975E-001f;
    t = t * a + 2.705875136435339E-001f;
    t = t * a + 4.006854436743395E-001f;
    t = t * a + 8.224669796332661E-001f;
    t = t * a + 5.772156651487230E-001f;
    t = t * a;
    return t;
  } else {
    t =       + 3.587515669447039E-003f;
    t = t * a - 5.471285428060787E-003f;
    t = t * a - 4.462712795343244E-002f;
    t = t * a + 1.673177015593242E-001f;
    t = t * a - 4.213597883575600E-002f;
    t = t * a - 6.558672843439567E-001f;
    t = t * a + 5.772153712885004E-001f;
    t = t * a;
    t = t * a + a;
    return -__internal_accurate_logf(t);
  }
}


static float __internal_sin_kernel(float x)
{
  float x2, z;

  x2 = x * x;
  z  =        - 1.95152959e-4f;
  z  = z * x2 + 8.33216087e-3f;
  z  = z * x2 - 1.66666546e-1f;
  z  = z * x2;
  z  = z * x + x;

  return z;
}


static float __internal_cos_kernel(float x)
{
  float x2, z;

  x2 = x * x;
  z  =          2.44331571e-5f;
  z  = z * x2 - 1.38873163e-3f;
  z  = z * x2 + 4.16666457e-2f;
  z  = z * x2 - 5.00000000e-1f;
  z  = z * x2 + 1.00000000e+0f;
  return z;
}

static float __internal_accurate_sinf(float a)
{
  float z;
  int   i;

  if (__cuda___isinff(a)) {
    return __int_as_float(0x7fffffff);
  }
  if (a == 0.0f) {
    return a;
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  if (i & 1) {
    z = __internal_cos_kernel(z);
  } else {
    z = __internal_sin_kernel(z);
  }
  if (i & 2) {
    z = -z;
  }
  return z;
}







static float __cuda_rintf(float a)
{
  return __cuda_nearbyintf(a);
}

static float __cuda_sinf(float a)
{


#line 1592 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_sinf(a);
#line 1594 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_cosf(float a)
{


#line 1601 "c:\\cuda\\include\\math_functions.h"
  float z;
  int i;

  if (__cuda___isinff(a)) {
    return __int_as_float(0x7fffffff);
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  i++;
  if (i & 1) {
    z = __internal_cos_kernel(z);
  } else {
    z = __internal_sin_kernel(z);
  }
  if (i & 2) {
    z = -z;
  }
  return z;
#line 1620 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_tanf(float a)
{


#line 1627 "c:\\cuda\\include\\math_functions.h"
  float z;
  int   i;

  if (__cuda___isinff(a)) {
    return __int_as_float(0x7fffffff);
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  z = __internal_tan_kernel(z);
  if (i & 1) {
    z = -1.0f / z;
  }
  return z;
#line 1641 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log2f(float a)
{


#line 1648 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_log2f(a);
#line 1650 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_expf(float a)
{


#line 1657 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_expf(a);
#line 1659 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_exp10f(float a)
{


#line 1666 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_exp10f(a);
#line 1668 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_coshf(float a)
{
  float z;

  a = __cuda_fabsf(a);
  z = __internal_expf_kernel(a, -2.0f);
  z = 2.0f * z + 0.125f / z;
  if (a >= 90.0f) {
    z = __int_as_float(0x7f800000);     
  }
  return z;
}

static float __cuda_sinhf(float a)
{
  float s, z;

  s = a;
  a = __cuda_fabsf(a);
  if (a < 1.0f) {         
    float a2 = a * a;
    
    z =          2.816951222e-6f;
    z = z * a2 + 1.983615978e-4f;
    z = z * a2 + 8.333350058e-3f;
    z = z * a2 + 1.666666650e-1f;
    z = z * a2;
    z = z * a + a;
  } else {
    z = __internal_expf_kernel(a, -2.0f);
    z = 2.0f * z - 0.125f / z;
    if (a >= 90.0f) {
      z = __int_as_float(0x7f800000);     
    }
  }
  return __cuda_copysignf(z, s);
}

static float __cuda_tanhf(float a)
{
  float t;

  t = __cuda_fabsf(a);
  if (t < 0.55f) {
    float z, z2;
    z = t;
    z2 = z * z;
    t =          1.643758066599993e-2f;
    t = t * z2 - 5.267181327760551e-2f;
    t = t * z2 + 1.332072505223051e-1f;
    t = t * z2 - 3.333294663641083e-1f;
    t = t * z2;
    t = t * z + z;
  } 
  else if (t < 88.0f) {
    t = 1.0f - 2.0f / (__internal_expf_kernel(2.0f * t, 0.0f) + 1.0f);
  }
  else if (t >= 88.0f) {
    t = 1.0f;
  }
  return __cuda_copysignf(t, a);
}

static float __cuda_atan2f(float a, float b)
{
  float t0, t1, t3;

  
  
  t3 = __cuda_fabsf(b);
  t1 = __cuda_fabsf(a);

  if (t3 == 0.0f && t1 == 0.0f) {
    t3 = __cuda___signbitf(b) ? 3.141592654f : 0;
  } else if (__cuda___isinff(t3) && __cuda___isinff(t1)) {
    t3 = __cuda___signbitf(b) ? 2.356194490f : 0.785398163f;
  } else {
    
    if (t3 < t1) {
      t0 = t1;
      t1 = t3;
    } else {
      t0 = t3;
      t1 = t1;
    }
    t3 = __internal_accurate_fdividef(t1, t0);
    t3 = __internal_atanf_kernel(t3);
    
    if (__cuda_fabsf(a) > __cuda_fabsf(b)) t3 = 1.570796327f - t3;
    if (b < 0.0f)                          t3 = 3.141592654f - t3;
  }
  t3 = __cuda_copysignf(t3, a);

  return t3;
}

static float __cuda_atanf(float a)
{
  float t0, t1;

  
  t0 = __cuda_fabsf(a);
  t1 = t0;
  if (t0 > 1.0f) {
    t1 = 1.0f / t1;
  }
  
  t1 = __internal_atanf_kernel(t1);
  
  if (t0 > 1.0f) {
    t1 = 1.570796327f - t1;
  }
  return __cuda_copysignf(t1, a);
}


static float __internal_asinf_kernel(float a)
{
  float t2, t3, t4;

  t2 = a * a;
  t3 =         - 0.501162291f;
  t3 = t3 * t2 + 0.915201485f;
  t3 = t3 * t2;
  t3 = t3 * a;
  t4 = t2      - 5.478654385f;
  t4 = t4 * t2 + 5.491230488f;
  t4 = 1.0f / t4;
  a = t3 * t4 + a;
  return a;
}

static float __cuda_asinf(float a)
{
  float t0, t1, t2;

  t0 = __cuda_fabsf(a);
  t2 = 1.0f - t0;
  t2 = 0.5f * t2;
  t2 = __cuda_sqrtf(t2);
  t1 = t0 > 0.575f ? t2 : t0;
  t1 = __internal_asinf_kernel(t1);
  t2 = -2.0f * t1 + 1.570796327f;
  if (t0 > 0.575f) {
    t1 = t2;
  }
  return __cuda_copysignf(t1, a);
}

static float __cuda_acosf(float a)
{
  float t0, t1, t2;

  t0 = __cuda_fabsf(a);
  t2 = 1.0f - t0;
  t2 = 0.5f * t2;
  t2 = __cuda_sqrtf(t2);
  t1 = t0 > 0.575f ? t2 : t0;
  t1 = __internal_asinf_kernel(t1);
  t1 = t0 > 0.575f ? 2.0f * t1 : 1.570796327f - t1;
  if (__cuda___signbitf(a)) {
    t1 = 3.141592654f - t1;
  }
  return t1;
}

static float __cuda_logf(float a)
{


#line 1841 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_logf(a);
#line 1843 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log10f(float a)
{


#line 1850 "c:\\cuda\\include\\math_functions.h"
  return 0.434294482f * __internal_accurate_logf(a);
#line 1852 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log1pf(float a)
{
  float t;

  
  if (a == 0.0f) return a;
#line 1861 "c:\\cuda\\include\\math_functions.h"
  if (a >= -0.394f && a <= 0.65f) {
    
    t = a + 2.0f;
    t = a / t;
    t = -a * t;
    t = __internal_atanhf_kernel (a, t);
  } else {
    t = __internal_accurate_logf (1.0f + a);
  }
  return t;
}

static float __cuda_acoshf(float a)
{
  float s, t;

  t = a - 1.0f;
  if (__cuda_fabsf(t) > 8388608.0f) {
    
    return 0.693147181f + __internal_accurate_logf(a);
  } else {
    s = a + 1.0f;
    t = t + __cuda_sqrtf(s * t);
    return __cuda_log1pf(t);
  }
}

static float __cuda_asinhf(float a)
{
  float fa, oofa, t;

  fa = __cuda_fabsf(a);
  if (fa > 8.507059173e37f) {   
    t = 0.693147181f + __logf(fa);  
  } else {
    oofa = 1.0f / fa;
    t = fa + fa / (oofa + __cuda_sqrtf(1.0f + oofa * oofa));
    t = __cuda_log1pf(t);
  }
  return __cuda_copysignf(t, a);
}

static float __cuda_atanhf(float a)
{
  float fa, t;

  fa = __cuda_fabsf(a);
  t = (2.0f * fa) / (1.0f - fa);
  t = 0.5f * __cuda_log1pf(t);
  return __cuda_copysignf(t, a);
}

static float __cuda_expm1f(float a)
{
  float t, z, j, u;
  
  t = __cuda_rintf (a * 1.442695041f);
  z = a - t * 0.6931457519f;
  z = z - t * 1.4286067653e-6f;
  
  if (__cuda_fabsf(a) < 0.41f) {
    z = a;
    t = 0.0f;
  }
  
  j = t;
  if (t == 128.0f) j = j - 1.0f; 
  
  u =         1.38795078474044430E-003f;
  u = u * z + 8.38241261853264930E-003f;
  u = u * z + 4.16678317762833940E-002f;
  u = u * z + 1.66663978874356580E-001f;
  u = u * z + 4.99999940395997040E-001f;
  u = u * z;
  u = u * z + z;
  if (a == 0.0f) u = a;            
  
  z = __cuda_exp2f (j);
  a = z - 1.0f;
  if (a != 0.0f)   u = u * z + a;  
  if (t == 128.0f) u = u + u;      
  
  if (j >  128.0f) u = __int_as_float(0x7f800000);
  if (j <  -25.0f) u = -1.0f;
  return u;
}

static float __cuda_hypotf(float a, float b)
{
  float v, w, t;

  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  
  if (a > b) {
    v = a;
    w = b; 
  } else {
    v = b;
    w = a;
  }
  t = __internal_accurate_fdividef(w, v);
  t = 1.0f + t * t;
  t = v * __cuda_sqrtf(t);
  if (v == 0.0f) {
    t = v + w;
  }
  if ((v == __int_as_float(0x7f800000)) || (w == __int_as_float(0x7f800000))) {
    t = __int_as_float(0x7f800000);
  }
  return t;
}

static float __cuda_cbrtf(float a)
{
  float s, t;
  if (a == 0.0f || __cuda___isinff(a)) {
    return a;
  } 
  s = __cuda_fabsf(a);
  t = __cuda_exp2f(0.333333333f * __log2f(s)); 
  t = t - (t - (s / (t * t))) * 0.333333333f;  
  if (__cuda___signbitf(a)) {
     t = -t;
  }
  return t;
}

static float __cuda_erff(float a)
{
  float t, r, q;

  t = __cuda_fabsf(a);
  if (t < 1.0f) {
    t = t * t;
    r =        -5.58510127926029810E-004f;
    r = r * t + 4.90688891415893070E-003f;
    r = r * t - 2.67027980930150640E-002f;
    r = r * t + 1.12799056505903940E-001f;
    r = r * t - 3.76122956138427440E-001f;
    r = r * t + 1.12837911712623450E+000f;
    a = a * r;
  } else if (t <= __int_as_float(0x7f800000)) { 
    


    q = 0.3275911f * t + 1.0f;
    q = 1.0f / q;
    r =         1.061405429f;
    r = r * q - 1.453152027f;
    r = r * q + 1.421413741f;
    r = r * q - 0.284496736f;
    r = r * q + 0.254829592f;
    r = r * q;
    q = __internal_expf_kernel(-a * a, 0.0f);
    r = 1.0f - q * r;
    if (t >= 5.5f) {
      r = 1.0f;
    }
    a = __int_as_float (__float_as_int(r) | (__float_as_int(a) & 0x80000000));
  }
  return a;
}

static float __cuda_erfcf(float a)
{
  if (a <= 0.55f) {
    return 1.0f - __cuda_erff(a);
  } else if (a > 10.0f) {
    return 0.0f;
  } else {
    float p;
    float q;
    float h;
    float l;
    



    p =       + 4.014893410762552E-006f;
    p = p * a + 5.640401259462436E-001f;
    p = p * a + 2.626649872281140E+000f;
    p = p * a + 5.486372652389673E+000f;
    p = p * a + 5.250714831459401E+000f;
    q =     a + 4.651376250488319E+000f;
    q = q * a + 1.026302828878470E+001f;
    q = q * a + 1.140762166021288E+001f;
    q = q * a + 5.251211619089947E+000f;
    
    h = 1.0f / q;
    q = 2.0f * h - q * h * h;
    p = p * q;
    
    h = __int_as_float(__float_as_int(a) & 0xfffff000);  
    l = a - h;  
    q = -h * h; 
    q = __internal_expf_kernel(q, 0.0f);
    if (l != 0.0f) {
      a = a + h;
      l = l * a;
      h = __internal_expf_kernel(-l, 0.0f);
      q = q * h;
    }
    p = p * q;
    return p;
  }
}

static float __cuda_lgammaf(float a)
{
  float t;
  float i;
  int quot;
  t = __internal_lgammaf_pos(__cuda_fabsf(a));
  if (a >= 0.0f) return t;
  a = __cuda_fabsf(a);
  i = __cuda_floorf(a);                   
  if (a == i) return __int_as_float(0x7f800000); 
  if (a < 1e-19f) return -__internal_accurate_logf(a);
  i = __cuda_rintf (2.0f * a);
  quot = (int)i;
  i = a - 0.5f * i;
  i = i * 3.141592654f;
  if (quot & 1) {
    i = __internal_cos_kernel(i);
  } else {
    i = __internal_sin_kernel(i);
  }
  i = __cuda_fabsf(i);
  t = 1.144729886f - __internal_accurate_logf(i * a) - t;
  return t;
}

static float __cuda_ldexpf(float a, int b)
{
  float fa = __cuda_fabsf(a);

  if (fa == 0.0f || __cuda___isinff(fa) || b == 0) {
    return a;
  } 
  else if (__cuda_abs(b) < 126) {
    return a * __cuda_exp2f((float)b);
  }
  else if (__cuda_abs(b) < 252) {
    int bhalf = b / 2;
    return a * __cuda_exp2f((float)bhalf) * __cuda_exp2f((float)(b - bhalf));
  } 
  else {
    int bquarter = b / 4;
    float t = __cuda_exp2f((float)bquarter);
    return a * t * t * t * __cuda_exp2f((float)(b - 3 * bquarter));
  }
}

static float __cuda_scalbnf(float a, int b)
{
  
  return __cuda_ldexpf(a, b);
}

static float __cuda_scalblnf(float a, long int b)
{
  int t;
  if (b > 2147483647L) {
    t = 2147483647;
  } else if (b < (-2147483647 - 1)) {
    t = (-2147483647 - 1);
  } else {
    t = (int)b;
  }
  return __cuda_scalbnf(a, t);
}

static float __cuda_frexpf(float a, int *b)
{
  float fa = __cuda_fabsf(a);
  unsigned int expo;
  unsigned int denorm;

  if (fa < 1.175494351e-38f) {
    a *= 16777216.0f;
    denorm = 24;
  } else {
    denorm = 0;
  }
  expo = ((__float_as_int(a) >> 23) & 0xff);
  if ((fa == 0.0f) || (expo == 0xff)) {
    expo = 0;
    a = a + a;
  } else {  
    expo = expo - denorm - 126;
    a = __int_as_float(((__float_as_int(a) & 0x807fffff) | 0x3f000000));
  }
  *b = expo;
  return a;
}

static float __cuda_modff(float a, float *b)
{
  float t;
  if (__cuda___finitef(a)) {
    t = __cuda_truncf(a);
    *b = t;
    t = a - t;
    return __cuda_copysignf(t, a);
  } else if (__cuda___isinff(a)) {
    t = 0.0f;
    *b = a;
    return __cuda_copysignf(t, a);
  } else {
    *b = a; 
    return a;
  }
}

static float __cuda_fmodf(float a, float b)
{
  float orig_a;

  if (__cuda___isnanf(a) || __cuda___isnanf(b)) {
    return a + b;
  }
  orig_a = a;
  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (__cuda___isinff(a) || b == 0.0f) {
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    
    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }






#line 2207 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      if (a >= scaled_b) {
        a -= scaled_b;
      }
      scaled_b *= 0.5f;
    }
    return __cuda_copysignf(a, orig_a);
  } else {
    return orig_a;
  }
}

static float __cuda_remainderf(float a, float b)
{
  float orig_a;
  float twoa = 0.0f;
  unsigned int quot0 = 0;  

  if (__cuda___isnanf(a) || __cuda___isnanf(b)) {
    return a + b;
  }
  orig_a = a;
  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (__cuda___isinff(a) || (b == 0.0f)) {
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }










#line 2255 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      quot0 = 0;
      if (a >= scaled_b) {
        twoa = (2.0f * a - scaled_b) - scaled_b;
        a -= scaled_b;
        quot0 = 1;
      }
      scaled_b *= 0.5f;
    }
  }
  

  twoa = 2.0f * a;
  if ((twoa > b) || ((twoa == b) && quot0)) {
    a -= b;
    a = __cuda_copysignf (a, -1.0f);
  }














#line 2287 "c:\\cuda\\include\\math_functions.h"
  a = __int_as_float((__float_as_int(orig_a) & 0x80000000)^
                     __float_as_int(a));
  return a;
}

static float __cuda_remquof(float a, float b, int* quo)
{
  float orig_a;
  float twoa = 0.0f;
  unsigned int quot = 0;  
  unsigned int sign;

  if (__cuda___isnanf(a) || __cuda___isnanf(b)) {
    *quo = quot;
    return a + b;
  }
  orig_a = a;
  
  sign = 0 - (__cuda___signbitf(a) != __cuda___signbitf(b));
  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (__cuda___isinff(a) || (b == 0.0f)) {
    *quo = quot;
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    
    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }
















#line 2340 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      quot <<= 1;
      if (a >= scaled_b) {
        twoa = (2.0f * a - scaled_b) - scaled_b;
        a -= scaled_b;
        quot += 1;
      }
      scaled_b *= 0.5f;
    }
  }
  

  twoa = 2.0f * a;
  if ((twoa > b) || ((twoa == b) && (quot & 1))) {
    quot++;
    a -= b;
    a = __cuda_copysignf (a, -1.0f);
  }
















#line 2375 "c:\\cuda\\include\\math_functions.h"
  a = __int_as_float((__float_as_int(orig_a) & 0x80000000)^
                     __float_as_int(a));
  quot = quot & (~((~0)<<3));
  quot = quot ^ sign;
  quot = quot - sign;
  *quo = quot;
  return a;
}

static float __cuda_fmaf(float a, float b, float c)
{
  unsigned int xx, yy, zz, ww;
  unsigned int temp, s, u;
  unsigned int expo_x, expo_y, expo_z;

  xx = __float_as_int(a);
  yy = __float_as_int(b);
  zz = __float_as_int(c);






#line 2400 "c:\\cuda\\include\\math_functions.h"

  temp = 0xff;
  expo_x = temp & (xx >> 23);
  expo_x = expo_x - 1;
  expo_y = temp & (yy >> 23);
  expo_y = expo_y - 1;
  expo_z = temp & (zz >> 23);
  expo_z = expo_z - 1;

  if (!((expo_x <= 0xFD) && 
        (expo_y <= 0xFD) &&
        (expo_z <= 0xFD))) {
    



    if ((yy << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    if ((zz << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    if ((xx << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    










    if ((((xx << 1) == 0) && ((yy << 1) == 0xff000000)) ||
        (((yy << 1) == 0) && ((xx << 1) == 0xff000000))) {
      return __int_as_float(0x7fffffff);
    }
    if ((zz << 1) == 0xff000000) {
      if (((yy << 1) == 0xff000000) || ((xx << 1) == 0xff000000)) {
        if ((int)(xx ^ yy ^ zz) < 0) {
          return __int_as_float(0x7fffffff);
        }
      }
    }
    



    if ((xx << 1) == 0xff000000) {
      xx = xx ^ (yy & 0x80000000);
      return __int_as_float(xx);
    }
    if ((yy << 1) == 0xff000000) {
      yy = yy ^ (xx & 0x80000000);
      return __int_as_float(yy);
    }
    if ((zz << 1) == 0xff000000) {
      return __int_as_float(zz);
    }
    




    if (zz == 0x80000000) {
      if (((xx << 1) == 0) || ((yy << 1) == 0)) {
        if ((int)(xx ^ yy) < 0) {
          return __int_as_float(zz);
        }
      }
    }
    


    if (((zz << 1) == 0) && 
        (((xx << 1) == 0) || ((yy << 1) == 0))) {
      zz &= 0x7fffffff;
      return __int_as_float(zz);
    }
    


    if (((xx << 1) == 0) || ((yy << 1) == 0)) {
      return __int_as_float(zz);
    }
    
    if (expo_x == (unsigned int)-1) {
      temp = xx & 0x80000000;
      xx = xx << 8;
      while (!(xx & 0x80000000)) {
        xx <<= 1;
        expo_x--;
      }
      expo_x++;
      xx = (xx >> 8) | temp;
    }
    
    if (expo_y == (unsigned int)-1) {
      temp = yy & 0x80000000;
      yy = yy << 8;
      while (!(yy & 0x80000000)) {
        yy <<= 1;
        expo_y--;
      }
      expo_y++;
      yy = (yy >> 8) | temp;
    }
    
    if ((expo_z == (unsigned int)-1) && ((zz << 1) != 0)) {
      temp = zz & 0x80000000;
      zz = zz << 8;
      while (!(zz & 0x80000000)) {
        zz <<= 1;
        expo_z--;
      }
      expo_z++;
      zz = (zz >> 8) | temp;
    }
  }
    
  expo_x = expo_x + expo_y;
  expo_y = xx ^ yy;
  xx = xx & 0x00ffffff;
  yy = yy << 8;
  xx = xx | 0x00800000;
  yy = yy | 0x80000000;
  
  s = __umulhi(xx, yy);
  yy = xx * yy;
  xx = s;
  expo_x = expo_x - 127 + 2;
  expo_y = expo_y & 0x80000000;

  
  if (xx < 0x00800000) {
      xx = (xx << 1) | (yy >> 31);
      yy = (yy << 1);
      expo_x--;
  }
  temp = 0;
  if ((zz << 1) != 0) { 
    s = zz & 0x80000000;
    zz &= 0x00ffffff;
    zz |= 0x00800000;
    ww = 0;
    
    if ((int)expo_z > (int)expo_x) {
      temp = expo_z;
      expo_z = expo_x;
      expo_x = temp;
      temp = zz;
      zz = xx;
      xx = temp;
      temp = ww;
      ww = yy;
      yy = temp;
      temp = expo_y;
      expo_y = s;
      s = temp;
    }
    
    
    expo_z = expo_x - expo_z;
    u = expo_y ^ s;
    if (expo_z <= 49) {
      
      temp = 0;
      while (expo_z >= 32) {
        temp = ww | (temp != 0);
        ww = zz;
        zz = 0;
        expo_z -= 32;
      }
      if (expo_z) {
        temp = ((temp >> expo_z) | (ww << (32 - expo_z)) | 
                ((temp << (32 - expo_z)) != 0));
        ww = (ww >> expo_z) | (zz << (32 - expo_z));
        zz = (zz >> expo_z);
      }
    } else {
      temp = 1;
      ww = 0;
      zz = 0;
    }            
    if ((int)u < 0) {
      
      temp = (unsigned)(-(int)temp);
      s = (temp != 0);
      u = yy - s;
      s = u > yy;
      yy = u - ww;
      s += yy > u;
      xx = (xx - zz) - s;
      if (!(xx | yy | temp)) {
        
        return __int_as_float(xx);
      }
      if ((int)xx < 0) {
        


        temp = ~temp;
        yy = ~yy;
        xx = ~xx;
        if (++temp == 0) {
          if (++yy == 0) {
            ++xx;
          }
        }
        expo_y ^= 0x80000000;
      }
      
      while (!(xx & 0x00800000)) {
        xx = (xx << 1) | (yy >> 31);
        yy = (yy << 1);
        expo_x--;
      }
    } else {
      
      yy = yy + ww;
      s =  yy < ww;
      xx = xx + zz + s;
      if (xx & 0x01000000) {
        temp = temp | (yy << 31);
        yy = (yy >> 1) | (xx << 31);
        xx = ((xx & 0x80000000) | (xx >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
  }
  temp = yy | (temp != 0);
  if (expo_x <= 0xFD) {
    
    xx |= expo_y; 
    s = xx & 1; 
    xx += (temp == 0x80000000) ? s : (temp >> 31);
    xx = xx + (expo_x << 23); 
    return __int_as_float(xx);
  } else if ((int)expo_x >= 126) {
    
    xx = expo_y | 0x7f800000;
    return __int_as_float(xx);
  }
  
  expo_x = (unsigned int)(-(int)expo_x);
  if (expo_x > 25) {
    
    return __int_as_float(expo_y);
  }
  yy = (xx << (32 - expo_x)) | ((yy) ? 1 : 0);
  xx = expo_y + (xx >> expo_x);
  xx = xx + ((yy==0x80000000) ? (xx & 1) : (yy >> 31));
  xx |= expo_y; 



#line 2660 "c:\\cuda\\include\\math_functions.h"
  return __int_as_float(xx);
}

static  float __cudart_A1[32] = 
{
  1.0000000000e+000f,
  1.0218971968e+000f,
  1.0442737341e+000f,
  1.0671404600e+000f,
  1.0905077457e+000f,
  1.1143867970e+000f,
  1.1387885809e+000f,
  1.1637248993e+000f,
  1.1892070770e+000f,
  1.2152473927e+000f,
  1.2418577671e+000f,
  1.2690509558e+000f,
  1.2968395948e+000f,
  1.3252366781e+000f,
  1.3542555571e+000f,
  1.3839099407e+000f,
  1.4142135382e+000f,
  1.4451807737e+000f,
  1.4768261909e+000f,
  1.5091644526e+000f,
  1.5422108173e+000f,
  1.5759809017e+000f,
  1.6104903221e+000f,
  1.6457555294e+000f,
  1.6817928553e+000f,
  1.7186193466e+000f,
  1.7562521696e+000f,
  1.7947090864e+000f,
  1.8340080976e+000f,
  1.8741676807e+000f,
  1.9152065516e+000f,
  1.9571441412e+000f
};

static  float __cudart_A2[32] = 
{
  0.0000000000e+000f,
 -4.8115598617e-008f,
  4.8334701575e-008f,
 -5.9337519787e-008f,
 -1.3077539940e-008f,
 -5.4355400181e-008f,
  5.3862223126e-008f,
 -4.0514414934e-008f,
  3.7976352729e-008f,
 -3.2673948880e-008f,
  4.4968381019e-008f,
  1.4193333175e-009f,
 -4.0189995332e-008f,
 -3.4963733242e-008f,
 -1.0123349270e-008f,
 -5.8755773580e-008f,
  2.4203234972e-008f,
  3.3241999375e-008f,
 -4.5008988536e-008f,
 -2.4959373235e-008f,
  8.0709048333e-009f,
 -5.6610254262e-008f,
  9.8362171741e-009f,
 -5.1249720912e-008f,
 -2.4755326677e-008f,
 -4.8496175964e-008f,
 -9.2357703707e-009f,
 -1.1415044909e-008f,
 -1.1239277953e-008f,
 -4.6630056261e-008f,
  9.8453281083e-009f,
 -1.7021804410e-008f
};

static  float __cudart_Ainv[32] = 
{
  1.0000000000e+000f,
  9.7857207060e-001f,
  9.5760327578e-001f,
  9.3708384037e-001f,
  9.1700404882e-001f,
  8.9735454321e-001f,
  8.7812608480e-001f,
  8.5930967331e-001f,
  8.4089642763e-001f,
  8.2287776470e-001f,
  8.0524516106e-001f,
  7.8799045086e-001f,
  7.7110540867e-001f,
  7.5458222628e-001f,
  7.3841309547e-001f,
  7.2259038687e-001f,
  7.0710676908e-001f,
  6.9195497036e-001f,
  6.7712777853e-001f,
  6.6261833906e-001f,
  6.4841979742e-001f,
  6.3452547789e-001f,
  6.2092888355e-001f,
  6.0762369633e-001f,
  5.9460353851e-001f,
  5.8186244965e-001f,
  5.6939429045e-001f,
  5.5719339848e-001f,
  5.4525387287e-001f,
  5.3357023001e-001f,
  5.2213686705e-001f,
  5.1094859838e-001f
};

static float __internal_accurate_powf(float a, float b)
{
  int i;
  float t;
  int expo;
  float log_hi, log_lo;
  float b_hi, b_lo;
  float prod_hi, prod_lo;
  
  if ((a > 0.707106781f) && (a < 1.414213562f)) {
    float f, g, u, v, q;

    




    f = a - 1.0f;
    g = a + 1.0f;
    g = 1.0f / g;
    u = 2.0f * f * g;
    v = u * u;
    q =         1.49356810919559350E-001f/64.0f;
    q = q * v + 1.99887797540072460E-001f/16.0f;
    q = q * v + 3.33333880955515580E-001f/4.0f;
    q = q * v;
    q = q * u;
    log_hi = __int_as_float(__float_as_int(u) & 0xfffff000);
    v = __int_as_float(__float_as_int(f) & 0xfffff000);
    u = 2.0f * (f - log_hi);
    f = f - v;
    u = u - log_hi * v;
    u = u - log_hi * f;
    u = g * u;
    log_lo = q + u;

    
    b_hi = __int_as_float(__float_as_int(b) & 0xfffff000);
    b_lo = b - b_hi;
    prod_lo  = b_lo * log_lo;
    prod_lo += b_lo * log_hi;
    prod_lo += b_hi * log_lo;
    prod_hi  = b_hi * log_hi;

    
    return __cuda_expf(prod_hi) * __cuda_expf(prod_lo);
  }

  
  if (a >= 1.175494351e-38f) {
    i = __float_as_int(a);
    expo = ((i >> 23) & 0xff) - 127;
  } else {
    a *= 16777216.0f;
    i = __float_as_int(a);
    expo = ((i >> 23) & 0xff) - 127 - 24;
  }   
  i = (i & 0x007fffff) | (0x3f800000);
  t = __int_as_float(i);

  i = 0;
  if (t >= __cudart_A1[i+16]) i += 16;
  if (t >= __cudart_A1[i+8])  i += 8;
  if (t >= __cudart_A1[i+4])  i += 4;
  if (t >= __cudart_A1[i+2])  i += 2;
  if (t >= __cudart_A1[i+1])  i += 1;

  t = t - __cudart_A1[i];
  t = t - __cudart_A2[i];
  
  t = t * __cudart_Ainv[i];

  
  log_hi = (float)expo + (float)i * 0.03125f;
  
  log_lo =            - 3.42338934684934650E-001f;
  log_lo = log_lo * t + 4.80524913518140690E-001f;
  log_lo = log_lo * t - 7.21345070621603800E-001f;
  log_lo = log_lo * t + 1.44269503837073180E+000f;
  log_lo = log_lo * t;

  
  b_hi   = __int_as_float(__float_as_int(b) & 0xfffff000);
  b_lo   = b - b_hi;
  prod_lo = b_lo * log_lo;  
  prod_lo = prod_lo + b_lo * log_hi;
  prod_lo = prod_lo + b_hi * log_lo;
  prod_hi = b_hi * log_hi;

  
  if (prod_hi >= 256.0f) {
    return __int_as_float(0x7f800000);
  }
  if (prod_hi <= -256.0f) {
    return 0.0f;
  }

  
  b = __cuda_exp2f (0.5f * prod_hi);
  t = __cuda_exp2f (prod_lo);
  t = t * b;
  t = t * b;
  return t;
}

static float __cuda_powif(float a, int b)
{
  unsigned int e = __cuda_abs(b);
  float        r = 1.0f;

  while (1) {
    if ((e & 1) != 0) {
      r = r * a;
    }
    e = e >> 1;
    if (e == 0) {
      return b < 0 ? 1.0f/r : r;
    }
    a = a * a;
  }
}

static double __cuda_powi(double a, int b)
{
  unsigned int e = __cuda_abs(b);
  double       r = 1.0;

  while (1) {
    if ((e & 1) != 0) {
      r = r * a;
    }
    e = e >> 1;
    if (e == 0) {
      return b < 0 ? 1.0/r : r;
    }
    a = a * a;
  }
}

static float __cuda_powf(float a, float b)
{


#line 2915 "c:\\cuda\\include\\math_functions.h"
  int bIsOddInteger;
  float t;
  if (a == 1.0f || b == 0.0f) {
    return 1.0f;
  } 
  if (__cuda___isnanf(a) || __cuda___isnanf(b)) {
    return a + b;
  }
  if (a == __int_as_float(0x7f800000)) {
    return __cuda___signbitf(b) ? 0.0f : __int_as_float(0x7f800000);
  }
  if (__cuda___isinff(b)) {
    if (a == -1.0f) {
      return 1.0f;
    }
    t = (__cuda_fabsf(a) > 1.0f) ? __int_as_float(0x7f800000) : 0.0f;
    if (b < 0.0f) {
      t = 1.0f / t;
    }
    return t;
  }
  bIsOddInteger = (b - (2.0f * floorf(0.5f * b))) == 1.0f;
  if (a == 0.0f) {
    t = bIsOddInteger ? a : 0.0f;
    if (b < 0.0f) {
      t = 1.0f / t;
    }
    return t;
  } 
  if (a == -__int_as_float(0x7f800000)) {
    t = (b < 0.0f) ? -1.0f/a : -a;
    if (bIsOddInteger) {
      t = __int_as_float(__float_as_int(t) ^ 0x80000000);
    }
    return t;
  } 
  if ((a < 0.0f) && (b != __cuda_truncf(b))) {
    return __int_as_float(0x7fffffff);
  }
  t = __cuda_fabsf(a);
  t = __internal_accurate_powf(t, b);
  if ((a < 0.0f) && bIsOddInteger) {
    t = __int_as_float(__float_as_int(t) ^ 0x80000000);
  }
  return t;
#line 2961 "c:\\cuda\\include\\math_functions.h"
}


static float __internal_tgammaf_kernel(float a)
{
  float t;
  t =       - 1.05767296987211380E-003f;
  t = t * a + 7.09279059435508670E-003f;
  t = t * a - 9.65347121958557050E-003f;
  t = t * a - 4.21736613253687960E-002f;
  t = t * a + 1.66542401247154280E-001f;
  t = t * a - 4.20043267827838460E-002f;
  t = t * a - 6.55878234051332940E-001f;
  t = t * a + 5.77215696929794240E-001f;
  t = t * a + 1.00000000000000000E+000f;
  return t;
}





static float __cuda_tgammaf(float a)
{
  float s, xx, x=a;
  if (x >= 0.0f) {
    if (x > 36.0f) x = 36.0f; 
    s = 1.0f;
    xx = x;
    if (x > 34.03f) { 
      xx -= 1.0f;
    }
    while (xx > 1.5f) {
      xx = xx - 1.0f;
      s = s * xx;
    }
    if (x >= 0.5f) {
      xx = xx - 1.0f;
    }
    xx = __internal_tgammaf_kernel(xx);
    if (x < 0.5f) {
      xx = xx * x;
    }
    s = s / xx;
    if (x > 34.03f) {
      
      xx = x - 1.0f;
      s = s * xx;
    }
    return s;
  } else {
    if (x == __cuda_floorf(x)) {  
      x = __int_as_float(0x7fffffff);  

      return x;
#line 3017 "c:\\cuda\\include\\math_functions.h"
    } 
    if (x < -41.1f) x = -41.1f; 
    xx = x;
    if (x < -34.03f) {           
      xx += 6.0f;
    } 
    s = xx;
    while (xx < -0.5f) {
      xx = xx + 1.0f;
      s = s * xx;
    }
    xx = __internal_tgammaf_kernel(xx);
    s = s * xx;
    s = 1.0f / s;
    if (x < -34.03f) {
      xx = x;
      xx *= (x + 1.0f);
      xx *= (x + 2.0f);
      xx *= (x + 3.0f);
      xx *= (x + 4.0f);
      xx *= (x + 5.0f);
      xx = 1.0f / xx;
      s = s * xx;
      if ((a < -42.0f) && !(((int)a)&1)) {
        s = __int_as_float(0x80000000);
      }
    }    
    return s;
  }
}

static float __cuda_roundf(float a)
{
  float fa = __cuda_fabsf(a);
  if (fa > 8388608.0f) {
    return a;
  } else {
    float u = __cuda_floorf(fa + 0.5f);
    if (fa < 0.5f) u = 0.0f;
    return __cuda_copysignf(u, a);
  }
}

static long long int __internal_llroundf_kernel(float a)
{
  unsigned long long int res, t = 0LL;
  int shift;
  unsigned int ia = __float_as_int(a);
  if ((ia << 1) > 0xff000000) return 0LL;
  if ((int)ia >= 0x5f000000) return 0x7fffffffffffffffLL;
  if (ia >= 0xdf000000) return 0x8000000000000000LL;
  shift = 189 - ((ia >> 23) & 0xff);
  res = ((long long int)(((ia << 8) | 0x80000000) >> 1)) << 32;
  if (shift >= 64) {
    t = res;
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (t >= 0x8000000000000000LL) {
      res++;
  }
  if ((int)ia < 0) res = (unsigned long long int)(-(long long int)res);
  return (long long int)res;
}

static long long int __cuda_llroundf(float a)
{
  return __internal_llroundf_kernel(a);
}

static long int __cuda_lroundf(float a)
{


#line 3094 "c:\\cuda\\include\\math_functions.h"

  if (__cuda___isnanf(a)) return 0L;
  if (a >=  2147483648.0f) return 2147483647L;
  if (a <= -2147483648.0f) return (-2147483647L - 1L);
#line 3099 "c:\\cuda\\include\\math_functions.h"
  return (long int)(__cuda_roundf(a));
#line 3101 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fdimf(float a, float b)
{
  float t;
  t = a - b;    
  if (a <= b) {
    t = 0.0f;
  }
  return t;
}

static int __cuda_ilogbf(float a)
{
  unsigned int i;
  int expo;
  a = __cuda_fabsf(a);
  if (a <= 1.175494351e-38f) {
    
    if (a == 0.0f) {
      expo = -((int)((unsigned int)-1 >> 1))-1;
    } else {
      expo = -126;
      i = __float_as_int(a);
      i = i << 8;
      while ((int)i >= 0) {
        expo--;
        i = i + i;
      }
    }
  } else {
    i = __float_as_int(a);
    expo = ((int)((i >> 23) & 0xff)) - 127;
    if ((i == 0x7f800000)) {
      expo = ((int)((unsigned int)-1 >> 1));
    }
    if ((i > 0x7f800000)) {
      expo = -((int)((unsigned int)-1 >> 1))-1;
    }
  } 
  return expo;
}

static float __cuda_logbf(float a)
{
  unsigned int i;
  int expo;
  float res;

  if (__cuda___isnanf(a)) return a + a;
#line 3152 "c:\\cuda\\include\\math_functions.h"
  a = __cuda_fabsf(a);
  if (a <= 1.175494351e-38f) {
    
    if (a == 0.0f) {
      res = -__int_as_float(0x7f800000);
    } else {
      expo = -126;
      i = __float_as_int(a);
      i = i << 8;
      while ((int)i >= 0) {
        expo--;
        i = i + i;
      }
      res = (float)expo;
    }
  } else {
    i = __float_as_int(a);
    expo = ((int)((i >> 23) & 0xff)) - 127;
    res = (float)expo;
    if ((i >= 0x7f800000)) {  
      
      res = a + a;
    }
  } 
  return res;
}

static void __cuda_sincosf(float a, float *sptr, float *cptr)
{


#line 3184 "c:\\cuda\\include\\math_functions.h"
  float t, u, s, c;
  int quadrant;
  if (__cuda___isinff(a)) {
    *sptr = __int_as_float(0x7fffffff);
    *cptr = __int_as_float(0x7fffffff);
    return;
  }
  if (a == 0.0f) {
    *sptr = a;
    *cptr = 1.0f;
    return;
  } 
  t = __internal_trig_reduction_kernel(a, &quadrant);
  u = __internal_cos_kernel(t);
  t = __internal_sin_kernel(t);
  if (quadrant & 1) {
    s = u;
    c = t;
  } else {
    s = t;
    c = u;
  }
  if (quadrant & 2) {
    s = -s;
  }
  quadrant++;
  if (quadrant & 2) {
    c = -c;
  }
  *sptr = s;
  *cptr = c;
#line 3216 "c:\\cuda\\include\\math_functions.h"
}









static double rsqrt(double a)
{
  return 1.0 / sqrt(a);
}

static float rsqrtf(float a)
{
  return (float)rsqrt((double)a);
}









static int __finite(double a)
{
  union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 < 0xffe0000000000000ull;
}

static int __isnan(double a)
{
  union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 > 0xffe0000000000000ull;
}

static int __isinf(double a)
{
  union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 == 0xffe0000000000000ull;
}

static double round(double a)
{
  double fa = fabs(a);

  if (fa > 4503599627370496.0) {
    return a;
  } else {
    double u = floor(fa + 0.5);

    if (__signbit(a)) {
      u = -u;
    }
    return u;
  }
}

static long int lround(double a)
{
  return (long int)round(a);
}

static long long int llround(double a)
{
  return (long long int)round(a);
}

static double rint(double a)
{
  double fa = fabs(a);
  double u = 4503599627370496.0 + fa;
  if (fa >= 4503599627370496.0) {
    u = a;
  } else {
    u = u - 4503599627370496.0;
    if (__signbit(a)) {
      u = -u;
    }
  }
  return u;  
}

static long int lrint(double a)
{
  return (long int)rint(a);
}

static long long int llrint(double a)
{
  return (long long int)rint(a);
}

static double fdim(double a, double b)
{
  if (a > b) {
    return (a - b);
  } else if (a <= b) {
    return 0.0;
  } else if (__isnan(a)) {
    return a;
  } else {
    return b;
  }
}

static double scalbn(double a, int b)
{
  return ldexp(a, b);
}

static double scalbln(double a, long int b)
{
  int t;
  if (b > 2147483647L) {
    t = 2147483647;
  } else if (b < (-2147483647 - 1)) {
    t = (-2147483647 - 1);
  } else {
    t = (int)b;
  }
  return scalbn(a, t);
}






static double log1p(double a)
{
  volatile double u, m;

  u = 1.0 + a;
  if (u == 1.0) {
    
    u = a;
  } else {
    m = u - 1.0;
    u = log(u);
    if (a < 1.0) {
      
      u = a * u;
      u = u / m;
    }
  }
  return u;
}




static double expm1(double a)
{
  volatile double u, m;

  u = exp(a);
  m = u - 1.0;
  if (m == 0.0) {
    
    m = a;
  } 
  else if (fabs(a) < 1.0) {
    
    u = log(u);
    m = m * a;
    m = m / u;
  }
  return m;
}

static double exp10(double a)
{
  return pow(10.0, a);
}

static double cbrt(double a)
{
  double s, t;
  if (a == 0.0 || __isinf(a)) {
    return a;
  } 
  s = fabs(a);
  t = exp2(3.3333333333333333e-1 * log2(s));           
  t = t - (t - (s / (t * t))) * 3.3333333333333333e-1; 
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static double acosh(double a)
{
  double s, t;

  t = a - 1.0;
  if (t == a) {
    return log(2.0) + log(a);
  } else {
    s = a + 1.0;
    t = t + sqrt(s * t);
    return log1p(t);
  }
}

static double asinh(double a)
{
  double fa, oofa, t;

  fa = fabs(a);
  oofa = 1.0 / fa;
  t = fa + fa / (oofa + sqrt(1.0 + oofa * oofa));
  t = log1p(t);
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static double atanh(double a)
{
  double fa, t;

  fa = fabs(a);
  t = (2.0 * fa) / (1.0 - fa);
  t = 0.5 * log1p(t);
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static int ilogb(double a)
{
  union {
    double                 d;
    unsigned long long int l;
  } x;
  unsigned long long int i;
  int expo = -1022;

  if (__isnan(a)) return -((int)((unsigned int)-1 >> 1))-1;
  if (__isinf(a)) return ((int)((unsigned int)-1 >> 1));
  x.d = a;
  i = x.l & 0x7fffffffffffffffull;
  if (i == 0) return -((int)((unsigned int)-1 >> 1))-1;
  if (i >= 0x0010000000000000ull) {
    return (int)(((i >> 52) & 0x7ff) - 1023);
  }
  while (i < 0x0010000000000000ull) {
    expo--;
    i <<= 1;
  }
  return expo;
}

static double logb(double a)
{
  union {
    double                 d;
    unsigned long long int l;
  } x;
  unsigned long long int i;
  int expo = -1022;

  if (__isnan(a)) return a;
  if (__isinf(a)) return fabs(a);
  x.d = a;
  i = x.l & 0x7fffffffffffffffull;
  if (i == 0) return -1.0/a;
  if (i >= 0x0010000000000000ull) {
    return (double)((int)((i >> 52) & 0x7ff) - 1023);
  }
  while (i < 0x0010000000000000ull) {
    expo--;
    i <<= 1;
  }
  return (double)expo;
}

static int __double2hiint(double a)
{
  union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.d = a;

  return cvt.i[1];
}

static int __double2loint(double a)
{
  union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.d = a;

  return cvt.i[0];
}

static double __hiloint2double(int a, int b)
{
  union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.i[0] = b;
  cvt.i[1] = a;

  return cvt.d;
}

static double fma(double a, double b, double c)
{
  struct {
    unsigned int lo;
    unsigned int hi;
  } xx, yy, zz, ww;
  unsigned int s, t, u, prod0, prod1, prod2, prod3, expo_x, expo_y, expo_z;
  
  xx.hi = __double2hiint(a);
  xx.lo = __double2loint(a);
  yy.hi = __double2hiint(b);
  yy.lo = __double2loint(b);
  zz.hi = __double2hiint(c);
  zz.lo = __double2loint(c);

  expo_z = 0x7FF;
  t =  xx.hi >> 20;
  expo_x = expo_z & t;
  expo_x = expo_x - 1;    
  t =  yy.hi >> 20;
  expo_y = expo_z & t;
  expo_y = expo_y - 1;    
  t =  zz.hi >> 20;
  expo_z = expo_z & t;
  expo_z = expo_z - 1;    

  if (!((expo_x <= 0x7FD) &&
        (expo_y <= 0x7FD) &&
        (expo_z <= 0x7FD))) {
    
    



    if (((yy.hi << 1) | (yy.lo != 0)) > 0xffe00000) {
      yy.hi |= 0x00080000;
      return __hiloint2double(yy.hi, yy.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) > 0xffe00000) {
      zz.hi |= 0x00080000;
      return __hiloint2double(zz.hi, zz.lo);
    }
    if (((xx.hi << 1) | (xx.lo != 0)) > 0xffe00000) {
      xx.hi |= 0x00080000;
      return __hiloint2double(xx.hi, xx.lo);
    }
    
    










    if (((((xx.hi << 1) | xx.lo) == 0) && 
         (((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000)) ||
        ((((yy.hi << 1) | yy.lo) == 0) && 
         (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000))) {
      xx.hi = 0xfff80000;
      xx.lo = 0x00000000;
      return __hiloint2double(xx.hi, xx.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) == 0xffe00000) {
      if ((((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000) ||
          (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000)) {
        if ((int)(xx.hi ^ yy.hi ^ zz.hi) < 0) {
          xx.hi = 0xfff80000;
          xx.lo = 0x00000000;
          return __hiloint2double(xx.hi, xx.lo);
        }
      }
    }
    



    if (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000) {
      xx.hi = xx.hi ^ (yy.hi & 0x80000000);
      return __hiloint2double(xx.hi, xx.lo);
    }
    if (((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000) {
      yy.hi = yy.hi ^ (xx.hi & 0x80000000);
      return __hiloint2double(yy.hi, yy.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) == 0xffe00000) {
      return __hiloint2double(zz.hi, zz.lo);
    }
    




    if ((zz.hi == 0x80000000) && (zz.lo == 0)) {
      if ((((xx.hi << 1) | xx.lo) == 0) ||
          (((yy.hi << 1) | yy.lo) == 0)) {
        if ((int)(xx.hi ^ yy.hi) < 0) {
          return __hiloint2double(zz.hi, zz.lo);
        }
      }
    }
    


    if ((((zz.hi << 1) | zz.lo) == 0) &&
        ((((xx.hi << 1) | xx.lo) == 0) ||
         (((yy.hi << 1) | yy.lo) == 0))) {
      zz.hi &= 0x7fffffff;
      return __hiloint2double(zz.hi, zz.lo);
    }
    
    


    if ((((xx.hi << 1) | xx.lo) == 0) ||
        (((yy.hi << 1) | yy.lo) == 0)) {
      return __hiloint2double(zz.hi, zz.lo);
    }
    
    if (expo_x == 0xffffffff) {
      expo_x++;
      t = xx.hi & 0x80000000;
      s = xx.lo >> 21;
      xx.lo = xx.lo << 11;
      xx.hi = xx.hi << 11;
      xx.hi = xx.hi | s;
      if (!xx.hi) {
        xx.hi = xx.lo;
        xx.lo = 0;
        expo_x -= 32;
      }
      while ((int)xx.hi > 0) {
        s = xx.lo >> 31;
        xx.lo = xx.lo + xx.lo;
        xx.hi = xx.hi + xx.hi;
        xx.hi = xx.hi | s;
        expo_x--;
      }
      xx.lo = (xx.lo >> 11);
      xx.lo |= (xx.hi << 21);
      xx.hi = (xx.hi >> 11) | t;
    }
    if (expo_y == 0xffffffff) {
      expo_y++;
      t = yy.hi & 0x80000000;
      s = yy.lo >> 21;
      yy.lo = yy.lo << 11;
      yy.hi = yy.hi << 11;
      yy.hi = yy.hi | s;
      if (!yy.hi) {
        yy.hi = yy.lo;
        yy.lo = 0;
        expo_y -= 32;
      }
      while ((int)yy.hi > 0) {
        s = yy.lo >> 31;
        yy.lo = yy.lo + yy.lo;
        yy.hi = yy.hi + yy.hi;
        yy.hi = yy.hi | s;
        expo_y--;
      }
      yy.lo = (yy.lo >> 11);
      yy.lo |= (yy.hi << 21);
      yy.hi = (yy.hi >> 11) | t;
    }
    if (expo_z == 0xffffffff) {
      expo_z++;
      t = zz.hi & 0x80000000;
      s = zz.lo >> 21;
      zz.lo = zz.lo << 11;
      zz.hi = zz.hi << 11;
      zz.hi = zz.hi | s;
      if (!zz.hi) {
        zz.hi = zz.lo;
        zz.lo = 0;
        expo_z -= 32;
      }
      while ((int)zz.hi > 0) {
        s = zz.lo >> 31;
        zz.lo = zz.lo + zz.lo;
        zz.hi = zz.hi + zz.hi;
        zz.hi = zz.hi | s;
        expo_z--;
      }
      zz.lo = (zz.lo >> 11);
      zz.lo |= (zz.hi << 21);
      zz.hi = (zz.hi >> 11) | t;
    }
  }
  
  expo_x = expo_x + expo_y;
  expo_y = xx.hi ^ yy.hi;
  t = xx.lo >> 21;
  xx.lo = xx.lo << 11;
  xx.hi = xx.hi << 11;
  xx.hi = xx.hi | t;
  yy.hi = yy.hi & 0x000fffff;
  xx.hi = xx.hi | 0x80000000; 
  yy.hi = yy.hi | 0x00100000; 

  prod0 = xx.lo * yy.lo;
  prod1 = __umulhi (xx.lo, yy.lo);
  prod2 = xx.hi * yy.lo;
  prod3 = xx.lo * yy.hi;
  prod1 += prod2;
  t = prod1 < prod2;
  prod1 += prod3;
  t += prod1 < prod3;
  prod2 = __umulhi (xx.hi, yy.lo);
  prod3 = __umulhi (xx.lo, yy.hi);
  prod2 += prod3;
  s = prod2 < prod3;
  prod3 = xx.hi * yy.hi;
  prod2 += prod3;
  s += prod2 < prod3;
  prod2 += t;
  s += prod2 < t;
  prod3 = __umulhi (xx.hi, yy.hi) + s;
  
  yy.lo = prod0;                 
  yy.hi = prod1;                 
  xx.lo = prod2;                 
  xx.hi = prod3;                 
  expo_x = expo_x - (1023 - 2);  
  expo_y = expo_y & 0x80000000;  

  if (xx.hi < 0x00100000) {
    s = xx.lo >> 31;
    s = (xx.hi << 1) + s;
    xx.hi = s;
    s = yy.hi >> 31;
    s = (xx.lo << 1) + s;
    xx.lo = s;
    s = yy.lo >> 31;
    s = (yy.hi << 1) + s;
    yy.hi = s;
    s = yy.lo << 1;
    yy.lo = s;
    expo_x--;
  }

  t = 0;
  if (((zz.hi << 1) | zz.lo) != 0) { 
    
    s = zz.hi & 0x80000000;
    
    zz.hi &= 0x000fffff;
    zz.hi |= 0x00100000;
    ww.hi = 0;
    ww.lo = 0;
    
    
    if ((int)expo_z > (int)expo_x) {
      t = expo_z;
      expo_z = expo_x;
      expo_x = t;
      t = zz.hi;
      zz.hi = xx.hi;
      xx.hi = t;
      t = zz.lo;
      zz.lo = xx.lo;
      xx.lo = t;
      t = ww.hi;
      ww.hi = yy.hi;
      yy.hi = t;
      t = ww.lo;
      ww.lo = yy.lo;
      yy.lo = t;
      t = expo_y;
      expo_y = s;
      s = t;
    }
    
    
    
    expo_z = expo_x - expo_z;
    u = expo_y ^ s;
    if (expo_z <= 107) {
      
      t = 0;
      while (expo_z >= 32) {
        t     = ww.lo | (t != 0);
        ww.lo = ww.hi;
        ww.hi = zz.lo;
        zz.lo = zz.hi;
        zz.hi = 0;
        expo_z -= 32;
      }
      if (expo_z) {
        t     = (t     >> expo_z) | (ww.lo << (32 - expo_z)) | 
                ((t << (32 - expo_z)) != 0);
        ww.lo = (ww.lo >> expo_z) | (ww.hi << (32 - expo_z));
        ww.hi = (ww.hi >> expo_z) | (zz.lo << (32 - expo_z));
        zz.lo = (zz.lo >> expo_z) | (zz.hi << (32 - expo_z));
        zz.hi = (zz.hi >> expo_z);
      }
    } else {
      t = 1;
      ww.lo = 0;
      ww.hi = 0;
      zz.lo = 0;
      zz.hi = 0;
    }
    if ((int)u < 0) {
      
      t = (unsigned)(-(int)t);
      s = (t != 0);
      u = yy.lo - s;
      s = u > yy.lo;
      yy.lo = u - ww.lo;
      s += yy.lo > u;
      u = yy.hi - s;
      s = u > yy.hi;
      yy.hi = u - ww.hi;
      s += yy.hi > u;
      u = xx.lo - s;
      s = u > xx.lo;
      xx.lo = u - zz.lo;
      s += xx.lo > u;
      xx.hi = (xx.hi - zz.hi) - s;
      if (!(xx.hi | xx.lo | yy.hi | yy.lo | t)) {
        
        return __hiloint2double(xx.hi, xx.lo);
      }
      if ((int)xx.hi < 0) {
        


        t = ~t;
        yy.lo = ~yy.lo;
        yy.hi = ~yy.hi;
        xx.lo = ~xx.lo;
        xx.hi = ~xx.hi;
        if (++t == 0) {
          if (++yy.lo == 0) {
            if (++yy.hi == 0) {
              if (++xx.lo == 0) {
              ++xx.hi;
              }
            }
          }
        }
        expo_y ^= 0x80000000;
      }
        
      
      while (!(xx.hi & 0x00100000)) {
        xx.hi = (xx.hi << 1) | (xx.lo >> 31);
        xx.lo = (xx.lo << 1) | (yy.hi >> 31);
        yy.hi = (yy.hi << 1) | (yy.lo >> 31);
        yy.lo = (yy.lo << 1);
        expo_x--;
      }
    } else {
      
      yy.lo = yy.lo + ww.lo;
      s = yy.lo < ww.lo;
      yy.hi = yy.hi + s;
      u = yy.hi < s;
      yy.hi = yy.hi + ww.hi;
      u += yy.hi < ww.hi;
      xx.lo = xx.lo + u;
      s = xx.lo < u;
      xx.lo = xx.lo + zz.lo;
      s += xx.lo < zz.lo;
      xx.hi = xx.hi + zz.hi + s;
      if (xx.hi & 0x00200000) {
        t = t | (yy.lo << 31);
        yy.lo = (yy.lo >> 1) | (yy.hi << 31);
        yy.hi = (yy.hi >> 1) | (xx.lo << 31);
        xx.lo = (xx.lo >> 1) | (xx.hi << 31);
        xx.hi = ((xx.hi & 0x80000000) | (xx.hi >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
  }
  t = yy.lo | (t != 0);
  t = yy.hi | (t != 0);
        
  xx.hi |= expo_y; 
  if (expo_x <= 0x7FD) {
    
    xx.hi = xx.hi & ~0x00100000; 
    s = xx.lo & 1; 
    u = xx.lo;
    xx.lo += (t == 0x80000000) ? s : (t >> 31);
    xx.hi += (u > xx.lo);
    xx.hi += ((expo_x + 1) << 20);
    return __hiloint2double(xx.hi, xx.lo);
  } else if ((int)expo_x >= 2046) {      
    
    xx.hi = (xx.hi & 0x80000000) | 0x7ff00000;
    xx.lo = 0;
    return __hiloint2double(xx.hi, xx.lo);
  }
  
  expo_x = (unsigned)(-(int)expo_x);
  if (expo_x > 54) {
    
    return __hiloint2double(xx.hi & 0x80000000, 0);
  }  
  yy.hi = xx.hi &  0x80000000;   
  xx.hi = xx.hi & ~0xffe00000;
  if (expo_x >= 32) {
    t = xx.lo | (t != 0);
    xx.lo = xx.hi;
    xx.hi = 0;
    expo_x -= 32;
  }
  if (expo_x) {
    t     = (t     >> expo_x) | (xx.lo << (32 - expo_x)) | (t != 0);
    xx.lo = (xx.lo >> expo_x) | (xx.hi << (32 - expo_x));
    xx.hi = (xx.hi >> expo_x);
  }
  expo_x = xx.lo & 1; 
  u = xx.lo;
  xx.lo += (t == 0x80000000) ? expo_x : (t >> 31);
  xx.hi += (u > xx.lo);
  xx.hi |= yy.hi;
  return __hiloint2double(xx.hi, xx.lo);
}

static void sincos(double a, double *sptr, double *cptr)
{
  *sptr = sin(a);
  *cptr = cos(a);
}







static float acoshf(float a)
{
  return (float)acosh((double)a);
}

static float asinhf(float a)
{
  return (float)asinh((double)a);
}

static float atanhf(float a)
{
  return (float)atanh((double)a);
}

static float cbrtf(float a)
{
  return (float)cbrt((double)a);
}

static float expm1f(float a)
{
  return (float)expm1((double)a);
}

static float exp10f(float a)
{
  return (float)exp10((double)a);
}

static float fdimf(float a, float b)
{
  return (float)fdim((double)a, (double)b);
}

static float hypotf(float a, float b)
{
  return (float)hypot((double)a, (double)b);
}

static float log1pf(float a)
{
  return (float)log1p((double)a);
}

static float scalbnf(float a, int b)
{
  return (float)scalbn((double)a, b);
}

static float fmaf(float a, float b, float c)
{
  return (float)fma((double)a, (double)b, (double)c);
}

static void sincosf(float a, float *sptr, float *cptr)
{
  double s, c;

  sincos ((double)a, &s, &c);
  *sptr = (float)s;
  *cptr = (float)c;
}







static int __finitef(float a)
{
  return __cuda___finitef(a);
}

static int __isinff(float a)
{
  return __cuda___isinff(a);
}

static int __isnanf(float a)
{
  return __cuda___isnanf(a);
}

static float roundf(float a)
{
  return __cuda_roundf(a);
}

static float rintf(float a)
{
  return __cuda_rintf(a);
}

static long int lrintf(float a)
{
  return __cuda_lrintf(a);
}

static long long int llrintf(float a)
{
  return __cuda_llrintf(a);
}

static int ilogbf(float a)
{
  return __cuda_ilogbf(a);
}

static float logbf(float a)
{
  return __cuda_logbf(a);
}

static float erff(float a)
{
  return __cuda_erff(a);
}

static float erfcf(float a)
{
  return __cuda_erfcf(a);
}

static float lgammaf(float a)
{
  return __cuda_lgammaf(a);
}

static float tgammaf(float a)
{
  return __cuda_tgammaf(a);
}







static double lgamma(double a)
{
  return (double)lgammaf((float)a);
}

static double tgamma(double a)
{
  return (double)tgammaf((float)a);
}

static double erf(double a)
{
  return (double)erff((float)a);
}

static double erfc(double a)
{
  return (double)erfcf((float)a);
}

#line 4154 "c:\\cuda\\include\\math_functions.h"

#line 4156 "c:\\cuda\\include\\math_functions.h"

#line 4158 "c:\\cuda\\include\\math_functions.h"





#line 4164 "c:\\cuda\\include\\math_functions.h"



#line 1 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"








































#line 42 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"





























































#line 63 "c:\\cuda\\include\\crt/func_macro.h"
#line 44 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

static double __cuda_fabs(double a)
{
  return (float)__cuda_fabsf((float)a);
}

static double __cuda_fmax(double a, double b)
{
  return (float)__cuda_fmaxf((float)a, (float)b);
}

static double __cuda_fmin(double a, double b)
{
  return (float)__cuda_fminf((float)a, (float)b);
}

static int __cuda___finite(double a)
{
  return __cuda___finitef((float)a);
}

static int __cuda___isinf(double a)
{
  return __cuda___isinff((float)a);
}

static int __cuda___isnan(double a)
{
  return __cuda___isnanf((float)a);
}

static int __cuda___signbit(double a)
{
  return __cuda___signbitf((float)a);
}

static double __cuda_sqrt(double a)
{
  return (double)__cuda_sqrtf((float)a);
}

static double __cuda_rsqrt(double a)
{
  return (double)__cuda_rsqrtf((float)a);
}

static double __cuda_ceil(double a)
{
  return (double)__cuda_ceilf((float)a);
}

static double __cuda_trunc(double a)
{
  return (double)__cuda_truncf((float)a);
}

static double __cuda_floor(double a)
{
  return (double)__cuda_floorf((float)a);
}

static double __cuda_copysign(double a, double b)
{
  return (double)__cuda_copysignf((float)a, (float)b);
}

static double __cuda_sin(double a)
{
  return (double)__cuda_sinf((float)a);
}

static double __cuda_cos(double a)
{
  return (double)__cuda_cosf((float)a);
}

static void __cuda_sincos(double a, double *sptr, double *cptr)
{
  float fs, fc;

  __cuda_sincosf((float)a, &fs, &fc);

  *sptr = (double)fs;
  *cptr = (double)fc;
}

static double __cuda_tan(double a)
{
  return (double)__cuda_tanf((float)a);
}

static double __cuda_exp(double a)
{
  return (double)__cuda_expf((float)a);
}

static double __cuda_exp2(double a)
{
  return (double)__cuda_exp2f((float)a);
}

static double __cuda_exp10(double a)
{
  return (double)__cuda_exp10f((float)a);
}

static double __cuda_expm1(double a)
{
  return (double)__cuda_expm1f((float)a);
}

static double __cuda_cosh(double a)
{
  return (double)__cuda_coshf((float)a);
}

static double __cuda_sinh(double a)
{
  return (double)__cuda_sinhf((float)a);
}

static double __cuda_tanh(double a)
{
  return (double)__cuda_tanhf((float)a);
}

static double __cuda_asin(double a)
{
  return (double)__cuda_asinf((float)a);
}

static double __cuda_acos(double a)
{
  return (double)__cuda_acosf((float)a);
}

static double __cuda_atan(double a)
{
  return (double)__cuda_atanf((float)a);
}

static double __cuda_atan2(double a, double b)
{
  return (double)__cuda_atan2f((float)a, (float)b);
}

static double __cuda_log(double a)
{
  return (double)__cuda_logf((float)a);
}

static double __cuda_log2(double a)
{
  return (double)__cuda_log2f((float)a);
}

static double __cuda_log10(double a)
{
  return (double)__cuda_log10f((float)a);
}

static double __cuda_log1p(double a)
{
  return (double)__cuda_log1pf((float)a);
}

static double __cuda_acosh(double a)
{
  return (double)__cuda_acoshf((float)a);
}

static double __cuda_asinh(double a)
{
  return (double)__cuda_asinhf((float)a);
}

static double __cuda_atanh(double a)
{
  return (double)__cuda_atanhf((float)a);
}

static double __cuda_hypot(double a, double b)
{
  return (double)__cuda_hypotf((float)a, (float)b);
}

static double __cuda_cbrt(double a)
{
  return (double)__cuda_cbrtf((float)a);
}

static double __cuda_erf(double a)
{
  return (double)__cuda_erff((float)a);
}

static double __cuda_erfc(double a)
{
  return (double)__cuda_erfcf((float)a);
}

static double __cuda_lgamma(double a)
{
  return (double)__cuda_lgammaf((float)a);
}

static double __cuda_tgamma(double a)
{
  return (double)__cuda_tgammaf((float)a);
}

static double __cuda_ldexp(double a, int b)
{
  return (double)__cuda_ldexpf((float)a, b);
}

static double __cuda_scalbn(double a, int b)
{
  return (double)__cuda_scalbnf((float)a, b);
}

static double __cuda_scalbln(double a, long b)
{
  return (double)__cuda_scalblnf((float)a, b);
}

static double __cuda_frexp(double a, int *b)
{
  return (double)__cuda_frexpf((float)a, b);
}

static double __cuda_modf(double a, double *b)
{
  float fb;
  float fa = __cuda_modff((float)a, &fb);

  *b = (double)fb;

  return (double)fa;  
}

static double __cuda_fmod(double a, double b)
{
  return (double)__cuda_fmodf((float)a, (float)b);
}

static double __cuda_remainder(double a, double b)
{
  return (double)__cuda_remainderf((float)a, (float)b);
}

static double __cuda_remquo(double a, double b, int *c)
{
  return (double)__cuda_remquof((float)a, (float)b, c);
}

static double __cuda_nextafter(double a, double b)
{
  return (double)__cuda_nextafterf((float)a, (float)b);
}

static double __cuda_nan(const char *tagp)
{
  return (double)__cuda_nanf(tagp);
}

static double __cuda_pow(double a, double b)
{
  return (double)__cuda_powf((float)a, (float)b);
}

static double __cuda_round(double a)
{
  return (double)__cuda_roundf((float)a);
}

static long __cuda_lround(double a)
{
  return __cuda_lroundf((float)a);
}

static long long __cuda_llround(double a)
{
  return __cuda_llroundf((float)a);
}

static double __cuda_rint(double a)
{
  return (double)__cuda_rintf((float)a);
}

static long __cuda_lrint(double a)
{
  return __cuda_lrintf((float)a);
}

static long long __cuda_llrint(double a)
{
  return __cuda_llrintf((float)a);
}

static double __cuda_nearbyint(double a)
{
  return (double)__cuda_nearbyintf((float)a);
}

static double __cuda_fdim(double a, double b)
{
  return (double)__cuda_fdimf((float)a, (float)b);
}

static int __cuda_ilogb(double a)
{
  return __cuda_ilogbf((float)a);
}

static double __cuda_logb(double a)
{
  return (double)__cuda_logbf((float)a);
}

static double __cuda_fma(double a, double b, double c)
{
  return (double)__cuda_fmaf((float)a, (float)b, (float)c);
}

#line 371 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

#line 373 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"
#line 4168 "c:\\cuda\\include\\math_functions.h"

#line 4170 "c:\\cuda\\include\\math_functions.h"

#line 4172 "c:\\cuda\\include\\math_functions.h"

#line 89 "C:\\CUDA\\include\\common_functions.h"

#line 91 "C:\\CUDA\\include\\common_functions.h"

#line 196 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 198 "C:\\CUDA\\include\\crt/host_runtime.h"















#line 214 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 6 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
struct __T20;
struct __T21;
struct __T22;
struct __T23;
struct __T24;
struct __T25;
struct __T26;
struct __T27;
struct __T20 {bool *__par0;bool *__par1;const unsigned *__par2;unsigned __par3;int __dummy_field;};
struct __T21 {const bool *__par0;const unsigned *__par1;unsigned __par2;unsigned *__par3;int __dummy_field;};
struct __T22 {unsigned __par0;const unsigned *__par1;const bool *__par2;const bool *__par3;unsigned *__par4;int __dummy_field;};
struct __T23 {unsigned __par0;unsigned *__par1;int __dummy_field;};
struct __T24 {unsigned __par0;const unsigned *__par1;const bool *__par2;const bool *__par3;unsigned *__par4;int __dummy_field;};
struct __T25 {unsigned __par0;const unsigned *__par1;const bool *__par2;const bool *__par3;unsigned *__par4;int __dummy_field;};
struct __T26 {unsigned __par0;const unsigned *__par1;const bool *__par2;const bool *__par3;unsigned *__par4;int __dummy_field;};
struct __T27 {unsigned __par0;unsigned *__par1;int __dummy_field;};


#line 25 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 28 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 31 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 34 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 37 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 40 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 43 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 46 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
extern void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void);
#pragma section(".CRT$XCU",read,write)
__declspec(allocate(".CRT$XCU"))static void (__cdecl *__dummy_static_init__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973[])(void) = {__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973};
void __device_stub__Z7kernel3PbS_PKjj(bool *__par0, bool *__par1, const unsigned *__par2, const unsigned __par3){auto struct __T20 __T28;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T28.__par0 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T28.__par1 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T28.__par2 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T28.__par3 - (size_t)&__T28) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z7kernel3PbS_PKjj); (void)cudaLaunch(__f); };}
void __device_stub__Z17kernel_minimizar1PKbPKjjPj(const bool *__par0, const unsigned *__par1, const unsigned __par2, unsigned *__par3){auto struct __T21 __T29;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T29.__par0 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T29.__par1 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T29.__par2 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T29.__par3 - (size_t)&__T29) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z17kernel_minimizar1PKbPKjjPj); (void)cudaLaunch(__f); };}
void __device_stub__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T22 __T210;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T210.__par0 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T210.__par1 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T210.__par2 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T210.__par3 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument(&__par4, sizeof(__par4), (size_t)&__T210.__par4 - (size_t)&__T210) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z13kernel1_SSSP7jPKjPKbS2_Pj); (void)cudaLaunch(__f); };}
void __device_stub__Z15kernel1_SSSP7_TjPj(const unsigned __par0, unsigned *__par1){auto struct __T23 __T211;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T211.__par0 - (size_t)&__T211) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T211.__par1 - (size_t)&__T211) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z15kernel1_SSSP7_TjPj); (void)cudaLaunch(__f); };}
void __device_stub__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T24 __T212;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T212.__par0 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T212.__par1 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T212.__par2 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T212.__par3 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument(&__par4, sizeof(__par4), (size_t)&__T212.__par4 - (size_t)&__T212) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z15kernel1_SSSP7_1jPKjPKbS2_Pj); (void)cudaLaunch(__f); };}
void __device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T25 __T213;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T213.__par0 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T213.__par1 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T213.__par2 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T213.__par3 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument(&__par4, sizeof(__par4), (size_t)&__T213.__par4 - (size_t)&__T213) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj); (void)cudaLaunch(__f); };}
void __device_stub__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T26 __T214;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T214.__par0 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T214.__par1 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument(&__par2, sizeof(__par2), (size_t)&__T214.__par2 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument(&__par3, sizeof(__par3), (size_t)&__T214.__par3 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument(&__par4, sizeof(__par4), (size_t)&__T214.__par4 - (size_t)&__T214) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj); (void)cudaLaunch(__f); };}
void __device_stub__Z16kernel1_SSSP7_RTjPj(const unsigned __par0, unsigned *__par1){auto struct __T27 __T215;
if (cudaSetupArgument(&__par0, sizeof(__par0), (size_t)&__T215.__par0 - (size_t)&__T215) != cudaSuccess) return;if (cudaSetupArgument(&__par1, sizeof(__par1), (size_t)&__T215.__par1 - (size_t)&__T215) != cudaSuccess) return;{ static char *__f = ((char *)__device_stub__Z16kernel1_SSSP7_RTjPj); (void)cudaLaunch(__f); };}


#line 68 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 71 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 74 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 77 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 80 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 83 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 86 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 89 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void){__cudaFatCubinHandle = __cudaRegisterFatBinary((void*)(&__fatDeviceText));__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z16kernel1_SSSP7_RTjPj, (char*)"_Z16kernel1_SSSP7_RTjPj", "_Z16kernel1_SSSP7_RTjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj, (char*)"_Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj", "_Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z13kernel1_SSSP9jPKjPKbS2_Pj, (char*)"_Z13kernel1_SSSP9jPKjPKbS2_Pj", "_Z13kernel1_SSSP9jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z15kernel1_SSSP7_1jPKjPKbS2_Pj, (char*)"_Z15kernel1_SSSP7_1jPKjPKbS2_Pj", "_Z15kernel1_SSSP7_1jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z15kernel1_SSSP7_TjPj, (char*)"_Z15kernel1_SSSP7_TjPj", "_Z15kernel1_SSSP7_TjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z13kernel1_SSSP7jPKjPKbS2_Pj, (char*)"_Z13kernel1_SSSP7jPKjPKbS2_Pj", "_Z13kernel1_SSSP7jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z17kernel_minimizar1PKbPKjjPj, (char*)"_Z17kernel_minimizar1PKbPKjjPj", "_Z17kernel_minimizar1PKbPKjjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub__Z7kernel3PbS_PKjj, (char*)"_Z7kernel3PbS_PKjj", "_Z7kernel3PbS_PKjj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_m, 0, "textura_m", 1, 0, 0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_p, 0, "textura_p", 1, 0, 0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_f, 0, "textura_f", 1, 0, 0);__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdata");__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdata1");__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdataP");}


#line 93 "c:\\archivos de programa\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 54 "template.cu"

