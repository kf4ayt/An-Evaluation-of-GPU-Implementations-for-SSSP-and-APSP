#if defined(__cplusplus)
extern "C" {
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z7kernel3PbS_PKjj
extern void __device_stub___globfunc__Z7kernel3PbS_PKjj(bool *, bool *, const unsigned *, const unsigned);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj
extern void __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(const bool *, const unsigned *, const unsigned, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj
extern void __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z15kernel1_SSSP7_TjPj
extern void __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(const unsigned, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj
extern void __device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj
extern void __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj
extern void __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#endif
#if !defined(__cplusplus) || __include___device_stub___globfunc__Z16kernel1_SSSP7_RTjPj
extern void __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(const unsigned, unsigned *);
#endif
#if defined(__cplusplus)
}
#endif
