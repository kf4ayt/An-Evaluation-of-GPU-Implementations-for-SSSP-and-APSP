#line 1 "template.cudafe1.cpp"
#line 1 "template.cu"
#line 89 "c:\\cuda\\include\\host_config.h"
class type_info; 













#line 104 "c:\\cuda\\include\\host_config.h"
#line 147 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#pragma pack ( push, 8 )
#line 32 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
#pragma pack ( push, 8 )
#line 52 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
extern "C" { typedef unsigned __w64 uintptr_t; }
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
extern "C" { typedef char *va_list; }
#line 151 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
#pragma pack ( pop )
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef unsigned size_t; 
#line 1 "C:\\CUDA\\include\\crt/host_runtime.h"
























































#line 58 "C:\\CUDA\\include\\crt/host_runtime.h"



#line 62 "C:\\CUDA\\include\\crt/host_runtime.h"





#line 68 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 1 "C:\\CUDA\\include\\cuda_runtime_api.h"











































 









#line 1 "c:\\cuda\\include\\host_defines.h"










































#line 44 "c:\\cuda\\include\\host_defines.h"















#line 60 "c:\\cuda\\include\\host_defines.h"










#line 71 "c:\\cuda\\include\\host_defines.h"




















#line 92 "c:\\cuda\\include\\host_defines.h"








#line 101 "c:\\cuda\\include\\host_defines.h"




#line 106 "c:\\cuda\\include\\host_defines.h"














#line 121 "c:\\cuda\\include\\host_defines.h"
#line 55 "C:\\CUDA\\include\\cuda_runtime_api.h"
#line 1 "c:\\cuda\\include\\builtin_types.h"









































#line 1 "c:\\cuda\\include\\device_types.h"













































enum cudaRoundMode
{
  cudaRoundNearest,
  cudaRoundZero,
  cudaRoundPosInf,
  cudaRoundMinInf
};

#line 55 "c:\\cuda\\include\\device_types.h"
#line 43 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\driver_types.h"

















































#line 51 "c:\\cuda\\include\\driver_types.h"








enum cudaError
{
  cudaSuccess = 0,
  cudaErrorMissingConfiguration,
  cudaErrorMemoryAllocation,
  cudaErrorInitializationError,
  cudaErrorLaunchFailure,
  cudaErrorPriorLaunchFailure,
  cudaErrorLaunchTimeout,
  cudaErrorLaunchOutOfResources,
  cudaErrorInvalidDeviceFunction,
  cudaErrorInvalidConfiguration,
  cudaErrorInvalidDevice,
  cudaErrorInvalidValue,
  cudaErrorInvalidPitchValue,
  cudaErrorInvalidSymbol,
  cudaErrorMapBufferObjectFailed,
  cudaErrorUnmapBufferObjectFailed,
  cudaErrorInvalidHostPointer,
  cudaErrorInvalidDevicePointer,
  cudaErrorInvalidTexture,
  cudaErrorInvalidTextureBinding,
  cudaErrorInvalidChannelDescriptor,
  cudaErrorInvalidMemcpyDirection,
  cudaErrorAddressOfConstant,
  cudaErrorTextureFetchFailed,
  cudaErrorTextureNotBound,
  cudaErrorSynchronizationError,
  cudaErrorInvalidFilterSetting,
  cudaErrorInvalidNormSetting,
  cudaErrorMixedDeviceExecution,
  cudaErrorCudartUnloading,
  cudaErrorUnknown,
  cudaErrorNotYetImplemented,
  cudaErrorMemoryValueTooLarge,
  cudaErrorInvalidResourceHandle,
  cudaErrorNotReady,
  cudaErrorStartupFailure = 0x7f,
  cudaErrorApiFailureBase = 10000
};


enum cudaChannelFormatKind
{
  cudaChannelFormatKindSigned,
  cudaChannelFormatKindUnsigned,
  cudaChannelFormatKindFloat
};


struct cudaChannelFormatDesc
{
  int                        x;
  int                        y;
  int                        z;
  int                        w;
  enum cudaChannelFormatKind f;
};


struct cudaArray;


enum cudaMemcpyKind
{
  cudaMemcpyHostToHost = 0,
  cudaMemcpyHostToDevice,
  cudaMemcpyDeviceToHost,
  cudaMemcpyDeviceToDevice
};


struct cudaPitchedPtr
{
  void   *ptr;
  size_t  pitch;
  size_t  xsize;
  size_t  ysize;
};


struct cudaExtent
{
  size_t width;
  size_t height;
  size_t depth;
};


struct cudaPos
{
  size_t x;
  size_t y;
  size_t z;
};


struct cudaMemcpy3DParms
{
  struct cudaArray      *srcArray;
  struct cudaPos         srcPos;
  struct cudaPitchedPtr  srcPtr;

  struct cudaArray      *dstArray;
  struct cudaPos         dstPos;
  struct cudaPitchedPtr  dstPtr;

  struct cudaExtent      extent;
  enum cudaMemcpyKind    kind;
};


struct cudaDeviceProp
{
  char   name[256];
  size_t totalGlobalMem;
  size_t sharedMemPerBlock;
  int    regsPerBlock;
  int    warpSize;
  size_t memPitch;
  int    maxThreadsPerBlock;
  int    maxThreadsDim[3];
  int    maxGridSize[3]; 
  int    clockRate;
  size_t totalConstMem; 
  int    major;
  int    minor;
  size_t textureAlignment;
  int    deviceOverlap;
  int    multiProcessorCount;
  int    __cudaReserved[40];
};




























typedef enum cudaError cudaError_t;


typedef int cudaStream_t;


typedef int cudaEvent_t;

#line 228 "c:\\cuda\\include\\driver_types.h"
#line 44 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\texture_types.h"













































enum cudaTextureAddressMode
{
  cudaAddressModeWrap,
  cudaAddressModeClamp
};


enum cudaTextureFilterMode
{
  cudaFilterModePoint,
  cudaFilterModeLinear
};


enum cudaTextureReadMode
{
  cudaReadModeElementType,
  cudaReadModeNormalizedFloat
};


struct textureReference
{
  int                          normalized;
  enum cudaTextureFilterMode   filterMode;
  enum cudaTextureAddressMode  addressMode[3];
  struct cudaChannelFormatDesc channelDesc;
  int                          __cudaReserved[16];
};
















































#line 124 "c:\\cuda\\include\\texture_types.h"

#line 126 "c:\\cuda\\include\\texture_types.h"
#line 45 "c:\\cuda\\include\\builtin_types.h"
#line 1 "c:\\cuda\\include\\vector_types.h"












































#line 1 "c:\\cuda\\include\\host_defines.h"























































































































#line 121 "c:\\cuda\\include\\host_defines.h"
#line 46 "c:\\cuda\\include\\vector_types.h"








struct char1
{
  signed char x;
};


struct uchar1 
{
  unsigned char x;
};


struct  char2
{
  signed char x, y;
};


struct  uchar2
{
  unsigned char x, y;
};


struct char3
{
  signed char x, y, z;
};


struct uchar3
{
  unsigned char x, y, z;
};


struct  char4
{
  signed char x, y, z, w;
};


struct  uchar4
{
  unsigned char x, y, z, w;
};


struct short1
{
  short x;
};


struct ushort1
{
  unsigned short x;
};


struct  short2
{
  short x, y;
};


struct  ushort2
{
  unsigned short x, y;
};


struct short3
{
  short x, y, z;
};


struct ushort3
{
  unsigned short x, y, z;
};


struct  short4
{
  short x, y, z, w;
};


struct  ushort4
{
  unsigned short x, y, z, w;
};


struct int1
{
  int x;
};


struct uint1
{
  unsigned int x;
};


struct  int2
{
  int x, y;
};


struct  uint2
{
  unsigned int x, y;
};


struct int3
{
  int x, y, z;
};


struct uint3
{
  unsigned int x, y, z;
};


struct  int4
{
  int x, y, z, w;
};


struct  uint4
{
  unsigned int x, y, z, w;
};


struct long1
{
  long int x;
};


struct ulong1
{
  unsigned long x;
};


struct 

       


#line 216 "c:\\cuda\\include\\vector_types.h"
                                             long2
{
  long int x, y;
};


struct 

       


#line 228 "c:\\cuda\\include\\vector_types.h"
                                                      ulong2
{
  unsigned long int x, y;
};




struct long3
{
  long int x, y, z;
};


struct ulong3
{
  unsigned long int x, y, z;
};


struct  long4
{
  long int x, y, z, w;
};


struct  ulong4
{
  unsigned long int x, y, z, w;
};

#line 260 "c:\\cuda\\include\\vector_types.h"


struct float1
{
  float x;
};


struct  float2
{
  float x, y;
};


struct float3
{
  float x, y, z;
};


struct  float4
{
  float x, y, z, w;
};


struct double1
{
  double x;
};


struct  double2
{
  double x, y;
};








typedef struct char1 char1;

typedef struct uchar1 uchar1;

typedef struct char2 char2;

typedef struct uchar2 uchar2;

typedef struct char3 char3;

typedef struct uchar3 uchar3;

typedef struct char4 char4;

typedef struct uchar4 uchar4;

typedef struct short1 short1;

typedef struct ushort1 ushort1;

typedef struct short2 short2;

typedef struct ushort2 ushort2;

typedef struct short3 short3;

typedef struct ushort3 ushort3;

typedef struct short4 short4;

typedef struct ushort4 ushort4;

typedef struct int1 int1;

typedef struct uint1 uint1;

typedef struct int2 int2;

typedef struct uint2 uint2;

typedef struct int3 int3;

typedef struct uint3 uint3;

typedef struct int4 int4;

typedef struct uint4 uint4;

typedef struct long1 long1;

typedef struct ulong1 ulong1;

typedef struct long2 long2;

typedef struct ulong2 ulong2;

typedef struct long3 long3;

typedef struct ulong3 ulong3;

typedef struct long4 long4;

typedef struct ulong4 ulong4;

typedef struct float1 float1;

typedef struct float2 float2;

typedef struct float3 float3;

typedef struct float4 float4;

typedef struct double1 double1;

typedef struct double2 double2;








typedef struct dim3 dim3;


struct dim3
{
    unsigned int x, y, z;

    dim3(unsigned int x = 1, unsigned int y = 1, unsigned int z = 1) : x(x), y(y), z(z) {}
    dim3(uint3 v) : x(v.x), y(v.y), z(v.z) {}
    operator uint3(void) { uint3 t; t.x = x; t.y = y; t.z = z; return t; }
#line 398 "c:\\cuda\\include\\vector_types.h"
};

#line 401 "c:\\cuda\\include\\vector_types.h"
#line 46 "c:\\cuda\\include\\builtin_types.h"
#line 56 "C:\\CUDA\\include\\cuda_runtime_api.h"














#line 71 "C:\\CUDA\\include\\cuda_runtime_api.h"








extern "C" {
#line 81 "C:\\CUDA\\include\\cuda_runtime_api.h"







extern  cudaError_t __stdcall cudaMalloc3D(struct cudaPitchedPtr* pitchDevPtr, struct cudaExtent extent);
extern  cudaError_t __stdcall cudaMalloc3DArray(struct cudaArray** arrayPtr, const struct cudaChannelFormatDesc* desc, struct cudaExtent extent);
extern  cudaError_t __stdcall cudaMemset3D(struct cudaPitchedPtr pitchDevPtr, int value, struct cudaExtent extent);
extern  cudaError_t __stdcall cudaMemcpy3D(const struct cudaMemcpy3DParms *p);
extern  cudaError_t __stdcall cudaMemcpy3DAsync(const struct cudaMemcpy3DParms *p, cudaStream_t stream);








extern  cudaError_t __stdcall cudaMalloc(void **devPtr, size_t size);
extern  cudaError_t __stdcall cudaMallocHost(void **ptr, size_t size);
extern  cudaError_t __stdcall cudaMallocPitch(void **devPtr, size_t *pitch, size_t width, size_t height);
extern  cudaError_t __stdcall cudaMallocArray(struct cudaArray **array, const struct cudaChannelFormatDesc *desc, size_t width, size_t height );
extern  cudaError_t __stdcall cudaFree(void *devPtr);
extern  cudaError_t __stdcall cudaFreeHost(void *ptr);
extern  cudaError_t __stdcall cudaFreeArray(struct cudaArray *array);








extern  cudaError_t __stdcall cudaMemcpy(void *dst, const void *src, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyToArray(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyFromArray(void *dst, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t count, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpyArrayToArray(struct cudaArray *dst, size_t wOffsetDst, size_t hOffsetDst, const struct cudaArray *src, size_t wOffsetSrc, size_t hOffsetSrc, size_t count, enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpy2D(void *dst, size_t dpitch, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DToArray(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DFromArray(void *dst, size_t dpitch, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t width, size_t height, enum cudaMemcpyKind kind);
extern  cudaError_t __stdcall cudaMemcpy2DArrayToArray(struct cudaArray *dst, size_t wOffsetDst, size_t hOffsetDst, const struct cudaArray *src, size_t wOffsetSrc, size_t hOffsetSrc, size_t width, size_t height, enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpyToSymbol(const char *symbol, const void *src, size_t count, size_t offset , enum cudaMemcpyKind kind );
extern  cudaError_t __stdcall cudaMemcpyFromSymbol(void *dst, const char *symbol, size_t count, size_t offset , enum cudaMemcpyKind kind );







extern  cudaError_t __stdcall cudaMemcpyAsync(void *dst, const void *src, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyToArrayAsync(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyFromArrayAsync(void *dst, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t count, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DAsync(void *dst, size_t dpitch, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DToArrayAsync(struct cudaArray *dst, size_t wOffset, size_t hOffset, const void *src, size_t spitch, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpy2DFromArrayAsync(void *dst, size_t dpitch, const struct cudaArray *src, size_t wOffset, size_t hOffset, size_t width, size_t height, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyToSymbolAsync(const char *symbol, const void *src, size_t count, size_t offset, enum cudaMemcpyKind kind, cudaStream_t stream);
extern  cudaError_t __stdcall cudaMemcpyFromSymbolAsync(void *dst, const char *symbol, size_t count, size_t offset, enum cudaMemcpyKind kind, cudaStream_t stream);







extern  cudaError_t __stdcall cudaMemset(void *mem, int c, size_t count);
extern  cudaError_t __stdcall cudaMemset2D(void *mem, size_t pitch, int c, size_t width, size_t height);







extern  cudaError_t __stdcall cudaGetSymbolAddress(void **devPtr, const char *symbol);
extern  cudaError_t __stdcall cudaGetSymbolSize(size_t *size, const char *symbol);







extern  cudaError_t __stdcall cudaGetDeviceCount(int *count);
extern  cudaError_t __stdcall cudaGetDeviceProperties(struct cudaDeviceProp *prop, int device);
extern  cudaError_t __stdcall cudaChooseDevice(int *device, const struct cudaDeviceProp *prop);
extern  cudaError_t __stdcall cudaSetDevice(int device);
extern  cudaError_t __stdcall cudaGetDevice(int *device);







extern  cudaError_t __stdcall cudaBindTexture(size_t *offset, const struct textureReference *texref, const void *devPtr, const struct cudaChannelFormatDesc *desc, size_t size );
extern  cudaError_t __stdcall cudaBindTextureToArray(const struct textureReference *texref, const struct cudaArray *array, const struct cudaChannelFormatDesc *desc);
extern  cudaError_t __stdcall cudaUnbindTexture(const struct textureReference *texref);
extern  cudaError_t __stdcall cudaGetTextureAlignmentOffset(size_t *offset, const struct textureReference *texref);
extern  cudaError_t __stdcall cudaGetTextureReference(const struct textureReference **texref, const char *symbol);







extern  cudaError_t __stdcall cudaGetChannelDesc(struct cudaChannelFormatDesc *desc, const struct cudaArray *array);
extern  struct cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int x, int y, int z, int w, enum cudaChannelFormatKind f);







extern  cudaError_t __stdcall cudaGetLastError(void);
extern  const char* __stdcall cudaGetErrorString(cudaError_t error);







extern  cudaError_t __stdcall cudaConfigureCall(dim3 gridDim, dim3 blockDim, size_t sharedMem , cudaStream_t stream );
extern  cudaError_t __stdcall cudaSetupArgument(const void *arg, size_t size, size_t offset);
extern  cudaError_t __stdcall cudaLaunch(const char *symbol);







extern  cudaError_t __stdcall cudaStreamCreate(cudaStream_t *stream);
extern  cudaError_t __stdcall cudaStreamDestroy(cudaStream_t stream);
extern  cudaError_t __stdcall cudaStreamSynchronize(cudaStream_t stream);
extern  cudaError_t __stdcall cudaStreamQuery(cudaStream_t stream);







extern  cudaError_t __stdcall cudaEventCreate(cudaEvent_t *event);
extern  cudaError_t __stdcall cudaEventRecord(cudaEvent_t event, cudaStream_t stream);
extern  cudaError_t __stdcall cudaEventQuery(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventSynchronize(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventDestroy(cudaEvent_t event);
extern  cudaError_t __stdcall cudaEventElapsedTime(float *ms, cudaEvent_t start, cudaEvent_t end);







extern  cudaError_t __stdcall cudaSetDoubleForDevice(double *d);
extern  cudaError_t __stdcall cudaSetDoubleForHost(double *d);







extern  cudaError_t __stdcall cudaThreadExit(void);
extern  cudaError_t __stdcall cudaThreadSynchronize(void);


}
#line 257 "C:\\CUDA\\include\\cuda_runtime_api.h"



#line 261 "C:\\CUDA\\include\\cuda_runtime_api.h"
#line 70 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 1 "c:\\cuda\\include\\crt\\storage_class.h"










































#line 44 "c:\\cuda\\include\\crt\\storage_class.h"






#line 51 "c:\\cuda\\include\\crt\\storage_class.h"





































#line 89 "c:\\cuda\\include\\crt\\storage_class.h"
#line 71 "C:\\CUDA\\include\\crt/host_runtime.h"












































































































































































#line 244 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 434 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#line 439 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef size_t rsize_t; }
#line 448 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int __w64 intptr_t; }
#line 466 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int __w64 ptrdiff_t; }
#line 477 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef unsigned short wint_t; }
#line 478 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef unsigned short wctype_t; }
#line 506 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int errcode; }
#line 511 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int errno_t; }
#line 515 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef long __w64 __time32_t; }
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef __int64 __time64_t; }
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef __time64_t time_t; }
#line 1702 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct threadlocaleinfostruct; 
#line 1703 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct threadmbcinfostruct; 
#line 1704 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef threadlocaleinfostruct *pthreadlocinfo; }
#line 1705 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef threadmbcinfostruct *pthreadmbcinfo; }
#line 1706 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct __lc_time_data; 
#line 1712 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef 
#line 1708 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct localeinfo_struct { 
#line 1710 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
pthreadlocinfo locinfo; 
#line 1711 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
pthreadmbcinfo mbcinfo; 
#line 1712 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
} _locale_tstruct; }extern "C" { typedef localeinfo_struct *_locale_t; }
#line 1719 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef 
#line 1715 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct tagLC_ID { 
#line 1716 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned short wLanguage; 
#line 1717 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned short wCountry; 
#line 1718 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned short wCodePage; 
#line 1719 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
} LC_ID; }extern "C" { typedef tagLC_ID *LPLC_ID; }
#line 1748 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef 
#line 1724 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct threadlocaleinfostruct { 
#line 1725 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int refcount; 
#line 1726 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned lc_codepage; 
#line 1727 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned lc_collate_cp; 
#line 1728 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned long lc_handle[6]; 
#line 1729 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
LC_ID lc_id[6]; 
#line 1730 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct { 
#line 1731 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
char *locale; 
#line 1732 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
__wchar_t *wlocale; 
#line 1733 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *refcount; 
#line 1734 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *wrefcount; 
#line 1735 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
} lc_category[6]; 
#line 1736 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int lc_clike; 
#line 1737 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int mb_cur_max; 
#line 1738 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *lconv_intl_refcount; 
#line 1739 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *lconv_num_refcount; 
#line 1740 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *lconv_mon_refcount; 
#line 1741 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct lconv *lconv; 
#line 1742 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
int *ctype1_refcount; 
#line 1743 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
unsigned short *ctype1; 
#line 1744 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
const unsigned short *pctype; 
#line 1745 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
const unsigned char *pclmap; 
#line 1746 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
const unsigned char *pcumap; 
#line 1747 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
__lc_time_data *lc_time_curr; 
#line 1748 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
} threadlocinfo; }
#line 1786 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#pragma pack ( pop )
#line 41 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern int *__cdecl _errno(); } 
#line 44 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern errno_t __cdecl _set_errno(int); } 
#line 45 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern errno_t __cdecl _get_errno(int *); } 
#line 68 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern unsigned long __cdecl __threadid(); } 
#line 70 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern uintptr_t __cdecl __threadhandle(); } 















































































#line 151 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"










#line 162 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"














#line 177 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"


#line 180 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"












#line 193 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"












#line 206 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"










#line 217 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"










#line 228 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"




















#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






































#line 288 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 292 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"


#line 295 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"


#line 298 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"









#line 308 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"








#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"








#line 326 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"














#line 341 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"







#line 349 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 356 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 363 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 370 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 377 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 384 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 391 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 398 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 405 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 412 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 419 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 426 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 433 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 440 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 447 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 454 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 461 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 468 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 475 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 482 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 489 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 496 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 503 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 510 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 517 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 524 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"







#line 532 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"







#line 540 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"







#line 548 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 555 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 562 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 569 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"







#line 577 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 584 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 591 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 598 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 605 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 612 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 616 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 620 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 624 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 628 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 632 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 636 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 640 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 644 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 648 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 652 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 656 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 660 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 664 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 668 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 672 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 676 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 680 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 684 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 688 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 692 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 696 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 700 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 704 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 708 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 712 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 716 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 720 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 724 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 728 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 732 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 736 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 740 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 744 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 748 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 752 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 756 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 760 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 764 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"

#line 766 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"



#line 770 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"






#line 777 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
#line 88 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMalloc3D(cudaPitchedPtr *, cudaExtent); } 
#line 89 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMalloc3DArray(cudaArray **, const cudaChannelFormatDesc *, cudaExtent); } 
#line 90 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemset3D(cudaPitchedPtr, int, cudaExtent); } 
#line 91 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy3D(const cudaMemcpy3DParms *); } 
#line 92 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy3DAsync(const cudaMemcpy3DParms *, cudaStream_t); } 
#line 101 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMalloc(void **, size_t); } 
#line 102 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMallocHost(void **, size_t); } 
#line 103 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMallocPitch(void **, size_t *, size_t, size_t); } 
#line 104 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMallocArray(cudaArray **, const cudaChannelFormatDesc *, size_t, size_t = (1)); } 
#line 105 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaFree(void *); } 
#line 106 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaFreeHost(void *); } 
#line 107 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaFreeArray(cudaArray *); } 
#line 116 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy(void *, const void *, size_t, cudaMemcpyKind); } 
#line 117 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyToArray(cudaArray *, size_t, size_t, const void *, size_t, cudaMemcpyKind); } 
#line 118 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromArray(void *, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 119 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyArrayToArray(cudaArray *, size_t, size_t, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind = cudaMemcpyDeviceToDevice); } 
#line 120 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2D(void *, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 121 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DToArray(cudaArray *, size_t, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 122 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DFromArray(void *, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 123 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DArrayToArray(cudaArray *, size_t, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind = cudaMemcpyDeviceToDevice); } 
#line 124 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyToSymbol(const char *, const void *, size_t, size_t = (0), cudaMemcpyKind = cudaMemcpyHostToDevice); } 
#line 125 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromSymbol(void *, const char *, size_t, size_t = (0), cudaMemcpyKind = cudaMemcpyDeviceToHost); } 
#line 133 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyAsync(void *, const void *, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 134 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyToArrayAsync(cudaArray *, size_t, size_t, const void *, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 135 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromArrayAsync(void *, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 136 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DAsync(void *, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 137 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DToArrayAsync(cudaArray *, size_t, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 138 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DFromArrayAsync(void *, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 139 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyToSymbolAsync(const char *, const void *, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 140 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromSymbolAsync(void *, const char *, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 148 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemset(void *, int, size_t); } 
#line 149 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMemset2D(void *, size_t, int, size_t, size_t); } 
#line 157 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetSymbolAddress(void **, const char *); } 
#line 158 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetSymbolSize(size_t *, const char *); } 
#line 166 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetDeviceCount(int *); } 
#line 167 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetDeviceProperties(cudaDeviceProp *, int); } 
#line 168 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaChooseDevice(int *, const cudaDeviceProp *); } 
#line 169 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaSetDevice(int); } 
#line 170 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetDevice(int *); } 
#line 178 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaBindTexture(size_t *, const textureReference *, const void *, const cudaChannelFormatDesc *, size_t = (4294967295U)); } 
#line 179 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaBindTextureToArray(const textureReference *, const cudaArray *, const cudaChannelFormatDesc *); } 
#line 180 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaUnbindTexture(const textureReference *); } 
#line 181 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetTextureAlignmentOffset(size_t *, const textureReference *); } 
#line 182 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetTextureReference(const textureReference **, const char *); } 
#line 190 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetChannelDesc(cudaChannelFormatDesc *, const cudaArray *); } 
#line 191 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int, int, int, int, cudaChannelFormatKind); } 
#line 199 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaGetLastError(); } 
#line 200 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern const char *__stdcall cudaGetErrorString(cudaError_t); } 
#line 208 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaConfigureCall(dim3, dim3, size_t = (0), cudaStream_t = (0)); } 
#line 209 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaSetupArgument(const void *, size_t, size_t); } 
#line 210 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaLaunch(const char *); } 
#line 218 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaStreamCreate(cudaStream_t *); } 
#line 219 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaStreamDestroy(cudaStream_t); } 
#line 220 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaStreamSynchronize(cudaStream_t); } 
#line 221 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaStreamQuery(cudaStream_t); } 
#line 229 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventCreate(cudaEvent_t *); } 
#line 230 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventRecord(cudaEvent_t, cudaStream_t); } 
#line 231 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventQuery(cudaEvent_t); } 
#line 232 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventSynchronize(cudaEvent_t); } 
#line 233 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventDestroy(cudaEvent_t); } 
#line 234 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaEventElapsedTime(float *, cudaEvent_t, cudaEvent_t); } 
#line 242 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaSetDoubleForDevice(double *); } 
#line 243 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaSetDoubleForHost(double *); } 
#line 251 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaThreadExit(); } 
#line 252 "C:\\CUDA\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaThreadSynchronize(); } 
#line 57 "c:\\cuda\\include\\channel_descriptor.h"
template<class T> __inline cudaChannelFormatDesc cudaCreateChannelDesc() 
#line 58 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 59 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(0, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 60 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 62 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char> () 
#line 63 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 64 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(char)) * 8); 
#line 69 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 71 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 73 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< signed char> () 
#line 74 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 75 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(signed char)) * 8); 
#line 77 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 78 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 80 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned char> () 
#line 81 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 82 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 84 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 85 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 87 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char1> () 
#line 88 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 89 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(signed char)) * 8); 
#line 91 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 92 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 94 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar1> () 
#line 95 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 96 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 98 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 99 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 101 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char2> () 
#line 102 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 103 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(signed char)) * 8); 
#line 105 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 106 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 108 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar2> () 
#line 109 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 110 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 112 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 113 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 115 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char4> () 
#line 116 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 117 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(signed char)) * 8); 
#line 119 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 120 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 122 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar4> () 
#line 123 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 124 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 126 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 127 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 129 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short> () 
#line 130 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 131 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(short)) * 8); 
#line 133 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 134 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 136 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned short> () 
#line 137 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 138 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 140 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 141 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 143 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short1> () 
#line 144 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 145 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(short)) * 8); 
#line 147 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 148 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 150 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort1> () 
#line 151 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 152 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 154 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 155 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 157 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short2> () 
#line 158 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 159 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(short)) * 8); 
#line 161 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 162 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 164 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort2> () 
#line 165 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 166 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 168 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 169 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 171 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short4> () 
#line 172 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 173 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(short)) * 8); 
#line 175 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 176 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 178 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort4> () 
#line 179 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 180 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 182 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 183 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 185 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int> () 
#line 186 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 187 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(int)) * 8); 
#line 189 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 190 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 192 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned> () 
#line 193 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 194 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 196 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 197 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 199 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int1> () 
#line 200 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 201 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(int)) * 8); 
#line 203 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 204 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 206 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint1> () 
#line 207 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 208 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 210 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 211 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 213 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int2> () 
#line 214 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 215 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(int)) * 8); 
#line 217 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 218 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 220 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint2> () 
#line 221 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 222 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 224 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 225 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 227 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int4> () 
#line 228 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 229 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(int)) * 8); 
#line 231 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 232 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 234 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint4> () 
#line 235 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 236 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 238 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 239 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 243 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long> () 
#line 244 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 245 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(long)) * 8); 
#line 247 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 248 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 250 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned long> () 
#line 251 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 252 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 254 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 255 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 257 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long1> () 
#line 258 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 259 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(long)) * 8); 
#line 261 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 262 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 264 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong1> () 
#line 265 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 266 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 268 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 269 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 271 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long2> () 
#line 272 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 273 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(long)) * 8); 
#line 275 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 276 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 278 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong2> () 
#line 279 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 280 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 282 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 283 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 285 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long4> () 
#line 286 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 287 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(long)) * 8); 
#line 289 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 290 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 292 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong4> () 
#line 293 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 294 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 296 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 297 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 301 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float> () 
#line 302 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 303 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(float)) * 8); 
#line 305 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindFloat); 
#line 306 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 308 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float1> () 
#line 309 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 310 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(float)) * 8); 
#line 312 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindFloat); 
#line 313 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 315 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float2> () 
#line 316 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 317 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(float)) * 8); 
#line 319 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindFloat); 
#line 320 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 322 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float4> () 
#line 323 "c:\\cuda\\include\\channel_descriptor.h"
{ 
#line 324 "c:\\cuda\\include\\channel_descriptor.h"
auto int e = (((int)sizeof(float)) * 8); 
#line 326 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindFloat); 
#line 327 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 94 "c:\\cuda\\include\\texture_types.h"
template<class T, int dim = 1, cudaTextureReadMode  = cudaReadModeElementType> 
#line 95 "c:\\cuda\\include\\texture_types.h"
struct texture : public textureReference { 
#line 97 "c:\\cuda\\include\\texture_types.h"
texture(int norm = 0, cudaTextureFilterMode 
#line 98 "c:\\cuda\\include\\texture_types.h"
fMode = cudaFilterModePoint, cudaTextureAddressMode 
#line 99 "c:\\cuda\\include\\texture_types.h"
aMode = cudaAddressModeClamp) 
#line 100 "c:\\cuda\\include\\texture_types.h"
{ 
#line 101 "c:\\cuda\\include\\texture_types.h"
(this->normalized) = norm; 
#line 102 "c:\\cuda\\include\\texture_types.h"
(this->filterMode) = fMode; 
#line 103 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[0]) = aMode; 
#line 104 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[1]) = aMode; 
#line 105 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[2]) = aMode; 
#line 106 "c:\\cuda\\include\\texture_types.h"
(this->channelDesc) = cudaCreateChannelDesc< T> (); 
#line 107 "c:\\cuda\\include\\texture_types.h"
} 
#line 109 "c:\\cuda\\include\\texture_types.h"
texture(int norm, cudaTextureFilterMode 
#line 110 "c:\\cuda\\include\\texture_types.h"
fMode, cudaTextureAddressMode 
#line 111 "c:\\cuda\\include\\texture_types.h"
aMode, cudaChannelFormatDesc 
#line 112 "c:\\cuda\\include\\texture_types.h"
desc) 
#line 113 "c:\\cuda\\include\\texture_types.h"
{ 
#line 114 "c:\\cuda\\include\\texture_types.h"
(this->normalized) = norm; 
#line 115 "c:\\cuda\\include\\texture_types.h"
(this->filterMode) = fMode; 
#line 116 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[0]) = aMode; 
#line 117 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[1]) = aMode; 
#line 118 "c:\\cuda\\include\\texture_types.h"
((this->addressMode)[2]) = aMode; 
#line 119 "c:\\cuda\\include\\texture_types.h"
(this->channelDesc) = desc; 
#line 120 "c:\\cuda\\include\\texture_types.h"
} 
#line 121 "c:\\cuda\\include\\texture_types.h"
}; 
#line 54 "c:\\cuda\\include\\driver_functions.h"
static __inline cudaPitchedPtr make_cudaPitchedPtr(void *d, size_t p, size_t xsz, size_t ysz) 
#line 55 "c:\\cuda\\include\\driver_functions.h"
{ 
#line 56 "c:\\cuda\\include\\driver_functions.h"
auto cudaPitchedPtr s; 
#line 58 "c:\\cuda\\include\\driver_functions.h"
(s.ptr) = d; 
#line 59 "c:\\cuda\\include\\driver_functions.h"
(s.pitch) = p; 
#line 60 "c:\\cuda\\include\\driver_functions.h"
(s.xsize) = xsz; 
#line 61 "c:\\cuda\\include\\driver_functions.h"
(s.ysize) = ysz; 
#line 63 "c:\\cuda\\include\\driver_functions.h"
return s; 
#line 64 "c:\\cuda\\include\\driver_functions.h"
} 
#line 66 "c:\\cuda\\include\\driver_functions.h"
static __inline cudaPos make_cudaPos(size_t x, size_t y, size_t z) 
#line 67 "c:\\cuda\\include\\driver_functions.h"
{ 
#line 68 "c:\\cuda\\include\\driver_functions.h"
auto cudaPos p; 
#line 70 "c:\\cuda\\include\\driver_functions.h"
(p.x) = x; 
#line 71 "c:\\cuda\\include\\driver_functions.h"
(p.y) = y; 
#line 72 "c:\\cuda\\include\\driver_functions.h"
(p.z) = z; 
#line 74 "c:\\cuda\\include\\driver_functions.h"
return p; 
#line 75 "c:\\cuda\\include\\driver_functions.h"
} 
#line 77 "c:\\cuda\\include\\driver_functions.h"
static __inline cudaExtent make_cudaExtent(size_t w, size_t h, size_t d) 
#line 78 "c:\\cuda\\include\\driver_functions.h"
{ 
#line 79 "c:\\cuda\\include\\driver_functions.h"
auto cudaExtent e; 
#line 81 "c:\\cuda\\include\\driver_functions.h"
(e.width) = w; 
#line 82 "c:\\cuda\\include\\driver_functions.h"
(e.height) = h; 
#line 83 "c:\\cuda\\include\\driver_functions.h"
(e.depth) = d; 
#line 85 "c:\\cuda\\include\\driver_functions.h"
return e; 
#line 86 "c:\\cuda\\include\\driver_functions.h"
} 
#line 54 "c:\\cuda\\include\\vector_functions.h"
static __inline char1 make_char1(signed char x) 
#line 55 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 56 "c:\\cuda\\include\\vector_functions.h"
auto char1 t; (t.x) = x; return t; 
#line 57 "c:\\cuda\\include\\vector_functions.h"
} 
#line 59 "c:\\cuda\\include\\vector_functions.h"
static __inline uchar1 make_uchar1(unsigned char x) 
#line 60 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 61 "c:\\cuda\\include\\vector_functions.h"
auto uchar1 t; (t.x) = x; return t; 
#line 62 "c:\\cuda\\include\\vector_functions.h"
} 
#line 64 "c:\\cuda\\include\\vector_functions.h"
static __inline char2 make_char2(signed char x, signed char y) 
#line 65 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 66 "c:\\cuda\\include\\vector_functions.h"
auto char2 t; (t.x) = x; (t.y) = y; return t; 
#line 67 "c:\\cuda\\include\\vector_functions.h"
} 
#line 69 "c:\\cuda\\include\\vector_functions.h"
static __inline uchar2 make_uchar2(unsigned char x, unsigned char y) 
#line 70 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 71 "c:\\cuda\\include\\vector_functions.h"
auto uchar2 t; (t.x) = x; (t.y) = y; return t; 
#line 72 "c:\\cuda\\include\\vector_functions.h"
} 
#line 74 "c:\\cuda\\include\\vector_functions.h"
static __inline char3 make_char3(signed char x, signed char y, signed char z) 
#line 75 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 76 "c:\\cuda\\include\\vector_functions.h"
auto char3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 77 "c:\\cuda\\include\\vector_functions.h"
} 
#line 79 "c:\\cuda\\include\\vector_functions.h"
static __inline uchar3 make_uchar3(unsigned char x, unsigned char y, unsigned char z) 
#line 80 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 81 "c:\\cuda\\include\\vector_functions.h"
auto uchar3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 82 "c:\\cuda\\include\\vector_functions.h"
} 
#line 84 "c:\\cuda\\include\\vector_functions.h"
static __inline char4 make_char4(signed char x, signed char y, signed char z, signed char w) 
#line 85 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 86 "c:\\cuda\\include\\vector_functions.h"
auto char4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 87 "c:\\cuda\\include\\vector_functions.h"
} 
#line 89 "c:\\cuda\\include\\vector_functions.h"
static __inline uchar4 make_uchar4(unsigned char x, unsigned char y, unsigned char z, unsigned char w) 
#line 90 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 91 "c:\\cuda\\include\\vector_functions.h"
auto uchar4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 92 "c:\\cuda\\include\\vector_functions.h"
} 
#line 94 "c:\\cuda\\include\\vector_functions.h"
static __inline short1 make_short1(short x) 
#line 95 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 96 "c:\\cuda\\include\\vector_functions.h"
auto short1 t; (t.x) = x; return t; 
#line 97 "c:\\cuda\\include\\vector_functions.h"
} 
#line 99 "c:\\cuda\\include\\vector_functions.h"
static __inline ushort1 make_ushort1(unsigned short x) 
#line 100 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 101 "c:\\cuda\\include\\vector_functions.h"
auto ushort1 t; (t.x) = x; return t; 
#line 102 "c:\\cuda\\include\\vector_functions.h"
} 
#line 104 "c:\\cuda\\include\\vector_functions.h"
static __inline short2 make_short2(short x, short y) 
#line 105 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 106 "c:\\cuda\\include\\vector_functions.h"
auto short2 t; (t.x) = x; (t.y) = y; return t; 
#line 107 "c:\\cuda\\include\\vector_functions.h"
} 
#line 109 "c:\\cuda\\include\\vector_functions.h"
static __inline ushort2 make_ushort2(unsigned short x, unsigned short y) 
#line 110 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 111 "c:\\cuda\\include\\vector_functions.h"
auto ushort2 t; (t.x) = x; (t.y) = y; return t; 
#line 112 "c:\\cuda\\include\\vector_functions.h"
} 
#line 114 "c:\\cuda\\include\\vector_functions.h"
static __inline short3 make_short3(short x, short y, short z) 
#line 115 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 116 "c:\\cuda\\include\\vector_functions.h"
auto short3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 117 "c:\\cuda\\include\\vector_functions.h"
} 
#line 119 "c:\\cuda\\include\\vector_functions.h"
static __inline ushort3 make_ushort3(unsigned short x, unsigned short y, unsigned short z) 
#line 120 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 121 "c:\\cuda\\include\\vector_functions.h"
auto ushort3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 122 "c:\\cuda\\include\\vector_functions.h"
} 
#line 124 "c:\\cuda\\include\\vector_functions.h"
static __inline short4 make_short4(short x, short y, short z, short w) 
#line 125 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 126 "c:\\cuda\\include\\vector_functions.h"
auto short4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 127 "c:\\cuda\\include\\vector_functions.h"
} 
#line 129 "c:\\cuda\\include\\vector_functions.h"
static __inline ushort4 make_ushort4(unsigned short x, unsigned short y, unsigned short z, unsigned short w) 
#line 130 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 131 "c:\\cuda\\include\\vector_functions.h"
auto ushort4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 132 "c:\\cuda\\include\\vector_functions.h"
} 
#line 134 "c:\\cuda\\include\\vector_functions.h"
static __inline int1 make_int1(int x) 
#line 135 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 136 "c:\\cuda\\include\\vector_functions.h"
auto int1 t; (t.x) = x; return t; 
#line 137 "c:\\cuda\\include\\vector_functions.h"
} 
#line 139 "c:\\cuda\\include\\vector_functions.h"
static __inline uint1 make_uint1(unsigned x) 
#line 140 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 141 "c:\\cuda\\include\\vector_functions.h"
auto uint1 t; (t.x) = x; return t; 
#line 142 "c:\\cuda\\include\\vector_functions.h"
} 
#line 144 "c:\\cuda\\include\\vector_functions.h"
static __inline int2 make_int2(int x, int y) 
#line 145 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 146 "c:\\cuda\\include\\vector_functions.h"
auto int2 t; (t.x) = x; (t.y) = y; return t; 
#line 147 "c:\\cuda\\include\\vector_functions.h"
} 
#line 149 "c:\\cuda\\include\\vector_functions.h"
static __inline uint2 make_uint2(unsigned x, unsigned y) 
#line 150 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 151 "c:\\cuda\\include\\vector_functions.h"
auto uint2 t; (t.x) = x; (t.y) = y; return t; 
#line 152 "c:\\cuda\\include\\vector_functions.h"
} 
#line 154 "c:\\cuda\\include\\vector_functions.h"
static __inline int3 make_int3(int x, int y, int z) 
#line 155 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 156 "c:\\cuda\\include\\vector_functions.h"
auto int3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 157 "c:\\cuda\\include\\vector_functions.h"
} 
#line 159 "c:\\cuda\\include\\vector_functions.h"
static __inline uint3 make_uint3(unsigned x, unsigned y, unsigned z) 
#line 160 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 161 "c:\\cuda\\include\\vector_functions.h"
auto uint3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 162 "c:\\cuda\\include\\vector_functions.h"
} 
#line 164 "c:\\cuda\\include\\vector_functions.h"
static __inline int4 make_int4(int x, int y, int z, int w) 
#line 165 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 166 "c:\\cuda\\include\\vector_functions.h"
auto int4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 167 "c:\\cuda\\include\\vector_functions.h"
} 
#line 169 "c:\\cuda\\include\\vector_functions.h"
static __inline uint4 make_uint4(unsigned x, unsigned y, unsigned z, unsigned w) 
#line 170 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 171 "c:\\cuda\\include\\vector_functions.h"
auto uint4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 172 "c:\\cuda\\include\\vector_functions.h"
} 
#line 174 "c:\\cuda\\include\\vector_functions.h"
static __inline long1 make_long1(long x) 
#line 175 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 176 "c:\\cuda\\include\\vector_functions.h"
auto long1 t; (t.x) = x; return t; 
#line 177 "c:\\cuda\\include\\vector_functions.h"
} 
#line 179 "c:\\cuda\\include\\vector_functions.h"
static __inline ulong1 make_ulong1(unsigned long x) 
#line 180 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 181 "c:\\cuda\\include\\vector_functions.h"
auto ulong1 t; (t.x) = x; return t; 
#line 182 "c:\\cuda\\include\\vector_functions.h"
} 
#line 184 "c:\\cuda\\include\\vector_functions.h"
static __inline long2 make_long2(long x, long y) 
#line 185 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 186 "c:\\cuda\\include\\vector_functions.h"
auto long2 t; (t.x) = x; (t.y) = y; return t; 
#line 187 "c:\\cuda\\include\\vector_functions.h"
} 
#line 189 "c:\\cuda\\include\\vector_functions.h"
static __inline ulong2 make_ulong2(unsigned long x, unsigned long y) 
#line 190 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 191 "c:\\cuda\\include\\vector_functions.h"
auto ulong2 t; (t.x) = x; (t.y) = y; return t; 
#line 192 "c:\\cuda\\include\\vector_functions.h"
} 
#line 196 "c:\\cuda\\include\\vector_functions.h"
static __inline long3 make_long3(long x, long y, long z) 
#line 197 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 198 "c:\\cuda\\include\\vector_functions.h"
auto long3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 199 "c:\\cuda\\include\\vector_functions.h"
} 
#line 201 "c:\\cuda\\include\\vector_functions.h"
static __inline ulong3 make_ulong3(unsigned long x, unsigned long y, unsigned long z) 
#line 202 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 203 "c:\\cuda\\include\\vector_functions.h"
auto ulong3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 204 "c:\\cuda\\include\\vector_functions.h"
} 
#line 206 "c:\\cuda\\include\\vector_functions.h"
static __inline long4 make_long4(long x, long y, long z, long w) 
#line 207 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 208 "c:\\cuda\\include\\vector_functions.h"
auto long4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 209 "c:\\cuda\\include\\vector_functions.h"
} 
#line 211 "c:\\cuda\\include\\vector_functions.h"
static __inline ulong4 make_ulong4(unsigned long x, unsigned long y, unsigned long z, unsigned long w) 
#line 212 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 213 "c:\\cuda\\include\\vector_functions.h"
auto ulong4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 214 "c:\\cuda\\include\\vector_functions.h"
} 
#line 218 "c:\\cuda\\include\\vector_functions.h"
static __inline float1 make_float1(float x) 
#line 219 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 220 "c:\\cuda\\include\\vector_functions.h"
auto float1 t; (t.x) = x; return t; 
#line 221 "c:\\cuda\\include\\vector_functions.h"
} 
#line 223 "c:\\cuda\\include\\vector_functions.h"
static __inline float2 make_float2(float x, float y) 
#line 224 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 225 "c:\\cuda\\include\\vector_functions.h"
auto float2 t; (t.x) = x; (t.y) = y; return t; 
#line 226 "c:\\cuda\\include\\vector_functions.h"
} 
#line 228 "c:\\cuda\\include\\vector_functions.h"
static __inline float3 make_float3(float x, float y, float z) 
#line 229 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 230 "c:\\cuda\\include\\vector_functions.h"
auto float3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 231 "c:\\cuda\\include\\vector_functions.h"
} 
#line 233 "c:\\cuda\\include\\vector_functions.h"
static __inline float4 make_float4(float x, float y, float z, float w) 
#line 234 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 235 "c:\\cuda\\include\\vector_functions.h"
auto float4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 236 "c:\\cuda\\include\\vector_functions.h"
} 
#line 238 "c:\\cuda\\include\\vector_functions.h"
static __inline double1 make_double1(double x) 
#line 239 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 240 "c:\\cuda\\include\\vector_functions.h"
auto double1 t; (t.x) = x; return t; 
#line 241 "c:\\cuda\\include\\vector_functions.h"
} 
#line 243 "c:\\cuda\\include\\vector_functions.h"
static __inline double2 make_double2(double x, double y) 
#line 244 "c:\\cuda\\include\\vector_functions.h"
{ 
#line 245 "c:\\cuda\\include\\vector_functions.h"
auto double2 t; (t.x) = x; (t.y) = y; return t; 
#line 246 "c:\\cuda\\include\\vector_functions.h"
} 
#line 35 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
#pragma pack ( push, 8 )
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { typedef long clock_t; }
#line 119 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { struct tm { 
#line 120 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_sec; 
#line 121 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_min; 
#line 122 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_hour; 
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_mday; 
#line 124 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_mon; 
#line 125 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_year; 
#line 126 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_wday; 
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_yday; 
#line 128 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
int tm_isdst; 
#line 129 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
}; }
#line 144 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_daylight instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int *__cdecl __daylight(); } 
#line 148 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_dstbias instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long *__cdecl __dstbias(); } 
#line 152 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_timezone instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long *__cdecl __timezone(); } 
#line 156 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_tzname instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char **__cdecl __tzname(); } 
#line 159 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _get_daylight(int *); } 
#line 160 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _get_dstbias(long *); } 
#line 161 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _get_timezone(long *); } 
#line 162 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _get_tzname(size_t *, char *, size_t, int); } 
#line 166 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using asctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl asctime(const tm *); } 
#line 168 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl asctime_s(char *, size_t, const tm *); } 
#line 170 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl asctime_s(char (&_Buffer)[_Size], const tm *_Time) { return asctime_s(_Buffer, _Size, _Time); } 
#line 172 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ctime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ctime32(const __time32_t *); } 
#line 173 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _ctime32_s(char *, size_t, const __time32_t *); } 
#line 174 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _ctime32_s(char (&_Buffer)[_Size], const __time32_t *_Time) { return _ctime32_s(_Buffer, _Size, _Time); } 
#line 176 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern clock_t __cdecl clock(); } 
#line 177 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern double __cdecl _difftime32(__time32_t, __time32_t); } 
#line 179 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gmtime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _gmtime32(const __time32_t *); } 
#line 180 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _gmtime32_s(tm *, const __time32_t *); } 
#line 182 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _localtime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _localtime32(const __time32_t *); } 
#line 183 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _localtime32_s(tm *, const __time32_t *); } 
#line 185 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern size_t __cdecl strftime(char *, size_t, const char *, const tm *); } 
#line 186 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern size_t __cdecl _strftime_l(char *, size_t, const char *, const tm *, _locale_t); } 
#line 188 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _strdate_s(char *, size_t); } 
#line 189 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _strdate_s(char (&_Buffer)[_Size]) { return _strdate_s(_Buffer, _Size); } 
#line 190 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strdate_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strdate(char *); } 
#line 192 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _strtime_s(char *, size_t); } 
#line 193 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _strtime_s(char (&_Buffer)[_Size]) { return _strtime_s(_Buffer, _Size); } 
#line 194 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strtime(char *); } 
#line 196 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time32_t __cdecl _time32(__time32_t *); } 
#line 197 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time32_t __cdecl _mktime32(tm *); } 
#line 198 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time32_t __cdecl _mkgmtime32(tm *); } 
#line 203 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern void __cdecl _tzset(); } 
#line 207 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern double __cdecl _difftime64(__time64_t, __time64_t); } 
#line 208 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ctime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ctime64(const __time64_t *); } 
#line 209 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _ctime64_s(char *, size_t, const __time64_t *); } 
#line 210 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _ctime64_s(char (&_Buffer)[_Size], const __time64_t *_Time) { return _ctime64_s(_Buffer, _Size, _Time); } 
#line 212 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gmtime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _gmtime64(const __time64_t *); } 
#line 213 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _gmtime64_s(tm *, const __time64_t *); } 
#line 215 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _localtime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _localtime64(const __time64_t *); } 
#line 216 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _localtime64_s(tm *, const __time64_t *); } 
#line 218 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time64_t __cdecl _mktime64(tm *); } 
#line 219 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time64_t __cdecl _mkgmtime64(tm *); } 
#line 220 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __time64_t __cdecl _time64(__time64_t *); } 
#line 224 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetLocalTimeinstead. See online help for details.")) unsigned __cdecl _getsystime(tm *); } 
#line 225 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSetLocalTimeinstead. See online help for details.")) unsigned __cdecl _setsystime(tm *, unsigned); } 
#line 237 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wasctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wasctime(const tm *); } 
#line 238 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _wasctime_s(__wchar_t *, size_t, const tm *); } 
#line 239 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _wasctime_s(__wchar_t (&_Buffer)[_Size], const tm *_Time) { return _wasctime_s(_Buffer, _Size, _Time); } 
#line 241 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wctime32(const __time32_t *); } 
#line 242 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _wctime32_s(__wchar_t *, size_t, const __time32_t *); } 
#line 243 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _wctime32_s(__wchar_t (&_Buffer)[_Size], const __time32_t *_Time) { return _wctime32_s(_Buffer, _Size, _Time); } 
#line 245 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern size_t __cdecl wcsftime(__wchar_t *, size_t, const __wchar_t *, const tm *); } 
#line 246 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern size_t __cdecl _wcsftime_l(__wchar_t *, size_t, const __wchar_t *, const tm *, _locale_t); } 
#line 248 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _wstrdate_s(__wchar_t *, size_t); } 
#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _wstrdate_s(__wchar_t (&_Buffer)[_Size]) { return _wstrdate_s(_Buffer, _Size); } 
#line 250 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wstrdate_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wstrdate(__wchar_t *); } 
#line 252 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _wstrtime_s(__wchar_t *, size_t); } 
#line 253 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _wstrtime_s(__wchar_t (&_Buffer)[_Size]) { return _wstrtime_s(_Buffer, _Size); } 
#line 254 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wstrtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wstrtime(__wchar_t *); } 
#line 257 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wctime64(const __time64_t *); } 
#line 258 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern errno_t __cdecl _wctime64_s(__wchar_t *, size_t, const __time64_t *); } 
#line 259 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl _wctime64_s(__wchar_t (&_Buffer)[_Size], const __time64_t *_Time) { return _wctime64_s(_Buffer, _Size, _Time); } 
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(push)
#pragma warning(disable:4996)
#line 46 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
extern "C" { static __inline __wchar_t *__cdecl _wctime(const time_t *_Time) 
#line 47 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _wctime64(_Time); 
#pragma warning( pop )
} } 
#line 54 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
extern "C" { static __inline errno_t __cdecl _wctime_s(__wchar_t *_Buffer, size_t _SizeInWords, const time_t *_Time) 
#line 55 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
{ 
#line 56 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
return _wctime64_s(_Buffer, _SizeInWords, _Time); 
#line 57 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
} } 
#line 60 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(pop)
#line 84 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline double __cdecl difftime(time_t _Time1, time_t _Time2) 
#line 85 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 86 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _difftime64(_Time1, _Time2); 
#line 87 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 88 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using ctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ctime(const time_t *_Time) 
#line 89 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _ctime64(_Time); 
#pragma warning( pop )
} } 
#line 96 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline errno_t __cdecl ctime_s(char *_Buffer, size_t _SizeInBytes, const time_t *_Time) 
#line 97 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 98 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _ctime64_s(_Buffer, _SizeInBytes, _Time); 
#line 99 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 101 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using gmtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl gmtime(const time_t *_Time) 
#line 102 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _gmtime64(_Time); 
#pragma warning( pop )
} } 
#line 109 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline errno_t __cdecl gmtime_s(tm *_Tm, const time_t *_Time) 
#line 110 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 111 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _gmtime64_s(_Tm, _Time); 
#line 112 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using localtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl localtime(const time_t *_Time) 
#line 115 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _localtime64(_Time); 
#pragma warning( pop )
} } 
#line 121 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline errno_t __cdecl localtime_s(tm *_Tm, const time_t *_Time) 
#line 122 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _localtime64_s(_Tm, _Time); 
#line 124 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 125 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline time_t __cdecl mktime(tm *_Tm) 
#line 126 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _mktime64(_Tm); 
#line 128 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 129 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline time_t __cdecl _mkgmtime(tm *_Tm) 
#line 130 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _mkgmtime64(_Tm); 
#line 132 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 133 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline time_t __cdecl time(time_t *_Time) 
#line 134 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
{ 
#line 135 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
return _time64(_Time); 
#line 136 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
} } 
#line 285 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_daylight instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int daylight; 
#line 286 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_timezone instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long timezone; 
#line 287 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_tzname instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *tzname[2]; 
#line 290 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _tzset. See online help for details.")) void __cdecl tzset(); } 
#line 300 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
#pragma pack ( pop )
#line 48 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl _memccpy(void *, const void *, int, size_t); } 
#line 49 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const void *__cdecl memchr(const void *, int, size_t); } 
#line 50 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _memicmp(const void *, const void *, size_t); } 
#line 51 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _memicmp_l(const void *, const void *, size_t, _locale_t); } 
#line 52 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl memcmp(const void *, const void *, size_t); } 
#line 53 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl memcpy(void *, const void *, size_t); } 
#line 55 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl memcpy_s(void *, rsize_t, const void *, rsize_t); } 
#line 57 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl memset(void *, int, size_t); } 
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _memccpy. See online help for details.")) void *__cdecl memccpy(void *, const void *, int, size_t); } 
#line 62 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _memicmp. See online help for details.")) int __cdecl memicmp(const void *, const void *, size_t); } 
#line 67 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strset(char *, int); } 
#line 68 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strset_s(char *, size_t, int); } 
#line 70 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl strcpy_s(char *, rsize_t, const char *); } 
#line 72 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strcpy_s(char (&_Dest)[_Size], const char *_Source) { return strcpy_s(_Dest, _Size, _Source); } 
#line 73 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strcpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strcpy(char *, const char *); } 
#line 75 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl strcat_s(char *, rsize_t, const char *); } 
#line 77 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strcat_s(char (&_Dest)[_Size], const char *_Source) { return strcat_s(_Dest, _Size, _Source); } 
#line 78 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strcat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strcat(char *, const char *); } 
#line 79 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl strcmp(const char *, const char *); } 
#line 80 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl strlen(const char *); } 
#line 81 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl strnlen(const char *, size_t); } 
#line 83 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { static __inline size_t __cdecl strnlen_s(const char *_Str, size_t _MaxCount) 
#line 84 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ 
#line 85 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
return strnlen(_Str, _MaxCount); 
#line 86 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
} } 
#line 89 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl memmove_s(void *, rsize_t, const void *, rsize_t); } 
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl memmove(void *, const void *, size_t); } 
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern char *__cdecl _strdup(const char *); } 
#line 109 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const char *__cdecl strchr(const char *, int); } 
#line 110 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _stricmp(const char *, const char *); } 
#line 111 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strcmpi(const char *, const char *); } 
#line 112 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _stricmp_l(const char *, const char *, _locale_t); } 
#line 113 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl strcoll(const char *, const char *); } 
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strcoll_l(const char *, const char *, _locale_t); } 
#line 115 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _stricoll(const char *, const char *); } 
#line 116 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _stricoll_l(const char *, const char *, _locale_t); } 
#line 117 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strncoll(const char *, const char *, size_t); } 
#line 118 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strncoll_l(const char *, const char *, size_t, _locale_t); } 
#line 119 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strnicoll(const char *, const char *, size_t); } 
#line 120 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strnicoll_l(const char *, const char *, size_t, _locale_t); } 
#line 121 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl strcspn(const char *, const char *); } 
#line 122 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strerror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strerror(const char *); } 
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strerror_s(char *, size_t, const char *); } 
#line 124 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _strerror_s(char (&_Buffer)[_Size], const char *_ErrorMessage) { return _strerror_s(_Buffer, _Size, _ErrorMessage); } 
#line 125 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strerror(int); } 
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl strerror_s(char *, size_t, int); } 
#line 129 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strerror_s(char (&_Buffer)[_Size], int _ErrorMessage) { return strerror_s(_Buffer, _Size, _ErrorMessage); } 
#line 130 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strlwr_s(char *, size_t); } 
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _strlwr_s(char (&_String)[_Size]) { return _strlwr_s(_String, _Size); } 
#line 132 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strlwr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strlwr(char *); } 
#line 133 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strlwr_s_l(char *, size_t, _locale_t); } 
#line 134 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _strlwr_s_l(char (&_String)[_Size], _locale_t _Locale) { return _strlwr_s_l(_String, _Size, _Locale); } 
#line 135 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strlwr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strlwr_l(char *, _locale_t); } 
#line 137 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl strncat_s(char *, rsize_t, const char *, rsize_t); } 
#line 139 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strncat_s(char (&_Dest)[_Size], const char *_Source, size_t _Count) { return strncat_s(_Dest, _Size, _Source, _Count); } 
#pragma warning(push)
#pragma warning(disable:4609 6059)
#line 143 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strncat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strncat(char *, const char *, size_t); } 
#pragma warning(pop)
#line 148 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl strncmp(const char *, const char *, size_t); } 
#line 150 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strnicmp(const char *, const char *, size_t); } 
#line 151 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strnicmp_l(const char *, const char *, size_t, _locale_t); } 
#line 153 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl strncpy_s(char *, rsize_t, const char *, rsize_t); } 
#line 155 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strncpy_s(char (&_Dest)[_Size], const char *_Source, size_t _Count) { return strncpy_s(_Dest, _Size, _Source, _Count); } 
#line 156 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strncpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strncpy(char *, const char *, size_t); } 
#line 157 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strnset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strnset(char *, int, size_t); } 
#line 158 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strnset_s(char *, size_t, int, size_t); } 
#line 159 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const char *__cdecl strpbrk(const char *, const char *); } 
#line 160 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const char *__cdecl strrchr(const char *, int); } 
#line 161 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern char *__cdecl _strrev(char *); } 
#line 162 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl strspn(const char *, const char *); } 
#line 163 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const char *__cdecl strstr(const char *, const char *); } 
#line 164 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strtok_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strtok(char *, const char *); } 
#line 166 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern char *__cdecl strtok_s(char *, const char *, char **); } 
#line 168 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strupr_s(char *, size_t); } 
#line 169 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _strupr_s(char (&_String)[_Size]) { return _strupr_s(_String, _Size); } 
#line 170 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strupr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strupr(char *); } 
#line 171 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strupr_s_l(char *, size_t, _locale_t); } 
#line 172 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _strupr_s_l(char (&_String)[_Size], _locale_t _Locale) { return _strupr_s_l(_String, _Size, _Locale); } 
#line 173 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strupr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strupr_l(char *, _locale_t); } 
#line 174 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl strxfrm(char *, const char *, size_t); } 
#line 175 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl _strxfrm_l(char *, const char *, size_t, _locale_t); } 
#line 181 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline char *__cdecl strchr(char *_Str, int _Ch) 
#line 182 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (char *)strchr((const char *)_Str, _Ch); } 
#line 183 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline char *__cdecl strpbrk(char *_Str, const char *_Control) 
#line 184 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (char *)strpbrk((const char *)_Str, _Control); } 
#line 185 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline char *__cdecl strrchr(char *_Str, int _Ch) 
#line 186 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (char *)strrchr((const char *)_Str, _Ch); } 
#line 187 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline char *__cdecl strstr(char *_Str, const char *_SubStr) 
#line 188 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (char *)strstr((const char *)_Str, _SubStr); } 
#line 192 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline void *__cdecl memchr(void *_Pv, int _C, size_t _N) 
#line 193 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (void *)memchr((const void *)_Pv, _C, _N); } 
#line 205 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strdup. See online help for details.")) char *__cdecl strdup(const char *); } 
#line 212 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strcmpi. See online help for details.")) int __cdecl strcmpi(const char *, const char *); } 
#line 213 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _stricmp. See online help for details.")) int __cdecl stricmp(const char *, const char *); } 
#line 214 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strlwr. See online help for details.")) char *__cdecl strlwr(char *); } 
#line 215 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strnicmp. See online help for details.")) int __cdecl strnicmp(const char *, const char *, size_t); } 
#line 216 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strnset. See online help for details.")) char *__cdecl strnset(char *, int, size_t); } 
#line 217 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strrev. See online help for details.")) char *__cdecl strrev(char *); } 
#line 218 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strset. See online help for details.")) char *__cdecl strset(char *, int); } 
#line 219 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strupr. See online help for details.")) char *__cdecl strupr(char *); } 
#line 233 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __wchar_t *__cdecl _wcsdup(const __wchar_t *); } 
#line 240 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcscat_s(__wchar_t *, rsize_t, const __wchar_t *); } 
#line 242 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcscat_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source) { return wcscat_s(_Dest, _Size, _Source); } 
#line 243 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcscat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcscat(__wchar_t *, const __wchar_t *); } 
#line 244 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const __wchar_t *__cdecl wcschr(const __wchar_t *, __wchar_t); } 
#line 245 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl wcscmp(const __wchar_t *, const __wchar_t *); } 
#line 247 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcscpy_s(__wchar_t *, rsize_t, const __wchar_t *); } 
#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcscpy_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source) { return wcscpy_s(_Dest, _Size, _Source); } 
#line 250 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcscpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcscpy(__wchar_t *, const __wchar_t *); } 
#line 251 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl wcscspn(const __wchar_t *, const __wchar_t *); } 
#line 252 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl wcslen(const __wchar_t *); } 
#line 253 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl wcsnlen(const __wchar_t *, size_t); } 
#line 255 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { static __inline size_t __cdecl wcsnlen_s(const __wchar_t *_Src, size_t _MaxCount) 
#line 256 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ 
#line 257 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
return wcsnlen(_Src, _MaxCount); 
#line 258 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
} } 
#line 261 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcsncat_s(__wchar_t *, rsize_t, const __wchar_t *, rsize_t); } 
#line 263 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcsncat_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source, size_t _Count) { return wcsncat_s(_Dest, _Size, _Source, _Count); } 
#line 264 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcsncat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcsncat(__wchar_t *, const __wchar_t *, size_t); } 
#line 265 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl wcsncmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 267 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcsncpy_s(__wchar_t *, rsize_t, const __wchar_t *, rsize_t); } 
#line 269 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcsncpy_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source, size_t _Count) { return wcsncpy_s(_Dest, _Size, _Source, _Count); } 
#line 270 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcsncpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcsncpy(__wchar_t *, const __wchar_t *, size_t); } 
#line 271 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const __wchar_t *__cdecl wcspbrk(const __wchar_t *, const __wchar_t *); } 
#line 272 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const __wchar_t *__cdecl wcsrchr(const __wchar_t *, __wchar_t); } 
#line 273 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl wcsspn(const __wchar_t *, const __wchar_t *); } 
#line 274 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const __wchar_t *__cdecl wcsstr(const __wchar_t *, const __wchar_t *); } 
#line 275 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcstok_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcstok(__wchar_t *, const __wchar_t *); } 
#line 276 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __wchar_t *__cdecl wcstok_s(__wchar_t *, const __wchar_t *, __wchar_t **); } 
#line 277 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcserror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcserror(int); } 
#line 278 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcserror_s(__wchar_t *, size_t, int); } 
#line 279 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _wcserror_s(__wchar_t (&_Buffer)[_Size], int _Error) { return _wcserror_s(_Buffer, _Size, _Error); } 
#line 280 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using __wcserror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl __wcserror(const __wchar_t *); } 
#line 281 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl __wcserror_s(__wchar_t *, size_t, const __wchar_t *); } 
#line 282 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl __wcserror_s(__wchar_t (&_Buffer)[_Size], const __wchar_t *_ErrorMessage) { return __wcserror_s(_Buffer, _Size, _ErrorMessage); } 
#line 284 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsicmp(const __wchar_t *, const __wchar_t *); } 
#line 285 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsicmp_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 286 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsnicmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 287 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsnicmp_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 288 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsnset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsnset(__wchar_t *, __wchar_t, size_t); } 
#line 289 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcsnset_s(__wchar_t *, size_t, __wchar_t, size_t); } 
#line 290 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __wchar_t *__cdecl _wcsrev(__wchar_t *); } 
#line 291 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsset(__wchar_t *, __wchar_t); } 
#line 292 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcsset_s(__wchar_t *, size_t, __wchar_t); } 
#line 294 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcslwr_s(__wchar_t *, size_t); } 
#line 295 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _wcslwr_s(__wchar_t (&_String)[_Size]) { return _wcslwr_s(_String, _Size); } 
#line 296 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcslwr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcslwr(__wchar_t *); } 
#line 297 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcslwr_s_l(__wchar_t *, size_t, _locale_t); } 
#line 298 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _wcslwr_s_l(__wchar_t (&_String)[_Size], _locale_t _Locale) { return _wcslwr_s_l(_String, _Size, _Locale); } 
#line 299 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcslwr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcslwr_l(__wchar_t *, _locale_t); } 
#line 300 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcsupr_s(__wchar_t *, size_t); } 
#line 301 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _wcsupr_s(__wchar_t (&_String)[_Size]) { return _wcsupr_s(_String, _Size); } 
#line 302 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsupr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsupr(__wchar_t *); } 
#line 303 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _wcsupr_s_l(__wchar_t *, size_t, _locale_t); } 
#line 304 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl _wcsupr_s_l(__wchar_t (&_String)[_Size], _locale_t _Locale) { return _wcsupr_s_l(_String, _Size, _Locale); } 
#line 305 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsupr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsupr_l(__wchar_t *, _locale_t); } 
#line 306 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl wcsxfrm(__wchar_t *, const __wchar_t *, size_t); } 
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern size_t __cdecl _wcsxfrm_l(__wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 308 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl wcscoll(const __wchar_t *, const __wchar_t *); } 
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcscoll_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 310 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsicoll(const __wchar_t *, const __wchar_t *); } 
#line 311 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsicoll_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 312 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsncoll(const __wchar_t *, const __wchar_t *, size_t); } 
#line 313 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsncoll_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 314 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsnicoll(const __wchar_t *, const __wchar_t *, size_t); } 
#line 315 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _wcsnicoll_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 321 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline __wchar_t *__cdecl wcschr(__wchar_t *_Str, __wchar_t _Ch) 
#line 322 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (__wchar_t *)wcschr((const __wchar_t *)_Str, _Ch); } 
#line 323 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline __wchar_t *__cdecl wcspbrk(__wchar_t *_Str, const __wchar_t *_Control) 
#line 324 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (__wchar_t *)wcspbrk((const __wchar_t *)_Str, _Control); } 
#line 325 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline __wchar_t *__cdecl wcsrchr(__wchar_t *_Str, __wchar_t _Ch) 
#line 326 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (__wchar_t *)wcsrchr((const __wchar_t *)_Str, _Ch); } 
#line 327 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline __wchar_t *__cdecl wcsstr(__wchar_t *_Str, const __wchar_t *_SubStr) 
#line 328 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
{ return (__wchar_t *)wcsstr((const __wchar_t *)_Str, _SubStr); } 
#line 340 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsdup. See online help for details.")) __wchar_t *__cdecl wcsdup(const __wchar_t *); } 
#line 350 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsicmp. See online help for details.")) int __cdecl wcsicmp(const __wchar_t *, const __wchar_t *); } 
#line 351 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsnicmp. See online help for details.")) int __cdecl wcsnicmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 352 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsnset. See online help for details.")) __wchar_t *__cdecl wcsnset(__wchar_t *, __wchar_t, size_t); } 
#line 353 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsrev. See online help for details.")) __wchar_t *__cdecl wcsrev(__wchar_t *); } 
#line 354 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsset. See online help for details.")) __wchar_t *__cdecl wcsset(__wchar_t *, __wchar_t); } 
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcslwr. See online help for details.")) __wchar_t *__cdecl wcslwr(__wchar_t *); } 
#line 356 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsupr. See online help for details.")) __wchar_t *__cdecl wcsupr(__wchar_t *); } 
#line 357 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsicoll. See online help for details.")) int __cdecl wcsicoll(const __wchar_t *, const __wchar_t *); } 
#line 56 "c:\\cuda\\include\\common_functions.h"
extern "C" { extern clock_t clock(); } 
#line 59 "c:\\cuda\\include\\common_functions.h"
extern "C" { extern void *memset(void *, int, size_t); } 
#line 62 "c:\\cuda\\include\\common_functions.h"
extern "C" { extern void *memcpy(void *, const void *, size_t); } 
#line 65 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int abs(int); } 
#line 67 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern long labs(long); } 
#line 69 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __int64 llabs(__int64); } 
#line 71 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fabs(double); } 
#line 73 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float fabsf(float); } 
#line 76 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int min(int, int); } 
#line 78 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern unsigned umin(unsigned, unsigned); } 
#line 80 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float fminf(float, float); } 
#line 82 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fmin(double, double); } 
#line 85 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int max(int, int); } 
#line 87 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern unsigned umax(unsigned, unsigned); } 
#line 89 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float fmaxf(float, float); } 
#line 91 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fmax(double, double); } 
#line 94 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double sin(double); } 
#line 96 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float sinf(float); } 
#line 99 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double cos(double); } 
#line 101 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float cosf(float); } 
#line 104 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern void sincos(double, double *, double *); } 
#line 106 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern void sincosf(float, float *, float *); } 
#line 109 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double tan(double); } 
#line 111 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float tanf(float); } 
#line 114 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double sqrt(double); } 
#line 116 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float sqrtf(float); } 
#line 119 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double rsqrt(double); } 
#line 121 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float rsqrtf(float); } 
#line 124 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double exp2(double); } 
#line 126 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float exp2f(float); } 
#line 129 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double exp10(double); } 
#line 131 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float exp10f(float); } 
#line 134 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double expm1(double); } 
#line 136 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float expm1f(float); } 
#line 139 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double log2(double); } 
#line 141 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float log2f(float); } 
#line 144 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double log10(double); } 
#line 146 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float log10f(float); } 
#line 149 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double log(double); } 
#line 151 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float logf(float); } 
#line 154 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double log1p(double); } 
#line 156 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float log1pf(float); } 
#line 159 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double floor(double); } 
#line 161 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float floorf(float); } 
#line 164 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double exp(double); } 
#line 166 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float expf(float); } 
#line 169 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double cosh(double); } 
#line 171 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float coshf(float); } 
#line 174 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double sinh(double); } 
#line 176 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float sinhf(float); } 
#line 179 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double tanh(double); } 
#line 181 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float tanhf(float); } 
#line 184 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double acosh(double); } 
#line 186 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float acoshf(float); } 
#line 189 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double asinh(double); } 
#line 191 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float asinhf(float); } 
#line 194 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double atanh(double); } 
#line 196 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float atanhf(float); } 
#line 199 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double ldexp(double, int); } 
#line 201 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float ldexpf(float, int); } 
#line 204 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double logb(double); } 
#line 206 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float logbf(float); } 
#line 209 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int ilogb(double); } 
#line 211 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int ilogbf(float); } 
#line 214 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double scalbn(double, int); } 
#line 216 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float scalbnf(float, int); } 
#line 219 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double scalbln(double, long); } 
#line 221 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float scalblnf(float, long); } 
#line 224 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double frexp(double, int *); } 
#line 226 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float frexpf(float, int *); } 
#line 229 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double round(double); } 
#line 231 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float roundf(float); } 
#line 234 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern long lround(double); } 
#line 236 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern long lroundf(float); } 
#line 239 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __int64 llround(double); } 
#line 241 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __int64 llroundf(float); } 
#line 244 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double rint(double); } 
#line 246 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float rintf(float); } 
#line 249 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern long lrint(double); } 
#line 251 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern long lrintf(float); } 
#line 254 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __int64 llrint(double); } 
#line 256 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __int64 llrintf(float); } 
#line 259 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double nearbyint(double); } 
#line 261 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float nearbyintf(float); } 
#line 264 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double ceil(double); } 
#line 266 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float ceilf(float); } 
#line 269 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double trunc(double); } 
#line 271 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float truncf(float); } 
#line 274 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fdim(double, double); } 
#line 276 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float fdimf(float, float); } 
#line 279 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double atan2(double, double); } 
#line 281 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float atan2f(float, float); } 
#line 284 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double atan(double); } 
#line 286 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float atanf(float); } 
#line 289 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double asin(double); } 
#line 291 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float asinf(float); } 
#line 294 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double acos(double); } 
#line 296 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float acosf(float); } 
#line 299 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _hypot. See online help for details.")) double hypot(double, double); } 
#line 301 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float hypotf(float, float); } 
#line 304 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double cbrt(double); } 
#line 306 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float cbrtf(float); } 
#line 309 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double pow(double, double); } 
#line 311 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float powf(float, float); } 
#line 314 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double modf(double, double *); } 
#line 316 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float modff(float, float *); } 
#line 319 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fmod(double, double); } 
#line 321 "c:\\cuda\\include\\math_functions.h"
extern "C" { inline float fmodf(float, float); } 
#line 324 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double remainder(double, double); } 
#line 326 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float remainderf(float, float); } 
#line 329 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double remquo(double, double, int *); } 
#line 331 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float remquof(float, float, int *); } 
#line 334 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double erf(double); } 
#line 336 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float erff(float); } 
#line 339 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double erfc(double); } 
#line 341 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float erfcf(float); } 
#line 344 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double lgamma(double); } 
#line 346 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float lgammaf(float); } 
#line 349 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double tgamma(double); } 
#line 351 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float tgammaf(float); } 
#line 354 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double copysign(double, double); } 
#line 356 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float copysignf(float, float); } 
#line 359 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double nextafter(double, double); } 
#line 361 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float nextafterf(float, float); } 
#line 364 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double nan(const char *); } 
#line 366 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float nanf(const char *); } 
#line 369 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __isinf(double); } 
#line 371 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __isinff(float); } 
#line 374 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __isnan(double); } 
#line 376 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __isnanf(float); } 
#line 390 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __finite(double); } 
#line 392 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __finitef(float); } 
#line 394 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __signbit(double); } 
#line 399 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __signbitf(float); } 
#line 402 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern double fma(double, double, double); } 
#line 404 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern float fmaf(float, float, float); } 
#line 25 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
#pragma pack ( push, 8 )
#line 39 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { struct _exception { 
#line 40 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
int type; 
#line 41 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
char *name; 
#line 42 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
double arg1; 
#line 43 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
double arg2; 
#line 44 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
double retval; 
#line 45 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
}; }
#line 56 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { struct _complex { 
#line 57 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
double x; double y; 
#line 58 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
}; }
#line 90 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" double _HUGE; 
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern int __cdecl abs(int); } 
#line 104 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern long __cdecl labs(long); } 
#line 107 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl acos(double); } 
#line 108 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl asin(double); } 
#line 109 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl atan(double); } 
#line 110 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl atan2(double, double); } 
#line 112 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _copysign(double, double); } 
#line 113 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _chgsign(double); } 
#line 116 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl cos(double); } 
#line 117 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl cosh(double); } 
#line 118 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl exp(double); } 
#line 119 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl fabs(double); } 
#line 120 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl fmod(double, double); } 
#line 121 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl log(double); } 
#line 122 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl log10(double); } 
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl pow(double, double); } 
#line 124 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl sin(double); } 
#line 125 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl sinh(double); } 
#line 126 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl tan(double); } 
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl tanh(double); } 
#line 128 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl sqrt(double); } 
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl atof(const char *); } 
#line 132 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _atof_l(const char *, _locale_t); } 
#line 135 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _cabs(_complex); } 
#line 136 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl ceil(double); } 
#line 137 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl floor(double); } 
#line 138 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl frexp(double, int *); } 
#line 139 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _hypot(double, double); } 
#line 140 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _j0(double); } 
#line 141 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _j1(double); } 
#line 142 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _jn(int, double); } 
#line 143 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl ldexp(double, int); } 
#line 149 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern int __cdecl _matherr(_exception *); } 
#line 152 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl modf(double, double *); } 
#line 154 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _y0(double); } 
#line 155 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _y1(double); } 
#line 156 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _yn(int, double); } 
#line 161 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern int __cdecl _set_SSE2_enable(int); } 
#line 162 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern float __cdecl _hypotf(float, float); } 
#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double acosl(long double _X) 
#line 318 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return acos((double)_X); } } 
#line 319 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double asinl(long double _X) 
#line 320 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return asin((double)_X); } } 
#line 321 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double atanl(long double _X) 
#line 322 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atan((double)_X); } } 
#line 323 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double atan2l(long double _X, long double _Y) 
#line 324 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atan2((double)_X, (double)_Y); } } 
#line 325 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double ceill(long double _X) 
#line 326 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ceil((double)_X); } } 
#line 327 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double cosl(long double _X) 
#line 328 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return cos((double)_X); } } 
#line 329 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double coshl(long double _X) 
#line 330 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return cosh((double)_X); } } 
#line 331 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double expl(long double _X) 
#line 332 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return exp((double)_X); } } 
#line 333 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double fabsl(long double _X) 
#line 334 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabs((double)_X); } } 
#line 335 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double floorl(long double _X) 
#line 336 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return floor((double)_X); } } 
#line 337 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double fmodl(long double _X, long double _Y) 
#line 338 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fmod((double)_X, (double)_Y); } } 
#line 339 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double frexpl(long double _X, int *_Y) 
#line 340 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return frexp((double)_X, _Y); } } 
#line 341 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double ldexpl(long double _X, int _Y) 
#line 342 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ldexp((double)_X, _Y); } } 
#line 343 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double logl(long double _X) 
#line 344 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return log((double)_X); } } 
#line 345 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double log10l(long double _X) 
#line 346 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return log10((double)_X); } } 
#line 347 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double modfl(long double _X, long double *_Y) 
#line 348 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ auto double _Di; auto double _Df = modf((double)_X, &_Di); 
#line 349 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
(*_Y) = (long double)_Di; 
#line 350 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
return _Df; } } 
#line 351 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double powl(long double _X, long double _Y) 
#line 352 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return pow((double)_X, (double)_Y); } } 
#line 353 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double sinl(long double _X) 
#line 354 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sin((double)_X); } } 
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double sinhl(long double _X) 
#line 356 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sinh((double)_X); } } 
#line 357 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double sqrtl(long double _X) 
#line 358 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sqrt((double)_X); } } 
#line 360 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double tanl(long double _X) 
#line 361 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tan((double)_X); } } 
#line 366 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double tanhl(long double _X) 
#line 367 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tanh((double)_X); } } 
#line 369 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double _chgsignl(long double _Number) 
#line 370 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ 
#line 371 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
return _chgsign(static_cast< double>(_Number)); 
#line 372 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
} } 
#line 374 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double _copysignl(long double _Number, long double _Sign) 
#line 375 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ 
#line 376 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
return _copysign(static_cast< double>(_Number), static_cast< double>(_Sign)); 
#line 377 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
} } 
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float frexpf(float _X, int *_Y) 
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)frexp((double)_X, _Y); } } 
#line 383 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float fabsf(float _X) 
#line 384 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)fabs((double)_X); } } 
#line 385 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float ldexpf(float _X, int _Y) 
#line 386 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)ldexp((double)_X, _Y); } } 
#line 388 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float acosf(float _X) 
#line 389 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)acos((double)_X); } } 
#line 390 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float asinf(float _X) 
#line 391 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)asin((double)_X); } } 
#line 392 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float atanf(float _X) 
#line 393 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)atan((double)_X); } } 
#line 394 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float atan2f(float _X, float _Y) 
#line 395 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)atan2((double)_X, (double)_Y); } } 
#line 396 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float ceilf(float _X) 
#line 397 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)ceil((double)_X); } } 
#line 398 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float cosf(float _X) 
#line 399 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)cos((double)_X); } } 
#line 400 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float coshf(float _X) 
#line 401 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)cosh((double)_X); } } 
#line 402 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float expf(float _X) 
#line 403 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)exp((double)_X); } } 
#line 404 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float floorf(float _X) 
#line 405 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)floor((double)_X); } } 
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float fmodf(float _X, float _Y) 
#line 407 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)fmod((double)_X, (double)_Y); } } 
#line 408 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float logf(float _X) 
#line 409 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)log((double)_X); } } 
#line 410 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float log10f(float _X) 
#line 411 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)log10((double)_X); } } 
#line 412 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float modff(float _X, float *_Y) 
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ auto double _Di; auto double _Df = modf((double)_X, &_Di); 
#line 414 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
(*_Y) = (float)_Di; 
#line 415 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
return (float)_Df; } } 
#line 416 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float powf(float _X, float _Y) 
#line 417 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)pow((double)_X, (double)_Y); } } 
#line 418 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float sinf(float _X) 
#line 419 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)sin((double)_X); } } 
#line 420 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float sinhf(float _X) 
#line 421 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)sinh((double)_X); } } 
#line 422 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float sqrtf(float _X) 
#line 423 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)sqrt((double)_X); } } 
#line 424 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float tanf(float _X) 
#line 425 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)tan((double)_X); } } 
#line 426 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline float tanhf(float _X) 
#line 427 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return (float)tanh((double)_X); } } 
#line 449 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" double HUGE; 
#line 454 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _cabs. See online help for details.")) double __cdecl cabs(_complex); } 
#line 455 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _hypot. See online help for details.")) double __cdecl hypot(double, double); } 
#line 456 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _j0. See online help for details.")) double __cdecl j0(double); } 
#line 457 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _j1. See online help for details.")) double __cdecl j1(double); } 
#line 458 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _jn. See online help for details.")) double __cdecl jn(int, double); } 
#line 459 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _y0. See online help for details.")) double __cdecl y0(double); } 
#line 460 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _y1. See online help for details.")) double __cdecl y1(double); } 
#line 461 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _yn. See online help for details.")) double __cdecl yn(int, double); } 
#line 472 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
template<class _Ty> inline _Ty 
#line 473 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_Pow_int(_Ty _X, int _Y) 
#line 474 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ auto unsigned _N; 
#line 475 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
if (_Y >= 0) { 
#line 476 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_N = (unsigned)_Y; } else { 
#line 478 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_N = (unsigned)(-_Y); }  
#line 479 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
for (_Ty _Z = ((_Ty)(1)); ; _X *= _X) 
#line 480 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ if ((_N & (1)) != (0)) { 
#line 481 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_Z *= _X; }  
#line 482 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
if ((_N >>= 1) == (0)) { 
#line 483 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
return (_Y < 0) ? (((_Ty)(1)) / _Z) : _Z; }  }  } 
#line 485 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long __cdecl abs(long _X) 
#line 486 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return labs(_X); } 
#line 487 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline double __cdecl abs(double _X) 
#line 488 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabs(_X); } 
#line 489 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline double __cdecl pow(double _X, int _Y) 
#line 490 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return _Pow_int(_X, _Y); } 
#line 491 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl abs(float _X) 
#line 492 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabsf(_X); } 
#line 493 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl acos(float _X) 
#line 494 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return acosf(_X); } 
#line 495 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl asin(float _X) 
#line 496 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return asinf(_X); } 
#line 497 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl atan(float _X) 
#line 498 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atanf(_X); } 
#line 499 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl atan2(float _Y, float _X) 
#line 500 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atan2f(_Y, _X); } 
#line 501 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl ceil(float _X) 
#line 502 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ceilf(_X); } 
#line 503 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl cos(float _X) 
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return cosf(_X); } 
#line 505 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl cosh(float _X) 
#line 506 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return coshf(_X); } 
#line 507 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl exp(float _X) 
#line 508 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return expf(_X); } 
#line 509 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl fabs(float _X) 
#line 510 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabsf(_X); } 
#line 511 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl floor(float _X) 
#line 512 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return floorf(_X); } 
#line 513 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl fmod(float _X, float _Y) 
#line 514 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fmodf(_X, _Y); } 
#line 515 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl frexp(float _X, int *_Y) 
#line 516 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return frexpf(_X, _Y); } 
#line 517 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl ldexp(float _X, int _Y) 
#line 518 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ldexpf(_X, _Y); } 
#line 519 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl log(float _X) 
#line 520 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return logf(_X); } 
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl log10(float _X) 
#line 522 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return log10f(_X); } 
#line 523 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl modf(float _X, float *_Y) 
#line 524 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return modff(_X, _Y); } 
#line 525 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl pow(float _X, float _Y) 
#line 526 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return powf(_X, _Y); } 
#line 527 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl pow(float _X, int _Y) 
#line 528 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return _Pow_int(_X, _Y); } 
#line 529 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl sin(float _X) 
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sinf(_X); } 
#line 531 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl sinh(float _X) 
#line 532 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sinhf(_X); } 
#line 533 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl sqrt(float _X) 
#line 534 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sqrtf(_X); } 
#line 535 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl tan(float _X) 
#line 536 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tanf(_X); } 
#line 537 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline float __cdecl tanh(float _X) 
#line 538 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tanhf(_X); } 
#line 539 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl abs(long double _X) 
#line 540 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabsl(_X); } 
#line 541 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl acos(long double _X) 
#line 542 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return acosl(_X); } 
#line 543 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl asin(long double _X) 
#line 544 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return asinl(_X); } 
#line 545 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl atan(long double _X) 
#line 546 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atanl(_X); } 
#line 547 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl atan2(long double _Y, long double _X) 
#line 548 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return atan2l(_Y, _X); } 
#line 549 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl ceil(long double _X) 
#line 550 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ceill(_X); } 
#line 551 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl cos(long double _X) 
#line 552 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return cosl(_X); } 
#line 553 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl cosh(long double _X) 
#line 554 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return coshl(_X); } 
#line 555 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl exp(long double _X) 
#line 556 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return expl(_X); } 
#line 557 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl fabs(long double _X) 
#line 558 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fabsl(_X); } 
#line 559 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl floor(long double _X) 
#line 560 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return floorl(_X); } 
#line 561 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl fmod(long double _X, long double _Y) 
#line 562 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return fmodl(_X, _Y); } 
#line 563 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl frexp(long double _X, int *_Y) 
#line 564 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return frexpl(_X, _Y); } 
#line 565 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl ldexp(long double _X, int _Y) 
#line 566 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return ldexpl(_X, _Y); } 
#line 567 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl log(long double _X) 
#line 568 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return logl(_X); } 
#line 569 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl log10(long double _X) 
#line 570 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return log10l(_X); } 
#line 571 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl modf(long double _X, long double *_Y) 
#line 572 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return modfl(_X, _Y); } 
#line 573 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl pow(long double _X, long double _Y) 
#line 574 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return powl(_X, _Y); } 
#line 575 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl pow(long double _X, int _Y) 
#line 576 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return _Pow_int(_X, _Y); } 
#line 577 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl sin(long double _X) 
#line 578 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sinl(_X); } 
#line 579 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl sinh(long double _X) 
#line 580 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sinhl(_X); } 
#line 581 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl sqrt(long double _X) 
#line 582 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return sqrtl(_X); } 
#line 583 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl tan(long double _X) 
#line 584 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tanl(_X); } 
#line 585 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
inline long double __cdecl tanh(long double _X) 
#line 586 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
{ return tanhl(_X); } 
#line 592 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
#pragma pack ( pop )
#line 31 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( push, 8 )
#line 56 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef int (__cdecl *_onexit_t)(void); }
#line 82 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 79 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _div_t { 
#line 80 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
int quot; 
#line 81 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
int rem; 
#line 82 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} div_t; }
#line 87 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 84 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _ldiv_t { 
#line 85 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
long quot; 
#line 86 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
long rem; 
#line 87 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} ldiv_t; }
#line 101 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( 4 )
#line 104 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 102 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _LDOUBLE { 
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
unsigned char ld[10]; 
#line 104 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} _LDOUBLE; }
#pragma pack ( )
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 121 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _CRT_DOUBLE { 
#line 122 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
double x; 
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} _CRT_DOUBLE; }
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 125 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _CRT_FLOAT { 
#line 126 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
float f; 
#line 127 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} _CRT_FLOAT; }
#line 138 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 133 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _LONGDOUBLE { 
#line 137 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
long double x; 
#line 138 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} _LONGDOUBLE; }
#line 142 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( 4 )
#line 145 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 143 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
struct _LDBL12 { 
#line 144 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
unsigned char ld12[12]; 
#line 145 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} _LDBL12; }
#pragma pack ( )
#line 166 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" int __mb_cur_max; 
#line 171 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl ___mb_cur_max_func(); } 
#line 172 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl ___mb_cur_max_l_func(_locale_t); } 
#line 211 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef void (__cdecl *_purecall_handler)(void); }
#line 214 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _purecall_handler __cdecl _set_purecall_handler(_purecall_handler); } 
#line 215 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _purecall_handler __cdecl _get_purecall_handler(); } 
#line 239 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef void (__cdecl *_invalid_parameter_handler)(const __wchar_t *, const __wchar_t *, const __wchar_t *, unsigned, uintptr_t); }
#line 242 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _invalid_parameter_handler __cdecl _set_invalid_parameter_handler(_invalid_parameter_handler); } 
#line 243 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _invalid_parameter_handler __cdecl _get_invalid_parameter_handler(); } 
#line 274 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long *__cdecl __doserrno(); } 
#line 277 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _set_doserrno(unsigned long); } 
#line 278 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _get_doserrno(unsigned long *); } 
#line 281 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char **__cdecl __sys_errlist(); } 
#line 284 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int *__cdecl __sys_nerr(); } 
#line 301 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" int __argc; 
#line 302 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" char **__argv; 
#line 303 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __wchar_t **__wargv; 
#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" char **_environ; 
#line 318 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __wchar_t **_wenviron; 
#line 321 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_pgmptr instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *_pgmptr; 
#line 322 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_wpgmptr instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *_wpgmptr; 
#line 339 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _get_pgmptr(char **); } 
#line 340 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _get_wpgmptr(__wchar_t **); } 
#line 344 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_fmode instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int _fmode; 
#line 350 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _set_fmode(int); } 
#line 351 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _get_fmode(int *); } 
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable:4141)
#line 359 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _osplatform; 
#line 360 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _osver; 
#line 361 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winver; 
#line 362 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winmajor; 
#line 363 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winminor; 
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 382 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_osplatform(unsigned *); } 
#line 383 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_osver(unsigned *); } 
#line 384 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winver(unsigned *); } 
#line 385 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winmajor(unsigned *); } 
#line 386 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winminor(unsigned *); } 
#line 395 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<class _CountofType, size_t _SizeOfArray> extern char (*__countof_helper(_CountofType (&)[_SizeOfArray]))[_SizeOfArray]; 
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec( noreturn ) void __cdecl exit(int); } 
#line 407 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec( noreturn ) void __cdecl _exit(int); } 
#line 408 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl abort(); } 
#line 411 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __cdecl _set_abort_behavior(unsigned, unsigned); } 
#line 420 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _abs64(__int64); } 
#line 446 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl atexit(void (__cdecl *)(void)); } 
#line 453 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl atoi(const char *); } 
#line 454 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atoi_l(const char *, _locale_t); } 
#line 455 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl atol(const char *); } 
#line 456 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl _atol_l(const char *, _locale_t); } 
#line 460 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl bsearch_s(const void *, const void *, rsize_t, rsize_t, int (__cdecl *)(void *, const void *, const void *), void *); } 
#line 464 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl bsearch(const void *, const void *, size_t, size_t, int (__cdecl *)(const void *, const void *)); } 
#line 469 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl qsort_s(void *, rsize_t, rsize_t, int (__cdecl *)(void *, const void *, const void *), void *); } 
#line 473 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl qsort(void *, size_t, size_t, int (__cdecl *)(const void *, const void *)); } 
#line 477 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned short __cdecl _byteswap_ushort(unsigned short); } 
#line 478 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl _byteswap_ulong(unsigned long); } 
#line 480 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _byteswap_uint64(unsigned __int64); } 
#line 482 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern div_t __cdecl div(int, int); } 
#line 483 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _dupenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl getenv(const char *); } 
#line 485 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl getenv_s(size_t *, char *, rsize_t, const char *); } 
#line 487 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl getenv_s(size_t *_ReturnSize, char (&_Dest)[_Size], const char *_VarName) { return getenv_s(_ReturnSize, _Dest, _Size, _VarName); } 
#line 488 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _dupenv_s(char **, size_t *, const char *); } 
#line 489 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _itoa_s(int, char *, size_t, int); } 
#line 490 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _itoa_s(int _Value, char (&_Dest)[_Size], int _Radix) { return _itoa_s(_Value, _Dest, _Size, _Radix); } 
#line 491 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _itoa(int, char *, int); } 
#line 493 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _i64toa_s(__int64, char *, size_t, int); } 
#line 494 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _i64toa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _i64toa(__int64, char *, int); } 
#line 495 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ui64toa_s(unsigned __int64, char *, size_t, int); } 
#line 496 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ui64toa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ui64toa(unsigned __int64, char *, int); } 
#line 497 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _atoi64(const char *); } 
#line 498 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _atoi64_l(const char *, _locale_t); } 
#line 499 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _strtoi64(const char *, char **, int); } 
#line 500 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _strtoi64_l(const char *, char **, int, _locale_t); } 
#line 501 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _strtoui64(const char *, char **, int); } 
#line 502 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _strtoui64_l(const char *, char **, int, _locale_t); } 
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern ldiv_t __cdecl ldiv(long, long); } 
#line 508 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
inline ldiv_t div(long _A1, long _A2) 
#line 509 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
{ 
#line 510 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
return ldiv(_A1, _A2); 
#line 511 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
} 
#line 514 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ltoa_s(long, char *, size_t, int); } 
#line 515 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _ltoa_s(long _Value, char (&_Dest)[_Size], int _Radix) { return _ltoa_s(_Value, _Dest, _Size, _Radix); } 
#line 516 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ltoa(long, char *, int); } 
#line 517 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl mblen(const char *, size_t); } 
#line 518 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _mblen_l(const char *, size_t, _locale_t); } 
#line 519 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern size_t __cdecl _mbstrlen(const char *); } 
#line 520 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern size_t __cdecl _mbstrlen_l(const char *, _locale_t); } 
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern size_t __cdecl _mbstrnlen(const char *, size_t); } 
#line 522 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern size_t __cdecl _mbstrnlen_l(const char *, size_t, _locale_t); } 
#line 523 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl mbtowc(__wchar_t *, const char *, size_t); } 
#line 524 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _mbtowc_l(__wchar_t *, const char *, size_t, _locale_t); } 
#line 525 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl mbstowcs_s(size_t *, __wchar_t *, size_t, const char *, size_t); } 
#line 526 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl mbstowcs_s(size_t *_PtNumOfCharConverted, __wchar_t (&_Dest)[_Size], const char *_Source, size_t _MaxCount) { return mbstowcs_s(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount); } 
#line 527 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using mbstowcs_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl mbstowcs(__wchar_t *, const char *, size_t); } 
#line 529 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _mbstowcs_s_l(size_t *, __wchar_t *, size_t, const char *, size_t, _locale_t); } 
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _mbstowcs_s_l(size_t *_PtNumOfCharConverted, __wchar_t (&_Dest)[_Size], const char *_Source, size_t _MaxCount, _locale_t _Locale) { return _mbstowcs_s_l(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount, _Locale); } 
#line 531 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _mbstowcs_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl _mbstowcs_l(__wchar_t *, const char *, size_t, _locale_t); } 
#line 533 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl rand(); } 
#line 538 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _set_error_mode(int); } 
#line 540 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl srand(unsigned); } 
#line 541 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl strtod(const char *, char **); } 
#line 542 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl _strtod_l(const char *, char **, _locale_t); } 
#line 543 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl strtol(const char *, char **, int); } 
#line 544 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl _strtol_l(const char *, char **, int, _locale_t); } 
#line 545 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl strtoul(const char *, char **, int); } 
#line 546 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl _strtoul_l(const char *, char **, int, _locale_t); } 
#line 549 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl system(const char *); } 
#line 551 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ultoa_s(unsigned long, char *, size_t, int); } 
#line 552 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _ultoa_s(unsigned long _Value, char (&_Dest)[_Size], int _Radix) { return _ultoa_s(_Value, _Dest, _Size, _Radix); } 
#line 553 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ultoa(unsigned long, char *, int); } 
#line 554 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wctomb_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl wctomb(char *, __wchar_t); } 
#line 555 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctomb_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _wctomb_l(char *, __wchar_t, _locale_t); } 
#line 557 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl wctomb_s(int *, char *, rsize_t, __wchar_t); } 
#line 559 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wctomb_s_l(int *, char *, size_t, __wchar_t, _locale_t); } 
#line 560 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl wcstombs_s(size_t *, char *, size_t, const __wchar_t *, size_t); } 
#line 561 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl wcstombs_s(size_t *_PtNumOfCharConverted, char (&_Dest)[_Size], const __wchar_t *_Source, size_t _MaxCount) { return wcstombs_s(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount); } 
#line 562 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcstombs_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl wcstombs(char *, const __wchar_t *, size_t); } 
#line 563 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wcstombs_s_l(size_t *, char *, size_t, const __wchar_t *, size_t, _locale_t); } 
#line 564 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _wcstombs_s_l(size_t *_PtNumOfCharConverted, char (&_Dest)[_Size], const __wchar_t *_Source, size_t _MaxCount, _locale_t _Locale) { return _wcstombs_s_l(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount, _Locale); } 
#line 565 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcstombs_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl _wcstombs_l(char *, const __wchar_t *, size_t, _locale_t); } 
#line 592 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl calloc(size_t, size_t); } 
#line 593 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl free(void *); } 
#line 594 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl malloc(size_t); } 
#line 595 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl realloc(void *, size_t); } 
#line 596 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _recalloc(void *, size_t, size_t); } 
#line 597 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl _aligned_free(void *); } 
#line 598 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_malloc(size_t, size_t); } 
#line 599 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_offset_malloc(size_t, size_t, size_t); } 
#line 600 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_realloc(void *, size_t, size_t); } 
#line 601 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_recalloc(void *, size_t, size_t, size_t); } 
#line 602 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_offset_realloc(void *, size_t, size_t, size_t); } 
#line 603 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl _aligned_offset_recalloc(void *, size_t, size_t, size_t, size_t); } 
#line 610 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _itow_s(int, __wchar_t *, size_t, int); } 
#line 611 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _itow_s(int _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _itow_s(_Value, _Dest, _Size, _Radix); } 
#line 612 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _itow(int, __wchar_t *, int); } 
#line 613 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ltow_s(long, __wchar_t *, size_t, int); } 
#line 614 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _ltow_s(long _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _ltow_s(_Value, _Dest, _Size, _Radix); } 
#line 615 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ltow(long, __wchar_t *, int); } 
#line 616 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ultow_s(unsigned long, __wchar_t *, size_t, int); } 
#line 617 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _ultow_s(unsigned long _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _ultow_s(_Value, _Dest, _Size, _Radix); } 
#line 618 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ultow(unsigned long, __wchar_t *, int); } 
#line 619 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl wcstod(const __wchar_t *, __wchar_t **); } 
#line 620 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl _wcstod_l(const __wchar_t *, __wchar_t **, _locale_t); } 
#line 621 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl wcstol(const __wchar_t *, __wchar_t **, int); } 
#line 622 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl _wcstol_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 623 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl wcstoul(const __wchar_t *, __wchar_t **, int); } 
#line 624 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl _wcstoul_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 625 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wdupenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wgetenv(const __wchar_t *); } 
#line 626 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wgetenv_s(size_t *, __wchar_t *, size_t, const __wchar_t *); } 
#line 627 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _wgetenv_s(size_t *_ReturnSize, __wchar_t (&_Dest)[_Size], const __wchar_t *_VarName) { return _wgetenv_s(_ReturnSize, _Dest, _Size, _VarName); } 
#line 628 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wdupenv_s(__wchar_t **, size_t *, const __wchar_t *); } 
#line 631 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _wsystem(const __wchar_t *); } 
#line 633 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl _wtof(const __wchar_t *); } 
#line 634 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl _wtof_l(const __wchar_t *, _locale_t); } 
#line 635 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _wtoi(const __wchar_t *); } 
#line 636 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _wtoi_l(const __wchar_t *, _locale_t); } 
#line 637 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl _wtol(const __wchar_t *); } 
#line 638 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern long __cdecl _wtol_l(const __wchar_t *, _locale_t); } 
#line 641 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _i64tow_s(__int64, __wchar_t *, size_t, int); } 
#line 642 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _i65tow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _i64tow(__int64, __wchar_t *, int); } 
#line 643 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ui64tow_s(unsigned __int64, __wchar_t *, size_t, int); } 
#line 644 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ui64tow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ui64tow(unsigned __int64, __wchar_t *, int); } 
#line 645 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _wtoi64(const __wchar_t *); } 
#line 646 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _wtoi64_l(const __wchar_t *, _locale_t); } 
#line 647 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _wcstoi64(const __wchar_t *, __wchar_t **, int); } 
#line 648 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __int64 __cdecl _wcstoi64_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 649 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _wcstoui64(const __wchar_t *, __wchar_t **, int); } 
#line 650 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _wcstoui64_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 669 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern char *__cdecl _fullpath(char *, const char *, size_t); } 
#line 675 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ecvt_s(char *, size_t, double, int, int *, int *); } 
#line 676 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _ecvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits, int *_PtDec, int *_PtSign) { return _ecvt_s(_Dest, _Size, _Value, _NumOfDigits, _PtDec, _PtSign); } 
#line 677 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ecvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ecvt(double, int, int *, int *); } 
#line 678 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _fcvt_s(char *, size_t, double, int, int *, int *); } 
#line 679 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _fcvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits, int *_PtDec, int *_PtSign) { return _fcvt_s(_Dest, _Size, _Value, _NumOfDigits, _PtDec, _PtSign); } 
#line 680 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _fcvt(double, int, int *, int *); } 
#line 681 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _gcvt_s(char *, size_t, double, int); } 
#line 682 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _gcvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits) { return _gcvt_s(_Dest, _Size, _Value, _NumOfDigits); } 
#line 683 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _gcvt(double, int, char *); } 
#line 685 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atodbl(_CRT_DOUBLE *, char *); } 
#line 686 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atoldbl(_LDOUBLE *, char *); } 
#line 687 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atoflt(_CRT_FLOAT *, char *); } 
#line 688 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atodbl_l(_CRT_DOUBLE *, char *, _locale_t); } 
#line 689 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atoldbl_l(_LDOUBLE *, char *, _locale_t); } 
#line 690 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _atoflt_l(_CRT_FLOAT *, char *, _locale_t); } 
#line 691 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl _lrotl(unsigned long, int); } 
#line 692 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long __cdecl _lrotr(unsigned long, int); } 
#line 693 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _makepath_s(char *, size_t, const char *, const char *, const char *, const char *); } 
#line 695 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _makepath_s(char (&_Path)[_Size], const char *_Drive, const char *_Dir, const char *_Filename, const char *_Ext) { return _makepath_s(_Path, _Size, _Drive, _Dir, _Filename, _Ext); } 
#line 696 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _makepath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _makepath(char *, const char *, const char *, const char *, const char *); } 
#line 723 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _onexit_t __cdecl _onexit(_onexit_t); } 
#line 728 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl perror(const char *); } 
#line 730 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _putenv(const char *); } 
#line 731 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _putenv_s(const char *, const char *); } 
#line 732 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __cdecl _rotl(unsigned, int); } 
#line 734 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _rotl64(unsigned __int64, int); } 
#line 736 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __cdecl _rotr(unsigned, int); } 
#line 738 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __int64 __cdecl _rotr64(unsigned __int64, int); } 
#line 740 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _searchenv_s(const char *, const char *, char *, size_t); } 
#line 741 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _searchenv_s(const char *_Filename, const char *_EnvVar, char (&_ResultPath)[_Size]) { return _searchenv_s(_Filename, _EnvVar, _ResultPath, _Size); } 
#line 742 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _searchenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _searchenv(const char *, const char *, char *); } 
#line 744 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _splitpath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _splitpath(const char *, char *, char *, char *, char *); } 
#line 745 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _splitpath_s(const char *, char *, size_t, char *, size_t, char *, size_t, char *, size_t); } 
#line 750 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _DriveSize, size_t _DirSize, size_t _NameSize, size_t _ExtSize> inline errno_t __cdecl _splitpath_s(const char *_Dest, char (&_Drive)[_DriveSize], char (&_Dir)[_DirSize], char (&_Name)[_NameSize], char (&_Ext)[_ExtSize]) { return _splitpath_s(_Dest, _Drive, _DriveSize, _Dir, _DirSize, _Name, _NameSize, _Ext, _ExtSize); } 
#line 752 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl _swab(char *, char *, int); } 
#line 763 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __wchar_t *__cdecl _wfullpath(__wchar_t *, const __wchar_t *, size_t); } 
#line 769 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wmakepath_s(__wchar_t *, size_t, const __wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *); } 
#line 771 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _wmakepath_s(__wchar_t (&_ResultPath)[_Size], const __wchar_t *_Drive, const __wchar_t *_Dir, const __wchar_t *_Filename, const __wchar_t *_Ext) { return _wmakepath_s(_ResultPath, _Size, _Drive, _Dir, _Filename, _Ext); } 
#line 772 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wmakepath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wmakepath(__wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *); } 
#line 775 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl _wperror(const __wchar_t *); } 
#line 777 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _wputenv(const __wchar_t *); } 
#line 778 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wputenv_s(const __wchar_t *, const __wchar_t *); } 
#line 779 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wsearchenv_s(const __wchar_t *, const __wchar_t *, __wchar_t *, size_t); } 
#line 780 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl _wsearchenv_s(const __wchar_t *_Filename, const __wchar_t *_EnvVar, __wchar_t (&_ResultPath)[_Size]) { return _wsearchenv_s(_Filename, _EnvVar, _ResultPath, _Size); } 
#line 781 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wsearchenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wsearchenv(const __wchar_t *, const __wchar_t *, __wchar_t *); } 
#line 782 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wsplitpath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wsplitpath(const __wchar_t *, __wchar_t *, __wchar_t *, __wchar_t *, __wchar_t *); } 
#line 783 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wsplitpath_s(const __wchar_t *, __wchar_t *, size_t, __wchar_t *, size_t, __wchar_t *, size_t, __wchar_t *, size_t); } 
#line 788 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _DriveSize, size_t _DirSize, size_t _NameSize, size_t _ExtSize> inline errno_t __cdecl _wsplitpath_s(const __wchar_t *_Path, __wchar_t (&_Drive)[_DriveSize], __wchar_t (&_Dir)[_DirSize], __wchar_t (&_Name)[_NameSize], __wchar_t (&_Ext)[_ExtSize]) { return _wsplitpath_s(_Path, _Drive, _DriveSize, _Dir, _DirSize, _Name, _NameSize, _Ext, _ExtSize); } 
#line 794 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSetErrorModeinstead. See online help for details.")) void __cdecl _seterrormode(int); } 
#line 795 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingBeepinstead. See online help for details.")) void __cdecl _beep(unsigned, unsigned); } 
#line 796 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSleepinstead. See online help for details.")) void __cdecl _sleep(unsigned long); } 
#line 815 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable: 4141)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ecvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ecvt(double, int, int *, int *); } 
#line 818 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl fcvt(double, int, int *, int *); } 
#line 819 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl gcvt(double, int, char *); } 
#line 820 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl itoa(int, char *, int); } 
#line 821 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ltoa(long, char *, int); } 
#line 822 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _putenv. See online help for details.")) int __cdecl putenv(const char *); } 
#line 823 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _swab. See online help for details.")) void __cdecl swab(char *, char *, int); } 
#line 824 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ultoa(unsigned long, char *, int); } 
#pragma warning(pop)
extern "C" { extern _onexit_t __cdecl onexit(_onexit_t); } 
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\use_ansi.h"
#pragma comment(lib,"libcpmt")
#line 838 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( pop )
#line 9 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma pack ( push, 8 )
#line 480 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
namespace std { 
#line 481 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
typedef bool _Bool; 
#line 482 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}
#line 498 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
typedef __int64 _Longlong; 
#line 499 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
typedef unsigned __int64 _ULonglong; 
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
namespace std { 
#line 525 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma warning(push)
#pragma warning(disable:4412)
class _Lockit { 
#line 547 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: explicit __thiscall _Lockit(); 
#line 548 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
explicit __thiscall _Lockit(int); 
#line 549 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
__thiscall ~_Lockit(); 
#line 552 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Lockit_ctor(int); 
#line 553 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Lockit_dtor(int); 
#line 556 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
private: static void __cdecl _Lockit_ctor(_Lockit *); 
#line 557 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Lockit_ctor(_Lockit *, int); 
#line 558 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Lockit_dtor(_Lockit *); 
#line 560 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
_Lockit(const _Lockit &); 
#line 561 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
_Lockit &operator=(const _Lockit &); 
#line 563 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
int _Locktype; 
#line 580 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#line 674 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
class _Mutex { 
#line 698 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: __thiscall _Mutex(); 
#line 699 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
__thiscall ~_Mutex(); 
#line 700 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
void __thiscall _Lock(); 
#line 701 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
void __thiscall _Unlock(); 
#line 705 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
private: static void __cdecl _Mutex_ctor(_Mutex *); 
#line 706 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Mutex_dtor(_Mutex *); 
#line 707 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Mutex_Lock(_Mutex *); 
#line 708 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Mutex_Unlock(_Mutex *); 
#line 710 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
_Mutex(const _Mutex &); 
#line 711 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
_Mutex &operator=(const _Mutex &); 
#line 712 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
void *_Mtx; 
#line 724 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#line 726 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
class _Init_locks { 
#line 742 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: __thiscall _Init_locks(); 
#line 743 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
__thiscall ~_Init_locks(); 
#line 747 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
private: static void __cdecl _Init_locks_ctor(_Init_locks *); 
#line 748 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Init_locks_dtor(_Init_locks *); 
#line 760 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#pragma warning(pop)
}
#line 771 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
extern void __cdecl _Atexit(void (__cdecl *)(void)); 
#line 773 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
typedef int _Mbstatet; 
#line 783 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma pack ( pop )
#line 17 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
namespace std { 
#line 18 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::acosf;using ::asinf;
#line 19 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::atanf;using ::atan2f;using ::ceilf;
#line 20 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::cosf;using ::coshf;using ::expf;
#line 21 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::fabsf;using ::floorf;using ::fmodf;
#line 22 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::frexpf;using ::ldexpf;using ::logf;
#line 23 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::log10f;using ::modff;using ::powf;
#line 24 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::sinf;using ::sinhf;using ::sqrtf;
#line 25 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::tanf;using ::tanhf;
#line 27 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::acosl;using ::asinl;
#line 28 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::atanl;using ::atan2l;using ::ceill;
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::cosl;using ::coshl;using ::expl;
#line 30 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::fabsl;using ::floorl;using ::fmodl;
#line 31 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::frexpl;using ::ldexpl;using ::logl;
#line 32 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::log10l;using ::modfl;using ::powl;
#line 33 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::sinl;using ::sinhl;using ::sqrtl;
#line 34 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::tanl;using ::tanhl;
#line 36 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::abs;
#line 37 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::acos;using ::asin;
#line 38 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::atan;using ::atan2;using ::ceil;
#line 39 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::cos;using ::cosh;using ::exp;
#line 40 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::fabs;using ::floor;using ::fmod;
#line 41 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::frexp;using ::ldexp;using ::log;
#line 42 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::log10;using ::modf;using ::pow;
#line 43 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::sin;using ::sinh;using ::sqrt;
#line 44 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
using ::tan;using ::tanh;
#line 46 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
}
#line 17 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
namespace std { 
#line 18 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::size_t;using ::div_t;using ::ldiv_t;
#line 20 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::abort;using ::atexit;
#line 21 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::atof;using ::atoi;using ::atol;
#line 22 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::bsearch;using ::calloc;using ::div;
#line 23 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::exit;using ::free;using ::getenv;
#line 24 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::labs;using ::ldiv;using ::malloc;
#line 25 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::mblen;using ::mbstowcs;using ::mbtowc;
#line 26 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::qsort;using ::rand;using ::realloc;
#line 27 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::srand;using ::strtod;using ::strtol;
#line 28 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::strtoul;using ::system;
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
using ::wcstombs;using ::wctomb;
#line 30 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
}
#line 413 "c:\\cuda\\include\\math_functions.h"
using namespace std;
#line 484 "c:\\cuda\\include\\math_functions.h"
static __inline __int64 abs(__int64 a) 
#line 485 "c:\\cuda\\include\\math_functions.h"
{ 
#line 486 "c:\\cuda\\include\\math_functions.h"
return llabs(a); 
#line 487 "c:\\cuda\\include\\math_functions.h"
} 
#line 489 "c:\\cuda\\include\\math_functions.h"
static __inline int signbit(double a) 
#line 490 "c:\\cuda\\include\\math_functions.h"
{ 
#line 491 "c:\\cuda\\include\\math_functions.h"
return __signbit(a); 
#line 492 "c:\\cuda\\include\\math_functions.h"
} 
#line 494 "c:\\cuda\\include\\math_functions.h"
static __inline int signbit(float a) 
#line 495 "c:\\cuda\\include\\math_functions.h"
{ 
#line 496 "c:\\cuda\\include\\math_functions.h"
return __signbitf(a); 
#line 497 "c:\\cuda\\include\\math_functions.h"
} 
#line 499 "c:\\cuda\\include\\math_functions.h"
static __inline int isinf(double a) 
#line 500 "c:\\cuda\\include\\math_functions.h"
{ 
#line 501 "c:\\cuda\\include\\math_functions.h"
return __isinf(a); 
#line 502 "c:\\cuda\\include\\math_functions.h"
} 
#line 504 "c:\\cuda\\include\\math_functions.h"
static __inline int isinf(float a) 
#line 505 "c:\\cuda\\include\\math_functions.h"
{ 
#line 506 "c:\\cuda\\include\\math_functions.h"
return __isinff(a); 
#line 507 "c:\\cuda\\include\\math_functions.h"
} 
#line 509 "c:\\cuda\\include\\math_functions.h"
static __inline int isnan(double a) 
#line 510 "c:\\cuda\\include\\math_functions.h"
{ 
#line 511 "c:\\cuda\\include\\math_functions.h"
return __isnan(a); 
#line 512 "c:\\cuda\\include\\math_functions.h"
} 
#line 514 "c:\\cuda\\include\\math_functions.h"
static __inline int isnan(float a) 
#line 515 "c:\\cuda\\include\\math_functions.h"
{ 
#line 516 "c:\\cuda\\include\\math_functions.h"
return __isnanf(a); 
#line 517 "c:\\cuda\\include\\math_functions.h"
} 
#line 519 "c:\\cuda\\include\\math_functions.h"
static __inline int isfinite(double a) 
#line 520 "c:\\cuda\\include\\math_functions.h"
{ 
#line 521 "c:\\cuda\\include\\math_functions.h"
return __finite(a); 
#line 522 "c:\\cuda\\include\\math_functions.h"
} 
#line 524 "c:\\cuda\\include\\math_functions.h"
static __inline int isfinite(float a) 
#line 525 "c:\\cuda\\include\\math_functions.h"
{ 
#line 526 "c:\\cuda\\include\\math_functions.h"
return __finitef(a); 
#line 527 "c:\\cuda\\include\\math_functions.h"
} 
#line 532 "c:\\cuda\\include\\math_functions.h"
template<class T> inline T _Pow_int(T, int); 
#line 538 "c:\\cuda\\include\\math_functions.h"
inline long abs(long); 
#line 539 "c:\\cuda\\include\\math_functions.h"
inline float abs(float); 
#line 540 "c:\\cuda\\include\\math_functions.h"
inline double abs(double); 
#line 541 "c:\\cuda\\include\\math_functions.h"
inline float fabs(float); 
#line 542 "c:\\cuda\\include\\math_functions.h"
inline float ceil(float); 
#line 543 "c:\\cuda\\include\\math_functions.h"
inline float floor(float); 
#line 544 "c:\\cuda\\include\\math_functions.h"
inline float sqrt(float); 
#line 545 "c:\\cuda\\include\\math_functions.h"
inline float pow(float, float); 
#line 546 "c:\\cuda\\include\\math_functions.h"
inline float pow(float, int); 
#line 547 "c:\\cuda\\include\\math_functions.h"
inline double pow(double, int); 
#line 548 "c:\\cuda\\include\\math_functions.h"
inline float log(float); 
#line 549 "c:\\cuda\\include\\math_functions.h"
inline float log10(float); 
#line 550 "c:\\cuda\\include\\math_functions.h"
inline float fmod(float, float); 
#line 551 "c:\\cuda\\include\\math_functions.h"
inline float modf(float, float *); 
#line 552 "c:\\cuda\\include\\math_functions.h"
inline float exp(float); 
#line 553 "c:\\cuda\\include\\math_functions.h"
inline float frexp(float, int *); 
#line 554 "c:\\cuda\\include\\math_functions.h"
inline float ldexp(float, int); 
#line 555 "c:\\cuda\\include\\math_functions.h"
inline float asin(float); 
#line 556 "c:\\cuda\\include\\math_functions.h"
inline float sin(float); 
#line 557 "c:\\cuda\\include\\math_functions.h"
inline float sinh(float); 
#line 558 "c:\\cuda\\include\\math_functions.h"
inline float acos(float); 
#line 559 "c:\\cuda\\include\\math_functions.h"
inline float cos(float); 
#line 560 "c:\\cuda\\include\\math_functions.h"
inline float cosh(float); 
#line 561 "c:\\cuda\\include\\math_functions.h"
inline float atan(float); 
#line 562 "c:\\cuda\\include\\math_functions.h"
inline float atan2(float, float); 
#line 563 "c:\\cuda\\include\\math_functions.h"
inline float tan(float); 
#line 564 "c:\\cuda\\include\\math_functions.h"
inline float tanh(float); 
#line 568 "c:\\cuda\\include\\math_functions.h"
static __inline float logb(float a) 
#line 569 "c:\\cuda\\include\\math_functions.h"
{ 
#line 570 "c:\\cuda\\include\\math_functions.h"
return logbf(a); 
#line 571 "c:\\cuda\\include\\math_functions.h"
} 
#line 573 "c:\\cuda\\include\\math_functions.h"
static __inline int ilogb(float a) 
#line 574 "c:\\cuda\\include\\math_functions.h"
{ 
#line 575 "c:\\cuda\\include\\math_functions.h"
return ilogbf(a); 
#line 576 "c:\\cuda\\include\\math_functions.h"
} 
#line 578 "c:\\cuda\\include\\math_functions.h"
static __inline float scalbn(float a, int b) 
#line 579 "c:\\cuda\\include\\math_functions.h"
{ 
#line 580 "c:\\cuda\\include\\math_functions.h"
return scalbnf(a, b); 
#line 581 "c:\\cuda\\include\\math_functions.h"
} 
#line 583 "c:\\cuda\\include\\math_functions.h"
static __inline float scalbln(float a, long b) 
#line 584 "c:\\cuda\\include\\math_functions.h"
{ 
#line 585 "c:\\cuda\\include\\math_functions.h"
return scalblnf(a, b); 
#line 586 "c:\\cuda\\include\\math_functions.h"
} 
#line 588 "c:\\cuda\\include\\math_functions.h"
static __inline float exp2(float a) 
#line 589 "c:\\cuda\\include\\math_functions.h"
{ 
#line 590 "c:\\cuda\\include\\math_functions.h"
return exp2f(a); 
#line 591 "c:\\cuda\\include\\math_functions.h"
} 
#line 593 "c:\\cuda\\include\\math_functions.h"
static __inline float exp10(float a) 
#line 594 "c:\\cuda\\include\\math_functions.h"
{ 
#line 595 "c:\\cuda\\include\\math_functions.h"
return exp10f(a); 
#line 596 "c:\\cuda\\include\\math_functions.h"
} 
#line 598 "c:\\cuda\\include\\math_functions.h"
static __inline float expm1(float a) 
#line 599 "c:\\cuda\\include\\math_functions.h"
{ 
#line 600 "c:\\cuda\\include\\math_functions.h"
return expm1f(a); 
#line 601 "c:\\cuda\\include\\math_functions.h"
} 
#line 603 "c:\\cuda\\include\\math_functions.h"
static __inline float log2(float a) 
#line 604 "c:\\cuda\\include\\math_functions.h"
{ 
#line 605 "c:\\cuda\\include\\math_functions.h"
return log2f(a); 
#line 606 "c:\\cuda\\include\\math_functions.h"
} 
#line 608 "c:\\cuda\\include\\math_functions.h"
static __inline float log1p(float a) 
#line 609 "c:\\cuda\\include\\math_functions.h"
{ 
#line 610 "c:\\cuda\\include\\math_functions.h"
return log1pf(a); 
#line 611 "c:\\cuda\\include\\math_functions.h"
} 
#line 613 "c:\\cuda\\include\\math_functions.h"
static __inline float rsqrt(float a) 
#line 614 "c:\\cuda\\include\\math_functions.h"
{ 
#line 615 "c:\\cuda\\include\\math_functions.h"
return rsqrtf(a); 
#line 616 "c:\\cuda\\include\\math_functions.h"
} 
#line 618 "c:\\cuda\\include\\math_functions.h"
static __inline float acosh(float a) 
#line 619 "c:\\cuda\\include\\math_functions.h"
{ 
#line 620 "c:\\cuda\\include\\math_functions.h"
return acoshf(a); 
#line 621 "c:\\cuda\\include\\math_functions.h"
} 
#line 623 "c:\\cuda\\include\\math_functions.h"
static __inline float asinh(float a) 
#line 624 "c:\\cuda\\include\\math_functions.h"
{ 
#line 625 "c:\\cuda\\include\\math_functions.h"
return asinhf(a); 
#line 626 "c:\\cuda\\include\\math_functions.h"
} 
#line 628 "c:\\cuda\\include\\math_functions.h"
static __inline float atanh(float a) 
#line 629 "c:\\cuda\\include\\math_functions.h"
{ 
#line 630 "c:\\cuda\\include\\math_functions.h"
return atanhf(a); 
#line 631 "c:\\cuda\\include\\math_functions.h"
} 
#line 633 "c:\\cuda\\include\\math_functions.h"
static __inline float hypot(float a, float b) 
#line 634 "c:\\cuda\\include\\math_functions.h"
{ 
#line 635 "c:\\cuda\\include\\math_functions.h"
return hypotf(a, b); 
#line 636 "c:\\cuda\\include\\math_functions.h"
} 
#line 638 "c:\\cuda\\include\\math_functions.h"
static __inline float cbrt(float a) 
#line 639 "c:\\cuda\\include\\math_functions.h"
{ 
#line 640 "c:\\cuda\\include\\math_functions.h"
return cbrtf(a); 
#line 641 "c:\\cuda\\include\\math_functions.h"
} 
#line 643 "c:\\cuda\\include\\math_functions.h"
static __inline void sincos(float a, float *sptr, float *cptr) 
#line 644 "c:\\cuda\\include\\math_functions.h"
{ 
#line 645 "c:\\cuda\\include\\math_functions.h"
sincosf(a, sptr, cptr); 
#line 646 "c:\\cuda\\include\\math_functions.h"
} 
#line 648 "c:\\cuda\\include\\math_functions.h"
static __inline float erf(float a) 
#line 649 "c:\\cuda\\include\\math_functions.h"
{ 
#line 650 "c:\\cuda\\include\\math_functions.h"
return erff(a); 
#line 651 "c:\\cuda\\include\\math_functions.h"
} 
#line 653 "c:\\cuda\\include\\math_functions.h"
static __inline float erfc(float a) 
#line 654 "c:\\cuda\\include\\math_functions.h"
{ 
#line 655 "c:\\cuda\\include\\math_functions.h"
return erfcf(a); 
#line 656 "c:\\cuda\\include\\math_functions.h"
} 
#line 658 "c:\\cuda\\include\\math_functions.h"
static __inline float lgamma(float a) 
#line 659 "c:\\cuda\\include\\math_functions.h"
{ 
#line 660 "c:\\cuda\\include\\math_functions.h"
return lgammaf(a); 
#line 661 "c:\\cuda\\include\\math_functions.h"
} 
#line 663 "c:\\cuda\\include\\math_functions.h"
static __inline float tgamma(float a) 
#line 664 "c:\\cuda\\include\\math_functions.h"
{ 
#line 665 "c:\\cuda\\include\\math_functions.h"
return tgammaf(a); 
#line 666 "c:\\cuda\\include\\math_functions.h"
} 
#line 668 "c:\\cuda\\include\\math_functions.h"
static __inline float copysign(float a, float b) 
#line 669 "c:\\cuda\\include\\math_functions.h"
{ 
#line 670 "c:\\cuda\\include\\math_functions.h"
return copysignf(a, b); 
#line 671 "c:\\cuda\\include\\math_functions.h"
} 
#line 673 "c:\\cuda\\include\\math_functions.h"
static __inline double copysign(double a, float b) 
#line 674 "c:\\cuda\\include\\math_functions.h"
{ 
#line 675 "c:\\cuda\\include\\math_functions.h"
return copysign(a, (double)b); 
#line 676 "c:\\cuda\\include\\math_functions.h"
} 
#line 678 "c:\\cuda\\include\\math_functions.h"
static __inline float copysign(float a, double b) 
#line 679 "c:\\cuda\\include\\math_functions.h"
{ 
#line 680 "c:\\cuda\\include\\math_functions.h"
return copysignf(a, (float)b); 
#line 681 "c:\\cuda\\include\\math_functions.h"
} 
#line 683 "c:\\cuda\\include\\math_functions.h"
static __inline float nextafter(float a, float b) 
#line 684 "c:\\cuda\\include\\math_functions.h"
{ 
#line 685 "c:\\cuda\\include\\math_functions.h"
return nextafterf(a, b); 
#line 686 "c:\\cuda\\include\\math_functions.h"
} 
#line 688 "c:\\cuda\\include\\math_functions.h"
static __inline float remainder(float a, float b) 
#line 689 "c:\\cuda\\include\\math_functions.h"
{ 
#line 690 "c:\\cuda\\include\\math_functions.h"
return remainderf(a, b); 
#line 691 "c:\\cuda\\include\\math_functions.h"
} 
#line 693 "c:\\cuda\\include\\math_functions.h"
static __inline float remquo(float a, float b, int *quo) 
#line 694 "c:\\cuda\\include\\math_functions.h"
{ 
#line 695 "c:\\cuda\\include\\math_functions.h"
return remquof(a, b, quo); 
#line 696 "c:\\cuda\\include\\math_functions.h"
} 
#line 698 "c:\\cuda\\include\\math_functions.h"
static __inline float round(float a) 
#line 699 "c:\\cuda\\include\\math_functions.h"
{ 
#line 700 "c:\\cuda\\include\\math_functions.h"
return roundf(a); 
#line 701 "c:\\cuda\\include\\math_functions.h"
} 
#line 703 "c:\\cuda\\include\\math_functions.h"
static __inline long lround(float a) 
#line 704 "c:\\cuda\\include\\math_functions.h"
{ 
#line 705 "c:\\cuda\\include\\math_functions.h"
return lroundf(a); 
#line 706 "c:\\cuda\\include\\math_functions.h"
} 
#line 708 "c:\\cuda\\include\\math_functions.h"
static __inline __int64 llround(float a) 
#line 709 "c:\\cuda\\include\\math_functions.h"
{ 
#line 710 "c:\\cuda\\include\\math_functions.h"
return llroundf(a); 
#line 711 "c:\\cuda\\include\\math_functions.h"
} 
#line 713 "c:\\cuda\\include\\math_functions.h"
static __inline float trunc(float a) 
#line 714 "c:\\cuda\\include\\math_functions.h"
{ 
#line 715 "c:\\cuda\\include\\math_functions.h"
return truncf(a); 
#line 716 "c:\\cuda\\include\\math_functions.h"
} 
#line 718 "c:\\cuda\\include\\math_functions.h"
static __inline float rint(float a) 
#line 719 "c:\\cuda\\include\\math_functions.h"
{ 
#line 720 "c:\\cuda\\include\\math_functions.h"
return rintf(a); 
#line 721 "c:\\cuda\\include\\math_functions.h"
} 
#line 723 "c:\\cuda\\include\\math_functions.h"
static __inline long lrint(float a) 
#line 724 "c:\\cuda\\include\\math_functions.h"
{ 
#line 725 "c:\\cuda\\include\\math_functions.h"
return lrintf(a); 
#line 726 "c:\\cuda\\include\\math_functions.h"
} 
#line 728 "c:\\cuda\\include\\math_functions.h"
static __inline __int64 llrint(float a) 
#line 729 "c:\\cuda\\include\\math_functions.h"
{ 
#line 730 "c:\\cuda\\include\\math_functions.h"
return llrintf(a); 
#line 731 "c:\\cuda\\include\\math_functions.h"
} 
#line 733 "c:\\cuda\\include\\math_functions.h"
static __inline float nearbyint(float a) 
#line 734 "c:\\cuda\\include\\math_functions.h"
{ 
#line 735 "c:\\cuda\\include\\math_functions.h"
return nearbyintf(a); 
#line 736 "c:\\cuda\\include\\math_functions.h"
} 
#line 738 "c:\\cuda\\include\\math_functions.h"
static __inline float fdim(float a, float b) 
#line 739 "c:\\cuda\\include\\math_functions.h"
{ 
#line 740 "c:\\cuda\\include\\math_functions.h"
return fdimf(a, b); 
#line 741 "c:\\cuda\\include\\math_functions.h"
} 
#line 743 "c:\\cuda\\include\\math_functions.h"
static __inline float fma(float a, float b, float c) 
#line 744 "c:\\cuda\\include\\math_functions.h"
{ 
#line 745 "c:\\cuda\\include\\math_functions.h"
return fmaf(a, b, c); 
#line 746 "c:\\cuda\\include\\math_functions.h"
} 
#line 748 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned min(unsigned a, unsigned b) 
#line 749 "c:\\cuda\\include\\math_functions.h"
{ 
#line 750 "c:\\cuda\\include\\math_functions.h"
return umin(a, b); 
#line 751 "c:\\cuda\\include\\math_functions.h"
} 
#line 753 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned min(int a, unsigned b) 
#line 754 "c:\\cuda\\include\\math_functions.h"
{ 
#line 755 "c:\\cuda\\include\\math_functions.h"
return umin((unsigned)a, b); 
#line 756 "c:\\cuda\\include\\math_functions.h"
} 
#line 758 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned min(unsigned a, int b) 
#line 759 "c:\\cuda\\include\\math_functions.h"
{ 
#line 760 "c:\\cuda\\include\\math_functions.h"
return umin(a, (unsigned)b); 
#line 761 "c:\\cuda\\include\\math_functions.h"
} 
#line 763 "c:\\cuda\\include\\math_functions.h"
static __inline float min(float a, float b) 
#line 764 "c:\\cuda\\include\\math_functions.h"
{ 
#line 765 "c:\\cuda\\include\\math_functions.h"
return fminf(a, b); 
#line 766 "c:\\cuda\\include\\math_functions.h"
} 
#line 768 "c:\\cuda\\include\\math_functions.h"
static __inline double min(double a, double b) 
#line 769 "c:\\cuda\\include\\math_functions.h"
{ 
#line 770 "c:\\cuda\\include\\math_functions.h"
return fmin(a, b); 
#line 771 "c:\\cuda\\include\\math_functions.h"
} 
#line 773 "c:\\cuda\\include\\math_functions.h"
static __inline double min(float a, double b) 
#line 774 "c:\\cuda\\include\\math_functions.h"
{ 
#line 775 "c:\\cuda\\include\\math_functions.h"
return fmin((double)a, b); 
#line 776 "c:\\cuda\\include\\math_functions.h"
} 
#line 778 "c:\\cuda\\include\\math_functions.h"
static __inline double min(double a, float b) 
#line 779 "c:\\cuda\\include\\math_functions.h"
{ 
#line 780 "c:\\cuda\\include\\math_functions.h"
return fmin(a, (double)b); 
#line 781 "c:\\cuda\\include\\math_functions.h"
} 
#line 783 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned max(unsigned a, unsigned b) 
#line 784 "c:\\cuda\\include\\math_functions.h"
{ 
#line 785 "c:\\cuda\\include\\math_functions.h"
return umax(a, b); 
#line 786 "c:\\cuda\\include\\math_functions.h"
} 
#line 788 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned max(int a, unsigned b) 
#line 789 "c:\\cuda\\include\\math_functions.h"
{ 
#line 790 "c:\\cuda\\include\\math_functions.h"
return umax((unsigned)a, b); 
#line 791 "c:\\cuda\\include\\math_functions.h"
} 
#line 793 "c:\\cuda\\include\\math_functions.h"
static __inline unsigned max(unsigned a, int b) 
#line 794 "c:\\cuda\\include\\math_functions.h"
{ 
#line 795 "c:\\cuda\\include\\math_functions.h"
return umax(a, (unsigned)b); 
#line 796 "c:\\cuda\\include\\math_functions.h"
} 
#line 798 "c:\\cuda\\include\\math_functions.h"
static __inline float max(float a, float b) 
#line 799 "c:\\cuda\\include\\math_functions.h"
{ 
#line 800 "c:\\cuda\\include\\math_functions.h"
return fmaxf(a, b); 
#line 801 "c:\\cuda\\include\\math_functions.h"
} 
#line 803 "c:\\cuda\\include\\math_functions.h"
static __inline double max(double a, double b) 
#line 804 "c:\\cuda\\include\\math_functions.h"
{ 
#line 805 "c:\\cuda\\include\\math_functions.h"
return fmax(a, b); 
#line 806 "c:\\cuda\\include\\math_functions.h"
} 
#line 808 "c:\\cuda\\include\\math_functions.h"
static __inline double max(float a, double b) 
#line 809 "c:\\cuda\\include\\math_functions.h"
{ 
#line 810 "c:\\cuda\\include\\math_functions.h"
return fmax((double)a, b); 
#line 811 "c:\\cuda\\include\\math_functions.h"
} 
#line 813 "c:\\cuda\\include\\math_functions.h"
static __inline double max(double a, float b) 
#line 814 "c:\\cuda\\include\\math_functions.h"
{ 
#line 815 "c:\\cuda\\include\\math_functions.h"
return fmax(a, (double)b); 
#line 816 "c:\\cuda\\include\\math_functions.h"
} 

#line 819 "c:\\cuda\\include\\math_functions.h"

#line 821 "c:\\cuda\\include\\math_functions.h"

#line 823 "c:\\cuda\\include\\math_functions.h"

#line 825 "c:\\cuda\\include\\math_functions.h"

#line 827 "c:\\cuda\\include\\math_functions.h"

#line 829 "c:\\cuda\\include\\math_functions.h"



#line 833 "c:\\cuda\\include\\math_functions.h"



#line 837 "c:\\cuda\\include\\math_functions.h"



#line 841 "c:\\cuda\\include\\math_functions.h"



#line 845 "c:\\cuda\\include\\math_functions.h"



#line 849 "c:\\cuda\\include\\math_functions.h"
#line 76 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 77 "C:\\CUDA\\include\\cuda_runtime.h"
cudaSetupArgument(T 
#line 78 "C:\\CUDA\\include\\cuda_runtime.h"
arg, size_t 
#line 79 "C:\\CUDA\\include\\cuda_runtime.h"
offset) 
#line 81 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 82 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaSetupArgument((const void *)(&arg), sizeof(T), offset); 
#line 83 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 93 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaMemcpyToSymbol(char *
#line 94 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, const void *
#line 95 "C:\\CUDA\\include\\cuda_runtime.h"
src, size_t 
#line 96 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 97 "C:\\CUDA\\include\\cuda_runtime.h"
offset = (0), cudaMemcpyKind 
#line 98 "C:\\CUDA\\include\\cuda_runtime.h"
kind = cudaMemcpyHostToDevice) 
#line 100 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 101 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyToSymbol((const char *)symbol, src, count, offset, kind); 
#line 102 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 104 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 105 "C:\\CUDA\\include\\cuda_runtime.h"
cudaMemcpyToSymbol(const T &
#line 106 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, const void *
#line 107 "C:\\CUDA\\include\\cuda_runtime.h"
src, size_t 
#line 108 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 109 "C:\\CUDA\\include\\cuda_runtime.h"
offset = (0), cudaMemcpyKind 
#line 110 "C:\\CUDA\\include\\cuda_runtime.h"
kind = cudaMemcpyHostToDevice) 
#line 112 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 113 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyToSymbol((const char *)(&symbol), src, count, offset, kind); 
#line 114 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 116 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaMemcpyToSymbolAsync(char *
#line 117 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, const void *
#line 118 "C:\\CUDA\\include\\cuda_runtime.h"
src, size_t 
#line 119 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 120 "C:\\CUDA\\include\\cuda_runtime.h"
offset, cudaMemcpyKind 
#line 121 "C:\\CUDA\\include\\cuda_runtime.h"
kind, cudaStream_t 
#line 122 "C:\\CUDA\\include\\cuda_runtime.h"
stream) 
#line 124 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 125 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyToSymbolAsync((const char *)symbol, src, count, offset, kind, stream); 
#line 126 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 128 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 129 "C:\\CUDA\\include\\cuda_runtime.h"
cudaMemcpyToSymbolAsync(const T &
#line 130 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, const void *
#line 131 "C:\\CUDA\\include\\cuda_runtime.h"
src, size_t 
#line 132 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 133 "C:\\CUDA\\include\\cuda_runtime.h"
offset, cudaMemcpyKind 
#line 134 "C:\\CUDA\\include\\cuda_runtime.h"
kind, cudaStream_t 
#line 135 "C:\\CUDA\\include\\cuda_runtime.h"
stream) 
#line 137 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 138 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyToSymbolAsync((const char *)(&symbol), src, count, offset, kind, stream); 
#line 139 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 147 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaMemcpyFromSymbol(void *
#line 148 "C:\\CUDA\\include\\cuda_runtime.h"
dst, char *
#line 149 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, size_t 
#line 150 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 151 "C:\\CUDA\\include\\cuda_runtime.h"
offset = (0), cudaMemcpyKind 
#line 152 "C:\\CUDA\\include\\cuda_runtime.h"
kind = cudaMemcpyDeviceToHost) 
#line 154 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 155 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyFromSymbol(dst, (const char *)symbol, count, offset, kind); 
#line 156 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 158 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 159 "C:\\CUDA\\include\\cuda_runtime.h"
cudaMemcpyFromSymbol(void *
#line 160 "C:\\CUDA\\include\\cuda_runtime.h"
dst, const T &
#line 161 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, size_t 
#line 162 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 163 "C:\\CUDA\\include\\cuda_runtime.h"
offset = (0), cudaMemcpyKind 
#line 164 "C:\\CUDA\\include\\cuda_runtime.h"
kind = cudaMemcpyDeviceToHost) 
#line 166 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 167 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyFromSymbol(dst, (const char *)(&symbol), count, offset, kind); 
#line 168 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 170 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaMemcpyFromSymbolAsync(void *
#line 171 "C:\\CUDA\\include\\cuda_runtime.h"
dst, char *
#line 172 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, size_t 
#line 173 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 174 "C:\\CUDA\\include\\cuda_runtime.h"
offset, cudaMemcpyKind 
#line 175 "C:\\CUDA\\include\\cuda_runtime.h"
kind, cudaStream_t 
#line 176 "C:\\CUDA\\include\\cuda_runtime.h"
stream) 
#line 178 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 179 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyFromSymbolAsync(dst, (const char *)symbol, count, offset, kind, stream); 
#line 180 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 182 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 183 "C:\\CUDA\\include\\cuda_runtime.h"
cudaMemcpyFromSymbolAsync(void *
#line 184 "C:\\CUDA\\include\\cuda_runtime.h"
dst, const T &
#line 185 "C:\\CUDA\\include\\cuda_runtime.h"
symbol, size_t 
#line 186 "C:\\CUDA\\include\\cuda_runtime.h"
count, size_t 
#line 187 "C:\\CUDA\\include\\cuda_runtime.h"
offset, cudaMemcpyKind 
#line 188 "C:\\CUDA\\include\\cuda_runtime.h"
kind, cudaStream_t 
#line 189 "C:\\CUDA\\include\\cuda_runtime.h"
stream) 
#line 191 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 192 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaMemcpyFromSymbolAsync(dst, (const char *)(&symbol), count, offset, kind, stream); 
#line 193 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 195 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaGetSymbolAddress(void **
#line 196 "C:\\CUDA\\include\\cuda_runtime.h"
devPtr, char *
#line 197 "C:\\CUDA\\include\\cuda_runtime.h"
symbol) 
#line 199 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 200 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaGetSymbolAddress(devPtr, (const char *)symbol); 
#line 201 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 203 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 204 "C:\\CUDA\\include\\cuda_runtime.h"
cudaGetSymbolAddress(void **
#line 205 "C:\\CUDA\\include\\cuda_runtime.h"
devPtr, const T &
#line 206 "C:\\CUDA\\include\\cuda_runtime.h"
symbol) 
#line 208 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 209 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaGetSymbolAddress(devPtr, (const char *)(&symbol)); 
#line 210 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 218 "C:\\CUDA\\include\\cuda_runtime.h"
static __inline cudaError_t cudaGetSymbolSize(size_t *
#line 219 "C:\\CUDA\\include\\cuda_runtime.h"
size, char *
#line 220 "C:\\CUDA\\include\\cuda_runtime.h"
symbol) 
#line 222 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 223 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaGetSymbolSize(size, (const char *)symbol); 
#line 224 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 226 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 227 "C:\\CUDA\\include\\cuda_runtime.h"
cudaGetSymbolSize(size_t *
#line 228 "C:\\CUDA\\include\\cuda_runtime.h"
size, const T &
#line 229 "C:\\CUDA\\include\\cuda_runtime.h"
symbol) 
#line 231 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 232 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaGetSymbolSize(size, (const char *)(&symbol)); 
#line 233 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 241 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 242 "C:\\CUDA\\include\\cuda_runtime.h"
cudaBindTexture(size_t *
#line 243 "C:\\CUDA\\include\\cuda_runtime.h"
offset, const texture< T, dim, readMode>  &
#line 244 "C:\\CUDA\\include\\cuda_runtime.h"
tex, const void *
#line 245 "C:\\CUDA\\include\\cuda_runtime.h"
devPtr, const cudaChannelFormatDesc &
#line 246 "C:\\CUDA\\include\\cuda_runtime.h"
desc, size_t 
#line 247 "C:\\CUDA\\include\\cuda_runtime.h"
size = (4294967295U)) 
#line 249 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 250 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaBindTexture(offset, &tex, devPtr, (&desc), size); 
#line 251 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 253 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 254 "C:\\CUDA\\include\\cuda_runtime.h"
cudaBindTexture(size_t *
#line 255 "C:\\CUDA\\include\\cuda_runtime.h"
offset, const texture< T, dim, readMode>  &
#line 256 "C:\\CUDA\\include\\cuda_runtime.h"
tex, const void *
#line 257 "C:\\CUDA\\include\\cuda_runtime.h"
devPtr, size_t 
#line 258 "C:\\CUDA\\include\\cuda_runtime.h"
size = (4294967295U)) 
#line 260 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 261 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaBindTexture(offset, tex, devPtr, (tex.channelDesc), size); 
#line 262 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 264 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 265 "C:\\CUDA\\include\\cuda_runtime.h"
cudaBindTextureToArray(const texture< T, dim, readMode>  &
#line 266 "C:\\CUDA\\include\\cuda_runtime.h"
tex, const cudaArray *
#line 267 "C:\\CUDA\\include\\cuda_runtime.h"
array, const cudaChannelFormatDesc &
#line 268 "C:\\CUDA\\include\\cuda_runtime.h"
desc) 
#line 270 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 271 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaBindTextureToArray(&tex, array, (&desc)); 
#line 272 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 274 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 275 "C:\\CUDA\\include\\cuda_runtime.h"
cudaBindTextureToArray(const texture< T, dim, readMode>  &
#line 276 "C:\\CUDA\\include\\cuda_runtime.h"
tex, const cudaArray *
#line 277 "C:\\CUDA\\include\\cuda_runtime.h"
array) 
#line 279 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 280 "C:\\CUDA\\include\\cuda_runtime.h"
auto cudaChannelFormatDesc desc; 
#line 281 "C:\\CUDA\\include\\cuda_runtime.h"
auto cudaError_t err = cudaGetChannelDesc(&desc, array); 
#line 283 "C:\\CUDA\\include\\cuda_runtime.h"
return (err == (cudaSuccess)) ? (cudaBindTextureToArray(tex, array, desc)) : err; 
#line 284 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 292 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 293 "C:\\CUDA\\include\\cuda_runtime.h"
cudaUnbindTexture(const texture< T, dim, readMode>  &
#line 294 "C:\\CUDA\\include\\cuda_runtime.h"
tex) 
#line 296 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 297 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaUnbindTexture(&tex); 
#line 298 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 306 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 307 "C:\\CUDA\\include\\cuda_runtime.h"
cudaGetTextureAlignmentOffset(size_t *
#line 308 "C:\\CUDA\\include\\cuda_runtime.h"
offset, const texture< T, dim, readMode>  &
#line 309 "C:\\CUDA\\include\\cuda_runtime.h"
tex) 
#line 311 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 312 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaGetTextureAlignmentOffset(offset, &tex); 
#line 313 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 321 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 322 "C:\\CUDA\\include\\cuda_runtime.h"
cudaLaunch(T *
#line 323 "C:\\CUDA\\include\\cuda_runtime.h"
symbol) 
#line 325 "C:\\CUDA\\include\\cuda_runtime.h"
{ 
#line 326 "C:\\CUDA\\include\\cuda_runtime.h"
return cudaLaunch((const char *)symbol); 
#line 327 "C:\\CUDA\\include\\cuda_runtime.h"
} 
#line 28 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma pack ( push, 8 )
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { struct _iobuf { 
#line 60 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
char *_ptr; 
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
int _cnt; 
#line 62 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
char *_base; 
#line 63 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
int _flag; 
#line 64 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
int _file; 
#line 65 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
int _charbuf; 
#line 66 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
int _bufsiz; 
#line 67 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
char *_tmpfname; 
#line 68 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
}; }
#line 69 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { typedef _iobuf FILE; }
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl __iob_func(); } 
#line 147 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { typedef __int64 fpos_t; }
#line 188 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _filbuf(FILE *); } 
#line 189 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _flsbuf(int, FILE *); } 
#line 194 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _fsopen(const char *, const char *, int); } 
#line 197 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl clearerr(FILE *); } 
#line 198 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl clearerr_s(FILE *); } 
#line 199 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fclose(FILE *); } 
#line 200 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fcloseall(); } 
#line 205 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _fdopen(int, const char *); } 
#line 208 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl feof(FILE *); } 
#line 209 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl ferror(FILE *); } 
#line 210 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fflush(FILE *); } 
#line 211 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fgetc(FILE *); } 
#line 212 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fgetchar(); } 
#line 213 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fgetpos(FILE *, fpos_t *); } 
#line 214 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern char *__cdecl fgets(char *, int, FILE *); } 
#line 219 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fileno(FILE *); } 
#line 227 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern char *__cdecl _tempnam(const char *, const char *); } 
#line 233 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _flushall(); } 
#line 234 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl fopen(const char *, const char *); } 
#line 236 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl fopen_s(FILE **, const char *, const char *); } 
#line 238 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fprintf(FILE *, const char *, ...); } 
#line 239 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fprintf_s(FILE *, const char *, ...); } 
#line 240 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fputc(int, FILE *); } 
#line 241 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fputchar(int); } 
#line 242 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fputs(const char *, FILE *); } 
#line 243 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl fread(void *, size_t, size_t, FILE *); } 
#line 244 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl fread_s(void *, size_t, size_t, size_t, FILE *); } 
#line 245 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using freopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl freopen(const char *, const char *, FILE *); } 
#line 247 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl freopen_s(FILE **, const char *, const char *, FILE *); } 
#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl fscanf(FILE *, const char *, ...); } 
#line 250 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _fscanf_l(FILE *, const char *, _locale_t, ...); } 
#line 252 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fscanf_s(FILE *, const char *, ...); } 
#line 254 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fscanf_s_l(FILE *, const char *, _locale_t, ...); } 
#line 255 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fsetpos(FILE *, const fpos_t *); } 
#line 256 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fseek(FILE *, long, int); } 
#line 257 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern long __cdecl ftell(FILE *); } 
#line 259 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fseeki64(FILE *, __int64, int); } 
#line 260 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __int64 __cdecl _ftelli64(FILE *); } 
#line 262 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl fwrite(const void *, size_t, size_t, FILE *); } 
#line 263 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl getc(FILE *); } 
#line 264 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl getchar(); } 
#line 265 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _getmaxstdio(); } 
#line 267 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern char *__cdecl gets_s(char *, rsize_t); } 
#line 269 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline char *__cdecl gets_s(char (&_Buffer)[_Size]) { return gets_s(_Buffer, _Size); } 
#line 270 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using gets_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl gets(char *); } 
#line 271 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _getw(FILE *); } 
#line 276 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _pclose(FILE *); } 
#line 277 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _popen(const char *, const char *); } 
#line 278 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl printf(const char *, ...); } 
#line 279 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl printf_s(const char *, ...); } 
#line 280 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl putc(int, FILE *); } 
#line 281 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl putchar(int); } 
#line 282 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl puts(const char *); } 
#line 283 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _putw(int, FILE *); } 
#line 286 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl remove(const char *); } 
#line 287 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl rename(const char *, const char *); } 
#line 288 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _unlink(const char *); } 
#line 290 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _unlink. See online help for details.")) int __cdecl unlink(const char *); } 
#line 293 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl rewind(FILE *); } 
#line 294 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _rmtmp(); } 
#line 295 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using scanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl scanf(const char *, ...); } 
#line 296 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _scanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _scanf_l(const char *, _locale_t, ...); } 
#line 298 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl scanf_s(const char *, ...); } 
#line 300 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scanf_s_l(const char *, _locale_t, ...); } 
#line 301 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using setvbuf instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl setbuf(FILE *, char *); } 
#line 302 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _setmaxstdio(int); } 
#line 303 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern unsigned __cdecl _set_output_format(unsigned); } 
#line 304 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern unsigned __cdecl _get_output_format(); } 
#line 305 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl setvbuf(FILE *, char *, int, size_t); } 
#line 306 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snprintf_s(char *, size_t, size_t, const char *, ...); } 
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
__pragma(warning(push)) __pragma(warning(disable: 4793)) template<size_t _Size> inline int __cdecl _snprintf_s(char (&_Dest)[_Size], size_t _Size, const char *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return _vsnprintf_s(_Dest, _Size, _Size, _Format, _ArgList); } __pragma(warning(pop)) 
#line 308 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl sprintf_s(char *, size_t, const char *, ...); } 
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
__pragma(warning(push)) __pragma(warning(disable: 4793)) template < size_t _Size > inline int __cdecl sprintf_s ( char ( & _Dest ) [ _Size ], const char * _Format, ... ) { va_list _ArgList; ( _ArgList = ( va_list ) ( & reinterpret_cast < const char & > ( _Format ) ) + ( ( sizeof ( _Format ) + sizeof ( int ) - 1 ) & ~ ( sizeof ( int ) - 1 ) ) ); return vsprintf_s ( _Dest, _Size, _Format, _ArgList ); }__pragma(warning(pop)) 
#line 310 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scprintf(const char *, ...); } 
#line 311 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using sscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl sscanf(const char *, const char *, ...); } 
#line 312 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _sscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _sscanf_l(const char *, const char *, _locale_t, ...); } 
#line 314 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl sscanf_s(const char *, const char *, ...); } 
#line 316 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _sscanf_s_l(const char *, const char *, _locale_t, ...); } 
#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snscanf(const char *, size_t, const char *, ...); } 
#line 318 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snscanf_l(const char *, size_t, const char *, _locale_t, ...); } 
#line 319 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snscanf_s(const char *, size_t, const char *, ...); } 
#line 320 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snscanf_s_l(const char *, size_t, const char *, _locale_t, ...); } 
#line 321 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using tmpfile_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl tmpfile(); } 
#line 323 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl tmpfile_s(FILE **); } 
#line 324 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl tmpnam_s(char *, rsize_t); } 
#line 326 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline errno_t __cdecl tmpnam_s(char (&_Buf)[_Size]) { return tmpnam_s(_Buf, _Size); } 
#line 327 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using tmpnam_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl tmpnam(char *); } 
#line 328 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl ungetc(int, FILE *); } 
#line 329 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vfprintf(FILE *, const char *, va_list); } 
#line 330 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vfprintf_s(FILE *, const char *, va_list); } 
#line 331 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vprintf(const char *, va_list); } 
#line 332 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vprintf_s(const char *, va_list); } 
#line 333 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using vsnprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vsnprintf(char *, size_t, const char *, va_list); } 
#line 334 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vsnprintf_s(char *, size_t, size_t, const char *, va_list); } 
#line 335 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnprintf_s(char *, size_t, size_t, const char *, va_list); } 
#line 336 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline int __cdecl _vsnprintf_s(char (&_Dest)[_Size], size_t _Size, const char *_Format, va_list _Args) { return _vsnprintf_s(_Dest, _Size, _Size, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snprintf(char *, size_t, const char *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnprintf(char *, size_t, const char *, va_list); } 
#pragma warning(pop)
extern "C" { extern int __cdecl vsprintf_s(char *, size_t, const char *, va_list); } 
#line 342 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline int __cdecl vsprintf_s(char (&_Dest)[_Size], const char *_Format, va_list _Args) { return vsprintf_s(_Dest, _Size, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using sprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl sprintf(char *, const char *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using vsprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vsprintf(char *, const char *, va_list); } 
#pragma warning(pop)
extern "C" { extern int __cdecl _vscprintf(const char *, va_list); } 
#line 348 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snprintf_c(char *, size_t, const char *, ...); } 
#line 349 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnprintf_c(char *, size_t, const char *, va_list); } 
#line 351 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fprintf_p(FILE *, const char *, ...); } 
#line 352 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _printf_p(const char *, ...); } 
#line 353 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _sprintf_p(char *, size_t, const char *, ...); } 
#line 354 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfprintf_p(FILE *, const char *, va_list); } 
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vprintf_p(const char *, va_list); } 
#line 356 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsprintf_p(char *, size_t, const char *, va_list); } 
#line 357 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scprintf_p(const char *, ...); } 
#line 358 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscprintf_p(const char *, va_list); } 
#line 359 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _set_printf_count_output(int); } 
#line 360 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _get_printf_count_output(); } 
#line 362 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _printf_l(const char *, _locale_t, ...); } 
#line 363 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _printf_p_l(const char *, _locale_t, ...); } 
#line 364 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _printf_s_l(const char *, _locale_t, ...); } 
#line 365 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vprintf_l(const char *, _locale_t, va_list); } 
#line 366 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vprintf_p_l(const char *, _locale_t, va_list); } 
#line 367 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vprintf_s_l(const char *, _locale_t, va_list); } 
#line 369 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fprintf_l(FILE *, const char *, _locale_t, ...); } 
#line 370 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fprintf_p_l(FILE *, const char *, _locale_t, ...); } 
#line 371 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fprintf_s_l(FILE *, const char *, _locale_t, ...); } 
#line 372 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfprintf_l(FILE *, const char *, _locale_t, va_list); } 
#line 373 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfprintf_p_l(FILE *, const char *, _locale_t, va_list); } 
#line 374 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfprintf_s_l(FILE *, const char *, _locale_t, va_list); } 
#line 376 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _sprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _sprintf_l(char *, const char *, _locale_t, ...); } 
#line 377 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _sprintf_p_l(char *, size_t, const char *, _locale_t, ...); } 
#line 378 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _sprintf_s_l(char *, size_t, const char *, _locale_t, ...); } 
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsprintf_l(char *, const char *, _locale_t, va_list); } 
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsprintf_p_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 381 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsprintf_s_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 383 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scprintf_l(const char *, _locale_t, ...); } 
#line 384 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scprintf_p_l(const char *, _locale_t, ...); } 
#line 385 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscprintf_l(const char *, _locale_t, va_list); } 
#line 386 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscprintf_p_l(const char *, _locale_t, va_list); } 
#line 388 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snprintf_l(char *, size_t, const char *, _locale_t, ...); } 
#line 389 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snprintf_c_l(char *, size_t, const char *, _locale_t, ...); } 
#line 390 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snprintf_s_l(char *, size_t, size_t, const char *, _locale_t, ...); } 
#line 391 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnprintf_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 392 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnprintf_c_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 393 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnprintf_s_l(char *, size_t, size_t, const char *, _locale_t, va_list); } 
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _wfsopen(const __wchar_t *, const __wchar_t *, int); } 
#line 409 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl fgetwc(FILE *); } 
#line 410 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl _fgetwchar(); } 
#line 411 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl fputwc(__wchar_t, FILE *); } 
#line 412 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl _fputwchar(__wchar_t); } 
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl getwc(FILE *); } 
#line 414 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { inline wint_t __cdecl getwchar(); } 
#line 415 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl putwc(__wchar_t, FILE *); } 
#line 416 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { inline wint_t __cdecl putwchar(__wchar_t); } 
#line 417 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl ungetwc(wint_t, FILE *); } 
#line 419 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __wchar_t *__cdecl fgetws(__wchar_t *, int, FILE *); } 
#line 420 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fputws(const __wchar_t *, FILE *); } 
#line 421 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __wchar_t *__cdecl _getws_s(__wchar_t *, size_t); } 
#line 422 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline __wchar_t *__cdecl _getws_s(__wchar_t (&_String)[_Size]) { return _getws_s(_String, _Size); } 
#line 423 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _getws_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _getws(__wchar_t *); } 
#line 424 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _putws(const __wchar_t *); } 
#line 426 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fwprintf(FILE *, const __wchar_t *, ...); } 
#line 427 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fwprintf_s(FILE *, const __wchar_t *, ...); } 
#line 428 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl wprintf(const __wchar_t *, ...); } 
#line 429 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl wprintf_s(const __wchar_t *, ...); } 
#line 430 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scwprintf(const __wchar_t *, ...); } 
#line 431 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vfwprintf(FILE *, const __wchar_t *, va_list); } 
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vfwprintf_s(FILE *, const __wchar_t *, va_list); } 
#line 433 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vwprintf(const __wchar_t *, va_list); } 
#line 434 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vwprintf_s(const __wchar_t *, va_list); } 
#line 436 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl swprintf_s(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
__pragma(warning(push)) __pragma(warning(disable: 4793)) template<size_t _Size> inline int __cdecl swprintf_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return vswprintf_s(_Dest, _Size, _Format, _ArgList); } __pragma(warning(pop)) 
#line 438 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl vswprintf_s(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 439 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline int __cdecl vswprintf_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Format, va_list _Args) { return vswprintf_s(_Dest, _Size, _Format, _Args); } 
#line 441 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swprintf_c(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 442 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vswprintf_c(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 444 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snwprintf_s(__wchar_t *, size_t, size_t, const __wchar_t *, ...); } 
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
__pragma(warning(push)) __pragma(warning(disable: 4793)) template<size_t _Size> inline int __cdecl _snwprintf_s(__wchar_t (&_Dest)[_Size], size_t _Count, const __wchar_t *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return _vsnwprintf_s(_Dest, _Size, _Count, _Format, _ArgList); } __pragma(warning(pop)) 
#line 446 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnwprintf_s(__wchar_t *, size_t, size_t, const __wchar_t *, va_list); } 
#line 447 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline int __cdecl _vsnwprintf_s(__wchar_t (&_Dest)[_Size], size_t _Count, const __wchar_t *_Format, va_list _Args) { return _vsnwprintf_s(_Dest, _Size, _Count, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwprintf(__wchar_t *, size_t, const __wchar_t *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnwprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnwprintf(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#pragma warning(pop)
#line 453 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwprintf_p(FILE *, const __wchar_t *, ...); } 
#line 454 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wprintf_p(const __wchar_t *, ...); } 
#line 455 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfwprintf_p(FILE *, const __wchar_t *, va_list); } 
#line 456 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vwprintf_p(const __wchar_t *, va_list); } 
#line 457 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swprintf_p(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 458 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vswprintf_p(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 459 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scwprintf_p(const __wchar_t *, ...); } 
#line 460 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscwprintf_p(const __wchar_t *, va_list); } 
#line 462 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wprintf_l(const __wchar_t *, _locale_t, ...); } 
#line 463 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wprintf_p_l(const __wchar_t *, _locale_t, ...); } 
#line 464 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wprintf_s_l(const __wchar_t *, _locale_t, ...); } 
#line 465 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vwprintf_l(const __wchar_t *, _locale_t, va_list); } 
#line 466 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vwprintf_p_l(const __wchar_t *, _locale_t, va_list); } 
#line 467 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vwprintf_s_l(const __wchar_t *, _locale_t, va_list); } 
#line 469 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwprintf_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 470 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwprintf_p_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 471 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwprintf_s_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 472 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfwprintf_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 473 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfwprintf_p_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 474 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vfwprintf_s_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 476 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swprintf_c_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 477 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swprintf_p_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 478 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swprintf_s_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 479 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vswprintf_c_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 480 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vswprintf_p_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 481 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vswprintf_s_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 483 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scwprintf_l(const __wchar_t *, _locale_t, ...); } 
#line 484 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scwprintf_p_l(const __wchar_t *, _locale_t, ...); } 
#line 485 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscwprintf_p_l(const __wchar_t *, _locale_t, va_list); } 
#line 487 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwprintf_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 488 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snwprintf_s_l(__wchar_t *, size_t, size_t, const __wchar_t *, _locale_t, ...); } 
#line 489 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnwprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnwprintf_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 490 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vsnwprintf_s_l(__wchar_t *, size_t, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4141 4996 4793)
extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl _swprintf(__wchar_t *, const __wchar_t *, ...); } extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl _vswprintf(__wchar_t *, const __wchar_t *, va_list); } 
#line 507 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl __swprintf_l(__wchar_t *, const __wchar_t *, _locale_t, ...); } extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl __vswprintf_l(__wchar_t *, const __wchar_t *, _locale_t, va_list); } 
#pragma warning(pop)
#line 34 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
extern "C" { static __inline int swprintf(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, ...) 
#line 37 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 38 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto va_list _Arglist; 
#line 39 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto int _Ret; 
#line 40 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 41 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Ret = _vswprintf_c_l(_String, _Count, _Format, 0, _Arglist); 
#line 42 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = ((va_list)0); 
#line 43 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _Ret; 
#line 44 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} } 
#pragma warning( pop )
#line 47 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4412 )
extern "C" { static __inline int __cdecl vswprintf(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, va_list _Ap) 
#line 50 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 51 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _vswprintf_c_l(_String, _Count, _Format, 0, _Ap); 
#line 52 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} } 
#pragma warning( pop )
#line 58 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
extern "C" { static __inline int _swprintf_l(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, _locale_t _Plocinfo, ...) 
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 62 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto va_list _Arglist; 
#line 63 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto int _Ret; 
#line 64 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Plocinfo))) + (((sizeof(_Plocinfo) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 65 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Ret = _vswprintf_c_l(_String, _Count, _Format, _Plocinfo, _Arglist); 
#line 66 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = ((va_list)0); 
#line 67 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _Ret; 
#line 68 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} } 
#pragma warning( pop )
#line 71 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4412 )
extern "C" { static __inline int __cdecl _vswprintf_l(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, _locale_t _Plocinfo, va_list _Ap) 
#line 74 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 75 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _vswprintf_c_l(_String, _Count, _Format, _Plocinfo, _Ap); 
#line 76 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} } 
#pragma warning( pop )
#line 80 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4996 )
#line 83 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using swprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int swprintf(__wchar_t *_String, const __wchar_t *_Format, ...) 
#line 86 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 87 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto va_list _Arglist; 
#line 88 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 89 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto int _Ret = _vswprintf(_String, _Format, _Arglist); 
#line 90 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = ((va_list)0); 
#line 91 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _Ret; 
#line 92 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} 
#pragma warning( pop )
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using vswprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vswprintf(__wchar_t *_String, const __wchar_t *_Format, va_list _Ap) 
#line 98 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 99 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _vswprintf(_String, _Format, _Ap); 
#line 100 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} 
#pragma warning( pop )
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using _swprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int _swprintf_l(__wchar_t *_String, const __wchar_t *_Format, _locale_t _Plocinfo, ...) 
#line 106 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 107 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto va_list _Arglist; 
#line 108 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Plocinfo))) + (((sizeof(_Plocinfo) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 109 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
auto int _Ret = __vswprintf_l(_String, _Format, _Plocinfo, _Arglist); 
#line 110 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
_Arglist = ((va_list)0); 
#line 111 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return _Ret; 
#line 112 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} 
#pragma warning( pop )
#line 115 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using _vswprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vswprintf_l(__wchar_t *_String, const __wchar_t *_Format, _locale_t _Plocinfo, va_list _Ap) 
#line 118 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
{ 
#line 119 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
return __vswprintf_l(_String, _Format, _Plocinfo, _Ap); 
#line 120 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
} 
#pragma warning( pop )
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )
#line 528 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __wchar_t *__cdecl _wtempnam(const __wchar_t *, const __wchar_t *); } 
#line 534 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscwprintf(const __wchar_t *, va_list); } 
#line 535 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscwprintf_l(const __wchar_t *, _locale_t, va_list); } 
#line 536 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fwscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl fwscanf(FILE *, const __wchar_t *, ...); } 
#line 537 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fwscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _fwscanf_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 539 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fwscanf_s(FILE *, const __wchar_t *, ...); } 
#line 541 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwscanf_s_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 542 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using swscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl swscanf(const __wchar_t *, const __wchar_t *, ...); } 
#line 543 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _swscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _swscanf_l(const __wchar_t *, const __wchar_t *, _locale_t, ...); } 
#line 545 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl swscanf_s(const __wchar_t *, const __wchar_t *, ...); } 
#line 547 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swscanf_s_l(const __wchar_t *, const __wchar_t *, _locale_t, ...); } 
#line 548 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwscanf(const __wchar_t *, size_t, const __wchar_t *, ...); } 
#line 549 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwscanf_l(const __wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 550 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snwscanf_s(const __wchar_t *, size_t, const __wchar_t *, ...); } 
#line 551 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _snwscanf_s_l(const __wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 552 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl wscanf(const __wchar_t *, ...); } 
#line 553 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _wscanf_l(const __wchar_t *, _locale_t, ...); } 
#line 555 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl wscanf_s(const __wchar_t *, ...); } 
#line 557 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wscanf_s_l(const __wchar_t *, _locale_t, ...); } 
#line 559 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _wfdopen(int, const __wchar_t *); } 
#line 560 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wfopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl _wfopen(const __wchar_t *, const __wchar_t *); } 
#line 561 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl _wfopen_s(FILE **, const __wchar_t *, const __wchar_t *); } 
#line 562 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wfreopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl _wfreopen(const __wchar_t *, const __wchar_t *, FILE *); } 
#line 563 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl _wfreopen_s(FILE **, const __wchar_t *, const __wchar_t *, FILE *); } 
#line 569 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _wpopen(const __wchar_t *, const __wchar_t *); } 
#line 570 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wremove(const __wchar_t *); } 
#line 571 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern errno_t __cdecl _wtmpnam_s(__wchar_t *, size_t); } 
#line 572 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline errno_t __cdecl _wtmpnam_s(__wchar_t (&_Buffer)[_Size]) { return _wtmpnam_s(_Buffer, _Size); } 
#line 573 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wtmpnam_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wtmpnam(__wchar_t *); } 
#line 575 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl _fgetwc_nolock(FILE *); } 
#line 576 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl _fputwc_nolock(__wchar_t, FILE *); } 
#line 577 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl _ungetwc_nolock(wint_t, FILE *); } 
#line 585 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { inline wint_t __cdecl getwchar() 
#line 586 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
{ return fgetwc(__iob_func() + 0); } } 
#line 587 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { inline wint_t __cdecl putwchar(__wchar_t _C) 
#line 588 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
{ return fputwc(_C, __iob_func() + 1); } } 
#line 635 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl _lock_file(FILE *); } 
#line 636 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl _unlock_file(FILE *); } 
#line 643 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fclose_nolock(FILE *); } 
#line 644 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fflush_nolock(FILE *); } 
#line 645 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl _fread_nolock(void *, size_t, size_t, FILE *); } 
#line 646 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl _fread_nolock_s(void *, size_t, size_t, size_t, FILE *); } 
#line 647 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fseek_nolock(FILE *, long, int); } 
#line 648 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern long __cdecl _ftell_nolock(FILE *); } 
#line 649 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fseeki64_nolock(FILE *, __int64, int); } 
#line 650 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __int64 __cdecl _ftelli64_nolock(FILE *); } 
#line 651 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern size_t __cdecl _fwrite_nolock(const void *, size_t, size_t, FILE *); } 
#line 652 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _ungetc_nolock(int, FILE *); } 
#line 679 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _tempnam. See online help for details.")) char *__cdecl tempnam(const char *, const char *); } 
#line 685 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fcloseall. See online help for details.")) int __cdecl fcloseall(); } 
#line 686 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fdopen. See online help for details.")) FILE *__cdecl fdopen(int, const char *); } 
#line 687 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fgetchar. See online help for details.")) int __cdecl fgetchar(); } 
#line 688 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fileno. See online help for details.")) int __cdecl fileno(FILE *); } 
#line 689 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _flushall. See online help for details.")) int __cdecl flushall(); } 
#line 690 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fputchar. See online help for details.")) int __cdecl fputchar(int); } 
#line 691 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _getw. See online help for details.")) int __cdecl getw(FILE *); } 
#line 692 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _putw. See online help for details.")) int __cdecl putw(int, FILE *); } 
#line 693 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _rmtmp. See online help for details.")) int __cdecl rmtmp(); } 
#line 37 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
#pragma warning( disable : 4996 )
#line 702 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma pack ( pop )
#line 65 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
enum CUTBoolean { 
#line 67 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
CUTFalse, 
#line 68 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
CUTTrue
#line 69 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
}; 
#line 77 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) void __stdcall cutFree(void *); } 
#line 95 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) void __stdcall cutCheckBankAccess(unsigned, unsigned, unsigned, unsigned, unsigned, unsigned, const char *, const int, const char *, const int); } 
#line 108 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) char *__stdcall cutFindFilePath(const char *, const char *); } 
#line 123 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFilef(const char *, float **, unsigned *, bool = false); } 
#line 139 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFiled(const char *, double **, unsigned *, bool = false); } 
#line 155 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFilei(const char *, int **, unsigned *, bool = false); } 
#line 170 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileui(const char *, unsigned **, unsigned *, bool = false); } 
#line 186 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileb(const char *, char **, unsigned *, bool = false); } 
#line 202 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileub(const char *, unsigned char **, unsigned *, bool = false); } 
#line 216 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFilef(const char *, const float *, unsigned, const float, bool = false); } 
#line 230 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFiled(const char *, const float *, unsigned, const double, bool = false); } 
#line 242 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFilei(const char *, const int *, unsigned, bool = false); } 
#line 254 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileui(const char *, const unsigned *, unsigned, bool = false); } 
#line 266 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileb(const char *, const char *, unsigned, bool = false); } 
#line 278 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileub(const char *, const unsigned char *, unsigned, bool = false); } 
#line 294 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 307 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPPMub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 321 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPPM4ub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 337 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMi(const char *, unsigned **, unsigned *, unsigned *); } 
#line 353 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMs(const char *, unsigned short **, unsigned *, unsigned *); } 
#line 368 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMf(const char *, float **, unsigned *, unsigned *); } 
#line 380 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMub(const char *, unsigned char *, unsigned, unsigned); } 
#line 392 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePPMub(const char *, unsigned char *, unsigned, unsigned); } 
#line 405 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePPM4ub(const char *, unsigned char *, unsigned, unsigned); } 
#line 417 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMi(const char *, unsigned *, unsigned, unsigned); } 
#line 429 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMs(const char *, unsigned short *, unsigned, unsigned); } 
#line 441 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMf(const char *, float *, unsigned, unsigned); } 
#line 462 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCheckCmdLineFlag(const int, const char **, const char *); } 
#line 476 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumenti(const int, const char **, const char *, int *); } 
#line 490 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentf(const int, const char **, const char *, float *); } 
#line 504 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentstr(const int, const char **, const char *, char **); } 
#line 519 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentListstr(const int, const char **, const char *, char **, unsigned *); } 
#line 533 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCheckCondition(int, const char *, const int); } 
#line 545 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparef(const float *, const float *, const unsigned); } 
#line 558 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparei(const int *, const int *, const unsigned); } 
#line 571 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareub(const unsigned char *, const unsigned char *, const unsigned); } 
#line 585 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareube(const unsigned char *, const unsigned char *, const unsigned, const int); } 
#line 599 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparefe(const float *, const float *, const unsigned, const float); } 
#line 614 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareL2fe(const float *, const float *, const unsigned, const float); } 
#line 627 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCreateTimer(unsigned *); } 
#line 636 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutDeleteTimer(unsigned); } 
#line 644 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutStartTimer(const unsigned); } 
#line 652 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutStopTimer(const unsigned); } 
#line 660 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutResetTimer(const unsigned); } 
#line 669 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) float __stdcall cutGetTimerValue(const unsigned); } 
#line 680 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern "C" { extern __declspec( dllimport ) float __stdcall cutGetAverageTimerValue(const unsigned); } 
#line 30 "template.cu"
unsigned NUM_THREADS_IN_BLOCK = (256); 
#line 47 "template.cu"
static   texture< int, 1, cudaReadModeElementType>  textura_m; 
#line 51 "template.cu"
static   texture< char1, 1, cudaReadModeElementType>  textura_p; 
#line 52 "template.cu"
static   texture< char1, 1, cudaReadModeElementType>  textura_f; 

#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z7kernel3PbS_PKjj(bool *, bool *, const unsigned *, const unsigned);
#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 55 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(const bool *, const unsigned *, const unsigned, unsigned *);
#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 58 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 61 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(const unsigned, unsigned *);
#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 64 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 67 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 70 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned, const unsigned *, const bool *, const bool *, unsigned *);
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 73 "template.cu"


#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 7 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 16 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

extern void __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(const unsigned, unsigned *);
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"

}
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.h"
#line 76 "template.cu"

#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern void mostrarB(const bool *, const unsigned, const char *); 
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern void mostrarI(const int *, const unsigned, const char *); 
#line 6 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern void mostrarUI(const unsigned *, const unsigned, const char *); 
#line 8 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern unsigned minimo(const unsigned, const unsigned); 
#line 12 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern void mostrarUI_M_Adyacencia(const unsigned *, const unsigned, const char *); 
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\Fibonacci_Heaps.h"
extern void computeGold_FH(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void copiarH2D(void *v_d, const void *v_h, const unsigned mem_size) { 
#line 14 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMemcpy(v_d, v_h, mem_size, cudaMemcpyHostToDevice); 
#line 15 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void copiarD2H(void *v_h, const void *v_d, const unsigned mem_size) { 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMemcpy(v_h, v_d, mem_size, cudaMemcpyDeviceToHost); 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void inicializar_Matriz_Device(const unsigned *m_h, const unsigned mem_size_M, unsigned *&
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
m_d) { 
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMalloc((void **)(&m_d), mem_size_M); 
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
copiarH2D(m_d, m_h, mem_size_M); 
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void inicializar_Sol(unsigned *&c_h, unsigned *&c_d, const unsigned 
#line 32 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
nv, const unsigned mem_size_V, const unsigned 
#line 33 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
infinito) { 
#line 35 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
c_h = (unsigned *)malloc(mem_size_V); 
#line 37 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
((c_h)[0]) = (0); 
#line 38 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
for (unsigned i = (1); i <= nv - (1); i++) { ((c_h)[i]) = infinito; }  
#line 41 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMalloc((void **)(&c_d), mem_size_V); 
#line 43 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
copiarH2D((void *)(c_d), (void *)(c_h), mem_size_V); 
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 51 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void inicializar_Pendientes(bool *&p_h, bool *&p_d, const unsigned 
#line 52 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
nv, const unsigned mem_size_F) { 
#line 54 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
p_h = (bool *)malloc(mem_size_F); 
#line 56 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
((p_h)[0]) = false; 
#line 57 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
for (unsigned i = (1); i <= nv - (1); i++) { ((p_h)[i]) = true; }  
#line 60 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMalloc((void **)(&p_d), mem_size_F); 
#line 62 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
copiarH2D((void *)(p_d), (void *)(p_h), mem_size_F); 
#line 67 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 70 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void inicializar_Frontera(bool *&f_h, bool *&f_d, const unsigned 
#line 71 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
nv, const unsigned mem_size_F) { 
#line 73 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
f_h = (bool *)malloc(mem_size_F); 
#line 75 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
((f_h)[0]) = true; 
#line 76 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
for (unsigned i = (1); i <= nv - (1); i++) { ((f_h)[i]) = false; }  
#line 79 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
cudaMalloc((void **)(&f_d), mem_size_F); 
#line 81 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
copiarH2D((void *)(f_d), (void *)(f_h), mem_size_F); 
#line 87 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
bool ejecutarIteracion_SSSP7(const unsigned 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
nVuelta, const dim3 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
nv, const unsigned mem_size_M, const unsigned 
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
infinito, bool *
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
minimoDelBloque_h, const unsigned *
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
m_d, bool *
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
minimoDelBloque_d) { 
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned shared_mem = (threads.x * (sizeof(unsigned) + sizeof(bool))); 
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 50 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
; 
#line 51 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaThreadSynchronize(); 
#line 72 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 75 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
; 
#line 76 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaThreadSynchronize(); 
#line 78 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 79 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned min = infinito; 
#line 90 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 91 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
}  
#line 111 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
; 
#line 114 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaThreadSynchronize(); 
#line 127 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
return min == infinito; 
#line 128 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
} 
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
void testGraph_SSSP7(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 132 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
infinito, unsigned num_threadsInBlock, const unsigned *
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
m_h, const unsigned *reference) { 
#line 136 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned *m_d; 
#line 139 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 141 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned *c_h; 
#line 142 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned *c_d; 
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 144 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 146 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto bool *f_h; 
#line 147 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto bool *f_d; 
#line 148 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 149 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 151 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto bool *p_h; 
#line 152 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto bool *p_d; 
#line 153 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 157 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 158 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 159 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 160 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 163 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 164 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 165 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned *minimoDelBloque_d; 
#line 167 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 168 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned timer = (0); 
#line 182 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cutCreateTimer(&timer); 
#line 183 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cutStartTimer(timer); 
#line 187 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto bool ultima = false; 
#line 188 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned i = (0); 
#line 189 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
while (!ultima) { 
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
i++; 
#line 191 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
ultima = ejecutarIteracion_SSSP7(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 201 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
}  
#line 203 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cutStopTimer(timer); 
#line 204 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 205 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cutDeleteTimer(timer); 
#line 207 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaFree(m_d); 
#line 213 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
free(f_h); 
#line 214 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
free(p_h); 
#line 216 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaFree(c_d); 
#line 217 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaFree(f_d); 
#line 218 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaFree(p_d); 
#line 220 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
free(minimoDelBloque_h); 
#line 222 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaFree(minimoDelBloque_d); 
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 226 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 230 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
free(c_h); 
#line 232 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
} 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
bool ejecutarIteracion_SSSP7_T(const unsigned 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
nVuelta, const dim3 
#line 21 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
nv, const unsigned mem_size_M, const unsigned 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
infinito, bool *
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
minimoDelBloque_h, const unsigned *
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
m_d, bool *
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 29 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
minimoDelBloque_d) { 
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned shared_mem = (threads.x * (sizeof(unsigned) + sizeof(bool))); 
#line 49 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(nv, c_d); 
#line 52 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
; 
#line 53 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaThreadSynchronize(); 
#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 77 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
; 
#line 78 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaThreadSynchronize(); 
#line 80 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 81 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned min = infinito; 
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 93 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 94 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
; 
#line 116 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaThreadSynchronize(); 
#line 129 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
return min == infinito; 
#line 130 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
} 
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
void testGraph_SSSP7_T(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 134 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
infinito, unsigned num_threadsInBlock, const unsigned *
#line 135 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
m_h, const unsigned *reference) { 
#line 137 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *m_d; 
#line 140 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaBindTexture(0, textura_m, m_d, mem_size_M); 
#line 145 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *c_h; 
#line 146 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *c_d; 
#line 147 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto bool *f_h; 
#line 151 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto bool *f_d; 
#line 152 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto bool *p_h; 
#line 156 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto bool *p_d; 
#line 157 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaBindTexture(0, textura_p, p_d, mem_size_F); 
#line 162 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaBindTexture(0, textura_f, f_d, mem_size_F); 
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 167 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 168 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 169 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 172 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 173 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 174 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 175 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *minimoDelBloque_d; 
#line 176 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 177 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned timer = (0); 
#line 191 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cutCreateTimer(&timer); 
#line 192 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cutStartTimer(timer); 
#line 196 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto bool ultima = false; 
#line 197 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned i = (0); 
#line 198 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
while (!ultima) { 
#line 199 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
i++; 
#line 200 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
ultima = ejecutarIteracion_SSSP7_T(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
}  
#line 213 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cutStopTimer(timer); 
#line 214 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 215 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cutDeleteTimer(timer); 
#line 217 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 220 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaUnbindTexture(textura_m); 
#line 223 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaFree(m_d); 
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
free(f_h); 
#line 226 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
free(p_h); 
#line 230 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaUnbindTexture(textura_p); 
#line 231 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaUnbindTexture(textura_f); 
#line 233 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaFree(c_d); 
#line 234 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaFree(f_d); 
#line 235 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaFree(p_d); 
#line 237 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
free(minimoDelBloque_h); 
#line 239 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaFree(minimoDelBloque_d); 
#line 242 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 243 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 246 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
free(c_h); 
#line 248 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
} 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
bool ejecutarIteracion_SSSP7_RT(const unsigned 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
nVuelta, const dim3 
#line 21 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
nv, const unsigned mem_size_M, const unsigned 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
infinito, bool *
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
minimoDelBloque_h, const unsigned *
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
m_d, bool *
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 29 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
minimoDelBloque_d) { 
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned shared_mem = (threads.x * ((((4) * sizeof(unsigned)) + sizeof(unsigned)) + sizeof(bool))); 
#line 49 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(nv, c_d); 
#line 52 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
; 
#line 53 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaThreadSynchronize(); 
#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 77 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
; 
#line 78 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaThreadSynchronize(); 
#line 80 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 81 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned min = infinito; 
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 93 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 94 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
; 
#line 116 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaThreadSynchronize(); 
#line 129 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
return min == infinito; 
#line 130 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
} 
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
void testGraph_SSSP7_RT(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 134 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
infinito, unsigned num_threadsInBlock, const unsigned *
#line 135 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
m_h, const unsigned *reference) { 
#line 137 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *m_d; 
#line 140 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaBindTexture(0, textura_m, m_d, mem_size_M); 
#line 145 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *c_h; 
#line 146 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *c_d; 
#line 147 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto bool *f_h; 
#line 151 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto bool *f_d; 
#line 152 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto bool *p_h; 
#line 156 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto bool *p_d; 
#line 157 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaBindTexture(0, textura_p, p_d, mem_size_F); 
#line 162 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaBindTexture(0, textura_f, f_d, mem_size_F); 
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 167 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 168 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 169 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 172 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 173 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 174 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 175 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *minimoDelBloque_d; 
#line 176 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 177 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned timer = (0); 
#line 191 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cutCreateTimer(&timer); 
#line 192 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cutStartTimer(timer); 
#line 196 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto bool ultima = false; 
#line 197 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned i = (0); 
#line 198 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
while (!ultima) { 
#line 199 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
i++; 
#line 200 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
ultima = ejecutarIteracion_SSSP7_RT(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
}  
#line 213 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cutStopTimer(timer); 
#line 214 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 215 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cutDeleteTimer(timer); 
#line 217 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 220 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaUnbindTexture(textura_m); 
#line 223 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaFree(m_d); 
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
free(f_h); 
#line 226 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
free(p_h); 
#line 230 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaUnbindTexture(textura_p); 
#line 231 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaUnbindTexture(textura_f); 
#line 233 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaFree(c_d); 
#line 234 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaFree(f_d); 
#line 235 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaFree(p_d); 
#line 237 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
free(minimoDelBloque_h); 
#line 239 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaFree(minimoDelBloque_d); 
#line 242 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 243 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 246 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
free(c_h); 
#line 248 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
bool ejecutarIteracion_SSSP9(const unsigned 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
nVuelta, const dim3 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
nv, const unsigned mem_size_M, const unsigned 
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
infinito, bool *
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
minimoDelBloque_h, const unsigned *
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
m_d, bool *
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
minimoDelBloque_d) { 
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaConfigureCall(grid, threads, threads.x * sizeof(bool)) ? ((void)0) : __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 50 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
; 
#line 51 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaThreadSynchronize(); 
#line 73 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 76 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
; 
#line 77 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaThreadSynchronize(); 
#line 79 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 80 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned min = infinito; 
#line 91 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 93 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
; 
#line 116 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaThreadSynchronize(); 
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
return min == infinito; 
#line 132 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
} 
#line 135 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
void testGraph_SSSP9(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 136 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
infinito, unsigned num_threadsInBlock, const unsigned *
#line 137 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
m_h, const unsigned *reference) { 
#line 140 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned *m_d; 
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 145 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned *c_h; 
#line 146 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned *c_d; 
#line 147 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto bool *f_h; 
#line 151 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto bool *f_d; 
#line 152 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto bool *p_h; 
#line 156 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto bool *p_d; 
#line 157 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 162 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 163 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 164 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 167 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 168 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 169 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 170 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned *minimoDelBloque_d; 
#line 171 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 172 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 185 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned timer = (0); 
#line 186 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cutCreateTimer(&timer); 
#line 187 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cutStartTimer(timer); 
#line 191 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto bool ultima = false; 
#line 192 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned i = (0); 
#line 193 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
while (!ultima) { 
#line 194 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
i++; 
#line 195 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
ultima = ejecutarIteracion_SSSP9(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 205 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
}  
#line 207 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cutStopTimer(timer); 
#line 208 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 209 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cutDeleteTimer(timer); 
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 215 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaFree(m_d); 
#line 217 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
free(f_h); 
#line 218 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
free(p_h); 
#line 220 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaFree(c_d); 
#line 221 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaFree(f_d); 
#line 222 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaFree(p_d); 
#line 224 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
free(minimoDelBloque_h); 
#line 226 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaFree(minimoDelBloque_d); 
#line 229 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 230 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 234 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
free(c_h); 
#line 236 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
bool ejecutarIteracion_SSSP9_Atomic(const unsigned 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
nVuelta, const dim3 
#line 20 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
nv, const unsigned mem_size_M, const unsigned 
#line 22 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
infinito, bool *
#line 24 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
minimoDelBloque_h, const unsigned *
#line 26 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
m_d, bool *
#line 27 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
minimoDelBloque_d) { 
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaConfigureCall(grid, threads, threads.x * sizeof(bool)) ? ((void)0) : __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 49 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
; 
#line 50 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaThreadSynchronize(); 
#line 71 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
; 
#line 75 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaThreadSynchronize(); 
#line 77 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 78 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned min = infinito; 
#line 89 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 90 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 91 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
}  
#line 110 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 112 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
; 
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaThreadSynchronize(); 
#line 126 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
return min == infinito; 
#line 127 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
} 
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
void testGraph_SSSP9_Atomic(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 132 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
infinito, unsigned num_threadsInBlock, const unsigned *
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
m_h, const unsigned *reference) { 
#line 136 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned *m_d; 
#line 139 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 141 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned *c_h; 
#line 142 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned *c_d; 
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 144 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 146 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto bool *f_h; 
#line 147 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto bool *f_d; 
#line 148 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 149 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 151 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto bool *p_h; 
#line 152 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto bool *p_d; 
#line 153 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 157 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 158 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 159 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 160 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 163 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 164 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 165 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned *minimoDelBloque_d; 
#line 167 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 168 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned timer = (0); 
#line 182 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cutCreateTimer(&timer); 
#line 183 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cutStartTimer(timer); 
#line 187 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto bool ultima = false; 
#line 188 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned i = (0); 
#line 189 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
while (!ultima) { 
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
i++; 
#line 191 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
ultima = ejecutarIteracion_SSSP9_Atomic(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 201 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
}  
#line 203 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cutStopTimer(timer); 
#line 204 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 205 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cutDeleteTimer(timer); 
#line 207 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaFree(m_d); 
#line 213 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
free(f_h); 
#line 214 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
free(p_h); 
#line 216 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaFree(c_d); 
#line 217 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaFree(f_d); 
#line 218 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaFree(p_d); 
#line 220 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
free(minimoDelBloque_h); 
#line 222 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaFree(minimoDelBloque_d); 
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 226 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 230 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
free(c_h); 
#line 232 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
} 
#line 71 "template.cu"
extern void runTest(); 
#line 72 "template.cu"
extern void generar_Matrices_Adyacencia(); 
#line 73 "template.cu"
extern void runFH(); 
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.h"
extern void computeGold_CPU7(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 10 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.h"
extern void computeGold_CPU9(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 6 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern void genera_M_Adyacencia(const unsigned, const unsigned, const unsigned, const unsigned, unsigned &, unsigned *&); 
#line 11 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern void guardaMatriz_FicheroB(const char *, const unsigned, const unsigned, const unsigned *); 
#line 15 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern void leeMatriz_FicheroB(const char *, unsigned &, unsigned &, unsigned *&); 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern unsigned RangedRand(unsigned, unsigned); 
#line 85 "template.cu"
int __cdecl main(int argc, char **argv) 
#line 86 "template.cu"
{ 
#line 88 "template.cu"
{ auto int deviceCount; cudaGetDeviceCount(&deviceCount); if (deviceCount == 0) { fprintf(__iob_func() + 2, "cutil error: no devices supporting CUDA.\n"); exit(1); }  auto int dev = 0; cutGetCmdLineArgumenti(argc, (const char **)argv, "device", &dev); if (dev > deviceCount - 1) { dev = deviceCount - 1; }  auto cudaDeviceProp deviceProp; cudaGetDeviceProperties(&deviceProp, dev); if (deviceProp.major < 1) { fprintf(__iob_func() + 2, "cutil error: device does not support CUDA.\n"); exit(1); }  if (cutCheckCmdLineFlag(argc, (const char **)argv, "quiet") == (CUTFalse)) { fprintf(__iob_func() + 2, "Using device %d: %s\n", dev, deviceProp.name); }  cudaSetDevice(dev); } ; 
#line 90 "template.cu"
srand(time(0)); 
#line 95 "template.cu"
runFH(); 
#line 111 "template.cu"
printf("\n\n"); 
#line 112 "template.cu"
printf(cudaGetErrorString(cudaGetLastError())); 
#line 113 "template.cu"
printf("\n\n"); 
#line 115 "template.cu"
if (!(cutCheckCmdLineFlag(argc, (const char **)argv, "noprompt"))) { printf("\nPress ENTER to exit...\n"); fflush(__iob_func() + 1); fflush(__iob_func() + 2); getchar(); }  exit(0); ; return 0; 
#line 117 "template.cu"
} 
#line 122 "template.cu"
void generar_Matrices_Adyacencia() { 
#line 124 "template.cu"
auto unsigned nv; 
#line 125 "template.cu"
auto unsigned *m; 
#line 126 "template.cu"
auto unsigned mem_size_M; 
#line 128 "template.cu"
auto unsigned degree; 
#line 129 "template.cu"
auto unsigned topeW = (10); 
#line 130 "template.cu"
auto unsigned infinito; 
#line 133 "template.cu"
auto char s[100]; 
#line 135 "template.cu"
auto unsigned timer; 
#line 137 "template.cu"
printf("Generando y Guardando Matrices de Adyacencia\n"); 
#line 139 "template.cu"
for (unsigned k = (1); k <= (15); k++) { 
#line 140 "template.cu"
nv = k * (1024); 
#line 141 "template.cu"
degree = nv / (5); 
#line 142 "template.cu"
infinito = nv * (10); 
#line 143 "template.cu"
printf("\n\nNODOS= %d * 1024\n", k); 
#line 144 "template.cu"
printf("topeW= %i\n", 10); 
#line 145 "template.cu"
printf("degree= nv/%i= %i\n", 5, degree); 
#line 146 "template.cu"
printf("infinito= nv*%i= %i\n\n", 10, infinito); 
#line 148 "template.cu"
printf("Matriz\t Generar\t Guardar\n"); 
#line 149 "template.cu"
for (unsigned i = (1); i <= (25); i++) { 
#line 151 "template.cu"
printf("%i\t", i); 
#line 153 "template.cu"
if (i < (10)) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 154 "template.cu"
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 158 "template.cu"
timer = (0); 
#line 159 "template.cu"
cutCreateTimer(&timer); 
#line 160 "template.cu"
cutStartTimer(timer); 
#line 162 "template.cu"
genera_M_Adyacencia(nv, degree, topeW, infinito, mem_size_M, m); 
#line 164 "template.cu"
cutStopTimer(timer); 
#line 165 "template.cu"
printf("%f\t", cutGetTimerValue(timer)); 
#line 166 "template.cu"
cutDeleteTimer(timer); 
#line 168 "template.cu"
timer = (0); 
#line 169 "template.cu"
cutCreateTimer(&timer); 
#line 170 "template.cu"
cutStartTimer(timer); 
#line 172 "template.cu"
guardaMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 174 "template.cu"
cutStopTimer(timer); 
#line 175 "template.cu"
printf("%f\n", cutGetTimerValue(timer)); 
#line 176 "template.cu"
cutDeleteTimer(timer); 
#line 179 "template.cu"
free(m); 
#line 181 "template.cu"
}  
#line 183 "template.cu"
}  
#line 185 "template.cu"
} 
#line 188 "template.cu"
void runTest() { 
#line 191 "template.cu"
auto unsigned nv; 
#line 192 "template.cu"
auto unsigned *m; 
#line 193 "template.cu"
auto unsigned mem_size_M; 
#line 195 "template.cu"
auto unsigned topeW = (10); 
#line 196 "template.cu"
auto unsigned infinito; 
#line 199 "template.cu"
auto unsigned *reference1; 
#line 200 "template.cu"
auto unsigned *reference2; 
#line 204 "template.cu"
printf("TEST SSSP7, SSSP9\n\n"); 
#line 205 "template.cu"
printf("degree= nv/%i\n", 5); 
#line 206 "template.cu"
printf("topeW= %i\n", topeW); 
#line 209 "template.cu"
auto char s[100]; 
#line 211 "template.cu"
for (unsigned t = (1); t <= (1); t++) { 
#line 213 "template.cu"
printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); 
#line 215 "template.cu"
for (unsigned k = (7); k <= (15); k++) { 
#line 216 "template.cu"
printf("\n\nNODOS= %i * 1024\n\n", k); 
#line 217 "template.cu"
printf("Grafo\t CPU7\t\t\t CPU9\t\t\t SSSP7\t\t\t SSSP9_Atomic\t\t\t SSSP9\t\t\t SSSP7_T\t\t\t SSSP7_RT\n\n"); 
#line 218 "template.cu"
nv = k * (1024); 
#line 219 "template.cu"
infinito = nv * (10); 
#line 221 "template.cu"
for (int i = 1; i <= 25; i++) { 
#line 223 "template.cu"
printf("%i\t", i); 
#line 225 "template.cu"
if (i < 10) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 226 "template.cu"
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 232 "template.cu"
leeMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 235 "template.cu"
reference1 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 236 "template.cu"
computeGold_CPU7(reference1, nv, m, infinito); 
#line 238 "template.cu"
reference2 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 239 "template.cu"
computeGold_CPU9(reference2, nv, m, infinito); 
#line 242 "template.cu"
auto CUTBoolean res = cutComparei((int *)reference1, (int *)reference2, nv); 
#line 243 "template.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 245 "template.cu"
free(reference2); 
#line 248 "template.cu"
testGraph_SSSP7(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 250 "template.cu"
testGraph_SSSP9_Atomic(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 252 "template.cu"
testGraph_SSSP9(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 254 "template.cu"
testGraph_SSSP7_T(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 256 "template.cu"
testGraph_SSSP7_RT(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 258 "template.cu"
printf("\n"); 
#line 261 "template.cu"
free(m); 
#line 262 "template.cu"
free(reference1); 
#line 264 "template.cu"
}  
#line 266 "template.cu"
}  
#line 268 "template.cu"
NUM_THREADS_IN_BLOCK = NUM_THREADS_IN_BLOCK * (2); 
#line 270 "template.cu"
}  
#line 271 "template.cu"
} 
#line 274 "template.cu"
void runFH() { 
#line 277 "template.cu"
auto unsigned nv; 
#line 278 "template.cu"
auto unsigned *m; 
#line 279 "template.cu"
auto unsigned mem_size_M; 
#line 281 "template.cu"
auto unsigned topeW = (10); 
#line 282 "template.cu"
auto unsigned infinito; 
#line 285 "template.cu"
auto unsigned *reference1; 
#line 286 "template.cu"
auto unsigned *reference2; 
#line 290 "template.cu"
printf("TEST SSSP MATRICES\n\n"); 
#line 291 "template.cu"
printf("degree= nv/%i\n", 5); 
#line 292 "template.cu"
printf("topeW= %i\n", topeW); 
#line 295 "template.cu"
auto char s[100]; 
#line 297 "template.cu"
printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); 
#line 299 "template.cu"
for (unsigned k = (1); k <= (15); k++) { 
#line 300 "template.cu"
printf("\n\nNODOS= %i * 1024\n\n", k); 
#line 301 "template.cu"
printf("Grafo\t CPU7\t\t\t FH\n\n"); 
#line 302 "template.cu"
nv = k * (1024); 
#line 303 "template.cu"
infinito = nv * (10); 
#line 305 "template.cu"
for (int i = 1; i <= 25; i++) { 
#line 307 "template.cu"
printf("%i\t", i); 
#line 309 "template.cu"
if (i < 10) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 310 "template.cu"
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 314 "template.cu"
leeMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 317 "template.cu"
reference1 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 318 "template.cu"
computeGold_CPU7(reference1, nv, m, infinito); 
#line 320 "template.cu"
reference2 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 321 "template.cu"
computeGold_FH(reference2, nv, m, infinito); 
#line 325 "template.cu"
auto CUTBoolean res = cutComparei((int *)reference1, (int *)reference2, nv); 
#line 326 "template.cu"
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 328 "template.cu"
printf("\n"); 
#line 331 "template.cu"
free(m); 
#line 332 "template.cu"
free(reference1); 
#line 333 "template.cu"
free(reference2); 
#line 336 "template.cu"
}  
#line 338 "template.cu"
}  
#line 340 "template.cu"
} 

#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"

extern "C" {
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 1 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"
#line 1 "C:\\CUDA\\include\\__cudaFatFormat.h"


















































































extern "C" {
#line 85 "C:\\CUDA\\include\\__cudaFatFormat.h"












typedef struct {
    char*            gpuProfileName;
    char*            cubin;
} __cudaFatCubinEntry;












typedef struct {
    char*            gpuProfileName;            
    char*            ptx;
} __cudaFatPtxEntry;








typedef struct {
    char*            gpuProfileName;            
    char*            debug;
} __cudaFatDebugEntry;


typedef enum {
      __cudaFatDontSearchFlag = (1 << 0),
      __cudaFatDontCacheFlag  = (1 << 1),
      __cudaFatSassDebugFlag  = (1 << 2)
} __cudaFatCudaBinaryFlag;










typedef struct {
    unsigned long     magic;
    unsigned long     version;
    unsigned long     gpuInfoVersion;
    char*            key;
    char*            ident;
    char*            usageMode;
    __cudaFatPtxEntry      *ptx;
    __cudaFatCubinEntry    *cubin;
    __cudaFatDebugEntry    *debug;
    void*           debugInfo;
    unsigned int            flags;
} __cudaFatCudaBinary;































void fatGetCubinForGpu( __cudaFatCudaBinary *binary, char* gpuName, char* *cubin, char* *dbgInfoFile );







void fatFreeCubin( char* cubin, char* dbgInfoFile );


}
#line 203 "C:\\CUDA\\include\\__cudaFatFormat.h"

#line 205 "C:\\CUDA\\include\\__cudaFatFormat.h"
#line 2 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"




extern "C" {
#line 8 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"

static const unsigned char __deviceText[] = {
0x61,0x72,0x63,0x68,0x69,0x74,0x65,0x63,0x74,0x75,0x72,0x65,0x20,0x7b,0x73,0x6d,
0x5f,0x31,0x31,0x7d,0x0d,0x0a,0x61,0x62,0x69,0x76,0x65,0x72,0x73,0x69,0x6f,0x6e,
0x20,0x7b,0x30,0x7d,0x0d,0x0a,0x6d,0x6f,0x64,0x6e,0x61,0x6d,0x65,0x20,0x7b,0x63,
0x75,0x62,0x69,0x6e,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,
0x72,0x61,0x5f,0x66,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,
0x20,0x32,0x0d,0x0a,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,
0x72,0x61,0x5f,0x70,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,
0x20,0x31,0x0d,0x0a,0x7d,0x0d,0x0a,0x73,0x61,0x6d,0x70,0x6c,0x65,0x72,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x74,0x65,0x78,0x74,0x75,
0x72,0x61,0x5f,0x6d,0x0d,0x0a,0x09,0x74,0x65,0x78,0x75,0x6e,0x69,0x74,0x20,0x3d,
0x20,0x30,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,
0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,
0x6e,0x63,0x5f,0x5f,0x5a,0x37,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x33,0x50,0x62,0x53,
0x5f,0x50,0x4b,0x6a,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,
0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,0x09,0x72,
0x65,0x67,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,
0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x34,0x30,
0x30,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,
0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x36,0x30,0x30,0x31,0x34,0x63,0x30,0x31,0x20,0x30,0x78,0x30,0x30,
0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x31,
0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x35,0x20,0x30,0x78,0x30,0x34,
0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x32,0x30,
0x39,0x20,0x30,0x78,0x61,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x38,0x30,0x39,0x20,0x30,0x78,0x30,0x34,
0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,
0x64,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x64,0x66,0x64,0x20,0x30,0x78,0x36,0x38,
0x34,0x30,0x38,0x37,0x63,0x38,0x20,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,
0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,
0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x30,
0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,
0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x30,0x63,0x66,0x66,
0x64,0x20,0x30,0x78,0x36,0x34,0x32,0x31,0x34,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,
0x30,0x30,0x30,0x32,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x30,0x30,0x30,
0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x61,0x30,
0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x30,0x30,
0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,
0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x61,0x30,
0x32,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,
0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,
0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,
0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,
0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,
0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,
0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,
0x62,0x66,0x75,0x6e,0x63,0x5f,0x5f,0x5a,0x31,0x37,0x6b,0x65,0x72,0x6e,0x65,0x6c,
0x5f,0x6d,0x69,0x6e,0x69,0x6d,0x69,0x7a,0x61,0x72,0x31,0x50,0x4b,0x62,0x50,0x4b,
0x6a,0x6a,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,
0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,0x09,0x72,0x65,
0x67,0x20,0x3d,0x20,0x37,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x31,0x0d,
0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x32,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x63,0x30,0x39,
0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x34,0x30,0x30,0x36,0x30,0x38,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x31,0x35,
0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x61,0x31,0x30,
0x20,0x30,0x78,0x32,0x31,0x30,0x34,0x65,0x38,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,
0x20,0x30,0x78,0x36,0x38,0x34,0x30,0x38,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x63,0x30,0x34,0x20,0x30,0x78,0x31,0x31,0x30,
0x30,0x65,0x63,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x38,0x30,0x35,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x32,
0x30,0x34,0x35,0x30,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x32,0x30,0x35,
0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x32,0x30,0x30,0x33,0x38,0x38,0x31,0x38,0x20,0x30,0x78,0x32,0x31,0x30,
0x36,0x65,0x38,0x31,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x38,0x31,0x31,
0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x38,0x30,0x31,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,
0x30,0x38,0x37,0x63,0x38,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x63,0x30,0x31,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,
0x30,0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x30,0x31,
0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x61,0x34,0x30,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x61,0x30,0x35,
0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,
0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,
0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x36,0x30,0x35,0x20,0x30,0x78,0x65,0x34,0x31,
0x30,0x30,0x37,0x63,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x32,0x31,0x30,0x30,0x33,
0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x30,0x35,0x30,0x33,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,
0x30,0x63,0x37,0x63,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x32,0x30,0x31,
0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x34,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x30,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,
0x30,0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x31,0x38,0x30,0x30,0x31,0x30,0x30,0x31,
0x20,0x30,0x78,0x34,0x34,0x30,0x30,0x63,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x34,0x30,0x30,0x64,0x30,0x30,0x31,0x20,0x30,0x78,0x61,0x34,0x32,
0x30,0x30,0x35,0x30,0x30,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,
0x20,0x30,0x78,0x65,0x34,0x32,0x30,0x30,0x35,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x32,0x30,0x35,
0x20,0x30,0x78,0x65,0x34,0x31,0x30,0x30,0x37,0x63,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x31,0x30,0x30,0x31,0x38,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x32,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x37,0x63,0x30,0x62,0x66,0x64,
0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x32,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x34,0x30,0x35,
0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,
0x30,0x78,0x31,0x31,0x30,0x30,0x66,0x30,0x30,0x30,0x20,0x30,0x78,0x32,0x31,0x30,
0x31,0x65,0x65,0x30,0x34,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x32,0x30,0x31,
0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,
0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,
0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,
0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,
0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,
0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,
0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,
0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,0x6e,0x63,0x5f,0x5f,0x5a,0x31,0x33,0x6b,
0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x37,0x6a,0x50,0x4b,0x6a,
0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,
0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x34,0x38,0x0d,
0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x37,0x0d,0x0a,0x09,0x62,0x61,0x72,
0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x31,0x39,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x30,0x30,0x30,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x63,0x32,0x63,0x30,0x30,0x20,
0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x36,0x32,0x38,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x31,0x34,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x31,0x30,0x61,0x65,0x63,0x30,0x30,0x20,
0x30,0x78,0x32,0x31,0x30,0x31,0x66,0x30,0x32,0x63,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x36,0x32,0x35,0x20,
0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x30,0x34,0x38,0x32,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x39,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x30,0x63,0x33,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x33,0x30,0x39,0x38,0x30,0x39,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x30,0x36,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x38,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,0x20,
0x30,0x78,0x36,0x38,0x34,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x32,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x36,0x30,0x35,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x30,0x36,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x35,0x20,
0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x63,0x65,0x33,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x64,0x20,
0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x64,0x30,0x33,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x63,0x31,0x31,0x20,
0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x31,0x61,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x38,0x30,0x31,0x20,
0x30,0x78,0x65,0x34,0x32,0x31,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x38,0x30,
0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x33,0x32,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x32,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x37,
0x63,0x30,0x64,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x38,0x37,0x64,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x32,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,
0x30,0x38,0x34,0x31,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x36,0x38,0x34,0x33,0x63,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x31,0x35,0x20,
0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x38,0x30,0x64,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x63,0x30,0x30,0x30,0x31,0x66,0x64,0x20,
0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x31,0x30,0x30,
0x32,0x65,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x35,0x38,0x32,0x31,0x63,0x20,
0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x38,0x30,0x30,0x20,0x30,0x78,0x34,0x30,0x30,
0x66,0x30,0x30,0x34,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x65,0x30,0x32,0x34,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x31,
0x30,0x32,0x30,0x34,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x65,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x38,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x63,0x61,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x32,0x30,0x61,0x30,0x64,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x63,0x30,0x30,0x64,0x38,0x30,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,
0x30,0x31,0x32,0x32,0x35,0x20,0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x38,0x31,0x31,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,
0x66,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x61,0x31,0x35,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,0x30,
0x31,0x66,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x38,0x36,0x31,
0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x36,0x30,0x64,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,
0x33,0x31,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x64,0x38,0x63,0x33,0x34,0x20,
0x30,0x78,0x32,0x30,0x30,0x63,0x39,0x63,0x33,0x38,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x38,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x31,0x34,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x31,0x36,0x32,0x35,0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,
0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,
0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,
0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,
0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,
0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,
0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,
0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,0x6e,0x63,0x5f,
0x5f,0x5a,0x31,0x35,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,
0x37,0x5f,0x54,0x6a,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,
0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,0x09,
0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x37,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,
0x20,0x31,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x31,0x35,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,
0x30,0x31,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x61,0x32,0x63,0x30,0x30,0x20,0x30,0x78,
0x32,0x30,0x30,0x30,0x38,0x63,0x30,0x34,0x20,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x32,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x20,0x30,0x78,
0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x34,
0x38,0x32,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x32,0x39,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,0x30,0x32,0x30,
0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x34,0x33,0x31,0x20,0x30,0x78,
0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x63,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x61,0x33,0x35,0x20,0x30,0x78,
0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x32,0x30,0x39,
0x61,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,
0x30,0x63,0x30,0x31,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x30,
0x63,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x38,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x37,0x63,0x30,0x31,0x66,0x64,0x20,0x30,0x78,
0x36,0x63,0x30,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,
0x36,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x63,0x30,0x31,0x20,0x30,0x78,
0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x30,
0x63,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x64,0x20,0x30,0x78,
0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x66,
0x38,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x33,0x39,0x20,0x30,0x78,
0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x30,
0x63,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x66,0x33,0x30,0x34,0x30,0x34,0x30,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x64,0x30,0x30,0x65,0x31,
0x63,0x31,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,
0x30,0x63,0x30,0x31,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x37,0x63,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x36,0x63,0x30,0x31,0x34,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,0x78,
0x65,0x34,0x32,0x31,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x32,0x38,0x30,0x31,0x34,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,
0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x38,0x36,0x31,0x66,0x66,
0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x33,0x35,0x30,0x30,0x33,0x20,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x35,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x37,0x63,0x30,0x62,0x66,0x64,0x20,0x30,0x78,
0x36,0x34,0x30,0x30,0x38,0x37,0x64,0x38,0x20,0x30,0x78,0x31,0x30,0x30,0x33,0x35,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x34,0x31,0x63,0x20,0x30,0x78,
0x32,0x30,0x30,0x35,0x38,0x34,0x33,0x63,0x20,0x30,0x78,0x31,0x30,0x30,0x30,0x66,
0x38,0x32,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x65,0x30,0x64,0x20,0x30,0x78,
0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x63,0x30,0x30,0x30,
0x31,0x66,0x64,0x20,0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x38,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x33,0x31,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x39,0x38,
0x36,0x32,0x30,0x20,0x30,0x78,0x31,0x31,0x30,0x30,0x65,0x38,0x30,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x31,0x31,0x30,0x30,0x34,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x31,0x30,0x30,
0x32,0x34,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x32,0x30,0x34,0x31,0x20,0x30,0x78,
0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x31,0x30,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x34,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x20,0x30,0x78,
0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x31,
0x32,0x30,0x64,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x66,0x33,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x32,0x63,0x30,0x30,0x64,
0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x31,0x38,0x33,0x31,0x20,0x30,0x78,
0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x38,
0x65,0x31,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x66,0x30,0x66,0x66,0x64,0x20,0x30,0x78,
0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x39,
0x32,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x34,0x30,0x30,0x33,0x20,0x30,0x78,
0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x31,0x38,
0x38,0x31,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x34,0x31,0x37,0x66,0x64,0x20,0x30,0x78,
0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x36,0x38,
0x61,0x31,0x38,0x20,0x30,0x78,0x32,0x30,0x30,0x64,0x39,0x63,0x33,0x38,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x36,0x30,0x64,0x20,0x30,0x78,
0x30,0x34,0x30,0x31,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x31,0x35,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x0d,
0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x34,0x33,0x31,0x20,0x30,0x78,
0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x7d,
0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,0x65,
0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,0x6e,0x63,0x5f,0x5f,0x5a,
0x31,0x35,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x37,0x5f,
0x31,0x6a,0x50,0x4b,0x6a,0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,
0x6c,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,
0x3d,0x20,0x34,0x38,0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x31,0x0d,
0x0a,0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,
0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,
0x34,0x32,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x34,
0x32,0x63,0x30,0x34,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x32,0x31,0x30,0x20,
0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x38,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,
0x64,0x30,0x31,0x35,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x31,0x39,0x20,0x30,0x78,0x30,0x34,0x32,
0x30,0x30,0x37,0x63,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x61,0x32,0x35,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x31,0x30,0x30,0x32,0x65,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x31,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,
0x63,0x63,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x31,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x38,0x30,
0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x31,0x34,0x37,0x63,0x38,0x20,
0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,
0x33,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x32,
0x61,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,
0x30,0x78,0x31,0x30,0x30,0x32,0x61,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x31,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x37,0x63,
0x30,0x35,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x38,0x37,0x64,0x38,0x20,
0x30,0x78,0x31,0x30,0x30,0x32,0x61,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x35,
0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x36,0x30,0x30,0x34,0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,
0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x36,0x30,0x30,0x34,0x30,0x30,0x30,0x64,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x32,
0x38,0x36,0x30,0x34,0x20,0x30,0x78,0x32,0x31,0x30,0x33,0x65,0x65,0x31,0x63,0x20,
0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x65,0x32,0x31,0x20,0x30,0x78,0x30,0x34,0x32,
0x30,0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x65,0x30,0x35,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x33,0x30,0x38,0x30,0x30,0x35,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,
0x30,0x38,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,
0x36,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,
0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x38,0x30,0x35,0x20,0x30,0x78,0x34,0x34,0x30,
0x30,0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x37,
0x30,0x34,0x32,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x36,0x30,0x30,0x36,0x30,0x36,0x32,0x39,0x20,0x30,0x78,0x30,0x30,0x30,
0x32,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,
0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x36,0x30,0x30,0x36,0x30,0x34,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,
0x32,0x38,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,
0x30,0x32,0x32,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x36,0x30,0x35,0x20,0x30,0x78,0x63,0x34,0x31,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,
0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x32,0x31,0x30,0x31,0x66,0x30,0x30,0x34,0x20,0x30,0x78,0x32,0x31,0x30,
0x61,0x65,0x61,0x32,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x32,0x30,0x35,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,
0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x34,0x32,0x39,0x20,0x30,0x78,0x38,0x30,0x63,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,
0x31,0x34,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x34,0x37,0x38,0x30,0x20,
0x30,0x78,0x33,0x30,0x30,0x31,0x31,0x32,0x32,0x35,0x20,0x30,0x78,0x61,0x34,0x30,
0x30,0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,
0x38,0x65,0x31,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x30,0x78,0x33,0x30,0x30,0x38,0x30,0x66,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,
0x31,0x34,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,
0x38,0x36,0x30,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x30,0x78,0x31,0x30,0x30,0x31,0x36,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,
0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,
0x30,0x64,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,
0x30,0x78,0x31,0x30,0x30,0x30,0x63,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,
0x30,0x31,0x32,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x61,0x32,0x35,0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,
0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,
0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,
0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,
0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,
0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,
0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,0x6d,
0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,0x6e,0x63,0x5f,0x5f,
0x5a,0x31,0x33,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,0x39,
0x6a,0x50,0x4b,0x6a,0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,
0x6d,0x65,0x6d,0x20,0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,
0x20,0x34,0x38,0x0d,0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x33,0x0d,0x0a,
0x09,0x62,0x61,0x72,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,
0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,
0x32,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x38,0x32,
0x63,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x32,0x31,0x34,0x20,0x30,
0x78,0x33,0x30,0x30,0x32,0x30,0x61,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x31,0x30,0x35,0x65,
0x65,0x30,0x30,0x20,0x30,0x78,0x32,0x31,0x30,0x32,0x66,0x30,0x30,0x38,0x20,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,
0x34,0x31,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x31,0x39,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x30,0x37,0x63,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,
0x78,0x33,0x30,0x38,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x31,
0x34,0x37,0x63,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,
0x32,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x32,0x30,0x30,0x30,0x63,0x63,0x32,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,
0x34,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,
0x38,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,
0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x33,
0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,
0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x30,0x34,0x30,0x30,0x36,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x34,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,
0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,
0x78,0x61,0x30,0x30,0x32,0x64,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x64,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,
0x78,0x33,0x30,0x37,0x63,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,
0x38,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x64,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,
0x78,0x31,0x30,0x33,0x30,0x38,0x30,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x33,0x30,0x38,
0x38,0x32,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,
0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x33,
0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x31,
0x32,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x61,0x38,0x30,0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x30,0x38,0x32,0x31,
0x38,0x37,0x64,0x38,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x39,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,
0x78,0x31,0x30,0x30,0x30,0x30,0x38,0x30,0x31,0x20,0x30,0x78,0x34,0x34,0x30,0x30,
0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x62,0x30,
0x30,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x36,0x30,0x30,0x61,0x30,0x32,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,
0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x31,
0x36,0x32,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x36,0x30,0x30,0x61,0x30,0x30,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,
0x63,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x33,0x38,
0x32,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x62,0x38,0x30,0x32,0x63,0x20,0x30,
0x78,0x33,0x30,0x30,0x32,0x31,0x36,0x32,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x32,0x31,0x30,0x62,0x65,0x61,0x32,0x63,0x20,0x30,0x78,0x32,0x31,0x30,0x30,
0x66,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,
0x36,0x32,0x64,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x33,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x31,
0x36,0x32,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x63,0x37,0x38,0x30,0x20,0x30,
0x78,0x33,0x30,0x30,0x62,0x31,0x38,0x32,0x64,0x20,0x30,0x78,0x61,0x34,0x30,0x30,
0x30,0x37,0x38,0x30,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,
0x30,0x32,0x64,0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,
0x78,0x32,0x30,0x30,0x31,0x39,0x32,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x61,0x31,
0x33,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,
0x78,0x32,0x30,0x30,0x31,0x38,0x36,0x30,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x31,0x38,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,
0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,
0x30,0x30,0x30,0x32,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,
0x65,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,
0x78,0x32,0x30,0x30,0x31,0x38,0x34,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,
0x64,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,
0x78,0x32,0x30,0x30,0x38,0x38,0x38,0x32,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x34,
0x38,0x32,0x30,0x34,0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x65,
0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,
0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,
0x74,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,
0x3d,0x20,0x63,0x6f,0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,
0x6d,0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,
0x3d,0x20,0x30,0x0d,0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,
0x0d,0x0a,0x09,0x09,0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,
0x0a,0x09,0x7d,0x0d,0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,
0x75,0x6e,0x63,0x5f,0x5f,0x5a,0x32,0x30,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,
0x53,0x53,0x53,0x50,0x39,0x5f,0x41,0x74,0x6f,0x6d,0x69,0x63,0x6a,0x50,0x4b,0x6a,
0x50,0x4b,0x62,0x53,0x32,0x5f,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,
0x3d,0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x34,0x38,0x0d,
0x0a,0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x32,0x0d,0x0a,0x09,0x62,0x61,0x72,
0x20,0x3d,0x20,0x31,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,
0x7b,0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x31,0x31,0x20,
0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x30,0x30,0x30,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x31,0x30,0x38,0x32,0x63,0x30,0x30,0x20,
0x30,0x78,0x32,0x30,0x30,0x30,0x38,0x32,0x31,0x34,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x30,0x61,0x30,0x39,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x31,0x30,0x35,0x65,0x65,0x30,0x30,0x20,
0x30,0x78,0x32,0x31,0x30,0x32,0x66,0x30,0x30,0x38,0x20,0x30,0x78,0x64,0x30,0x30,
0x65,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x34,0x31,0x39,0x20,
0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x30,0x34,0x38,0x31,0x64,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x38,
0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x38,0x34,0x31,0x34,0x37,0x63,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x35,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x63,0x63,0x32,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x30,0x34,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x35,0x20,
0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,
0x30,0x66,0x38,0x30,0x39,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x30,0x30,0x31,0x20,
0x30,0x78,0x38,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,0x30,
0x30,0x36,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x61,0x30,0x30,
0x32,0x62,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x62,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x37,
0x63,0x30,0x39,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x38,0x37,0x64,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x62,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x33,
0x30,0x38,0x30,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x33,0x30,0x38,0x38,0x32,0x39,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x31,0x30,0x30,
0x30,0x66,0x38,0x30,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x30,0x39,0x20,
0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x38,0x30,
0x30,0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x38,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x32,0x37,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,0x30,0x78,0x31,0x30,0x30,
0x30,0x30,0x38,0x30,0x31,0x20,0x30,0x78,0x34,0x34,0x30,0x30,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x62,0x30,0x30,0x32,0x64,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,
0x61,0x30,0x32,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x31,0x36,0x32,0x64,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,
0x61,0x30,0x30,0x32,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x32,0x63,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x33,0x38,0x32,0x30,0x30,0x20,
0x30,0x78,0x32,0x30,0x30,0x62,0x38,0x30,0x32,0x63,0x20,0x30,0x78,0x33,0x30,0x30,
0x32,0x31,0x36,0x32,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,
0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x31,0x30,
0x62,0x65,0x61,0x32,0x63,0x20,0x30,0x78,0x32,0x31,0x30,0x30,0x66,0x30,0x30,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x31,0x36,0x32,0x64,0x20,
0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x30,0x31,0x36,0x32,0x64,0x20,0x30,0x78,0x30,0x34,0x30,0x31,0x38,0x37,0x38,0x30,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x30,0x32,0x64,0x20,
0x30,0x78,0x63,0x30,0x63,0x30,0x30,0x37,0x39,0x63,0x20,0x30,0x78,0x32,0x30,0x30,
0x31,0x39,0x32,0x32,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x61,0x31,0x33,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,0x30,
0x31,0x38,0x36,0x30,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x31,0x38,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,
0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x32,0x30,0x30,
0x31,0x38,0x34,0x30,0x39,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x66,0x66,0x64,0x20,
0x30,0x78,0x36,0x34,0x30,0x31,0x34,0x37,0x64,0x38,0x20,0x30,0x78,0x32,0x30,0x30,
0x38,0x38,0x38,0x32,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x34,0x38,0x32,0x30,0x34,
0x20,0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x65,0x30,0x30,0x33,0x20,
0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,
0x30,0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x31,
0x20,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,
0x6e,0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,
0x31,0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,
0x0a,0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,
0x6d,0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x30,0x30,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,
0x0a,0x7d,0x0d,0x0a,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x6e,0x61,
0x6d,0x65,0x20,0x3d,0x20,0x5f,0x5f,0x67,0x6c,0x6f,0x62,0x66,0x75,0x6e,0x63,0x5f,
0x5f,0x5a,0x31,0x36,0x6b,0x65,0x72,0x6e,0x65,0x6c,0x31,0x5f,0x53,0x53,0x53,0x50,
0x37,0x5f,0x52,0x54,0x6a,0x50,0x6a,0x0d,0x0a,0x09,0x6c,0x6d,0x65,0x6d,0x20,0x3d,
0x20,0x30,0x0d,0x0a,0x09,0x73,0x6d,0x65,0x6d,0x20,0x3d,0x20,0x33,0x32,0x0d,0x0a,
0x09,0x72,0x65,0x67,0x20,0x3d,0x20,0x31,0x34,0x0d,0x0a,0x09,0x62,0x61,0x72,0x20,
0x3d,0x20,0x31,0x0d,0x0a,0x09,0x62,0x69,0x6e,0x63,0x6f,0x64,0x65,0x20,0x20,0x7b,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x32,0x30,0x39,0x20,0x30,
0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,
0x30,0x30,0x31,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x31,0x30,0x34,0x30,0x35,0x20,0x30,
0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x38,0x30,0x35,0x20,0x30,
0x78,0x30,0x34,0x30,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x32,0x30,
0x38,0x30,0x31,0x64,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x32,0x30,0x35,0x20,0x30,
0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x37,
0x38,0x34,0x32,0x30,0x20,0x30,0x78,0x34,0x31,0x30,0x34,0x32,0x63,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x39,0x30,0x32,0x38,0x20,0x30,
0x78,0x32,0x30,0x30,0x30,0x38,0x38,0x30,0x63,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x30,0x36,0x31,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x34,0x38,0x32,0x35,0x20,0x30,
0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x63,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x30,
0x66,0x38,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x38,0x36,0x30,0x30,0x20,0x30,
0x78,0x32,0x31,0x30,0x35,0x65,0x61,0x31,0x38,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x31,0x34,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x34,0x33,0x66,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,0x30,0x32,
0x30,0x32,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x64,0x30,0x30,0x65,0x30,0x63,0x31,0x35,0x20,0x30,
0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x35,
0x62,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x38,0x32,0x64,0x20,0x30,
0x78,0x30,0x34,0x30,0x30,0x38,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x31,0x36,0x32,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x30,0x63,0x30,0x31,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x38,
0x39,0x36,0x32,0x63,0x20,0x30,0x78,0x32,0x30,0x30,0x37,0x38,0x38,0x33,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x37,0x63,0x30,0x31,0x66,0x64,0x20,0x30,
0x78,0x36,0x63,0x30,0x31,0x34,0x37,0x63,0x38,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x31,0x36,0x30,0x39,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x35,0x61,0x30,0x30,0x33,0x20,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x30,0x38,0x32,0x64,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x34,0x30,0x30,0x35,0x30,0x34,0x30,0x31,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,
0x30,0x36,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x31,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x36,0x30,0x30,0x34,
0x30,0x34,0x30,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x20,0x30,
0x78,0x30,0x34,0x30,0x31,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x63,0x61,0x30,0x31,0x20,0x30,
0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x38,0x30,0x63,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x38,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x31,0x36,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x31,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x38,0x30,0x30,
0x63,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x32,0x31,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x33,0x30,0x34,0x30,0x34,0x30,0x31,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x61,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x63,0x30,0x31,0x63,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x37,0x63,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x36,0x63,0x30,0x31,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x32,0x38,0x30,0x31,0x34,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x38,0x30,0x35,0x20,0x30,
0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x34,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x35,
0x33,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x35,0x33,0x30,0x30,0x33,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x31,0x30,0x30,0x20,0x30,0x78,0x36,0x30,0x38,0x30,
0x30,0x34,0x30,0x31,0x20,0x30,0x78,0x36,0x30,0x34,0x31,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x33,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,
0x31,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x35,0x20,0x30,
0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x37,0x63,
0x30,0x35,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x38,0x37,0x64,0x38,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x66,0x38,0x30,0x31,0x20,0x30,
0x78,0x30,0x34,0x30,0x33,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x34,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x33,0x66,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x35,0x33,0x30,0x30,0x33,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,
0x31,0x36,0x30,0x35,0x20,0x30,0x78,0x30,0x34,0x30,0x32,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x64,0x20,0x30,
0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x61,0x30,0x30,0x35,
0x32,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x38,0x30,0x30,0x63,0x30,0x30,0x35,0x20,0x30,
0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x63,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x34,0x30,0x30,0x63,0x30,0x30,0x31,0x20,0x30,
0x78,0x30,0x34,0x32,0x31,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x31,0x31,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x61,0x30,0x30,0x30,0x30,0x31,0x66,0x64,0x20,0x30,
0x78,0x30,0x38,0x32,0x31,0x38,0x37,0x64,0x63,0x20,0x30,0x78,0x61,0x30,0x30,0x34,
0x64,0x30,0x30,0x33,0x20,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x34,0x34,0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x34,
0x64,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x31,0x30,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x30,0x30,0x30,0x30,0x38,0x30,0x31,0x20,0x30,
0x78,0x34,0x34,0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x34,0x30,0x30,0x33,
0x30,0x30,0x33,0x35,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x32,0x33,0x35,0x20,0x30,
0x78,0x30,0x30,0x30,0x33,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x33,0x30,0x31,0x30,
0x31,0x61,0x33,0x35,0x20,0x30,0x78,0x63,0x34,0x31,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x36,0x30,0x30,0x32,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x30,0x30,0x30,0x33,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x32,0x30,0x30,0x30,
0x30,0x36,0x30,0x31,0x20,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x32,0x63,0x30,0x31,0x31,0x20,0x30,
0x78,0x63,0x30,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x33,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x30,0x37,0x38,0x34,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x30,0x64,0x30,0x30,0x31,0x20,0x30,
0x78,0x30,0x34,0x32,0x30,0x30,0x37,0x38,0x34,0x20,0x30,0x78,0x33,0x30,0x30,0x30,
0x30,0x61,0x31,0x35,0x20,0x30,0x78,0x61,0x34,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x31,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x34,0x34,0x30,0x30,0x63,0x37,0x38,0x30,0x20,0x30,0x78,0x66,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x30,0x30,0x31,0x38,0x30,0x30,0x31,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x32,
0x30,0x31,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x34,0x37,0x64,0x38,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x34,0x32,0x30,0x30,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x33,
0x61,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x66,0x30,0x30,0x30,
0x30,0x30,0x30,0x31,0x20,0x30,0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x38,0x36,0x31,0x66,0x66,0x65,0x30,0x33,0x20,0x30,
0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x20,0x30,0x78,0x30,0x30,0x30,0x30,
0x31,0x34,0x30,0x35,0x20,0x30,0x78,0x63,0x30,0x30,0x30,0x30,0x37,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x32,0x35,0x30,0x31,0x65,0x30,0x30,0x35,0x20,0x30,
0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x33,0x20,0x30,0x78,0x33,0x30,0x30,0x39,
0x30,0x33,0x66,0x64,0x20,0x30,0x78,0x36,0x34,0x30,0x30,0x34,0x37,0x64,0x38,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x30,0x34,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x34,0x32,0x30,0x34,0x37,0x38,0x30,0x20,0x30,0x78,0x31,0x30,0x30,0x31,
0x61,0x30,0x30,0x33,0x20,0x30,0x78,0x30,0x30,0x30,0x30,0x31,0x32,0x38,0x30,0x20,
0x0d,0x0a,0x09,0x09,0x30,0x78,0x66,0x30,0x30,0x30,0x30,0x30,0x30,0x31,0x20,0x30,
0x78,0x65,0x30,0x30,0x30,0x30,0x30,0x30,0x32,0x20,0x30,0x78,0x64,0x30,0x30,0x65,
0x30,0x63,0x31,0x35,0x20,0x30,0x78,0x61,0x30,0x63,0x30,0x30,0x37,0x38,0x31,0x20,
0x0d,0x0a,0x09,0x7d,0x0d,0x0a,0x09,0x63,0x6f,0x6e,0x73,0x74,0x20,0x20,0x7b,0x0d,
0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x61,0x6d,0x65,0x20,0x3d,0x20,0x63,0x6f,0x6e,
0x73,0x74,0x0d,0x0a,0x09,0x09,0x73,0x65,0x67,0x6e,0x75,0x6d,0x20,0x3d,0x20,0x31,
0x0d,0x0a,0x09,0x09,0x6f,0x66,0x66,0x73,0x65,0x74,0x20,0x3d,0x20,0x30,0x0d,0x0a,
0x09,0x09,0x62,0x79,0x74,0x65,0x73,0x20,0x3d,0x20,0x34,0x0d,0x0a,0x09,0x09,0x6d,
0x65,0x6d,0x20,0x20,0x7b,0x0d,0x0a,0x09,0x09,0x09,0x30,0x78,0x30,0x30,0x30,0x30,
0x30,0x30,0x30,0x33,0x20,0x0d,0x0a,0x09,0x09,0x7d,0x0d,0x0a,0x09,0x7d,0x0d,0x0a,
0x7d,0x0d,0x0a,0x00
};


}
#line 761 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.fatbin.c"

static __cudaFatPtxEntry   __ptxEntries  [] = {{0,0}};
static __cudaFatCubinEntry __cubinEntries[] = {{(char*)"sm_11",(char*)__deviceText},{0,0}};
static __cudaFatDebugEntry __debugEntries[] = {{0,0}};
#pragma data_seg(".nvFatBinSegment")
#pragma data_seg()

__declspec(allocate(".nvFatBinSegment")) static __cudaFatCudaBinary __fatDeviceText= {0x1ee55a01,0x00000002,0x8ecc680c,(char*)"63374b3d93aa6cce",(char*)"template.cu",(char*)"",__ptxEntries,__cubinEntries,__debugEntries,0,0};

#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 1 "C:\\CUDA\\include\\crt/host_runtime.h"







































































#line 73 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 1 "C:\\CUDA\\include\\host_defines.h"























































































































#line 121 "C:\\CUDA\\include\\host_defines.h"
#line 75 "C:\\CUDA\\include\\crt/host_runtime.h"





















extern "C" {
#line 98 "C:\\CUDA\\include\\crt/host_runtime.h"

extern void** __stdcall __cudaRegisterFatBinary(
  void *fatCubin
);

extern void __stdcall __cudaUnregisterFatBinary(
  void **fatCubinHandle
);

extern void __stdcall __cudaRegisterVar(
        void **fatCubinHandle,
        char  *hostVar,
        char  *deviceAddress,
  const char  *deviceName,
        int    ext,
        int    size,
        int    constant,
        int    global
);

extern void __stdcall __cudaRegisterTexture(
        void                    **fatCubinHandle,
  const struct textureReference  *hostVar,
  const void                    **deviceAddress,
  const char                     *deviceName,
        int                       dim,       
        int                       norm,      
        int                       ext        
);

extern void __stdcall __cudaRegisterShared(
  void **fatCubinHandle,
  void **devicePtr
);

extern void __stdcall __cudaRegisterSharedVar(
  void   **fatCubinHandle,
  void   **devicePtr,
  size_t   size,
  size_t   alignment,
  int      storage
);

extern void __stdcall __cudaRegisterFunction(
        void   **fatCubinHandle,
  const char    *hostFun,
        char    *deviceFun,
  const char    *deviceName,
        int      thread_limit,
        uint3   *tid,
        uint3   *bid,
        dim3    *bDim,
        dim3    *gDim,
        int     *wSize
);


}
#line 157 "C:\\CUDA\\include\\crt/host_runtime.h"

static void **__cudaFatCubinHandle;

static void __cudaUnregisterBinaryUtil(void)
{
  __cudaUnregisterFatBinary(__cudaFatCubinHandle);
}








#line 173 "C:\\CUDA\\include\\crt/host_runtime.h"





#line 179 "C:\\CUDA\\include\\crt/host_runtime.h"

#pragma section(".CRT$XPU")

#line 183 "C:\\CUDA\\include\\crt/host_runtime.h"

__declspec(allocate(".CRT$XPU"))
static void (__cdecl *__cudaUnregister[])(void) = {__cudaUnregisterBinaryUtil};

#line 188 "C:\\CUDA\\include\\crt/host_runtime.h"
























#line 213 "C:\\CUDA\\include\\crt/host_runtime.h"












#line 1 "C:\\CUDA\\include\\common_functions.h"

































































#line 67 "C:\\CUDA\\include\\common_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"













































#line 47 "c:\\cuda\\include\\crt/func_macro.h"





#line 53 "c:\\cuda\\include\\crt/func_macro.h"






#line 60 "c:\\cuda\\include\\crt/func_macro.h"




#line 65 "c:\\cuda\\include\\crt/func_macro.h"




#line 70 "c:\\cuda\\include\\crt/func_macro.h"




#line 75 "c:\\cuda\\include\\crt/func_macro.h"

#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 69 "C:\\CUDA\\include\\common_functions.h"

static clock_t __cuda_clock(void)
{
  return clock();
}

static void *__cuda_memset(void *s, int c, size_t n)
{
  return memset(s, c, n);
}

static void *__cuda_memcpy(void *d, const void *s, size_t n)
{
  return memcpy(d, s, n);
}

#line 86 "C:\\CUDA\\include\\common_functions.h"







#line 1 "c:\\cuda\\include\\math_functions.h"

















































































































































































































































































































































































































































































































































































































































































































































































































































#line 819 "c:\\cuda\\include\\math_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 821 "c:\\cuda\\include\\math_functions.h"



























#line 849 "c:\\cuda\\include\\math_functions.h"





static double log2(double a)
{
  return log(a) / log(2.0);
}

static float log2f(float a)
{
  return (float)log2((double)a);
}

static double exp2(double a)
{
  return pow(2.0, a);
}

static float exp2f(float a)
{
  return (float)exp2((double)a);
}

static long long int llabs(long long int a)
{
  return a < 0ll ? -a : a;
}

#line 880 "c:\\cuda\\include\\math_functions.h"

#line 882 "c:\\cuda\\include\\math_functions.h"

static int __cuda_abs(int a)
{
  return abs(a);
}

static float __cuda_fabsf(float a)
{
  return fabsf(a);
}

static long long int __cuda_llabs(long long int a)
{

  return ::llabs(a);


#line 900 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_exp2f(float a)
{
  return exp2f(a);
}

#line 1 "c:\\cuda\\include\\device_functions.h"





















































































































































































































































































































































#line 343 "c:\\cuda\\include\\device_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 345 "c:\\cuda\\include\\device_functions.h"

#line 1 "c:\\cuda\\include\\host_defines.h"























































































































#line 121 "c:\\cuda\\include\\host_defines.h"
#line 347 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\math_constants.h"
















































































#line 82 "c:\\cuda\\include\\math_constants.h"






#line 89 "c:\\cuda\\include\\math_constants.h"

















































#line 139 "c:\\cuda\\include\\math_constants.h"
#line 348 "c:\\cuda\\include\\device_functions.h"



static int __cuda___isnan(double a);
static int __cuda___isnanf(float a);
static int __double2int_rz(double);
static unsigned int __double2uint_rz(double);
static long long int __double2ll_rz(double);
static unsigned long long int __double2ull_rz(double);













static int __mulhi(int a, int b)
{
  long long int c = (long long int)a * (long long int)b;

  return (int)(c >> 32);
}

static unsigned int __umulhi(unsigned int a, unsigned int b)
{
  unsigned long long int c = (unsigned long long int)a * (unsigned long long int)b;

  return (unsigned int)(c >> 32);
}

static unsigned long long int __umul64hi(unsigned long long int a, unsigned long long int b)
{
  unsigned int           a_lo = (unsigned int)a;
  unsigned long long int a_hi = a >> 32;
  unsigned int           b_lo = (unsigned int)b;
  unsigned long long int b_hi = b >> 32;
  unsigned long long int m1 = a_lo * b_hi;
  unsigned long long int m2 = a_hi * b_lo;
  unsigned int           carry;

  carry = (0ULL + __umulhi(a_lo, b_lo) + (unsigned int)m1 + (unsigned int)m2) >> 32;

  return a_hi * b_hi + (m1 >> 32) + (m2 >> 32) + carry;
}

static long long int __mul64hi(long long int a, long long int b)
{
  long long int res;
  res = __umul64hi(a, b);
  if (a < 0LL) res = res - b;
  if (b < 0LL) res = res - a;
  return res;
}

static float __saturatef(float a)
{
  return a >= 1.0f ? 1.0f : a <= 0.0f ? 0.0f : a;
}

static unsigned int __sad(int a, int b, unsigned int c)
{
  long long int diff = (long long int)a - (long long int)b;

  return (unsigned int)(__cuda_llabs(diff) + (long long int)c);
}

static unsigned int __usad(unsigned int a, unsigned int b, unsigned int c)
{
  long long int diff = (long long int)a - (long long int)b;

  return (unsigned int)(__cuda_llabs(diff) + (long long int)c);
}

static int __mul24(int a, int b)
{

  a &= 0xffffff;
  a = (a & 0x800000) != 0 ? a | ~0xffffff : a;
  b &= 0xffffff;
  b = (b & 0x800000) != 0 ? b | ~0xffffff : b;
#line 435 "c:\\cuda\\include\\device_functions.h"

  return a * b;
}

static unsigned int __umul24(unsigned int a, unsigned int b)
{

  a &= 0xffffff;
  b &= 0xffffff;
#line 445 "c:\\cuda\\include\\device_functions.h"

  return a * b;
}

static float __int_as_float(int a)
{
  volatile union {int a; float b;} u;

  u.a = a;

  return u.b;
}

static int __float_as_int(float a)
{
  volatile union {float a; int b;} u;

  u.a = a;

  return u.b;
}

static long long int __internal_float2ll_kernel(float a, long long int max, long long int min, long long int nan, enum cudaRoundMode rndMode)
{
  unsigned long long int res, t = 0ULL;
  int shift;
  unsigned int ia;

  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= min) return min;
  ia = __float_as_int(a);
  shift = 189 - ((ia >> 23) & 0xff);
  res = (unsigned long long int)(((ia << 8) | 0x80000000) >> 1) << 32;
  if (shift >= 64) {
    t = res;
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (rndMode == cudaRoundNearest && (long long int)t < 0LL) {
    res += t == 0x8000000000000000ULL ? res & 1ULL : 1ULL;
  }
  else if (rndMode == cudaRoundMinInf && t != 0ULL && ia > 0x80000000) {
    res++;
  }
  else if (rndMode == cudaRoundPosInf && t != 0ULL && (int)ia > 0) {
    res++;
  }
  if ((int)ia < 0) res = (unsigned long long int)-(long long int)res;
  return (long long int)res;
}

static int __internal_float2int(float a, enum cudaRoundMode rndMode)
{
  return (int)__internal_float2ll_kernel(a, 2147483647LL, -2147483648LL, 0LL, rndMode);
}

static int __float2int_rz(float a)
{


#line 507 "c:\\cuda\\include\\device_functions.h"
  return __internal_float2int(a, cudaRoundZero);
#line 509 "c:\\cuda\\include\\device_functions.h"
}

static int __float2int_ru(float a)
{
  return __internal_float2int(a, cudaRoundPosInf);
}

static int __float2int_rd(float a)
{
  return __internal_float2int(a, cudaRoundMinInf);
}

static int __float2int_rn(float a)
{
  return __internal_float2int(a, cudaRoundNearest);
}

static long long int __internal_float2ll(float a, enum cudaRoundMode rndMode)
{
  return __internal_float2ll_kernel(a, 9223372036854775807LL, -9223372036854775807LL -1LL, -9223372036854775807LL -1LL, rndMode);
}

static long long int __float2ll_rz(float a)
{


#line 536 "c:\\cuda\\include\\device_functions.h"
  return __internal_float2ll(a, cudaRoundZero);
#line 538 "c:\\cuda\\include\\device_functions.h"
}

static long long int __float2ll_ru(float a)
{
  return __internal_float2ll(a, cudaRoundPosInf);
}

static long long int __float2ll_rd(float a)
{
  return __internal_float2ll(a, cudaRoundMinInf);
}

static long long int __float2ll_rn(float a)
{
  return __internal_float2ll(a, cudaRoundNearest);
}

static unsigned long long int __internal_float2ull_kernel(float a, unsigned long long int max, unsigned long long int nan, enum cudaRoundMode rndMode)
{
  unsigned long long int res, t = 0ULL;
  int shift;
  unsigned int ia;

  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= 0LL) return 0LL;
  ia = __float_as_int(a);
  shift = 190 - ((ia >> 23) & 0xff);
  res = (unsigned long long int)((ia << 8) | 0x80000000) << 32;
  if (shift >= 64) {
    t = res >> (int)(shift > 64);
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (rndMode == cudaRoundNearest && (long long int)t < 0LL) {
    res += t == 0x8000000000000000ULL ? res & 1ULL : 1ULL;
  }
  else if (rndMode == cudaRoundPosInf && t != 0ULL) {
    res++;
  }
  return res;
}

static unsigned int __internal_float2uint(float a, enum cudaRoundMode rndMode)
{
  return (unsigned int)__internal_float2ull_kernel(a, 4294967295U, 0U, rndMode);
}

static unsigned int __float2uint_rz(float a)
{


#line 591 "c:\\cuda\\include\\device_functions.h"
  return __internal_float2uint(a, cudaRoundZero);
#line 593 "c:\\cuda\\include\\device_functions.h"
}

static unsigned int __float2uint_ru(float a)
{
  return __internal_float2uint(a, cudaRoundPosInf);
}

static unsigned int __float2uint_rd(float a)
{
  return __internal_float2uint(a, cudaRoundMinInf);
}

static unsigned int __float2uint_rn(float a)
{
  return __internal_float2uint(a, cudaRoundNearest);
}

static unsigned long long int __internal_float2ull(float a, enum cudaRoundMode rndMode)
{
  return __internal_float2ull_kernel(a, 18446744073709551615ULL, 9223372036854775808ULL, rndMode);
}

static unsigned long long int __float2ull_rz(float a)
{


#line 620 "c:\\cuda\\include\\device_functions.h"
  return __internal_float2ull(a, cudaRoundZero);
#line 622 "c:\\cuda\\include\\device_functions.h"
}

static unsigned long long int __float2ull_ru(float a)
{
  return __internal_float2ull(a, cudaRoundPosInf);
}

static unsigned long long int __float2ull_rd(float a)
{
  return __internal_float2ull(a, cudaRoundMinInf);
}

static unsigned long long int __float2ull_rn(float a)
{
  return __internal_float2ull(a, cudaRoundNearest);
}

static int __internal_normalize64(unsigned long long int *a)
{
  int lz = 0;

  if ((*a & 0xffffffff00000000ULL) == 0ULL) {
    *a <<= 32;
    lz += 32;
  }
  if ((*a & 0xffff000000000000ULL) == 0ULL) {
    *a <<= 16;
    lz += 16;
  }
  if ((*a & 0xff00000000000000ULL) == 0ULL) {
    *a <<= 8;
    lz += 8;
  }
  if ((*a & 0xf000000000000000ULL) == 0ULL) {
    *a <<= 4;
    lz += 4;
  }
  if ((*a & 0xC000000000000000ULL) == 0ULL) {
    *a <<= 2;
    lz += 2;
  }
  if ((*a & 0x8000000000000000ULL) == 0ULL) {
    *a <<= 1;
    lz += 1;
  }
  return lz;
}

static int __internal_normalize(unsigned int *a)
{
  unsigned long long int t = (unsigned long long int)*a;
  int lz = __internal_normalize64(&t);
  
  *a = (unsigned int)(t >> 32);

  return lz - 32;
}

static float __internal_int2float_kernel(int a, enum cudaRoundMode rndMode)
{
  volatile union {
    float f;
    unsigned int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.f;
  if (a < 0) res.i = (unsigned int)-a;
  shift = __internal_normalize((unsigned int*)&res.i);
  t = res.i << 24;
  res.i = (res.i >> 8);
  res.i += (127 + 30 - shift) << 23;
  if (a < 0) res.i |= 0x80000000;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : (t >> 31);
  }
  else if ((rndMode == cudaRoundMinInf) && t && (a < 0)) {
    res.i++;
  }
  else if ((rndMode == cudaRoundPosInf) && t && (a > 0)) {
    res.i++;
  }
  return res.f;
}

static float __int2float_rz(int a)
{
  return __internal_int2float_kernel(a, cudaRoundZero);
}

static float __int2float_ru(int a)
{
  return __internal_int2float_kernel(a, cudaRoundPosInf);
}

static float __int2float_rd(int a)
{
  return __internal_int2float_kernel(a, cudaRoundMinInf);
}

static float __int2float_rn(int a)
{


#line 728 "c:\\cuda\\include\\device_functions.h"
  return __internal_int2float_kernel(a, cudaRoundNearest);
#line 730 "c:\\cuda\\include\\device_functions.h"
}

static float __internal_uint2float_kernel(unsigned int a, enum cudaRoundMode rndMode)
{
  volatile union {
    float f;
    unsigned int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.f;
  shift = __internal_normalize((unsigned int*)&res.i);
  t = res.i << 24;
  res.i = (res.i >> 8);
  res.i += (127 + 30 - shift) << 23;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : (t >> 31);
  }
  else if ((rndMode == cudaRoundPosInf) && t) {
    res.i++;
  }
  return res.f;
}

static float __uint2float_rz(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundZero);
}

static float __uint2float_ru(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundPosInf);
}

static float __uint2float_rd(unsigned int a)
{
  return __internal_uint2float_kernel(a, cudaRoundMinInf);
}

static float __uint2float_rn(unsigned int a)
{


#line 775 "c:\\cuda\\include\\device_functions.h"
  return __internal_uint2float_kernel(a, cudaRoundNearest);
#line 777 "c:\\cuda\\include\\device_functions.h"
}

static float __ll2float_rn(long long int a)
{
  return (float)a;
}      

static float __ull2float_rn(unsigned long long int a)
{


#line 789 "c:\\cuda\\include\\device_functions.h"
  unsigned long long int temp;
  unsigned int res, t;
  int shift;
  if (a == 0ULL) return 0.0f;
  temp = a;
  shift = __internal_normalize64(&temp);
  temp = (temp >> 8) | ((temp & 0xffULL) ? 1ULL : 0ULL);
  res = (unsigned int)(temp >> 32);
  t = (unsigned int)temp;
  res += (127 + 62 - shift) << 23; 
  res += t == 0x80000000 ? res & 1 : t >> 31;
  return __int_as_float(res);
#line 802 "c:\\cuda\\include\\device_functions.h"
}      

static float __internal_fmul_kernel(float a, float b, int rndNearest)
{
  unsigned long long product;
  volatile union {
    float f;
    unsigned int i;
  } xx, yy;
  unsigned expo_x, expo_y;
    
  xx.f = a;
  yy.f = b;

  expo_y = 0xFF;
  expo_x = expo_y & (xx.i >> 23);
  expo_x = expo_x - 1;
  expo_y = expo_y & (yy.i >> 23);
  expo_y = expo_y - 1;
    
  if ((expo_x <= 0xFD) && 
      (expo_y <= 0xFD)) {
multiply:
    expo_x = expo_x + expo_y;
    expo_y = xx.i ^ yy.i;
    xx.i = xx.i & 0x00ffffff;
    yy.i = yy.i << 8;
    xx.i = xx.i | 0x00800000;
    yy.i = yy.i | 0x80000000;
    
    product = ((unsigned long long)xx.i) * yy.i;
    expo_x = expo_x - 127 + 2;
    expo_y = expo_y & 0x80000000;
    xx.i = (unsigned int)(product >> 32);
    yy.i = (unsigned int)(product & 0xffffffff);
    
    if (xx.i < 0x00800000) {
      xx.i = (xx.i << 1) | (yy.i >> 31);
      yy.i = (yy.i << 1);
      expo_x--;
    }
    if (expo_x <= 0xFD) {
      xx.i = xx.i | expo_y;          
      xx.i = xx.i + (expo_x << 23);  
      
      if (yy.i < 0x80000000) return xx.f;
      xx.i += (((yy.i == 0x80000000) ? (xx.i & 1) : (yy.i >> 31)) 
               && rndNearest);
      return xx.f;
    } else if ((int)expo_x >= 254) {
      
      xx.i = (expo_y | 0x7F800000) - (!rndNearest);
      return xx.f;
    } else {
      
      expo_x = ((unsigned int)-((int)expo_x));
      if (expo_x > 25) {
        
        xx.i = expo_y;
        return xx.f;
      } else {
        yy.i = (xx.i << (32 - expo_x)) | ((yy.i) ? 1 : 0);
        xx.i = expo_y + (xx.i >> expo_x);
        xx.i += (((yy.i == 0x80000000) ? (xx.i & 1) : (yy.i >> 31)) 
                 && rndNearest);
        return xx.f;
      }
    }
  } else {
    product = xx.i ^ yy.i;
    product = product & 0x80000000;
    if (!(xx.i & 0x7fffffff)) {
      if (expo_y != 254) {
        xx.i = (unsigned int)product;
        return xx.f;
      }
      expo_y = yy.i << 1;
      if (expo_y == 0xFF000000) {
        xx.i = expo_y | 0x00C00000;
      } else {
        xx.i = yy.i | 0x00400000;
      }
      return xx.f;
    }
    if (!(yy.i & 0x7fffffff)) {
      if (expo_x != 254) {
        xx.i = (unsigned int)product;
        return xx.f;
      }
      expo_x = xx.i << 1;
      if (expo_x == 0xFF000000) {
        xx.i = expo_x | 0x00C00000;
      } else {
        xx.i = xx.i | 0x00400000;
      }
      return xx.f;
    }
    if ((expo_y != 254) && (expo_x != 254)) {
      expo_y++;
      expo_x++;
      if (expo_x == 0) {
        expo_y |= xx.i & 0x80000000;
        



        xx.i = xx.i << 8;
        while (!(xx.i & 0x80000000)) {
          xx.i <<= 1;
          expo_x--;
        }
        xx.i = (xx.i >> 8) | (expo_y & 0x80000000);
        expo_y &= ~0x80000000;
        expo_y--;
        goto multiply;
      }
      if (expo_y == 0) {
        expo_x |= yy.i & 0x80000000;
        yy.i = yy.i << 8;
        while (!(yy.i & 0x80000000)) {
          yy.i <<= 1;
          expo_y--;
        }
        yy.i = (yy.i >> 8) | (expo_x & 0x80000000);
        expo_x &= ~0x80000000;
        expo_x--;
        goto multiply;
      }
    }
    expo_x = xx.i << 1;
    expo_y = yy.i << 1;
    
    if (expo_x > 0xFF000000) {
      
      xx.i = xx.i | 0x00400000;
      return xx.f;
    }
    
    if (expo_y > 0xFF000000) {
      
      xx.i = yy.i | 0x00400000;
      return xx.f;
    } 
    xx.i = (unsigned int)product | 0x7f800000;
    return xx.f;
  }
}

static float __internal_fadd_kernel(float a, float b, int rndNearest)
{
  volatile union {
    float f;
    unsigned int i;
  } xx, yy;
  unsigned int expo_x;
  unsigned int expo_y;
  unsigned int temp;

  xx.f = a;
  yy.f = b;

  
  expo_y = yy.i << 1;
  if (expo_y > (xx.i << 1)) {
    expo_y = xx.i;
    xx.i   = yy.i;
    yy.i   = expo_y;
  }
    
  temp = 0xff;
  expo_x = temp & (xx.i >> 23);
  expo_x = expo_x - 1;
  expo_y = temp & (yy.i >> 23);
  expo_y = expo_y - 1;
    
  if ((expo_x <= 0xFD) && 
      (expo_y <= 0xFD)) {
        
add:
    expo_y = expo_x - expo_y;
    if (expo_y > 25) {
      expo_y = 31;
    }
    temp = xx.i ^ yy.i;
    xx.i = xx.i & ~0x7f000000;
    xx.i = xx.i |  0x00800000;
    yy.i = yy.i & ~0xff000000;
    yy.i = yy.i |  0x00800000;
        
    if ((int)temp < 0) {
      
      temp = 32 - expo_y;
      temp = (expo_y) ? (yy.i << temp) : 0;
      temp = (unsigned int)(-((int)temp));
      xx.i = xx.i - (yy.i >> expo_y) - (temp ? 1 : 0);
      if (xx.i & 0x00800000) {
        if (expo_x <= 0xFD) {
          xx.i = xx.i & ~0x00800000; 
          xx.i = (xx.i + (expo_x << 23)) + 0x00800000;
          if (temp < 0x80000000) return xx.f;
          xx.i += (((temp == 0x80000000) ? (xx.i & 1) : (temp >> 31))
                   && rndNearest);
          return xx.f;
        }
      } else {
        if ((temp | (xx.i << 1)) == 0) {
          
          xx.i = 0;
          return xx.f;
        }
        
        yy.i = xx.i & 0x80000000;
        do {
          xx.i = (xx.i << 1) | (temp >> 31);
          temp <<= 1;
          expo_x--;
        } while (!(xx.i & 0x00800000));
        xx.i = xx.i | yy.i;
      }
    } else {
      
      temp = 32 - expo_y;
      temp = (expo_y) ? (yy.i << temp) : 0;
      xx.i = xx.i + (yy.i >> expo_y);
      if (!(xx.i & 0x01000000)) {
        if (expo_x <= 0xFD) {
          expo_y = xx.i & 1;
          xx.i = xx.i + (expo_x << 23);
          if (temp < 0x80000000) return xx.f;
          xx.i += (((temp == 0x80000000) ? expo_y : (temp >> 31)) 
                   && rndNearest);
          return xx.f;
        }
      } else {
        
        temp = (xx.i << 31) | (temp >> 1);
        
        xx.i = ((xx.i & 0x80000000) | (xx.i >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
    if (expo_x <= 0xFD) {
      expo_y = xx.i & 1;
      xx.i += (((temp == 0x80000000) ? expo_y : (temp >> 31)) 
               && rndNearest);
      xx.i = xx.i + (expo_x << 23);
      return xx.f;
    }
    if ((int)expo_x >= 254) {
      
        xx.i = ((xx.i & 0x80000000) | 0x7f800000) - (!rndNearest);
        return xx.f;
    }
    
    expo_y = expo_x + 32;
    yy.i = xx.i &  0x80000000;
    xx.i = xx.i & ~0xff000000;
        
    expo_x = (unsigned int)(-((int)expo_x));
    temp = xx.i << expo_y | ((temp) ? 1 : 0);
    xx.i = yy.i | (xx.i >> expo_x);
    xx.i += (((temp == 0x80000000) ? (xx.i & 1) : (temp >> 31)) 
             && rndNearest);
    return xx.f;
  } else {
    
    if (!(yy.i << 1)) {
      if (xx.i == 0x80000000) {
        xx.i = yy.i;
      }
      return xx.f;
    }
    if ((expo_y != 254) && (expo_x != 254)) {
      
      if (expo_x == (unsigned int) -1) {
        temp = xx.i & 0x80000000;
        xx.i = xx.i << 8;
        while (!(xx.i & 0x80000000)) {
          xx.i <<= 1;
          expo_x--;
        }
        expo_x++;
        xx.i = (xx.i >> 8) | temp;
      }
      if (expo_y == (unsigned int) -1) {
        temp = yy.i & 0x80000000;
        yy.i = yy.i << 8;
        while (!(yy.i & 0x80000000)) {
          yy.i <<= 1;
          expo_y--;
        }
        expo_y++;
        yy.i = (yy.i >> 8) | temp;
      }
      goto add;
    }
    expo_x = xx.i << 1;
    expo_y = yy.i << 1;
    
    if (expo_x > 0xff000000) {
      
      xx.i = xx.i | 0x00400000;
      return xx.f;
    }
    
    if (expo_y > 0xff000000) {
      
      xx.i = yy.i | 0x00400000;
      return xx.f;
    }
    if ((expo_x == 0xff000000) && (expo_y == 0xff000000)) {
      



      expo_x = xx.i ^ yy.i;
      xx.i = xx.i | ((expo_x) ? 0xffc00000 : 0);
      return xx.f;
    }
    
    if (expo_y == 0xff000000) {
      xx.i = yy.i;
    }
    return xx.f;
  }
}

static float __fadd_rz(float a, float b)
{
  return __internal_fadd_kernel(a, b, 0);
}

static float __fmul_rz(float a, float b)
{
  return __internal_fmul_kernel(a, b, 0);
}

static float __fadd_rn(float a, float b)
{
  return __internal_fadd_kernel(a, b, 1);
}

static float __fmul_rn(float a, float b)
{
  return __internal_fmul_kernel(a, b, 1);
}

static void __brkpt(int c)
{
  
}











#line 1165 "c:\\cuda\\include\\device_functions.h"

extern int __stdcall __cudaSynchronizeThreads(void**, void*);









#line 1177 "c:\\cuda\\include\\device_functions.h"




#line 1182 "c:\\cuda\\include\\device_functions.h"

#line 1184 "c:\\cuda\\include\\device_functions.h"








#line 1193 "c:\\cuda\\include\\device_functions.h"

static void __trap(void)
{
  __debugbreak();
}

#line 1200 "c:\\cuda\\include\\device_functions.h"

#line 1202 "c:\\cuda\\include\\device_functions.h"







static float __fdividef(float a, float b)
{


#line 1214 "c:\\cuda\\include\\device_functions.h"

#line 1216 "c:\\cuda\\include\\device_functions.h"
  
  if (__cuda_fabsf(b) > 8.507059173e37f) {
    if (__cuda_fabsf(a) <= 3.402823466e38f) {
      return ((a / b) / 3.402823466e38f) / 3.402823466e38f;
    } else {
      return __int_as_float(0x7fffffff);
    }
  } else {
    return a / b;
  }
#line 1227 "c:\\cuda\\include\\device_functions.h"
}

static float __sinf(float a)
{
  return sinf(a);
}

static float __cosf(float a)
{
  return cosf(a);
}

static float __log2f(float a)
{
  return log2f(a);
}







static float __internal_accurate_fdividef(float a, float b)
{
  if (__cuda_fabsf(b) > 8.507059173e37f) {
    a *= .25f;
    b *= .25f;
  }
  return __fdividef(a, b);
}

static float __tanf(float a)
{


#line 1264 "c:\\cuda\\include\\device_functions.h"
  return __sinf(a) / __cosf(a);
#line 1266 "c:\\cuda\\include\\device_functions.h"
}

static void __sincosf(float a, float *sptr, float *cptr)
{


#line 1273 "c:\\cuda\\include\\device_functions.h"
  *sptr = __sinf(a);
  *cptr = __cosf(a);
#line 1276 "c:\\cuda\\include\\device_functions.h"
}

static float __expf(float a)
{


#line 1283 "c:\\cuda\\include\\device_functions.h"
  return __cuda_exp2f(a * 1.442695041f);
#line 1285 "c:\\cuda\\include\\device_functions.h"
}

static float __exp10f(float a)
{


#line 1292 "c:\\cuda\\include\\device_functions.h"
  return __cuda_exp2f(a * 3.321928094f);
#line 1294 "c:\\cuda\\include\\device_functions.h"
}

static float __log10f(float a)
{


#line 1301 "c:\\cuda\\include\\device_functions.h"
  return 0.301029996f * __log2f(a);
#line 1303 "c:\\cuda\\include\\device_functions.h"
}

static float __logf(float a)
{


#line 1310 "c:\\cuda\\include\\device_functions.h"
  return 0.693147181f * __log2f(a);
#line 1312 "c:\\cuda\\include\\device_functions.h"
}

static float __powf(float a, float b)
{


#line 1319 "c:\\cuda\\include\\device_functions.h"
  return __cuda_exp2f(b * __log2f(a));
#line 1321 "c:\\cuda\\include\\device_functions.h"
}

static float fdividef(float a, float b)
{


#line 1328 "c:\\cuda\\include\\device_functions.h"

#line 1330 "c:\\cuda\\include\\device_functions.h"
  return __internal_accurate_fdividef(a, b);
#line 1332 "c:\\cuda\\include\\device_functions.h"
}

static int __clz(int a)
{
  return (a)?(158-(__float_as_int(__uint2float_rz((unsigned int)a))>>23)):32;
}

static int __ffs(int a)
{
  return 32 - __clz (a & -a);
}

static int __popc(unsigned int a)
{
  unsigned int s = 033333333333;
  unsigned int t = 030707070707;
  unsigned int n;
  n = (a >> 1) & s;
  a = a - n;
  n = (n >> 1) & s;
  a = a - n;
  n = (a >> 3) + a;
  a = n & t;
  t = (t << 2) & t;  
  a = (a >> 30) + ((a * t) >> 26);
  return a;
}

static int __clzll(long long int a)
{
  int ahi = ((int)(a >> 32));
  int alo = ((int)(a & 0xffffffffULL));
  int res;
  if (ahi) {
      res = 0;
  } else {
      res = 32;
      ahi = alo;
  }
  res = res + __clz(ahi);
  return res;
}

static int __ffsll(long long int a)
{
  return 64 - __clzll (a & -a);
}

static int __popcll(unsigned long long int a)
{
  unsigned int ahi = ((unsigned int)(a >> 32));
  unsigned int alo = ((unsigned int)(a & 0xffffffffULL));
  return __popc(ahi) + __popc(alo);
}





#line 1392 "c:\\cuda\\include\\device_functions.h"



static double fdivide(double a, double b)
{
  return (double)fdividef((float)a, (float)b);
}



static int __double2int_rz(double a)
{
  return __float2int_rz((float)a);
}

static unsigned int __double2uint_rz(double a)
{
  return __float2uint_rz((float)a);
}

static long long int __double2ll_rz(double a)
{
  return __float2ll_rz((float)a);
}

static unsigned long long int __double2ull_rz(double a)
{
  return __float2ull_rz((float)a);
}

#line 1423 "c:\\cuda\\include\\device_functions.h"

#line 1425 "c:\\cuda\\include\\device_functions.h"





































#line 1463 "c:\\cuda\\include\\device_functions.h"

#line 1465 "c:\\cuda\\include\\device_functions.h"







#line 1 "c:\\cuda\\include\\sm_11_atomic_functions.h"















































































































































































































#line 209 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 211 "c:\\cuda\\include\\sm_11_atomic_functions.h"



static int __iAtomicAdd(int *address, int val)
{
  int old = *address;

  *address = old + val;

  return old;
}

static unsigned int __uAtomicAdd(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old + val;

  return old;
}

static int __iAtomicExch(int *address, int val)
{
  int old = *address;

  *address = val;

  return old;
}

static unsigned int __uAtomicExch(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = val;

  return old;
}

static float __fAtomicExch(float *address, float val)
{
  float old = *address;

  *address = val;

  return old;
}

static int __iAtomicMin(int *address, int val)
{
  int old = *address;

  *address = old < val ? old : val;

  return old;
}

static unsigned int __uAtomicMin(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old < val ? old : val;

  return old;
}

static int __iAtomicMax(int *address, int val)
{
  int old = *address;

  *address = old > val ? old : val;

  return old;
}

static unsigned int __uAtomicMax(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old > val ? old : val;

  return old;
}

static unsigned int __uAtomicInc(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = (old >= val) ? 0 : old + 1;

  return old;
}

static unsigned int __uAtomicDec(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = ((old == 0) | (old > val)) ? val : (old - 1);

  return old;
}

static int __iAtomicAnd(int *address, int val)
{
  int old = *address;

  *address = old & val;

  return old;
}

static unsigned int __uAtomicAnd(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old & val;

  return old;
}

static int __iAtomicOr(int *address, int val)
{
  int old = *address;

  *address = old | val;

  return old;
}

static unsigned int __uAtomicOr(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old | val;

  return old;
}

static int __iAtomicXor(int *address, int val)
{
  int old = *address;

  *address = old ^ val;

  return old;
}

static unsigned int __uAtomicXor(unsigned int *address, unsigned int val)
{
  unsigned int old = *address;

  *address = old ^ val;

  return old;
}

static int __iAtomicCAS(int *address, int compare, int val)
{
  int old = *address;

  *address = old == compare ? val : old;

  return old;
}

static unsigned int __uAtomicCAS(unsigned int *address, unsigned int compare, unsigned int val)
{
  unsigned int old = *address;

  *address = old == compare ? val : old;

  return old;
}

#line 386 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 388 "c:\\cuda\\include\\sm_11_atomic_functions.h"

#line 390 "c:\\cuda\\include\\sm_11_atomic_functions.h"
#line 1473 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\sm_12_atomic_functions.h"




































































































#line 102 "c:\\cuda\\include\\sm_12_atomic_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 104 "c:\\cuda\\include\\sm_12_atomic_functions.h"



static unsigned long long int __ullAtomicAdd(unsigned long long int *address, unsigned long long int val)
{
  unsigned long long int old = *address;

  *address = old + val;

  return old;
}

static unsigned long long int __ullAtomicExch(unsigned long long int *address, unsigned long long int val)
{
  unsigned long long int old = *address;

  *address = val;

  return old;
}

static unsigned long long int __ullAtomicCAS(unsigned long long int *address, unsigned long long int compare, unsigned long long int val)
{
  unsigned long long int old = *address;

  *address = old == compare ? val : old;

  return old;
}

static int __any(int cond)
{
  return cond;
}

static int __all(int cond)
{
  return cond;
}

#line 145 "c:\\cuda\\include\\sm_12_atomic_functions.h"

#line 147 "c:\\cuda\\include\\sm_12_atomic_functions.h"

#line 149 "c:\\cuda\\include\\sm_12_atomic_functions.h"
#line 1474 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\sm_13_double_functions.h"





























































































































































































































































#line 255 "c:\\cuda\\include\\sm_13_double_functions.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 257 "c:\\cuda\\include\\sm_13_double_functions.h"









static double __longlong_as_double(long long int a)
{
  volatile union {long long int a; double b;} u;

  u.a = a;

  return u.b;
}

static long long int __double_as_longlong(double a)
{
  volatile union {double a; long long int b;} u;
  
  u.a = a;

  return u.b;
}

static float __internal_double2float_kernel(double a)
{
  volatile union {
    double d;
    unsigned long long int i;
  } xx;
  volatile union {
    float f;
    unsigned int i;
  } res;
  int shift;
  xx.d = a;
  if (xx.i == 0) return 0.0f;
  res.i = (((unsigned int) (xx.i >> 32)) & 0x80000000);
  if ((xx.i & 0x7ff0000000000000ULL) == 0x7ff0000000000000ULL) {
    if ((xx.i & 0x7fffffffffffffffULL) > 0x7ff0000000000000ULL) {
      
      res.i = 0x7f8fffff;
    } else {
      
      res.i |= 0x7f800000;
    }
    return res.f;
  }
  shift = ((int) ((xx.i >> 52) & 0x7ff)) - 1023;
  
  xx.i = (xx.i & 0x000fffffffffffffULL);
  if (shift >= 128) {
    res.i |= 0x7f7fffff;
    return res.f;
  }
  if (shift <= -127) {
    if (shift < -180) {
      
      xx.i = 0;
    } else {
      xx.i |= 0x0010000000000000ULL;
      xx.i >>= 127 + shift;
    }
  } else {
    res.i |= (unsigned int) (127 + shift) << 23;
  }
  res.i |= ((unsigned int) (xx.i >> 29)) & 0x007fffff;
  xx.i &= 0x1fffffff;
  return res.f;
}

static double __internal_ll2double_kernel(long long int a, enum cudaRoundMode rndMode)
{
  volatile union {
    double d;
    unsigned long long int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.d;
  if (a < 0) res.i = (unsigned long long int)-a;
  shift = __internal_normalize64((unsigned long long int*)&res.i);
  t = ((unsigned int) res.i) << 21;
  res.i >>= 11;
  res.i += ((unsigned long long int)(1023 + 62 - shift)) << 52;
  if (a < 0) res.i |= 0x8000000000000000ULL;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : 1;
  }
  else if ((rndMode == cudaRoundMinInf) && t && (a < 0)) {
    res.i++;
  }
  else if ((rndMode == cudaRoundPosInf) && t && (a > 0)) {
    res.i++;
  }
  return res.d;
}

static double __internal_ull2double_kernel(unsigned long long int a, enum cudaRoundMode rndMode)
{
  volatile union {
    double d;
    unsigned long long int i;
  } res;
  int shift;
  unsigned int t;
  res.i = a;
  if (a == 0) return res.d;
  shift = __internal_normalize64((unsigned long long int *)&res.i);
  t = ((unsigned int) res.i) << 21;
  res.i >>= 11;
  res.i += ((unsigned long long int)(1023 + 62 - shift)) << 52;
  if ((rndMode == cudaRoundNearest) && (t >= 0x80000000)) {
    res.i += (t == 0x80000000) ? (res.i & 1) : 1;
  }
  else if ((rndMode == cudaRoundPosInf) && t) {
    res.i++;
  }
  return res.d;
}

static long long int __internal_double2ll_kernel(double a, long long int max, long long int min, long long int nan, enum cudaRoundMode rndMode)
{
  volatile union {
    double d;
    unsigned long long int i;
  } xx, res;
  unsigned long long int t = 0;
  int shift;

  xx.d = a;
  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= min) return min;
  shift = (int) (1023 + 62 - ((xx.i >> 52) & 0x7ff));
  res.i = ((xx.i << 11) | 0x8000000000000000ULL) >> 1;
  if (shift >= 64) { 
    t = res.i;
    res.i = 0;
  } else if (shift) {
    t = res.i << (64 - shift);
    res.i = res.i >> shift;
  }
  if ((rndMode == cudaRoundNearest) && (t >= 0x8000000000000000ULL)) {
    res.i += (t == 0x8000000000000000ULL) ? (res.i & 1) : 1;
  }
  else if ((rndMode ==  cudaRoundMinInf) && t && 
          (xx.i > 0x8000000000000000ULL)) {
    res.i++;
  }
  else if ((rndMode == cudaRoundPosInf) && t && ((long long int)xx.i > 0)) {
    res.i++;
  }
  if ((long long int)xx.i < 0) {
    res.i = (unsigned long long int)(-(long long int)res.i);
  }
  return res.i;
}

static unsigned long long int __internal_double2ull_kernel(double a, unsigned long long int max, unsigned long long int nan, enum cudaRoundMode rndMode)
{
  volatile union {
    double d;
    unsigned long long int i;
  } xx, res;
  unsigned long long int t = 0;
  int shift;
  xx.d = a;
  if (sizeof(a) == sizeof(double) && __cuda___isnan((double)a)) return nan; if (sizeof(a) == sizeof(float) && __cuda___isnanf((float)a)) return nan; if (a >= max) return max; if (a <= 0LL) return 0LL;

  if (a == 0.0) return 0LL;
  shift = (int) (1023 + 63 - ((xx.i >> 52) & 0x7ff));
  res.i = ((xx.i << 11) | 0x8000000000000000ULL);
  if (shift >= 64) { 
    t = res.i >> (int)(shift > 64); 
    res.i = 0; 
  } else if (shift) {
    t = res.i << (64 - shift);
    res.i = res.i >> shift;
  }
  if ((rndMode == cudaRoundNearest) && (t >= 0x8000000000000000ULL)) {
    res.i += (t == 0x8000000000000000ULL) ? (res.i & 1) : 1;
  }
  else if ((rndMode == cudaRoundPosInf) && t) {
    res.i++;
  }
  return res.i;
}

static int __double2hiint(double a)
{
  volatile union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.d = a;

  return cvt.i[1];
}

static int __double2loint(double a)
{
  volatile union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.d = a;

  return cvt.i[0];
}

static double __hiloint2double(int a, int b)
{
  volatile union {
    double     d;
    signed int i[2];
  } cvt;

  cvt.i[0] = b;
  cvt.i[1] = a;

  return cvt.d;
}

static float __double2float_rn(double a)
{
  return (float)a;
}

static float __double2float_rz(double a)
{
  return __internal_double2float_kernel(a);
}

static int __internal_double2int(double a, enum cudaRoundMode rndMode)
{
  return (int)__internal_double2ll_kernel(a, 2147483647LL, -2147483648LL, -2147483648LL, rndMode);
}

static int __double2int_rn(double a)
{
  return __internal_double2int(a, cudaRoundNearest);
}

static int __double2int_ru(double a)
{
  return __internal_double2int(a, cudaRoundPosInf);
}

static int __double2int_rd(double a)
{
  return __internal_double2int(a, cudaRoundMinInf);
}

static unsigned int __internal_double2uint(double a, enum cudaRoundMode rndMode)
{
  return (unsigned int)__internal_double2ull_kernel(a, 4294967295ULL, 2147483648ULL, rndMode);
}

static unsigned int __double2uint_rn(double a)
{
  return __internal_double2uint(a, cudaRoundNearest);
}

static unsigned int __double2uint_ru(double a)
{
  return __internal_double2uint(a, cudaRoundPosInf);
}

static unsigned int __double2uint_rd(double a)
{
  return __internal_double2uint(a, cudaRoundMinInf);
}

static long long int __internal_double2ll(double a, enum cudaRoundMode rndMode)
{
  return __internal_double2ll_kernel(a, 9223372036854775807LL, -9223372036854775807LL -1LL, -9223372036854775807LL -1LL, rndMode);
}

static long long int __double2ll_rn(double a)
{
  return __internal_double2ll(a, cudaRoundNearest);
}

static long long int __double2ll_ru(double a)
{
  return __internal_double2ll(a, cudaRoundPosInf);
}

static long long int __double2ll_rd(double a)
{
  return __internal_double2ll(a, cudaRoundMinInf);
}

static unsigned long long int __internal_double2ull(double a, enum cudaRoundMode rndMode)
{
  return __internal_double2ull_kernel(a, 18446744073709551615ULL, 9223372036854775808ULL, rndMode);
}

static unsigned long long int __double2ull_rn(double a)
{
  return __internal_double2ull(a, cudaRoundNearest);
}

static unsigned long long int __double2ull_ru(double a)
{
  return __internal_double2ull(a, cudaRoundPosInf);
}

static unsigned long long int __double2ull_rd(double a)
{
  return __internal_double2ull(a, cudaRoundMinInf);
}

static double __int2double_rn(int a)
{
  return (double)a;
}

static double __uint2double_rn(unsigned int a)
{
  return (double)a;
}

static double __ll2double_rn(long long int a)
{
  return (double)a;
}

static double __ll2double_rz(long long int a)
{
  return __internal_ll2double_kernel(a, cudaRoundZero);
}

static double __ll2double_rd(long long int a)
{
  return __internal_ll2double_kernel(a, cudaRoundMinInf);
}

static double __ll2double_ru(long long int a)
{
  return __internal_ll2double_kernel(a, cudaRoundPosInf);
}

static double __ull2double_rn(unsigned long long int a)
{
  return __internal_ull2double_kernel(a, cudaRoundNearest);
}

static double __ull2double_rz(unsigned long long int a)
{
  return __internal_ull2double_kernel(a, cudaRoundZero);
}

static double __ull2double_rd(unsigned long long int a)
{
  return __internal_ull2double_kernel(a, cudaRoundMinInf);
}

static double __ull2double_ru(unsigned long long int a)
{
  return __internal_ull2double_kernel(a, cudaRoundPosInf);
}

#line 626 "c:\\cuda\\include\\sm_13_double_functions.h"



static double __internal_fma_kernel(double x, double y, double z, enum cudaRoundMode rndMode)
{
  struct {
    unsigned int lo;
    unsigned int hi;
  } xx, yy, zz, ww;
  unsigned int s, t, u, prod0, prod1, prod2, prod3, expo_x, expo_y, expo_z;
  
  xx.hi = __double2hiint(x);
  xx.lo = __double2loint(x);
  yy.hi = __double2hiint(y);
  yy.lo = __double2loint(y);
  zz.hi = __double2hiint(z);
  zz.lo = __double2loint(z);

  expo_z = 0x7FF;
  t =  xx.hi >> 20;
  expo_x = expo_z & t;
  expo_x = expo_x - 1;    
  t =  yy.hi >> 20;
  expo_y = expo_z & t;
  expo_y = expo_y - 1;    
  t =  zz.hi >> 20;
  expo_z = expo_z & t;
  expo_z = expo_z - 1;    

  if (!((expo_x <= 0x7FD) &&
        (expo_y <= 0x7FD) &&
        (expo_z <= 0x7FD))) {
    
    



    if (((yy.hi << 1) | (yy.lo != 0)) > 0xffe00000) {
      yy.hi |= 0x00080000;
      return __hiloint2double(yy.hi, yy.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) > 0xffe00000) {
      zz.hi |= 0x00080000;
      return __hiloint2double(zz.hi, zz.lo);
    }
    if (((xx.hi << 1) | (xx.lo != 0)) > 0xffe00000) {
      xx.hi |= 0x00080000;
      return __hiloint2double(xx.hi, xx.lo);
    }
    
    










    if (((((xx.hi << 1) | xx.lo) == 0) && 
         (((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000)) ||
        ((((yy.hi << 1) | yy.lo) == 0) && 
         (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000))) {
      xx.hi = 0xfff80000;
      xx.lo = 0x00000000;
      return __hiloint2double(xx.hi, xx.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) == 0xffe00000) {
      if ((((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000) ||
          (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000)) {
        if ((int)(xx.hi ^ yy.hi ^ zz.hi) < 0) {
          xx.hi = 0xfff80000;
          xx.lo = 0x00000000;
          return __hiloint2double(xx.hi, xx.lo);
        }
      }
    }
    



    if (((xx.hi << 1) | (xx.lo != 0)) == 0xffe00000) {
      xx.hi = xx.hi ^ (yy.hi & 0x80000000);
      return __hiloint2double(xx.hi, xx.lo);
    }
    if (((yy.hi << 1) | (yy.lo != 0)) == 0xffe00000) {
      yy.hi = yy.hi ^ (xx.hi & 0x80000000);
      return __hiloint2double(yy.hi, yy.lo);
    }
    if (((zz.hi << 1) | (zz.lo != 0)) == 0xffe00000) {
      return __hiloint2double(zz.hi, zz.lo);
    }
    




    if ((zz.hi == 0x80000000) && (zz.lo == 0)) {
      if ((((xx.hi << 1) | xx.lo) == 0) ||
          (((yy.hi << 1) | yy.lo) == 0)) {
        if ((int)(xx.hi ^ yy.hi) < 0) {
          return __hiloint2double(zz.hi, zz.lo);
        }
      }
    }
    


    if ((((zz.hi << 1) | zz.lo) == 0) &&
        ((((xx.hi << 1) | xx.lo) == 0) ||
         (((yy.hi << 1) | yy.lo) == 0))) {
      if (rndMode == cudaRoundMinInf) {
        return __hiloint2double((xx.hi ^ yy.hi ^ zz.hi) & 0x80000000, zz.lo);
      } else {
        zz.hi &= 0x7fffffff;
        return __hiloint2double(zz.hi, zz.lo);
      }
    }
    
    


    if ((((xx.hi << 1) | xx.lo) == 0) ||
        (((yy.hi << 1) | yy.lo) == 0)) {
      return __hiloint2double(zz.hi, zz.lo);
    }
    
    if (expo_x == 0xffffffff) {
      expo_x++;
      t = xx.hi & 0x80000000;
      s = xx.lo >> 21;
      xx.lo = xx.lo << 11;
      xx.hi = xx.hi << 11;
      xx.hi = xx.hi | s;
      if (!xx.hi) {
        xx.hi = xx.lo;
        xx.lo = 0;
        expo_x -= 32;
      }
      while ((int)xx.hi > 0) {
        s = xx.lo >> 31;
        xx.lo = xx.lo + xx.lo;
        xx.hi = xx.hi + xx.hi;
        xx.hi = xx.hi | s;
        expo_x--;
      }
      xx.lo = (xx.lo >> 11);
      xx.lo |= (xx.hi << 21);
      xx.hi = (xx.hi >> 11) | t;
    }
    if (expo_y == 0xffffffff) {
      expo_y++;
      t = yy.hi & 0x80000000;
      s = yy.lo >> 21;
      yy.lo = yy.lo << 11;
      yy.hi = yy.hi << 11;
      yy.hi = yy.hi | s;
      if (!yy.hi) {
        yy.hi = yy.lo;
        yy.lo = 0;
        expo_y -= 32;
      }
      while ((int)yy.hi > 0) {
        s = yy.lo >> 31;
        yy.lo = yy.lo + yy.lo;
        yy.hi = yy.hi + yy.hi;
        yy.hi = yy.hi | s;
        expo_y--;
      }
      yy.lo = (yy.lo >> 11);
      yy.lo |= (yy.hi << 21);
      yy.hi = (yy.hi >> 11) | t;
    }
    if (expo_z == 0xffffffff) {
      expo_z++;
      t = zz.hi & 0x80000000;
      s = zz.lo >> 21;
      zz.lo = zz.lo << 11;
      zz.hi = zz.hi << 11;
      zz.hi = zz.hi | s;
      if (!zz.hi) {
        zz.hi = zz.lo;
        zz.lo = 0;
        expo_z -= 32;
      }
      while ((int)zz.hi > 0) {
        s = zz.lo >> 31;
        zz.lo = zz.lo + zz.lo;
        zz.hi = zz.hi + zz.hi;
        zz.hi = zz.hi | s;
        expo_z--;
      }
      zz.lo = (zz.lo >> 11);
      zz.lo |= (zz.hi << 21);
      zz.hi = (zz.hi >> 11) | t;
    }
  }
  
  expo_x = expo_x + expo_y;
  expo_y = xx.hi ^ yy.hi;
  t = xx.lo >> 21;
  xx.lo = xx.lo << 11;
  xx.hi = xx.hi << 11;
  xx.hi = xx.hi | t;
  yy.hi = yy.hi & 0x000fffff;
  xx.hi = xx.hi | 0x80000000; 
  yy.hi = yy.hi | 0x00100000; 

  prod0 = xx.lo * yy.lo;
  prod1 = __umulhi (xx.lo, yy.lo);
  prod2 = xx.hi * yy.lo;
  prod3 = xx.lo * yy.hi;
  prod1 += prod2;
  t = prod1 < prod2;
  prod1 += prod3;
  t += prod1 < prod3;
  prod2 = __umulhi (xx.hi, yy.lo);
  prod3 = __umulhi (xx.lo, yy.hi);
  prod2 += prod3;
  s = prod2 < prod3;
  prod3 = xx.hi * yy.hi;
  prod2 += prod3;
  s += prod2 < prod3;
  prod2 += t;
  s += prod2 < t;
  prod3 = __umulhi (xx.hi, yy.hi) + s;
  
  yy.lo = prod0;                 
  yy.hi = prod1;                 
  xx.lo = prod2;                 
  xx.hi = prod3;                 
  expo_x = expo_x - (1023 - 2);  
  expo_y = expo_y & 0x80000000;  

  if (xx.hi < 0x00100000) {
    s = xx.lo >> 31;
    s = (xx.hi << 1) + s;
    xx.hi = s;
    s = yy.hi >> 31;
    s = (xx.lo << 1) + s;
    xx.lo = s;
    s = yy.lo >> 31;
    s = (yy.hi << 1) + s;
    yy.hi = s;
    s = yy.lo << 1;
    yy.lo = s;
    expo_x--;
  }

  t = 0;
  if (((zz.hi << 1) | zz.lo) != 0) { 
    
    s = zz.hi & 0x80000000;
    
    zz.hi &= 0x000fffff;
    zz.hi |= 0x00100000;
    ww.hi = 0;
    ww.lo = 0;
    
    
    if ((int)expo_z > (int)expo_x) {
      t = expo_z;
      expo_z = expo_x;
      expo_x = t;
      t = zz.hi;
      zz.hi = xx.hi;
      xx.hi = t;
      t = zz.lo;
      zz.lo = xx.lo;
      xx.lo = t;
      t = ww.hi;
      ww.hi = yy.hi;
      yy.hi = t;
      t = ww.lo;
      ww.lo = yy.lo;
      yy.lo = t;
      t = expo_y;
      expo_y = s;
      s = t;
    }
    
    
    
    expo_z = expo_x - expo_z;
    u = expo_y ^ s;
    if (expo_z <= 107) {
      
      t = 0;
      while (expo_z >= 32) {
        t     = ww.lo | (t != 0);
        ww.lo = ww.hi;
        ww.hi = zz.lo;
        zz.lo = zz.hi;
        zz.hi = 0;
        expo_z -= 32;
      }
      if (expo_z) {
        t     = (t     >> expo_z) | (ww.lo << (32 - expo_z)) | 
                ((t << (32 - expo_z)) != 0);
        ww.lo = (ww.lo >> expo_z) | (ww.hi << (32 - expo_z));
        ww.hi = (ww.hi >> expo_z) | (zz.lo << (32 - expo_z));
        zz.lo = (zz.lo >> expo_z) | (zz.hi << (32 - expo_z));
        zz.hi = (zz.hi >> expo_z);
      }
    } else {
      t = 1;
      ww.lo = 0;
      ww.hi = 0;
      zz.lo = 0;
      zz.hi = 0;
    }
    if ((int)u < 0) {
      
      t = (unsigned)(-(int)t);
      s = (t != 0);
      u = yy.lo - s;
      s = u > yy.lo;
      yy.lo = u - ww.lo;
      s += yy.lo > u;
      u = yy.hi - s;
      s = u > yy.hi;
      yy.hi = u - ww.hi;
      s += yy.hi > u;
      u = xx.lo - s;
      s = u > xx.lo;
      xx.lo = u - zz.lo;
      s += xx.lo > u;
      xx.hi = (xx.hi - zz.hi) - s;
      if (!(xx.hi | xx.lo | yy.hi | yy.lo | t)) {
        
        if (rndMode == cudaRoundMinInf) {
          return __hiloint2double(0x80000000, xx.lo);
        } else {
          return __hiloint2double(xx.hi, xx.lo);
        }
      }
      if ((int)xx.hi < 0) {
        


        t = ~t;
        yy.lo = ~yy.lo;
        yy.hi = ~yy.hi;
        xx.lo = ~xx.lo;
        xx.hi = ~xx.hi;
        if (++t == 0) {
          if (++yy.lo == 0) {
            if (++yy.hi == 0) {
              if (++xx.lo == 0) {
              ++xx.hi;
              }
            }
          }
        }
        expo_y ^= 0x80000000;
      }
        
      
      while (!(xx.hi & 0x00100000)) {
        xx.hi = (xx.hi << 1) | (xx.lo >> 31);
        xx.lo = (xx.lo << 1) | (yy.hi >> 31);
        yy.hi = (yy.hi << 1) | (yy.lo >> 31);
        yy.lo = (yy.lo << 1);
        expo_x--;
      }
    } else {
      
      yy.lo = yy.lo + ww.lo;
      s = yy.lo < ww.lo;
      yy.hi = yy.hi + s;
      u = yy.hi < s;
      yy.hi = yy.hi + ww.hi;
      u += yy.hi < ww.hi;
      xx.lo = xx.lo + u;
      s = xx.lo < u;
      xx.lo = xx.lo + zz.lo;
      s += xx.lo < zz.lo;
      xx.hi = xx.hi + zz.hi + s;
      if (xx.hi & 0x00200000) {
        t = t | (yy.lo << 31);
        yy.lo = (yy.lo >> 1) | (yy.hi << 31);
        yy.hi = (yy.hi >> 1) | (xx.lo << 31);
        xx.lo = (xx.lo >> 1) | (xx.hi << 31);
        xx.hi = ((xx.hi & 0x80000000) | (xx.hi >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
  }
  t = yy.lo | (t != 0);
  t = yy.hi | (t != 0);
        
  xx.hi |= expo_y; 
  if (expo_x <= 0x7FD) {
    
    xx.hi = xx.hi & ~0x00100000; 
    s = xx.lo & 1; 
    u = xx.lo;
    if (rndMode == cudaRoundNearest) {
      xx.lo += (t == 0x80000000) ? s : (t >> 31);
    } else if (((rndMode == cudaRoundPosInf) && t && (!expo_y)) ||
               ((rndMode == cudaRoundMinInf) && t && expo_y)) {
      xx.lo += 1;
    }
    xx.hi += (u > xx.lo);
    xx.hi += ((expo_x + 1) << 20);
    return __hiloint2double(xx.hi, xx.lo);
  } else if ((int)expo_x >= 2046) {      
    
    if ((rndMode == cudaRoundNearest) || 
        ((rndMode == cudaRoundPosInf) && (!expo_y)) ||
        ((rndMode == cudaRoundMinInf) && expo_y)) {
      xx.hi = (xx.hi & 0x80000000) | 0x7ff00000;
      xx.lo = 0;
    } else {
      xx.hi = (xx.hi & 0x80000000) | 0x7fefffff;
      xx.lo = 0xffffffff;
    }
    return __hiloint2double(xx.hi, xx.lo);
  }
  
  expo_x = (unsigned)(-(int)expo_x);
  if (expo_x > 54) {
    
    if (((rndMode == cudaRoundPosInf) && (!expo_y)) ||
        ((rndMode == cudaRoundMinInf) && expo_y)) {
      return __hiloint2double(xx.hi & 0x80000000, 1);
    } else {
      return __hiloint2double(xx.hi & 0x80000000, 0);
    }
  }  
  yy.hi = xx.hi &  0x80000000;   
  xx.hi = xx.hi & ~0xffe00000;
  if (expo_x >= 32) {
    t = xx.lo | (t != 0);
    xx.lo = xx.hi;
    xx.hi = 0;
    expo_x -= 32;
  }
  if (expo_x) {
    t     = (t     >> expo_x) | (xx.lo << (32 - expo_x)) | (t != 0);
    xx.lo = (xx.lo >> expo_x) | (xx.hi << (32 - expo_x));
    xx.hi = (xx.hi >> expo_x);
  }
  expo_x = xx.lo & 1; 
  u = xx.lo;
  if (rndMode == cudaRoundNearest) {
    xx.lo += (t == 0x80000000) ? expo_x : (t >> 31);
  } else if (((rndMode == cudaRoundPosInf) && t && (!expo_y)) ||
             ((rndMode == cudaRoundMinInf) && t && expo_y)) {
    xx.lo += 1;
  }
  xx.hi += (u > xx.lo);
  xx.hi |= yy.hi;
  return __hiloint2double(xx.hi, xx.lo);
}

static double __fma_rn(double x, double y, double z)
{
  return __internal_fma_kernel(x, y, z, cudaRoundNearest);
}

static double __fma_rd(double x, double y, double z)
{
  return __internal_fma_kernel(x, y, z, cudaRoundMinInf);
}

static double __fma_ru(double x, double y, double z)
{
  return __internal_fma_kernel(x, y, z, cudaRoundPosInf);
}

static double __fma_rz(double x, double y, double z)
{
  return __internal_fma_kernel(x, y, z, cudaRoundZero);
}

static double __dadd_rz(double a, double b)
{
  return __fma_rz(a, 1.0, b); 
}

static double __dadd_ru(double a, double b)
{
  return __fma_ru(a, 1.0, b); 
}

static double __dadd_rd(double a, double b)
{
  return __fma_rd(a, 1.0, b); 
}

static double __dmul_rz(double a, double b)
{
  return __fma_rz(a, b, __hiloint2double(0x80000000, 0x00000000)); 
}

static double __dmul_ru(double a, double b)
{
  return __fma_ru(a, b, __hiloint2double(0x80000000, 0x00000000)); 
}

static double __dmul_rd(double a, double b)
{
  return __fma_rd(a, b, 0.0); 
}

static double __dadd_rn(double a, double b)
{
  return __fma_rn(a, 1.0, b); 
}

static double __dmul_rn(double a, double b)
{
  return __fma_rn(a, b, __hiloint2double(0x80000000, 0x00000000)); 
}

#line 1145 "c:\\cuda\\include\\sm_13_double_functions.h"







#line 1153 "c:\\cuda\\include\\sm_13_double_functions.h"

#line 1155 "c:\\cuda\\include\\sm_13_double_functions.h"

#line 1475 "c:\\cuda\\include\\device_functions.h"
#line 1 "c:\\cuda\\include\\texture_fetch_functions.h"

















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































#line 1875 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1 "c:\\cuda\\include\\host_defines.h"























































































































#line 121 "c:\\cuda\\include\\host_defines.h"
#line 1877 "c:\\cuda\\include\\texture_fetch_functions.h"
#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 1878 "c:\\cuda\\include\\texture_fetch_functions.h"





























#line 1908 "c:\\cuda\\include\\texture_fetch_functions.h"

extern void __stdcall __cudaTextureFetch(const void *tex, void *index, int integer, void *val);

static int4 __itexfetchi(const void *tex, int4 index)
{
  int4 val;

  __cudaTextureFetch(tex, (void*)&index, 1, (void*)&val);

  return val;
}

static uint4 __utexfetchi(const void *tex, int4 index)
{
  uint4 val;

  __cudaTextureFetch(tex, (void*)&index, 1, (void*)&val);

  return val;
}

static float4 __ftexfetchi(const void *tex, int4 index)
{
  float4 val;

  __cudaTextureFetch(tex, (void*)&index, 1, (void*)&val);

  return val;
}

static int4 __itexfetch(const void *tex, float4 index, int dim)
{
  int4 val;

  __cudaTextureFetch(tex, (void*)&index, 0, (void*)&val);

  return val;
}

static uint4 __utexfetch(const void *tex, float4 index, int dim)
{
  uint4 val;

  __cudaTextureFetch(tex, (void*)&index, 0, (void*)&val);

  return val;
}

static float4 __ftexfetch(const void *tex, float4 index, int dim)
{
  float4 val;

  __cudaTextureFetch(tex, (void*)&index, 0, (void*)&val);

  return val;
}

#line 1966 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1968 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1970 "c:\\cuda\\include\\texture_fetch_functions.h"

#line 1476 "c:\\cuda\\include\\device_functions.h"

#line 1478 "c:\\cuda\\include\\device_functions.h"

#line 908 "c:\\cuda\\include\\math_functions.h"
#line 1 "c:\\cuda\\include\\math_constants.h"









































































































































#line 139 "c:\\cuda\\include\\math_constants.h"
#line 909 "c:\\cuda\\include\\math_functions.h"

static int __cuda___signbitf(float a)
{
  return (int)((unsigned int)__float_as_int(a) >> 31);
}




static float __cuda_copysignf(float a, float b)
{
  return __int_as_float((__float_as_int(b) &  0x80000000) | 
                        (__float_as_int(a) & ~0x80000000));
}









static int min(int a, int b)
{
  return a < b ? a : b;
}

static unsigned int umin(unsigned int a, unsigned int b)
{
  return a < b ? a : b;
}

static int max(int a, int b)
{
  return a > b ? a : b;
}

static unsigned int umax(unsigned int a, unsigned int b)
{
  return a > b ? a : b;
}



static double fmax(double a, double b)
{
  return a > b ? a : b;
}

static double fmin(double a, double b)
{
  return a < b ? a : b;
}

static float fmaxf(float a, float b)
{
  return (float)fmax((double)a, (double)b);
}

static float fminf(float a, float b)
{
  return (float)fmin((double)a, (double)b);
}

static int __signbit(double a)
{
  volatile union {
    double               d;
    signed long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l < 0ll;
}

static double copysign(double a, double b)
{
  volatile union {
    double d;
    unsigned long long int l;
  } cvta, cvtb;
  cvta.d = a;
  cvtb.d = b;
  cvta.l = (cvta.l & 0x7fffffffffffffffULL) | (cvtb.l & 0x8000000000000000ULL);
  return cvta.d;
}

static int __signbitf(float a)
{
  return __cuda___signbitf(a);
}

static float copysignf(float a, float b)
{
  return __cuda_copysignf(a, b);
}

#line 1009 "c:\\cuda\\include\\math_functions.h"







static float __internal_nearbyintf(float a)
{
  float fa = fabsf(a);

  if (fa >= 8388608.0f) {
    return a;
  } else {
    volatile float u = 8388608.0f + fa;

    u = u - 8388608.0f;
    return copysignf(u, a);
  }
}

static float __internal_fminf(float a, float b)
{
  volatile union {
    float        f;
    unsigned int i;
  } cvta, cvtb;

  cvta.f = a;
  cvtb.f = b;
  if ((cvta.i << 1) > 0xff000000) return b;
  if ((cvtb.i << 1) > 0xff000000) return a;
  if ((cvta.i | cvtb.i) == 0x80000000) {
    return __int_as_float(0x80000000);
  }
  return a < b ? a : b;
}

static float __internal_fmaxf(float a, float b)
{
  volatile union {
    float        f;
    unsigned int i;
  } cvta, cvtb;

  cvta.f = a;
  cvtb.f = b;
  if ((cvta.i << 1) > 0xff000000) return b;
  if ((cvtb.i << 1) > 0xff000000) return a;
  if ((cvta.f == 0.0f) && (cvtb.f == 0.0f)) {
    cvta.i &= cvtb.i;
    return cvta.f;
  }
  return a > b ? a : b;
}



static double trunc(double a)
{
  return a < 0.0 ? ceil(a) : floor(a);
}

static double nearbyint(double a)
{
  double fa = fabs(a);
  if (fa >= 4503599627370496.0) {
    return a;
  } else {
    double u = 4503599627370496.0 + fa;
    u = u - 4503599627370496.0;
    return copysign(u, a);
  }
}

static float truncf(float a)
{
  return (float)trunc((double)a);
}

static float nearbyintf(float a)
{
  return __internal_nearbyintf(a);
}

#line 1095 "c:\\cuda\\include\\math_functions.h"

#line 1097 "c:\\cuda\\include\\math_functions.h"







static long int __cuda_labs(long int a)
{
  return labs(a);
}

static float __cuda_ceilf(float a)
{
  return ceilf(a);
}

static float __cuda_floorf(float a)
{
  return floorf(a);
}

static float __cuda_sqrtf(float a)
{
   return sqrtf(a);
}

static float __cuda_rsqrtf(float a)
{
   return 1.0f / sqrtf(a);
}

static float __cuda_truncf(float a)
{
  return truncf(a);
}

static int __cuda_max(int a, int b)
{
  return max(a, b);
}

static int __cuda_min(int a, int b)
{
  return min(a, b);
}

static unsigned int __cuda_umax(unsigned int a, unsigned int b)
{
  return umax(a, b);
}

static unsigned int __cuda_umin(unsigned int a, unsigned int b)
{
  return umin(a, b);
}

static long long int __cuda_llrintf(float a)
{


#line 1159 "c:\\cuda\\include\\math_functions.h"
  return __float2ll_rn(a);
#line 1161 "c:\\cuda\\include\\math_functions.h"
}

static long int __cuda_lrintf(float a)
{


#line 1168 "c:\\cuda\\include\\math_functions.h"


#line 1171 "c:\\cuda\\include\\math_functions.h"
  return (long int)__float2int_rn(a);
#line 1173 "c:\\cuda\\include\\math_functions.h"
#line 1174 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_nearbyintf(float a)
{


#line 1181 "c:\\cuda\\include\\math_functions.h"
  return __internal_nearbyintf(a);
#line 1183 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fmaxf(float a, float b)
{


#line 1190 "c:\\cuda\\include\\math_functions.h"

#line 1192 "c:\\cuda\\include\\math_functions.h"
  return __internal_fmaxf(a, b);
#line 1194 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fminf(float a, float b)
{


#line 1201 "c:\\cuda\\include\\math_functions.h"

#line 1203 "c:\\cuda\\include\\math_functions.h"
  return __internal_fminf(a, b);
#line 1205 "c:\\cuda\\include\\math_functions.h"
}

















static int __cuda___finitef(float a)
{
  return __cuda_fabsf(a) < __int_as_float(0x7f800000);
}








#line 1236 "c:\\cuda\\include\\math_functions.h"

static int __cuda___isinff(float a)
{
  return __cuda_fabsf(a) == __int_as_float(0x7f800000);
}

static int __cuda___isnanf(float a)
{
  return !(__cuda_fabsf(a) <= __int_as_float(0x7f800000));
}

static float __cuda_nextafterf(float a, float b)
{
  unsigned int ia;
  unsigned int ib;
  ia = __float_as_int(a);
  ib = __float_as_int(b);



#line 1257 "c:\\cuda\\include\\math_functions.h"
  if (__cuda___isnanf(a) || __cuda___isnanf(b)) return a + b; 
  if (__int_as_float (ia | ib) == 0.0f) return __int_as_float(ib);




#line 1264 "c:\\cuda\\include\\math_functions.h"
  if (__int_as_float(ia) == 0.0f) {
    return __cuda_copysignf(__int_as_float(0x00000001), b); 
  }
#line 1268 "c:\\cuda\\include\\math_functions.h"
  if ((a < b) && (a < 0.0f)) ia--;
  if ((a < b) && (a > 0.0f)) ia++;
  if ((a > b) && (a < 0.0f)) ia++;
  if ((a > b) && (a > 0.0f)) ia--;
  a = __int_as_float(ia);




#line 1278 "c:\\cuda\\include\\math_functions.h"
  return a;
}

static float __cuda_nanf(const char *tagp)
{
  
  return __int_as_float(0x7fffffff);
}


static float __internal_atanhf_kernel(float a_1, float a_2)
{
  float a, a2, t;

  a = a_1 + a_2;
  a2 = a * a;    
  t =          1.566305595598990E-001f/64.0f;
  t = t * a2 + 1.995081856004762E-001f/16.0f;
  t = t * a2 + 3.333382699617026E-001f/4.0f;
  t = t * a2;
  t = t * a + a_2;
  t = t + a_1;
  return t;
}  




static float __internal_atanf_kernel(float a)
{
  float t4, t0, t1;

  t4 = a * a;
  t0 =         - 5.674867153f;
  t0 = t4 *    - 0.823362947f + t0;
  t0 = t0 * t4 - 6.565555096f;
  t0 = t0 * t4;
  t0 = t0 * a;
  t1 = t4      + 11.33538818f;
  t1 = t1 * t4 + 28.84246826f;
  t1 = t1 * t4 + 19.69667053f;
  t1 = 1.0f / t1;
  a = t0 * t1 + a;
  return a;
}


static float __internal_tan_kernel(float a)
{
  float a2, s, t;

  a2 = a * a;
  t  = 4.114678393115178E-003f * a2 - 8.231194034909670E-001f;
  s  = a2 - 2.469348886157666E+000f;
  s  = 1.0f / s;
  t  = t * s;
  t  = t * a2;
  t  = t * a + a;
  return t;
}

static float __internal_accurate_logf(float a)
{
  float t;
  float z;
  float m;
  int ia, e;
  ia = __float_as_int(a);
  
  if ((ia < 0x00800000) || (ia > 0x7f7fffff)) {
    return __logf(a);
  }
  
  m = __int_as_float((ia & 0x807fffff) | 0x3f800000);
  e = ((unsigned)ia >> 23) - 127;
  if (m > 1.414213562f) {
    m = m * 0.5f;
    e = e + 1;
  }      
  t = m - 1.0f;
  z = m + 1.0f;
  z = t / z;
  z = -t * z;
  z = __internal_atanhf_kernel(t, z);
  z = (float)e * 0.693147181f + z;
  return z;
}  

static float2 __internal_log_ep(float a)
{
  float2 res;
  int expo;
  float m;
  float log_hi, log_lo;
  float t_hi, t_lo;
  float f, g, u, v, q;


#line 1377 "c:\\cuda\\include\\math_functions.h"
  float r, s, e;
#line 1379 "c:\\cuda\\include\\math_functions.h"
  expo = (__float_as_int(a) >> 23) & 0xff;

  
  if (expo == 0) {
    a *= 16777216.0f;
    expo = (__float_as_int(a) >> 23) & 0xff;
    expo -= 24;
  }  
#line 1388 "c:\\cuda\\include\\math_functions.h"
  expo -= 127;
  m = __int_as_float((__float_as_int(a) & 0x807fffff) | 0x3f800000);
  if (m > 1.414213562f) {
    m = m * 0.5f;
    expo = expo + 1;
  }

  




  f = m - 1.0f;
  g = m + 1.0f;
  g = 1.0f / g;
  u = 2.0f * f * g;
  v = u * u;
  q =         1.49356810919559350E-001f/64.0f;
  q = q * v + 1.99887797540072460E-001f/16.0f;
  q = q * v + 3.33333880955515580E-001f/4.0f;
  q = q * v;
  q = q * u;
  log_hi = __int_as_float(__float_as_int(u) & 0xfffff000);
  v = __int_as_float(__float_as_int(f) & 0xfffff000);
  u = 2.0f * (f - log_hi);
  f = f - v;
  u = u - log_hi * v;
  u = u - log_hi * f;
  u = g * u;
  

  
  r = log_hi + u;
  s = u - (r - log_hi);
  log_hi = r;
  log_lo = s;
  
  r = log_hi + q;
  s = ((log_hi - r) + q) + log_lo;
  log_hi = e = r + s;
  log_lo = (r - e) + s;

  
  t_hi = expo * 0.6931457519f;    
  t_lo = expo * 1.4286067653e-6f;

  
  r = t_hi + log_hi;
  s = (((t_hi - r) + log_hi) + log_lo) + t_lo;
  res.y = e = r + s;
  res.x = (r - e) + s;
  return res;
}

static float __internal_accurate_log2f(float a)
{
  return 1.442695041f * __internal_accurate_logf(a);
}


static  unsigned int __cudart_i2opi_f [] = {
  0x3c439041,
  0xdb629599,
  0xf534ddc0,
  0xfc2757d1,
  0x4e441529,
  0xa2f9836e,
};


static float __internal_trig_reduction_kernel(float a, int *quadrant)
{
  float j;
  int q;
  if (__cuda_fabsf(a) > 48039.0f) {
    
    unsigned int ia = __float_as_int(a);
    unsigned int s = ia & 0x80000000;
    unsigned int result[7];
    unsigned int phi, plo;
    unsigned int hi, lo;
    unsigned int e;
    int idx;
    e = ((ia >> 23) & 0xff) - 128;
    ia = (ia << 8) | 0x80000000;
    
    idx = 4 - (e >> 5);
    hi = 0;


#line 1479 "c:\\cuda\\include\\math_functions.h"
    for (q = 0; q < 6; q++) {
      plo = __cudart_i2opi_f[q] * ia;
      phi = __umulhi (__cudart_i2opi_f[q], ia);
      lo = hi + plo;
      hi = phi + (lo < plo);
      result[q] = lo;
    }
    result[q] = hi;
    e = e & 31;
    


    hi = result[idx+2];
    lo = result[idx+1];
    if (e) {
      q = 32 - e;
      hi = (hi << e) | (lo >> q);
      lo = (lo << e) | (result[idx] >> q);
    }
    q = hi >> 30;
    
    hi = (hi << 2) | (lo >> 30);
    lo = (lo << 2);
    e = (hi + (lo > 0)) > 0x80000000; 
    q += e;
    if (s) q = -q;
    if (e) {
      unsigned int t;
      hi = ~hi;
      lo = -(int)lo;
      t = (lo == 0);
      hi += t;
      s = s ^ 0x80000000;
    }
    *quadrant = q;
    
    e = 0;
    while ((int)hi > 0) {
      hi = (hi << 1) | (lo >> 31);
      lo = (lo << 1);
      e--;
    }
    lo = hi * 0xc90fdaa2;
    hi = __umulhi(hi, 0xc90fdaa2);
    if ((int)hi > 0) {
      hi = (hi << 1) | (lo >> 31);
      lo = (lo << 1);
      e--;
    }
    hi = hi + (lo > 0);
    ia = s | (((e + 126) << 23) + (hi >> 8) + ((hi << 24) >= 0x80000000));
    return __int_as_float(ia);
  }
  q = __float2int_rn(a * 0.636619772f);
  j = (float)q;
  a = a - j * 1.5703125000000000e+000f;
  a = a - j * 4.8351287841796875e-004f;
  a = a - j * 3.1385570764541626e-007f;
  a = a - j * 6.0771005065061922e-011f;
  *quadrant = q;
  return a;
}










static float __internal_expf_kernel(float a, float scale)
{
  float j, z;

  j = __cuda_truncf(a * 1.442695041f);
  z = a - j * 0.6931457519f;
  z = z - j * 1.4286067653e-6f;
  z = z * 1.442695041f;
  z = __cuda_exp2f(z) * __cuda_exp2f(j + scale);
  return z;
}

static float __internal_accurate_expf(float a)
{
  float z;
  z = __internal_expf_kernel(a, 0.0f);
  if (a < -105.0f) z = 0.0f;
  if (a >  105.0f) z = __int_as_float(0x7f800000);
  return z;
}

static float __internal_accurate_exp10f(float a)
{
  float j, z;
  j = __cuda_truncf(a * 3.321928094f);
  z = a - j * 3.0102920532226563e-001f;
  z = z - j * 7.9034171557301747e-007f;
  z = z * 3.321928094f;
  z = __cuda_exp2f(z) * __cuda_exp2f(j);
  if (a < -46.0f) z = 0.0f;
  if (a >  46.0f) z = __int_as_float(0x7f800000);
  return z;
}

static float __internal_lgammaf_pos(float a)
{
  float sum;
  float s, t;

  if (a == __int_as_float(0x7f800000)) {
    return a;
  }
  if (a >= 3.0f) {
    if (a >= 7.8f) {
      


      s = 1.0f / a;
      t = s * s;
      sum =           0.77783067e-3f;
      sum = sum * t - 0.2777655457e-2f;
      sum = sum * t + 0.83333273853e-1f;
      sum = sum * s + 0.918938533204672f;
      s = 0.5f * __internal_accurate_logf(a);
      t = a - 0.5f;
      s = s * t;
      t = s - a;
      s = __fadd_rn(s, sum); 
      t = t + s;
      return t;
    } else {
      a = a - 3.0f;
      s =       - 7.488903254816711E+002f;
      s = s * a - 1.234974215949363E+004f;
      s = s * a - 4.106137688064877E+004f;
      s = s * a - 4.831066242492429E+004f;
      s = s * a - 1.430333998207429E+005f;
      t =     a - 2.592509840117874E+002f;
      t = t * a - 1.077717972228532E+004f;
      t = t * a - 9.268505031444956E+004f;
      t = t * a - 2.063535768623558E+005f;
      t = s / t;
      t = t + a;
      return t;
    }
  } else if (a >= 1.5f) {
    a = a - 2.0f;
    t =       + 4.959849168282574E-005f;
    t = t * a - 2.208948403848352E-004f;
    t = t * a + 5.413142447864599E-004f;
    t = t * a - 1.204516976842832E-003f;
    t = t * a + 2.884251838546602E-003f;
    t = t * a - 7.382757963931180E-003f;
    t = t * a + 2.058131963026755E-002f;
    t = t * a - 6.735248600734503E-002f;
    t = t * a + 3.224670187176319E-001f;
    t = t * a + 4.227843368636472E-001f;
    t = t * a;
    return t;
  } else if (a >= 0.7f) {
    a = 1.0f - a;
    t =       + 4.588266515364258E-002f;
    t = t * a + 1.037396712740616E-001f;
    t = t * a + 1.228036339653591E-001f;
    t = t * a + 1.275242157462838E-001f;
    t = t * a + 1.432166835245778E-001f;
    t = t * a + 1.693435824224152E-001f;
    t = t * a + 2.074079329483975E-001f;
    t = t * a + 2.705875136435339E-001f;
    t = t * a + 4.006854436743395E-001f;
    t = t * a + 8.224669796332661E-001f;
    t = t * a + 5.772156651487230E-001f;
    t = t * a;
    return t;
  } else {
    t =       + 3.587515669447039E-003f;
    t = t * a - 5.471285428060787E-003f;
    t = t * a - 4.462712795343244E-002f;
    t = t * a + 1.673177015593242E-001f;
    t = t * a - 4.213597883575600E-002f;
    t = t * a - 6.558672843439567E-001f;
    t = t * a + 5.772153712885004E-001f;
    t = t * a;
    t = t * a + a;
    return -__internal_accurate_logf(t);
  }
}


static float __internal_sin_kernel(float x)
{
  float x2, z;

  x2 = x * x;
  z  =        - 1.95152959e-4f;
  z  = z * x2 + 8.33216087e-3f;
  z  = z * x2 - 1.66666546e-1f;
  z  = z * x2;
  z  = z * x + x;

  return z;
}


static float __internal_cos_kernel(float x)
{
  float x2, z;

  x2 = x * x;
  z  =          2.44331571e-5f;
  z  = z * x2 - 1.38873163e-3f;
  z  = z * x2 + 4.16666457e-2f;
  z  = z * x2 - 5.00000000e-1f;
  z  = z * x2 + 1.00000000e+0f;
  return z;
}

static float __internal_accurate_sinf(float a)
{
  float z;
  int   i;

  if ((__cuda___isinff(a)) || (a == 0.0f)) {
    return __fmul_rn (a, 0.0f);
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  if (i & 1) {
    z = __internal_cos_kernel(z);
  } else {
    z = __internal_sin_kernel(z);
  }
  if (i & 2) {
    z = -z;
  }
  return z;
}







static float __cuda_rintf(float a)
{


#line 1730 "c:\\cuda\\include\\math_functions.h"
  return __cuda_nearbyintf(a);
#line 1732 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_sinf(float a)
{


#line 1739 "c:\\cuda\\include\\math_functions.h"

#line 1741 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_sinf(a);
#line 1743 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_cosf(float a)
{


#line 1750 "c:\\cuda\\include\\math_functions.h"

#line 1752 "c:\\cuda\\include\\math_functions.h"
  float z;
  int i;

  if (__cuda___isinff(a)) {
    return __int_as_float(0x7fffffff);
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  i++;
  if (i & 1) {
    z = __internal_cos_kernel(z);
  } else {
    z = __internal_sin_kernel(z);
  }
  if (i & 2) {
    z = -z;
  }
  return z;
#line 1771 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_tanf(float a)
{


#line 1778 "c:\\cuda\\include\\math_functions.h"

#line 1780 "c:\\cuda\\include\\math_functions.h"
  float z;
  int   i;

  if (__cuda___isinff(a)) {
    return __int_as_float(0x7fffffff);
  }
  z = __internal_trig_reduction_kernel(a, &i);
  
  z = __internal_tan_kernel(z);
  if (i & 1) {
    z = -1.0f / z;
  }
  return z;
#line 1794 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log2f(float a)
{


#line 1801 "c:\\cuda\\include\\math_functions.h"

#line 1803 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_log2f(a);
#line 1805 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_expf(float a)
{


#line 1812 "c:\\cuda\\include\\math_functions.h"

#line 1814 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_expf(a);
#line 1816 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_exp10f(float a)
{


#line 1823 "c:\\cuda\\include\\math_functions.h"

#line 1825 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_exp10f(a);
#line 1827 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_coshf(float a)
{
  float z;

  a = __cuda_fabsf(a);
  z = __internal_expf_kernel(a, -2.0f);
  z = 2.0f * z + 0.125f / z;
  if (a >= 90.0f) {
    z = __int_as_float(0x7f800000);     
  }
  return z;
}

static float __cuda_sinhf(float a)
{
  float s, z;

  s = a;
  a = __cuda_fabsf(a);
  if (a < 1.0f) {         
    float a2 = a * a;
    
    z =          2.816951222e-6f;
    z = z * a2 + 1.983615978e-4f;
    z = z * a2 + 8.333350058e-3f;
    z = z * a2 + 1.666666650e-1f;
    z = z * a2;
    z = z * a + a;
  } else {
    z = __internal_expf_kernel(a, -2.0f);
    z = 2.0f * z - 0.125f / z;
    if (a >= 90.0f) {
      z = __int_as_float(0x7f800000);     
    }
  }
  return __cuda_copysignf(z, s);
}

static float __cuda_tanhf(float a)
{
  float s, t;

  t = __cuda_fabsf(a);
  if (t < 0.55f) {
    float z, z2;
    z = t;
    z2 = z * z;
    t =          1.643758066599993e-2f;
    t = t * z2 - 5.267181327760551e-2f;
    t = t * z2 + 1.332072505223051e-1f;
    t = t * z2 - 3.333294663641083e-1f;
    t = t * z2;
    s = t * z + z;
  } else {
    s = 1.0f - 2.0f / (__internal_expf_kernel(2.0f * t, 0.0f) + 1.0f);
    if (t >= 88.0f) {
      s = 1.0f;
    }
  }
  return __cuda_copysignf(s, a);
}

static float __cuda_atan2f(float a, float b)
{


#line 1896 "c:\\cuda\\include\\math_functions.h"
  float t0, t1, t3, fa, fb;

  
  
  fb = __cuda_fabsf(b);
  fa = __cuda_fabsf(a);

  if (fa == 0.0f && fb == 0.0f) {
    t3 = __cuda___signbitf(b) ? 3.141592654f : 0;
  } else if ((fa == __int_as_float(0x7f800000)) && (fb == __int_as_float(0x7f800000))) {
    t3 = __cuda___signbitf(b) ? 2.356194490f : 0.785398163f;
  } else {
    
    if (fb < fa) {
      t0 = fa;
      t1 = fb;
    } else {
      t0 = fb;
      t1 = fa;
    }
    t3 = __internal_accurate_fdividef(t1, t0);
    t3 = __internal_atanf_kernel(t3);
    
    if (fa > fb)  t3 = 1.570796327f - t3;
    if (b < 0.0f) t3 = 3.141592654f - t3;
  }
  t3 = __cuda_copysignf(t3, a);

  return t3;
#line 1926 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_atanf(float a)
{
  float t0, t1;

  
  t0 = __cuda_fabsf(a);
  t1 = t0;
  if (t0 > 1.0f) {
    t1 = 1.0f / t1;
  }
  
  t1 = __internal_atanf_kernel(t1);
  
  if (t0 > 1.0f) {
    t1 = 1.570796327f - t1;
  }
  return __cuda_copysignf(t1, a);
}


static float __internal_asinf_kernel(float a)
{
  float t2, t3, t4;

  t2 = a * a;
  t3 =         - 0.501162291f;
  t3 = t3 * t2 + 0.915201485f;
  t3 = t3 * t2;
  t3 = t3 * a;
  t4 = t2      - 5.478654385f;
  t4 = t4 * t2 + 5.491230488f;
  t4 = 1.0f / t4;
  a = t3 * t4 + a;
  return a;
}

static float __cuda_asinf(float a)
{
  float t0, t1, t2;

  t0 = __cuda_fabsf(a);
  t2 = 1.0f - t0;
  t2 = 0.5f * t2;
  t2 = __cuda_sqrtf(t2);
  t1 = t0 > 0.575f ? t2 : t0;
  t1 = __internal_asinf_kernel(t1);
  t2 = -2.0f * t1 + 1.570796327f;
  if (t0 > 0.575f) {
    t1 = t2;
  }
  return __cuda_copysignf(t1, a);
}

static float __cuda_acosf(float a)
{
  float t0, t1, t2;

  t0 = __cuda_fabsf(a);
  t2 = 1.0f - t0;
  t2 = 0.5f * t2;
  t2 = __cuda_sqrtf(t2);
  t1 = t0 > 0.575f ? t2 : t0;
  t1 = __internal_asinf_kernel(t1);
  t1 = t0 > 0.575f ? 2.0f * t1 : 1.570796327f - t1;
  if (__cuda___signbitf(a)) {
    t1 = 3.141592654f - t1;
  }
  return t1;
}

static float __cuda_logf(float a)
{


#line 2003 "c:\\cuda\\include\\math_functions.h"

#line 2005 "c:\\cuda\\include\\math_functions.h"
  return __internal_accurate_logf(a);
#line 2007 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log10f(float a)
{


#line 2014 "c:\\cuda\\include\\math_functions.h"

#line 2016 "c:\\cuda\\include\\math_functions.h"
  return 0.434294482f * __internal_accurate_logf(a);
#line 2018 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_log1pf(float a)
{


#line 2025 "c:\\cuda\\include\\math_functions.h"
  float t;

  
  if (a == 0.0f) return a;
#line 2030 "c:\\cuda\\include\\math_functions.h"
  if (a >= -0.394f && a <= 0.65f) {
    
    t = a + 2.0f;
    t = a / t;
    t = -a * t;
    t = __internal_atanhf_kernel (a, t);
  } else {
    t = __internal_accurate_logf (1.0f + a);
  }
  return t;
#line 2041 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_acoshf(float a)
{


#line 2048 "c:\\cuda\\include\\math_functions.h"
  float s, t;

  t = a - 1.0f;
  if (__cuda_fabsf(t) > 8388608.0f) {
    
    return 0.693147181f + __internal_accurate_logf(a);
  } else {
    s = a + 1.0f;
    t = t + __cuda_sqrtf(s * t);
    return __cuda_log1pf(t);
  }
#line 2060 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_asinhf(float a)
{


#line 2067 "c:\\cuda\\include\\math_functions.h"
  float fa, oofa, t;

  fa = __cuda_fabsf(a);
  if (fa > 8.507059173e37f) {   
    t = 0.693147181f + __logf(fa);  
  } else {
    oofa = 1.0f / fa;
    t = fa + fa / (oofa + __cuda_sqrtf(1.0f + oofa * oofa));
    t = __cuda_log1pf(t);
  }
  return __cuda_copysignf(t, a);
#line 2079 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_atanhf(float a)
{


#line 2086 "c:\\cuda\\include\\math_functions.h"
  float fa, t;

  fa = __cuda_fabsf(a);
  t = (2.0f * fa) / (1.0f - fa);
  t = 0.5f * __cuda_log1pf(t);
  return __cuda_copysignf(t, a);
#line 2093 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_expm1f(float a)
{
  float t, z, j, u;
  
  t = __cuda_rintf (a * 1.442695041f);
  z = a - t * 0.6931457519f;
  z = z - t * 1.4286067653e-6f;
  
  if (__cuda_fabsf(a) < 0.41f) {
    z = a;
    t = 0.0f;
  }
  
  j = t;
  if (t == 128.0f) j = j - 1.0f; 
  
  u =         1.38795078474044430E-003f;
  u = u * z + 8.38241261853264930E-003f;
  u = u * z + 4.16678317762833940E-002f;
  u = u * z + 1.66663978874356580E-001f;
  u = u * z + 4.99999940395997040E-001f;
  u = u * z;
  u = u * z + z;
  if (a == 0.0f) u = a;            
  
  z = __cuda_exp2f (j);
  a = z - 1.0f;
  if (a != 0.0f)   u = u * z + a;  
  if (t == 128.0f) u = u + u;      
  
  if (j >  128.0f) u = __int_as_float(0x7f800000);
  if (j <  -25.0f) u = -1.0f;
  return u;
}

static float __cuda_hypotf(float a, float b)
{


#line 2135 "c:\\cuda\\include\\math_functions.h"
  float v, w, t;

  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  
  if (a > b) {
    v = a;
    w = b; 
  } else {
    v = b;
    w = a;
  }
  t = __internal_accurate_fdividef(w, v);
  t = 1.0f + t * t;
  t = v * __cuda_sqrtf(t);
  if (v == 0.0f) {
    t = v + w;
  }
  if ((v == __int_as_float(0x7f800000)) || (w == __int_as_float(0x7f800000))) {
    t = __int_as_float(0x7f800000);
  }
  return t;
#line 2158 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_cbrtf(float a)
{


#line 2165 "c:\\cuda\\include\\math_functions.h"
  float s, t;

  s = __cuda_fabsf(a);
  if ((a == 0.0f) || (s == __int_as_float(0x7f800000))) {
    return a;
  } 
  t = __cuda_exp2f(0.333333333f * __log2f(s)); 
  t = t - (t - (s / (t * t))) * 0.333333333f;  
  if (__cuda___signbitf(a)) {
     t = -t;
  }
  return t;
#line 2178 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_erff(float a)
{
  float t, r, q;

  t = __cuda_fabsf(a);
  if (t < 1.0f) {
    t = t * t;
    r =        -5.58510127926029810E-004f;
    r = r * t + 4.90688891415893070E-003f;
    r = r * t - 2.67027980930150640E-002f;
    r = r * t + 1.12799056505903940E-001f;
    r = r * t - 3.76122956138427440E-001f;
    r = r * t + 1.12837911712623450E+000f;
    a = a * r;
  } else if (t <= __int_as_float(0x7f800000)) { 
    


    q = 0.3275911f * t + 1.0f;
    q = 1.0f / q;
    r =         1.061405429f;
    r = r * q - 1.453152027f;
    r = r * q + 1.421413741f;
    r = r * q - 0.284496736f;
    r = r * q + 0.254829592f;
    r = r * q;
    q = __internal_expf_kernel(-a * a, 0.0f);
    r = 1.0f - q * r;
    if (t >= 5.5f) {
      r = 1.0f;
    }
    a = __int_as_float (__float_as_int(r) | (__float_as_int(a) & 0x80000000));
  }
  return a;
}

static float __cuda_erfcf(float a)
{
  if (a <= 0.55f) {
    return 1.0f - __cuda_erff(a);
  } else if (a > 10.0f) {
    return 0.0f;
  } else {
    float p;
    float q;
    float h;
    float l;
    



    p =       + 4.014893410762552E-006f;
    p = p * a + 5.640401259462436E-001f;
    p = p * a + 2.626649872281140E+000f;
    p = p * a + 5.486372652389673E+000f;
    p = p * a + 5.250714831459401E+000f;
    q =     a + 4.651376250488319E+000f;
    q = q * a + 1.026302828878470E+001f;
    q = q * a + 1.140762166021288E+001f;
    q = q * a + 5.251211619089947E+000f;
    
    h = 1.0f / q;
    q = 2.0f * h - q * h * h;
    p = p * q;
    
    h = __int_as_float(__float_as_int(a) & 0xfffff000);  
    l = __fadd_rn (a, -h);  
    q = __fmul_rn (-h, h);  
    q = __internal_expf_kernel(q, 0.0f);
    a = a + h;
    l = l * a;
    h = __internal_expf_kernel(-l, 0.0f);
    q = q * h;
    p = p * q;
    return p;
  }
}

static float __cuda_lgammaf(float a)
{
  float t;
  float i;
  int quot;
  t = __internal_lgammaf_pos(__cuda_fabsf(a));
  if (a >= 0.0f) return t;
  a = __cuda_fabsf(a);
  i = __cuda_floorf(a);                   
  if (a == i) return __int_as_float(0x7f800000); 
  if (a < 1e-19f) return -__internal_accurate_logf(a);
  i = __cuda_rintf (2.0f * a);
  quot = (int)i;
  i = a - 0.5f * i;
  i = i * 3.141592654f;
  if (quot & 1) {
    i = __internal_cos_kernel(i);
  } else {
    i = __internal_sin_kernel(i);
  }
  i = __cuda_fabsf(i);
  t = 1.144729886f - __internal_accurate_logf(i * a) - t;
  return t;
}

static float __cuda_ldexpf(float a, int b)
{


#line 2288 "c:\\cuda\\include\\math_functions.h"
  float fa = __cuda_fabsf(a);

  if ((fa == 0.0f) || (fa == __int_as_float(0x7f800000)) || (b == 0)) {
    return a;
  }
  else if (__cuda_abs(b) < 126) {
    return a * __cuda_exp2f((float)b);
  }
  else if (__cuda_abs(b) < 252) {
    int bhalf = b / 2;
    return a * __cuda_exp2f((float)bhalf) * __cuda_exp2f((float)(b - bhalf));
  } 
  else {
    int bquarter = b / 4;
    float t = __cuda_exp2f((float)bquarter);
    return a * t * t * t * __cuda_exp2f((float)(b - 3 * bquarter));
  }
#line 2306 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_scalbnf(float a, int b)
{


#line 2313 "c:\\cuda\\include\\math_functions.h"
  
  return __cuda_ldexpf(a, b);
#line 2316 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_scalblnf(float a, long int b)
{


#line 2323 "c:\\cuda\\include\\math_functions.h"
  int t;
  if (b > 2147483647L) {
    t = 2147483647;
  } else if (b < (-2147483647 - 1)) {
    t = (-2147483647 - 1);
  } else {
    t = (int)b;
  }
  return __cuda_scalbnf(a, t);
#line 2333 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_frexpf(float a, int *b)
{
  float fa = __cuda_fabsf(a);
  unsigned int expo;
  unsigned int denorm;

  if (fa < 1.175494351e-38f) {
    a *= 16777216.0f;
    denorm = 24;
  } else {
    denorm = 0;
  }
  expo = ((__float_as_int(a) >> 23) & 0xff);
  if ((fa == 0.0f) || (expo == 0xff)) {
    expo = 0;
    a = a + a;
  } else {  
    expo = expo - denorm - 126;
    a = __int_as_float(((__float_as_int(a) & 0x807fffff) | 0x3f000000));
  }
  *b = expo;
  return a;
}

static float __cuda_modff(float a, float *b)
{


#line 2364 "c:\\cuda\\include\\math_functions.h"
  float t;
  if (__cuda___finitef(a)) {
    t = __cuda_truncf(a);
    *b = t;
    t = a - t;
    return __cuda_copysignf(t, a);
  } else if (__cuda___isinff(a)) {
    t = 0.0f;
    *b = a;
    return __cuda_copysignf(t, a);
  } else {
    *b = a; 
    return a;
  }
#line 2379 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fmodf(float a, float b)
{


#line 2386 "c:\\cuda\\include\\math_functions.h"
  float orig_a = a;
  float orig_b = b;
  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (!((a <= __int_as_float(0x7f800000)) && (b <= __int_as_float(0x7f800000)))) {
    return orig_a + orig_b;
  }
  if ((a == __int_as_float(0x7f800000)) || (b == 0.0f)) {
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    
    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }






#line 2414 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      if (a >= scaled_b) {
        a -= scaled_b;
      }
      scaled_b *= 0.5f;
    }
    return __cuda_copysignf(a, orig_a);
  } else {
    return orig_a;
  }
#line 2425 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_remainderf(float a, float b)
{

  float twoa = 0.0f;
  unsigned int quot0 = 0;  
  float orig_a = a;
  float orig_b = b;

  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (!((a <= __int_as_float(0x7f800000)) && (b <= __int_as_float(0x7f800000)))) {
    return orig_a + orig_b;
  }
  if ((a == __int_as_float(0x7f800000)) || (b == 0.0f)) {
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }










#line 2464 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      quot0 = 0;
      if (a >= scaled_b) {
        twoa = (2.0f * a - scaled_b) - scaled_b;
        a -= scaled_b;
        quot0 = 1;
      }
      scaled_b *= 0.5f;
    }
  }
  

  twoa = 2.0f * a;
  if ((twoa > b) || ((twoa == b) && quot0)) {
    a -= b;
    a = __cuda_copysignf (a, -1.0f);
  }














#line 2496 "c:\\cuda\\include\\math_functions.h"
  a = __int_as_float((__float_as_int(orig_a) & 0x80000000)^
                     __float_as_int(a));
  return a;
}

static float __cuda_remquof(float a, float b, int* quo)
{
  float twoa = 0.0f;
  unsigned int quot = 0;  
  unsigned int sign;
  float orig_a = a;
  float orig_b = b;

  
  sign = 0 - (__cuda___signbitf(a) != __cuda___signbitf(b));
  a = __cuda_fabsf(a);
  b = __cuda_fabsf(b);
  if (!((a <= __int_as_float(0x7f800000)) && (b <= __int_as_float(0x7f800000)))) {
    *quo = quot;
    return orig_a + orig_b;
  }
  if ((a == __int_as_float(0x7f800000)) || (b == 0.0f)) {
    *quo = quot;
    return __int_as_float(0x7fffffff);
  } else if (a >= b) {

    
    int expoa = (a < 1.175494351e-38f) ? 
        ((int)__log2f(a)) : (((__float_as_int(a) >> 23) & 0xff) - 127);
    int expob = (b < 1.175494351e-38f) ? 
        ((int)__log2f(b)) : (((__float_as_int(b) >> 23) & 0xff) - 127);
    int scale = expoa - expob;
    float scaled_b = __cuda_ldexpf(b, scale);
    if (scaled_b <= 0.5f * a) {
      scaled_b *= 2.0f;
    }
















#line 2549 "c:\\cuda\\include\\math_functions.h"
    while (scaled_b >= b) {
      quot <<= 1;
      if (a >= scaled_b) {
        twoa = (2.0f * a - scaled_b) - scaled_b;
        a -= scaled_b;
        quot += 1;
      }
      scaled_b *= 0.5f;
    }
  }
  

  twoa = 2.0f * a;
  if ((twoa > b) || ((twoa == b) && (quot & 1))) {
    quot++;
    a -= b;
    a = __cuda_copysignf (a, -1.0f);
  }
















#line 2584 "c:\\cuda\\include\\math_functions.h"
  a = __int_as_float((__float_as_int(orig_a) & 0x80000000)^
                     __float_as_int(a));
  quot = quot & (~((~0)<<3));
  quot = quot ^ sign;
  quot = quot - sign;
  *quo = quot;
  return a;
}

static float __cuda_fmaf(float a, float b, float c)
{
  unsigned int xx, yy, zz, ww;
  unsigned int temp, s, u;
  unsigned int expo_x, expo_y, expo_z;

  xx = __float_as_int(a);
  yy = __float_as_int(b);
  zz = __float_as_int(c);






#line 2609 "c:\\cuda\\include\\math_functions.h"

  temp = 0xff;
  expo_x = temp & (xx >> 23);
  expo_x = expo_x - 1;
  expo_y = temp & (yy >> 23);
  expo_y = expo_y - 1;
  expo_z = temp & (zz >> 23);
  expo_z = expo_z - 1;

  if (!((expo_x <= 0xFD) && 
        (expo_y <= 0xFD) &&
        (expo_z <= 0xFD))) {
    



    if ((yy << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    if ((zz << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    if ((xx << 1) > 0xff000000) {
      return __int_as_float(0x7fffffff);
    }
    










    if ((((xx << 1) == 0) && ((yy << 1) == 0xff000000)) ||
        (((yy << 1) == 0) && ((xx << 1) == 0xff000000))) {
      return __int_as_float(0x7fffffff);
    }
    if ((zz << 1) == 0xff000000) {
      if (((yy << 1) == 0xff000000) || ((xx << 1) == 0xff000000)) {
        if ((int)(xx ^ yy ^ zz) < 0) {
          return __int_as_float(0x7fffffff);
        }
      }
    }
    



    if ((xx << 1) == 0xff000000) {
      xx = xx ^ (yy & 0x80000000);
      return __int_as_float(xx);
    }
    if ((yy << 1) == 0xff000000) {
      yy = yy ^ (xx & 0x80000000);
      return __int_as_float(yy);
    }
    if ((zz << 1) == 0xff000000) {
      return __int_as_float(zz);
    }
    




    if (zz == 0x80000000) {
      if (((xx << 1) == 0) || ((yy << 1) == 0)) {
        if ((int)(xx ^ yy) < 0) {
          return __int_as_float(zz);
        }
      }
    }
    


    if (((zz << 1) == 0) && 
        (((xx << 1) == 0) || ((yy << 1) == 0))) {
      zz &= 0x7fffffff;
      return __int_as_float(zz);
    }
    


    if (((xx << 1) == 0) || ((yy << 1) == 0)) {
      return __int_as_float(zz);
    }
    
    if (expo_x == (unsigned int)-1) {
      temp = xx & 0x80000000;
      xx = xx << 8;
      while (!(xx & 0x80000000)) {
        xx <<= 1;
        expo_x--;
      }
      expo_x++;
      xx = (xx >> 8) | temp;
    }
    
    if (expo_y == (unsigned int)-1) {
      temp = yy & 0x80000000;
      yy = yy << 8;
      while (!(yy & 0x80000000)) {
        yy <<= 1;
        expo_y--;
      }
      expo_y++;
      yy = (yy >> 8) | temp;
    }
    
    if ((expo_z == (unsigned int)-1) && ((zz << 1) != 0)) {
      temp = zz & 0x80000000;
      zz = zz << 8;
      while (!(zz & 0x80000000)) {
        zz <<= 1;
        expo_z--;
      }
      expo_z++;
      zz = (zz >> 8) | temp;
    }
  }
    
  expo_x = expo_x + expo_y;
  expo_y = xx ^ yy;
  xx = xx & 0x00ffffff;
  yy = yy << 8;
  xx = xx | 0x00800000;
  yy = yy | 0x80000000;
  
  s = __umulhi(xx, yy);
  yy = xx * yy;
  xx = s;
  expo_x = expo_x - 127 + 2;
  expo_y = expo_y & 0x80000000;

  
  if (xx < 0x00800000) {
      xx = (xx << 1) | (yy >> 31);
      yy = (yy << 1);
      expo_x--;
  }
  temp = 0;
  if ((zz << 1) != 0) { 
    s = zz & 0x80000000;
    zz &= 0x00ffffff;
    zz |= 0x00800000;
    ww = 0;
    
    if ((int)expo_z > (int)expo_x) {
      temp = expo_z;
      expo_z = expo_x;
      expo_x = temp;
      temp = zz;
      zz = xx;
      xx = temp;
      temp = ww;
      ww = yy;
      yy = temp;
      temp = expo_y;
      expo_y = s;
      s = temp;
    }
    
    
    expo_z = expo_x - expo_z;
    u = expo_y ^ s;
    if (expo_z <= 49) {
      
      temp = 0;
      while (expo_z >= 32) {
        temp = ww | (temp != 0);
        ww = zz;
        zz = 0;
        expo_z -= 32;
      }
      if (expo_z) {
        temp = ((temp >> expo_z) | (ww << (32 - expo_z)) | 
                ((temp << (32 - expo_z)) != 0));
        ww = (ww >> expo_z) | (zz << (32 - expo_z));
        zz = (zz >> expo_z);
      }
    } else {
      temp = 1;
      ww = 0;
      zz = 0;
    }            
    if ((int)u < 0) {
      
      temp = (unsigned)(-(int)temp);
      s = (temp != 0);
      u = yy - s;
      s = u > yy;
      yy = u - ww;
      s += yy > u;
      xx = (xx - zz) - s;
      if (!(xx | yy | temp)) {
        
        return __int_as_float(xx);
      }
      if ((int)xx < 0) {
        


        temp = ~temp;
        yy = ~yy;
        xx = ~xx;
        if (++temp == 0) {
          if (++yy == 0) {
            ++xx;
          }
        }
        expo_y ^= 0x80000000;
      }
      
      while (!(xx & 0x00800000)) {
        xx = (xx << 1) | (yy >> 31);
        yy = (yy << 1);
        expo_x--;
      }
    } else {
      
      yy = yy + ww;
      s =  yy < ww;
      xx = xx + zz + s;
      if (xx & 0x01000000) {
        temp = temp | (yy << 31);
        yy = (yy >> 1) | (xx << 31);
        xx = ((xx & 0x80000000) | (xx >> 1)) & ~0x40000000;
        expo_x++;
      }
    }
  }
  temp = yy | (temp != 0);
  if (expo_x <= 0xFD) {
    
    xx |= expo_y; 
    s = xx & 1; 
    xx += (temp == 0x80000000) ? s : (temp >> 31);
    xx = xx + (expo_x << 23); 
    return __int_as_float(xx);
  } else if ((int)expo_x >= 126) {
    
    xx = expo_y | 0x7f800000;
    return __int_as_float(xx);
  }
  
  expo_x = (unsigned int)(-(int)expo_x);
  if (expo_x > 25) {
    
    return __int_as_float(expo_y);
  }
  yy = (xx << (32 - expo_x)) | ((yy) ? 1 : 0);
  xx = expo_y + (xx >> expo_x);
  xx = xx + ((yy==0x80000000) ? (xx & 1) : (yy >> 31));
  xx |= expo_y; 



#line 2869 "c:\\cuda\\include\\math_functions.h"
  return __int_as_float(xx);
}

static float __internal_accurate_powf(float a, float b)
{
  float2 loga, prod;

  volatile float t;


#line 2880 "c:\\cuda\\include\\math_functions.h"


#line 2883 "c:\\cuda\\include\\math_functions.h"
  float up, vp, u1, u2, v1, v2, mh, ml;
#line 2885 "c:\\cuda\\include\\math_functions.h"

  
  loga = __internal_log_ep(a);

  
  if (__cuda_fabsf(b) > 1.0e34f) b *= 1.220703125e-4f;
  
  up  = loga.y * 4097.0f;
  u1  = (loga.y - up) + up;
  u2  = loga.y - u1;
  vp  = b * 4097.0f;
  v1  = (b - vp) + vp;
  v2  = b - v1;
  mh  = __fmul_rn(loga.y, b);
  ml  = (((u1 * v1 - mh) + u1 * v2) + u2 * v1) + u2 * v2;
  ml  = __fmul_rn(loga.x, b) + ml;
  prod.y = up = mh + ml;
  prod.x = (mh - up) + ml;

  
  t = __cuda_expf(prod.y);
  
  if (t != __int_as_float(0x7f800000)) {
    


    t = t * prod.x + t;
  }
  return t;
}

static float __cuda_powif(float a, int b)
{
  unsigned int e = __cuda_abs(b);
  float        r = 1.0f;

  while (1) {
    if ((e & 1) != 0) {
      r = r * a;
    }
    e = e >> 1;
    if (e == 0) {
      return b < 0 ? 1.0f/r : r;
    }
    a = a * a;
  }
}

static double __cuda_powi(double a, int b)
{
  unsigned int e = __cuda_abs(b);
  double       r = 1.0;

  while (1) {
    if ((e & 1) != 0) {
      r = r * a;
    }
    e = e >> 1;
    if (e == 0) {
      return b < 0 ? 1.0/r : r;
    }
    a = a * a;
  }
}

static float __cuda_powf(float a, float b)
{


#line 2955 "c:\\cuda\\include\\math_functions.h"

#line 2957 "c:\\cuda\\include\\math_functions.h"
  int bIsOddInteger;
  float t;
  if (a == 1.0f || b == 0.0f) {
    return 1.0f;
  } 
  if (__cuda___isnanf(a) || __cuda___isnanf(b)) {
    return a + b;
  }
  if (a == __int_as_float(0x7f800000)) {
    return __cuda___signbitf(b) ? 0.0f : __int_as_float(0x7f800000);
  }
  if (__cuda___isinff(b)) {
    if (a == -1.0f) {
      return 1.0f;
    }
    t = (__cuda_fabsf(a) > 1.0f) ? __int_as_float(0x7f800000) : 0.0f;
    if (b < 0.0f) {
      t = 1.0f / t;
    }
    return t;
  }
  bIsOddInteger = (b - (2.0f * floorf(0.5f * b))) == 1.0f;
  if (a == 0.0f) {
    t = bIsOddInteger ? a : 0.0f;
    if (b < 0.0f) {
      t = 1.0f / t;
    }
    return t;
  } 
  if (a == -__int_as_float(0x7f800000)) {
    t = (b < 0.0f) ? -1.0f/a : -a;
    if (bIsOddInteger) {
      t = __int_as_float(__float_as_int(t) ^ 0x80000000);
    }
    return t;
  } 
  if ((a < 0.0f) && (b != __cuda_truncf(b))) {
    return __int_as_float(0x7fffffff);
  }
  t = __cuda_fabsf(a);
  t = __internal_accurate_powf(t, b);
  if ((a < 0.0f) && bIsOddInteger) {
    t = __int_as_float(__float_as_int(t) ^ 0x80000000);
  }
  return t;
#line 3003 "c:\\cuda\\include\\math_functions.h"
}


static float __internal_tgammaf_kernel(float a)
{
  float t;
  t =       - 1.05767296987211380E-003f;
  t = t * a + 7.09279059435508670E-003f;
  t = t * a - 9.65347121958557050E-003f;
  t = t * a - 4.21736613253687960E-002f;
  t = t * a + 1.66542401247154280E-001f;
  t = t * a - 4.20043267827838460E-002f;
  t = t * a - 6.55878234051332940E-001f;
  t = t * a + 5.77215696929794240E-001f;
  t = t * a + 1.00000000000000000E+000f;
  return t;
}





static float __cuda_tgammaf(float a)
{
  float s, xx, x=a;
  if (x >= 0.0f) {
    if (x > 36.0f) x = 36.0f; 
    s = 1.0f;
    xx = x;
    if (x > 34.03f) { 
      xx -= 1.0f;
    }
    while (xx > 1.5f) {
      xx = xx - 1.0f;
      s = s * xx;
    }
    if (x >= 0.5f) {
      xx = xx - 1.0f;
    }
    xx = __internal_tgammaf_kernel(xx);
    if (x < 0.5f) {
      xx = xx * x;
    }
    s = s / xx;
    if (x > 34.03f) {
      
      xx = x - 1.0f;
      s = s * xx;
    }
    return s;
  } else {
    if (x == __cuda_floorf(x)) {  
      x = __int_as_float(0x7fffffff);  

      return x;
#line 3059 "c:\\cuda\\include\\math_functions.h"
    } 
    if (x < -41.1f) x = -41.1f; 
    xx = x;
    if (x < -34.03f) {           
      xx += 6.0f;
    } 
    s = xx;
    while (xx < -0.5f) {
      xx = xx + 1.0f;
      s = s * xx;
    }
    xx = __internal_tgammaf_kernel(xx);
    s = s * xx;
    s = 1.0f / s;
    if (x < -34.03f) {
      xx = x;
      xx *= (x + 1.0f);
      xx *= (x + 2.0f);
      xx *= (x + 3.0f);
      xx *= (x + 4.0f);
      xx *= (x + 5.0f);
      xx = 1.0f / xx;
      s = s * xx;
      if ((a < -42.0f) && !(((int)a)&1)) {
        s = __int_as_float(0x80000000);
      }
    }    
    return s;
  }
}

static float __cuda_roundf(float a)
{


#line 3095 "c:\\cuda\\include\\math_functions.h"
  float fa = __cuda_fabsf(a);
  if (fa > 8388608.0f) {
    return a;
  } else {
    float u = __cuda_floorf(fa + 0.5f);
    if (fa < 0.5f) u = 0.0f;
    return __cuda_copysignf(u, a);
  }
#line 3104 "c:\\cuda\\include\\math_functions.h"
}

static long long int __internal_llroundf_kernel(float a)
{
  unsigned long long int res, t = 0LL;
  int shift;
  unsigned int ia = __float_as_int(a);
  if ((ia << 1) > 0xff000000) return 0LL;
  if ((int)ia >= 0x5f000000) return 0x7fffffffffffffffLL;
  if (ia >= 0xdf000000) return 0x8000000000000000LL;
  shift = 189 - ((ia >> 23) & 0xff);
  res = ((long long int)(((ia << 8) | 0x80000000) >> 1)) << 32;
  if (shift >= 64) {
    t = res;
    res = 0;
  } else if (shift) {
    t = res << (64 - shift);
    res = res >> shift;
  }
  if (t >= 0x8000000000000000LL) {
      res++;
  }
  if ((int)ia < 0) res = (unsigned long long int)(-(long long int)res);
  return (long long int)res;
}

static long long int __cuda_llroundf(float a)
{


#line 3135 "c:\\cuda\\include\\math_functions.h"
  return __internal_llroundf_kernel(a);
#line 3137 "c:\\cuda\\include\\math_functions.h"
}

static long int __cuda_lroundf(float a)
{


#line 3144 "c:\\cuda\\include\\math_functions.h"


#line 3147 "c:\\cuda\\include\\math_functions.h"

  if (__cuda___isnanf(a)) return 0L;
  if (a >=  2147483648.0f) return 2147483647L;
  if (a <= -2147483648.0f) return (-2147483647L - 1L);
#line 3152 "c:\\cuda\\include\\math_functions.h"
  return (long int)(__cuda_roundf(a));
#line 3154 "c:\\cuda\\include\\math_functions.h"
#line 3155 "c:\\cuda\\include\\math_functions.h"
}

static float __cuda_fdimf(float a, float b)
{
  float t;
  t = a - b;    
  if (a <= b) {
    t = 0.0f;
  }
  return t;
}

static int __cuda_ilogbf(float a)
{
  unsigned int i;
  int expo;
  a = __cuda_fabsf(a);
  if (a <= 1.175494351e-38f) {
    
    if (a == 0.0f) {
      expo = -((int)((unsigned int)-1 >> 1))-1;
    } else {
      expo = -126;
      i = __float_as_int(a);
      i = i << 8;
      while ((int)i >= 0) {
        expo--;
        i = i + i;
      }
    }
  } else {
    i = __float_as_int(a);
    expo = ((int)((i >> 23) & 0xff)) - 127;
    if ((i == 0x7f800000)) {
      expo = ((int)((unsigned int)-1 >> 1));
    }
    if ((i > 0x7f800000)) {
      expo = -((int)((unsigned int)-1 >> 1))-1;
    }
  } 
  return expo;
}

static float __cuda_logbf(float a)
{


#line 3203 "c:\\cuda\\include\\math_functions.h"
  unsigned int i;
  int expo;
  float res;

  if (__cuda___isnanf(a)) return a + a;
#line 3209 "c:\\cuda\\include\\math_functions.h"
  a = __cuda_fabsf(a);
  if (a <= 1.175494351e-38f) {
    
    if (a == 0.0f) {
      res = -__int_as_float(0x7f800000);
    } else {
      expo = -126;
      i = __float_as_int(a);
      i = i << 8;
      while ((int)i >= 0) {
        expo--;
        i = i + i;
      }
      res = (float)expo;
    }
  } else {
    i = __float_as_int(a);
    expo = ((int)((i >> 23) & 0xff)) - 127;
    res = (float)expo;
    if ((i >= 0x7f800000)) {  
      
      res = a + a;
    }
  } 
  return res;
#line 3235 "c:\\cuda\\include\\math_functions.h"
}

static void __cuda_sincosf(float a, float *sptr, float *cptr)
{


#line 3242 "c:\\cuda\\include\\math_functions.h"

#line 3244 "c:\\cuda\\include\\math_functions.h"
  float t, u, s, c;
  int quadrant;
  if (__cuda___isinff(a)) {
    *sptr = __int_as_float(0x7fffffff);
    *cptr = __int_as_float(0x7fffffff);
    return;
  }
  if (a == 0.0f) {
    *sptr = a;
    *cptr = 1.0f;
    return;
  } 
  t = __internal_trig_reduction_kernel(a, &quadrant);
  u = __internal_cos_kernel(t);
  t = __internal_sin_kernel(t);
  if (quadrant & 1) {
    s = u;
    c = t;
  } else {
    s = t;
    c = u;
  }
  if (quadrant & 2) {
    s = -s;
  }
  quadrant++;
  if (quadrant & 2) {
    c = -c;
  }
  *sptr = s;
  *cptr = c;
#line 3276 "c:\\cuda\\include\\math_functions.h"
}









static double rsqrt(double a)
{
  return 1.0 / sqrt(a);
}

static float rsqrtf(float a)
{
  return (float)rsqrt((double)a);
}









static double exp10(double a)
{
  return pow(10.0, a);
}

#line 3310 "c:\\cuda\\include\\math_functions.h"


static int __finite(double a)
{
  volatile union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 < 0xffe0000000000000ull;
}

static int __isnan(double a)
{
  volatile union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 > 0xffe0000000000000ull;
}

static int __isinf(double a)
{
  volatile union {
    double                 d;
    unsigned long long int l;
  } cvt;

  cvt.d = a;

  return cvt.l << 1 == 0xffe0000000000000ull;
}

static double round(double a)
{
  double fa = fabs(a);

  if (fa > 4503599627370496.0) {
    return a;
  } else {
    double u = floor(fa + 0.5);

    if (__signbit(a)) {
      u = -u;
    }
    return u;
  }
}

static long int lround(double a)
{
  return (long int)round(a);
}

static long long int llround(double a)
{
  return (long long int)round(a);
}

static double rint(double a)
{
  double fa = fabs(a);
  double u = 4503599627370496.0 + fa;
  if (fa >= 4503599627370496.0) {
    u = a;
  } else {
    u = u - 4503599627370496.0;
    if (__signbit(a)) {
      u = -u;
    }
  }
  return u;  
}

static long int lrint(double a)
{
  return (long int)rint(a);
}

static long long int llrint(double a)
{
  return (long long int)rint(a);
}

static double fdim(double a, double b)
{
  if (a > b) {
    return (a - b);
  } else if (a <= b) {
    return 0.0;
  } else if (__isnan(a)) {
    return a;
  } else {
    return b;
  }
}

static double scalbn(double a, int b)
{
  return ldexp(a, b);
}

static double scalbln(double a, long int b)
{
  int t;
  if (b > 2147483647L) {
    t = 2147483647;
  } else if (b < (-2147483647 - 1)) {
    t = (-2147483647 - 1);
  } else {
    t = (int)b;
  }
  return scalbn(a, t);
}






static double log1p(double a)
{
  volatile double u, m;

  u = 1.0 + a;
  if (u == 1.0) {
    
    u = a;
  } else {
    m = u - 1.0;
    u = log(u);
    if (a < 1.0) {
      
      u = a * u;
      u = u / m;
    }
  }
  return u;
}




static double expm1(double a)
{
  volatile double u, m;

  u = exp(a);
  m = u - 1.0;
  if (m == 0.0) {
    
    m = a;
  } 
  else if (fabs(a) < 1.0) {
    
    u = log(u);
    m = m * a;
    m = m / u;
  }
  return m;
}

static double cbrt(double a)
{
  double s, t;
  if (a == 0.0 || __isinf(a)) {
    return a;
  } 
  s = fabs(a);
  t = exp2(3.3333333333333333e-1 * log2(s));           
  t = t - (t - (s / (t * t))) * 3.3333333333333333e-1; 
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static double acosh(double a)
{
  double s, t;

  t = a - 1.0;
  if (t == a) {
    return log(2.0) + log(a);
  } else {
    s = a + 1.0;
    t = t + sqrt(s * t);
    return log1p(t);
  }
}

static double asinh(double a)
{
  double fa, oofa, t;

  fa = fabs(a);
  oofa = 1.0 / fa;
  t = fa + fa / (oofa + sqrt(1.0 + oofa * oofa));
  t = log1p(t);
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static double atanh(double a)
{
  double fa, t;

  fa = fabs(a);
  t = (2.0 * fa) / (1.0 - fa);
  t = 0.5 * log1p(t);
  if (__signbit(a)) {
    t = -t;
  }
  return t;
}

static int ilogb(double a)
{
  volatile union {
    double                 d;
    unsigned long long int l;
  } x;
  unsigned long long int i;
  int expo = -1022;

  if (__isnan(a)) return -((int)((unsigned int)-1 >> 1))-1;
  if (__isinf(a)) return ((int)((unsigned int)-1 >> 1));
  x.d = a;
  i = x.l & 0x7fffffffffffffffull;
  if (i == 0) return -((int)((unsigned int)-1 >> 1))-1;
  if (i >= 0x0010000000000000ull) {
    return (int)(((i >> 52) & 0x7ff) - 1023);
  }
  while (i < 0x0010000000000000ull) {
    expo--;
    i <<= 1;
  }
  return expo;
}

static double logb(double a)
{
  volatile union {
    double                 d;
    unsigned long long int l;
  } x;
  unsigned long long int i;
  int expo = -1022;

  if (__isnan(a)) return a;
  if (__isinf(a)) return fabs(a);
  x.d = a;
  i = x.l & 0x7fffffffffffffffull;
  if (i == 0) return -1.0/a;
  if (i >= 0x0010000000000000ull) {
    return (double)((int)((i >> 52) & 0x7ff) - 1023);
  }
  while (i < 0x0010000000000000ull) {
    expo--;
    i <<= 1;
  }
  return (double)expo;
}

static double fma(double a, double b, double c)
{
  return __fma_rn(a, b, c);
}

static void sincos(double a, double *sptr, double *cptr)
{
  *sptr = sin(a);
  *cptr = cos(a);
}







static float roundf(float a)
{
  return (float)round((double)a);
}

static long int lroundf(float a)
{
  return lround((double)a);
}

static long long int llroundf(float a)
{
  return llround((double)a);
}

static float rintf(float a)
{
  return (float)rint((double)a);
}

static long int lrintf(float a)
{
  return lrint((double)a);
}

static long long int llrintf(float a)
{
  return llrint((double)a);
}

static float logbf(float a)
{
  return (float)logb((double)a);
}

static float scalblnf(float a, long int b)
{
  return (float)scalbln((double)a, b);
}

static float acoshf(float a)
{
  return (float)acosh((double)a);
}

static float asinhf(float a)
{
  return (float)asinh((double)a);
}

static float atanhf(float a)
{
  return (float)atanh((double)a);
}

static float cbrtf(float a)
{
  return (float)cbrt((double)a);
}

static float expm1f(float a)
{
  return (float)expm1((double)a);
}

static float exp10f(float a)
{
  return (float)exp10((double)a);
}

static float fdimf(float a, float b)
{
  return (float)fdim((double)a, (double)b);
}

static float hypotf(float a, float b)
{
  return (float)hypot((double)a, (double)b);
}

static float log1pf(float a)
{
  return (float)log1p((double)a);
}

static float scalbnf(float a, int b)
{
  return (float)scalbn((double)a, b);
}

static float fmaf(float a, float b, float c)
{
  return (float)fma((double)a, (double)b, (double)c);
}

static void sincosf(float a, float *sptr, float *cptr)
{
  double s, c;

  sincos((double)a, &s, &c);
  *sptr = (float)s;
  *cptr = (float)c;
}

static int ilogbf(float a)
{
  return ilogb((double)a);
}

static float erff(float a)
{
  return (float)erf((double)a);
}

static float erfcf(float a)
{
  return (float)erfc((double)a);
}

static float lgammaf(float a)
{
  return (float)lgamma((double)a);
}

static float tgammaf(float a)
{
  return (float)tgamma((double)a);
}

static float remquof(float a, float b, int *quo)
{
  return (float)remquo((double)a, (double)b, quo);
}

static float remainderf(float a, float b)
{
  return (float)remainder((double)a, (double)b);
}

static float nextafterf(float a, float b)
{
  return (float)nextafter((double)a, (double)b);
}







static int __finitef(float a)
{
  return __cuda___finitef(a);
}

static int __isinff(float a)
{
  return __cuda___isinff(a);
}

static int __isnanf(float a)
{
  return __cuda___isnanf(a);
}







static double lgamma(double a)
{
  return (double)__cuda_lgammaf((float)a);
}

static double tgamma(double a)
{
  return (double)__cuda_tgammaf((float)a);
}

static double erf(double a)
{
  return (double)__cuda_erff((float)a);
}

static double erfc(double a)
{
  return (double)__cuda_erfcf((float)a);
}

static double remquo(double a, double b, int *quo)
{
  return (double)__cuda_remquof((float)a, (float)b, quo);
}

static double remainder(double a, double b)
{
  return (double)__cuda_remainderf((float)a, (float)b);
}

static double nextafter(double a, double b)
{
  return (double)__cuda_nextafterf((float)a, (float)b);
}

#line 3805 "c:\\cuda\\include\\math_functions.h"

#line 3807 "c:\\cuda\\include\\math_functions.h"

#line 3809 "c:\\cuda\\include\\math_functions.h"





#line 3815 "c:\\cuda\\include\\math_functions.h"



#line 1 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"








































#line 42 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

#line 1 "c:\\cuda\\include\\crt/func_macro.h"











































































#line 77 "c:\\cuda\\include\\crt/func_macro.h"
#line 44 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

static double __cuda_fabs(double a)
{
  return (float)__cuda_fabsf((float)a);
}

static double __cuda_fmax(double a, double b)
{
  return (float)__cuda_fmaxf((float)a, (float)b);
}

static double __cuda_fmin(double a, double b)
{
  return (float)__cuda_fminf((float)a, (float)b);
}

static int __cuda___finite(double a)
{
  return __cuda___finitef((float)a);
}

static int __cuda___isinf(double a)
{
  return __cuda___isinff((float)a);
}

static int __cuda___isnan(double a)
{
  return __cuda___isnanf((float)a);
}

static int __cuda___signbit(double a)
{
  return __cuda___signbitf((float)a);
}

static double __cuda_sqrt(double a)
{
  return (double)__cuda_sqrtf((float)a);
}

static double __cuda_rsqrt(double a)
{
  return (double)__cuda_rsqrtf((float)a);
}

static double __cuda_ceil(double a)
{
  return (double)__cuda_ceilf((float)a);
}

static double __cuda_trunc(double a)
{
  return (double)__cuda_truncf((float)a);
}

static double __cuda_floor(double a)
{
  return (double)__cuda_floorf((float)a);
}

static double __cuda_copysign(double a, double b)
{
  return (double)__cuda_copysignf((float)a, (float)b);
}

static double __cuda_sin(double a)
{
  return (double)__cuda_sinf((float)a);
}

static double __cuda_cos(double a)
{
  return (double)__cuda_cosf((float)a);
}

static void __cuda_sincos(double a, double *sptr, double *cptr)
{
  float fs, fc;

  __cuda_sincosf((float)a, &fs, &fc);

  *sptr = (double)fs;
  *cptr = (double)fc;
}

static double __cuda_tan(double a)
{
  return (double)__cuda_tanf((float)a);
}

static double __cuda_exp(double a)
{
  return (double)__cuda_expf((float)a);
}

static double __cuda_exp2(double a)
{
  return (double)__cuda_exp2f((float)a);
}

static double __cuda_exp10(double a)
{
  return (double)__cuda_exp10f((float)a);
}

static double __cuda_expm1(double a)
{
  return (double)__cuda_expm1f((float)a);
}

static double __cuda_cosh(double a)
{
  return (double)__cuda_coshf((float)a);
}

static double __cuda_sinh(double a)
{
  return (double)__cuda_sinhf((float)a);
}

static double __cuda_tanh(double a)
{
  return (double)__cuda_tanhf((float)a);
}

static double __cuda_asin(double a)
{
  return (double)__cuda_asinf((float)a);
}

static double __cuda_acos(double a)
{
  return (double)__cuda_acosf((float)a);
}

static double __cuda_atan(double a)
{
  return (double)__cuda_atanf((float)a);
}

static double __cuda_atan2(double a, double b)
{
  return (double)__cuda_atan2f((float)a, (float)b);
}

static double __cuda_log(double a)
{
  return (double)__cuda_logf((float)a);
}

static double __cuda_log2(double a)
{
  return (double)__cuda_log2f((float)a);
}

static double __cuda_log10(double a)
{
  return (double)__cuda_log10f((float)a);
}

static double __cuda_log1p(double a)
{
  return (double)__cuda_log1pf((float)a);
}

static double __cuda_acosh(double a)
{
  return (double)__cuda_acoshf((float)a);
}

static double __cuda_asinh(double a)
{
  return (double)__cuda_asinhf((float)a);
}

static double __cuda_atanh(double a)
{
  return (double)__cuda_atanhf((float)a);
}

static double __cuda_hypot(double a, double b)
{
  return (double)__cuda_hypotf((float)a, (float)b);
}

static double __cuda_cbrt(double a)
{
  return (double)__cuda_cbrtf((float)a);
}

static double __cuda_erf(double a)
{
  return (double)__cuda_erff((float)a);
}

static double __cuda_erfc(double a)
{
  return (double)__cuda_erfcf((float)a);
}

static double __cuda_lgamma(double a)
{
  return (double)__cuda_lgammaf((float)a);
}

static double __cuda_tgamma(double a)
{
  return (double)__cuda_tgammaf((float)a);
}

static double __cuda_ldexp(double a, int b)
{
  return (double)__cuda_ldexpf((float)a, b);
}

static double __cuda_scalbn(double a, int b)
{
  return (double)__cuda_scalbnf((float)a, b);
}

static double __cuda_scalbln(double a, long b)
{
  return (double)__cuda_scalblnf((float)a, b);
}

static double __cuda_frexp(double a, int *b)
{
  return (double)__cuda_frexpf((float)a, b);
}

static double __cuda_modf(double a, double *b)
{
  float fb;
  float fa = __cuda_modff((float)a, &fb);

  *b = (double)fb;

  return (double)fa;  
}

static double __cuda_fmod(double a, double b)
{
  return (double)__cuda_fmodf((float)a, (float)b);
}

static double __cuda_remainder(double a, double b)
{
  return (double)__cuda_remainderf((float)a, (float)b);
}

static double __cuda_remquo(double a, double b, int *c)
{
  return (double)__cuda_remquof((float)a, (float)b, c);
}

static double __cuda_nextafter(double a, double b)
{
  return (double)__cuda_nextafterf((float)a, (float)b);
}

static double __cuda_nan(const char *tagp)
{
  return (double)__cuda_nanf(tagp);
}

static double __cuda_pow(double a, double b)
{
  return (double)__cuda_powf((float)a, (float)b);
}

static double __cuda_round(double a)
{
  return (double)__cuda_roundf((float)a);
}

static long __cuda_lround(double a)
{
  return __cuda_lroundf((float)a);
}

static long long __cuda_llround(double a)
{
  return __cuda_llroundf((float)a);
}

static double __cuda_rint(double a)
{
  return (double)__cuda_rintf((float)a);
}

static long __cuda_lrint(double a)
{
  return __cuda_lrintf((float)a);
}

static long long __cuda_llrint(double a)
{
  return __cuda_llrintf((float)a);
}

static double __cuda_nearbyint(double a)
{
  return (double)__cuda_nearbyintf((float)a);
}

static double __cuda_fdim(double a, double b)
{
  return (double)__cuda_fdimf((float)a, (float)b);
}

static int __cuda_ilogb(double a)
{
  return __cuda_ilogbf((float)a);
}

static double __cuda_logb(double a)
{
  return (double)__cuda_logbf((float)a);
}

static double __cuda_fma(double a, double b, double c)
{
  return (double)__cuda_fmaf((float)a, (float)b, (float)c);
}











#line 381 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

#line 383 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"

#line 385 "c:\\cuda\\include\\math_functions_dbl_ptx1.h"
#line 3819 "c:\\cuda\\include\\math_functions.h"

#line 3821 "c:\\cuda\\include\\math_functions.h"





#line 3827 "c:\\cuda\\include\\math_functions.h"

#line 3829 "c:\\cuda\\include\\math_functions.h"

#line 94 "C:\\CUDA\\include\\common_functions.h"

#line 96 "C:\\CUDA\\include\\common_functions.h"

#line 226 "C:\\CUDA\\include\\crt/host_runtime.h"

#line 228 "C:\\CUDA\\include\\crt/host_runtime.h"















#line 244 "C:\\CUDA\\include\\crt/host_runtime.h"
#line 6 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
struct __T20;
struct __T21;
struct __T22;
struct __T23;
struct __T24;
struct __T25;
struct __T26;
struct __T27;
struct __T20 {char *__par0;char *__par1;const unsigned *__par2;unsigned __par3;int __dummy_field;};
struct __T21 {const char *__par0;const unsigned *__par1;unsigned __par2;unsigned *__par3;int __dummy_field;};
struct __T22 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T23 {unsigned __par0;unsigned *__par1;int __dummy_field;};
struct __T24 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T25 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T26 {unsigned __par0;const unsigned *__par1;const char *__par2;const char *__par3;unsigned *__par4;int __dummy_field;};
struct __T27 {unsigned __par0;unsigned *__par1;int __dummy_field;};


#line 25 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 28 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 34 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 37 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 40 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 43 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 46 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
static void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void);
#pragma section(".CRT$XCU",read,write)
__declspec(allocate(".CRT$XCU"))static void (__cdecl *__dummy_static_init__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973[])(void) = {__sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973};
void __device_stub___globfunc__Z7kernel3PbS_PKjj(bool *__par0, bool *__par1, const unsigned *__par2, const unsigned __par3){auto struct __T20 __T28;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T28.__par0 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T28.__par1 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T28.__par2 - (size_t)&__T28) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T28.__par3 - (size_t)&__T28) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z7kernel3PbS_PKjj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z7kernel3PbS_PKjj)); };}
void __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(const bool *__par0, const unsigned *__par1, const unsigned __par2, unsigned *__par3){auto struct __T21 __T29;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T29.__par0 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T29.__par1 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T29.__par2 - (size_t)&__T29) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T29.__par3 - (size_t)&__T29) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj)); };}
void __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T22 __T210;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T210.__par0 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T210.__par1 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T210.__par2 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T210.__par3 - (size_t)&__T210) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par4, sizeof(__par4), (size_t)&__T210.__par4 - (size_t)&__T210) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj)); };}
void __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(const unsigned __par0, unsigned *__par1){auto struct __T23 __T211;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T211.__par0 - (size_t)&__T211) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T211.__par1 - (size_t)&__T211) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z15kernel1_SSSP7_TjPj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z15kernel1_SSSP7_TjPj)); };}
void __device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T24 __T212;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T212.__par0 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T212.__par1 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T212.__par2 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T212.__par3 - (size_t)&__T212) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par4, sizeof(__par4), (size_t)&__T212.__par4 - (size_t)&__T212) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj)); };}
void __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T25 __T213;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T213.__par0 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T213.__par1 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T213.__par2 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T213.__par3 - (size_t)&__T213) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par4, sizeof(__par4), (size_t)&__T213.__par4 - (size_t)&__T213) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj)); };}
void __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(const unsigned __par0, const unsigned *__par1, const bool *__par2, const bool *__par3, unsigned *__par4){auto struct __T26 __T214;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T214.__par0 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T214.__par1 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par2, sizeof(__par2), (size_t)&__T214.__par2 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par3, sizeof(__par3), (size_t)&__T214.__par3 - (size_t)&__T214) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par4, sizeof(__par4), (size_t)&__T214.__par4 - (size_t)&__T214) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj)); };}
void __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(const unsigned __par0, unsigned *__par1){auto struct __T27 __T215;
if (cudaSetupArgument((void*)(char*)&__par0, sizeof(__par0), (size_t)&__T215.__par0 - (size_t)&__T215) != cudaSuccess) return;if (cudaSetupArgument((void*)(char*)&__par1, sizeof(__par1), (size_t)&__T215.__par1 - (size_t)&__T215) != cudaSuccess) return;{ volatile static char *__f; __f = ((char *)__device_stub___globfunc__Z16kernel1_SSSP7_RTjPj); (void)cudaLaunch(((char *)__device_stub___globfunc__Z16kernel1_SSSP7_RTjPj)); };}


#line 68 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 71 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 77 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 80 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 83 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 86 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"


#line 89 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
static void __sti____cudaRegisterAll_16_template_cpp1_ii_a6b7a973(void){__cudaFatCubinHandle = __cudaRegisterFatBinary((void*)(&__fatDeviceText));__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z16kernel1_SSSP7_RTjPj, (char*)"__globfunc__Z16kernel1_SSSP7_RTjPj", "__globfunc__Z16kernel1_SSSP7_RTjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj, (char*)"__globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj", "__globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj, (char*)"__globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj", "__globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj, (char*)"__globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj", "__globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z15kernel1_SSSP7_TjPj, (char*)"__globfunc__Z15kernel1_SSSP7_TjPj", "__globfunc__Z15kernel1_SSSP7_TjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj, (char*)"__globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj", "__globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj, (char*)"__globfunc__Z17kernel_minimizar1PKbPKjjPj", "__globfunc__Z17kernel_minimizar1PKbPKjjPj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterFunction(__cudaFatCubinHandle, (const char*)__device_stub___globfunc__Z7kernel3PbS_PKjj, (char*)"__globfunc__Z7kernel3PbS_PKjj", "__globfunc__Z7kernel3PbS_PKjj", (-1), (uint3*)0, (uint3*)0, (dim3*)0, (dim3*)0, (int*)0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_m, 0, "textura_m", 1, 0, 0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_p, 0, "textura_p", 1, 0, 0);__cudaRegisterTexture(__cudaFatCubinHandle, (const struct textureReference*)&textura_f, 0, "textura_f", 1, 0, 0);__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdata");__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdata1");__cudaRegisterShared(__cudaFatCubinHandle, (void**)"sdataP");}

}
#line 93 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template.cudafe1.stub.c"
#line 343 "template.cu"

