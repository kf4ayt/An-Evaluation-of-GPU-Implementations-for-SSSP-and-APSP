#include "tools.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//IMPLEMENTACION
void mostrarB(const bool* v, const unsigned int n, const char* vs){
    printf("\n%s[0..%i]\n", vs, n-1);    
    for( unsigned int i = 0; i < n; i++){
        printf( "%i\t", v[i]);
    }
    printf("\n\n");    
}
void mostrarI(const int* v, const unsigned int n, const char* vs){
    printf("\n%s[0..%i]\n", vs, n-1);    
    for( unsigned int i = 0; i < n; i++){
        printf( "%i\t", v[i]);
    }
    printf("\n\n");    
}
void mostrarUI(const unsigned int* v, const unsigned int n, const char* vs){
    printf("\n%s[0..%i]\n", vs, n-1);    
    for( unsigned int i = 0; i < n; i++){
        printf( "%i\t", v[i]);
    }
    printf("\n\n");    
}


unsigned int minimo(const unsigned int a, const unsigned int b){
	if(a<b) return a;
	return b;
}


void mostrarUI_M_Adyacencia( const unsigned int* m, const unsigned int nv, const char* ms){
    printf("\n%s[0..%i]\n", ms, nv*nv-1);    
    for( unsigned int i = 0; i < nv; i++){
	    for( unsigned int j = 0; j < nv; j++){
			printf( "%i\t", MATRIX(m, i, j));
		}//for
        printf("\n\n\n");    
    }//for

	printf("\n");    
}