#ifdef _WIN32
#pragma warning(disable:4164 4003)
#endif 
#line 1 "template.cu"
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(push)
#pragma warning(disable:4996)
#line 60 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(pop)
#line 140 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
#pragma warning(push)
#pragma warning(disable:4609 6059)


#pragma warning(pop)
#line 355 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable:4141)
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 815 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable: 4141)
#line 825 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\use_ansi.h"
#pragma comment(lib,"libcpmt")
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 307 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)

#pragma warning(push)
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)
#line 337 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)


#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 437 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(disable: 4793)
#line 445 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(pop)


#pragma warning(push)
#pragma warning(disable:4793)

#pragma warning(pop)
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4141 4996 4793)


#pragma warning(pop)
#line 34 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
#line 45 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4412 )




#pragma warning( pop )
#line 58 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
#line 69 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4412 )




#pragma warning( pop )


#pragma warning( push )
#pragma warning( disable : 4996 )

#pragma warning( push )
#pragma warning( disable : 4793 4141 )
#line 93 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4141 )




#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4793 4141 )
#line 113 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( pop )

#pragma warning( push )
#pragma warning( disable : 4141 )




#pragma warning( pop )

#pragma warning( pop )
#line 37 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
#pragma warning( disable : 4996 )
#line 525 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma warning(push)
#pragma warning(disable:4412)
#line 761 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma warning(pop)
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char, (int)1, (cudaTextureReadMode)0>  _Z7textureIcLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIcLi1EL19cudaTextureReadMode0EE _Z7textureIcLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIcLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<signed char, (int)1, (cudaTextureReadMode)0>  _Z7textureIaLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIaLi1EL19cudaTextureReadMode0EE _Z7textureIaLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIaLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)1, (cudaTextureReadMode)0>  _Z7textureIhLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIhLi1EL19cudaTextureReadMode0EE _Z7textureIhLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIhLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char1, (int)1, (cudaTextureReadMode)0>  _Z7textureI5char1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE _Z7textureI5char1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)1, (cudaTextureReadMode)0>  _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char2, (int)1, (cudaTextureReadMode)0>  _Z7textureI5char2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char2Li1EL19cudaTextureReadMode0EE _Z7textureI5char2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)1, (cudaTextureReadMode)0>  _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char4, (int)1, (cudaTextureReadMode)0>  _Z7textureI5char4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char4Li1EL19cudaTextureReadMode0EE _Z7textureI5char4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)1, (cudaTextureReadMode)0>  _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short, (int)1, (cudaTextureReadMode)0>  _Z7textureIsLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIsLi1EL19cudaTextureReadMode0EE _Z7textureIsLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIsLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)1, (cudaTextureReadMode)0>  _Z7textureItLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureItLi1EL19cudaTextureReadMode0EE _Z7textureItLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureItLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short1, (int)1, (cudaTextureReadMode)0>  _Z7textureI6short1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short1Li1EL19cudaTextureReadMode0EE _Z7textureI6short1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)1, (cudaTextureReadMode)0>  _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short2, (int)1, (cudaTextureReadMode)0>  _Z7textureI6short2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short2Li1EL19cudaTextureReadMode0EE _Z7textureI6short2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)1, (cudaTextureReadMode)0>  _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short4, (int)1, (cudaTextureReadMode)0>  _Z7textureI6short4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short4Li1EL19cudaTextureReadMode0EE _Z7textureI6short4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)1, (cudaTextureReadMode)0>  _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIiLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int, (int)1, (cudaTextureReadMode)0>  _Z7textureIiLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIiLi1EL19cudaTextureReadMode0EE _Z7textureIiLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIiLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIjLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned int, (int)1, (cudaTextureReadMode)0>  _Z7textureIjLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIjLi1EL19cudaTextureReadMode0EE _Z7textureIjLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIjLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int1, (int)1, (cudaTextureReadMode)0>  _Z7textureI4int1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int1Li1EL19cudaTextureReadMode0EE _Z7textureI4int1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint1, (int)1, (cudaTextureReadMode)0>  _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int2, (int)1, (cudaTextureReadMode)0>  _Z7textureI4int2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int2Li1EL19cudaTextureReadMode0EE _Z7textureI4int2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint2, (int)1, (cudaTextureReadMode)0>  _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int4, (int)1, (cudaTextureReadMode)0>  _Z7textureI4int4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int4Li1EL19cudaTextureReadMode0EE _Z7textureI4int4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint4, (int)1, (cudaTextureReadMode)0>  _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIlLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long, (int)1, (cudaTextureReadMode)0>  _Z7textureIlLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIlLi1EL19cudaTextureReadMode0EE _Z7textureIlLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIlLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureImLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned long, (int)1, (cudaTextureReadMode)0>  _Z7textureImLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureImLi1EL19cudaTextureReadMode0EE _Z7textureImLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureImLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long1, (int)1, (cudaTextureReadMode)0>  _Z7textureI5long1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long1Li1EL19cudaTextureReadMode0EE _Z7textureI5long1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong1, (int)1, (cudaTextureReadMode)0>  _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long2, (int)1, (cudaTextureReadMode)0>  _Z7textureI5long2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long2Li1EL19cudaTextureReadMode0EE _Z7textureI5long2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong2, (int)1, (cudaTextureReadMode)0>  _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long4, (int)1, (cudaTextureReadMode)0>  _Z7textureI5long4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long4Li1EL19cudaTextureReadMode0EE _Z7textureI5long4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong4, (int)1, (cudaTextureReadMode)0>  _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIfLi1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float, (int)1, (cudaTextureReadMode)0>  _Z7textureIfLi1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIfLi1EL19cudaTextureReadMode0EE _Z7textureIfLi1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIfLi1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float1Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float1, (int)1, (cudaTextureReadMode)0>  _Z7textureI6float1Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float1Li1EL19cudaTextureReadMode0EE _Z7textureI6float1Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float1Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float2Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float2, (int)1, (cudaTextureReadMode)0>  _Z7textureI6float2Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float2Li1EL19cudaTextureReadMode0EE _Z7textureI6float2Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float2Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float4Li1EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float4, (int)1, (cudaTextureReadMode)0>  _Z7textureI6float4Li1EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float4Li1EL19cudaTextureReadMode0EE _Z7textureI6float4Li1EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float4Li1EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char, (int)1, (cudaTextureReadMode)1>  _Z7textureIcLi1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIcLi1EL19cudaTextureReadMode1EE _Z7textureIcLi1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIcLi1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<signed char, (int)1, (cudaTextureReadMode)1>  _Z7textureIaLi1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIaLi1EL19cudaTextureReadMode1EE _Z7textureIaLi1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIaLi1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)1, (cudaTextureReadMode)1>  _Z7textureIhLi1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIhLi1EL19cudaTextureReadMode1EE _Z7textureIhLi1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIhLi1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char1, (int)1, (cudaTextureReadMode)1>  _Z7textureI5char1Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char1Li1EL19cudaTextureReadMode1EE _Z7textureI5char1Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char1Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)1, (cudaTextureReadMode)1>  _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char2, (int)1, (cudaTextureReadMode)1>  _Z7textureI5char2Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char2Li1EL19cudaTextureReadMode1EE _Z7textureI5char2Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char2Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)1, (cudaTextureReadMode)1>  _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char4, (int)1, (cudaTextureReadMode)1>  _Z7textureI5char4Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char4Li1EL19cudaTextureReadMode1EE _Z7textureI5char4Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char4Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)1, (cudaTextureReadMode)1>  _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short, (int)1, (cudaTextureReadMode)1>  _Z7textureIsLi1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIsLi1EL19cudaTextureReadMode1EE _Z7textureIsLi1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIsLi1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)1, (cudaTextureReadMode)1>  _Z7textureItLi1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureItLi1EL19cudaTextureReadMode1EE _Z7textureItLi1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureItLi1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short1, (int)1, (cudaTextureReadMode)1>  _Z7textureI6short1Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short1Li1EL19cudaTextureReadMode1EE _Z7textureI6short1Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short1Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)1, (cudaTextureReadMode)1>  _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short2, (int)1, (cudaTextureReadMode)1>  _Z7textureI6short2Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short2Li1EL19cudaTextureReadMode1EE _Z7textureI6short2Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short2Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)1, (cudaTextureReadMode)1>  _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short4, (int)1, (cudaTextureReadMode)1>  _Z7textureI6short4Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short4Li1EL19cudaTextureReadMode1EE _Z7textureI6short4Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short4Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)1, (cudaTextureReadMode)1>  _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char, (int)2, (cudaTextureReadMode)0>  _Z7textureIcLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIcLi2EL19cudaTextureReadMode0EE _Z7textureIcLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIcLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<signed char, (int)2, (cudaTextureReadMode)0>  _Z7textureIaLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIaLi2EL19cudaTextureReadMode0EE _Z7textureIaLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIaLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)2, (cudaTextureReadMode)0>  _Z7textureIhLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIhLi2EL19cudaTextureReadMode0EE _Z7textureIhLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIhLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char1, (int)2, (cudaTextureReadMode)0>  _Z7textureI5char1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char1Li2EL19cudaTextureReadMode0EE _Z7textureI5char1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)2, (cudaTextureReadMode)0>  _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char2, (int)2, (cudaTextureReadMode)0>  _Z7textureI5char2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char2Li2EL19cudaTextureReadMode0EE _Z7textureI5char2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)2, (cudaTextureReadMode)0>  _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char4, (int)2, (cudaTextureReadMode)0>  _Z7textureI5char4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char4Li2EL19cudaTextureReadMode0EE _Z7textureI5char4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)2, (cudaTextureReadMode)0>  _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short, (int)2, (cudaTextureReadMode)0>  _Z7textureIsLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIsLi2EL19cudaTextureReadMode0EE _Z7textureIsLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIsLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)2, (cudaTextureReadMode)0>  _Z7textureItLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureItLi2EL19cudaTextureReadMode0EE _Z7textureItLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureItLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short1, (int)2, (cudaTextureReadMode)0>  _Z7textureI6short1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short1Li2EL19cudaTextureReadMode0EE _Z7textureI6short1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)2, (cudaTextureReadMode)0>  _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short2, (int)2, (cudaTextureReadMode)0>  _Z7textureI6short2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short2Li2EL19cudaTextureReadMode0EE _Z7textureI6short2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)2, (cudaTextureReadMode)0>  _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short4, (int)2, (cudaTextureReadMode)0>  _Z7textureI6short4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short4Li2EL19cudaTextureReadMode0EE _Z7textureI6short4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)2, (cudaTextureReadMode)0>  _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIiLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int, (int)2, (cudaTextureReadMode)0>  _Z7textureIiLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIiLi2EL19cudaTextureReadMode0EE _Z7textureIiLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIiLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIjLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned int, (int)2, (cudaTextureReadMode)0>  _Z7textureIjLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIjLi2EL19cudaTextureReadMode0EE _Z7textureIjLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIjLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int1, (int)2, (cudaTextureReadMode)0>  _Z7textureI4int1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int1Li2EL19cudaTextureReadMode0EE _Z7textureI4int1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint1, (int)2, (cudaTextureReadMode)0>  _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int2, (int)2, (cudaTextureReadMode)0>  _Z7textureI4int2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int2Li2EL19cudaTextureReadMode0EE _Z7textureI4int2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint2, (int)2, (cudaTextureReadMode)0>  _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int4, (int)2, (cudaTextureReadMode)0>  _Z7textureI4int4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int4Li2EL19cudaTextureReadMode0EE _Z7textureI4int4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint4, (int)2, (cudaTextureReadMode)0>  _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIlLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long, (int)2, (cudaTextureReadMode)0>  _Z7textureIlLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIlLi2EL19cudaTextureReadMode0EE _Z7textureIlLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIlLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureImLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned long, (int)2, (cudaTextureReadMode)0>  _Z7textureImLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureImLi2EL19cudaTextureReadMode0EE _Z7textureImLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureImLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long1, (int)2, (cudaTextureReadMode)0>  _Z7textureI5long1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long1Li2EL19cudaTextureReadMode0EE _Z7textureI5long1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong1, (int)2, (cudaTextureReadMode)0>  _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long2, (int)2, (cudaTextureReadMode)0>  _Z7textureI5long2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long2Li2EL19cudaTextureReadMode0EE _Z7textureI5long2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong2, (int)2, (cudaTextureReadMode)0>  _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long4, (int)2, (cudaTextureReadMode)0>  _Z7textureI5long4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long4Li2EL19cudaTextureReadMode0EE _Z7textureI5long4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong4, (int)2, (cudaTextureReadMode)0>  _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIfLi2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float, (int)2, (cudaTextureReadMode)0>  _Z7textureIfLi2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIfLi2EL19cudaTextureReadMode0EE _Z7textureIfLi2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIfLi2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float1Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float1, (int)2, (cudaTextureReadMode)0>  _Z7textureI6float1Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float1Li2EL19cudaTextureReadMode0EE _Z7textureI6float1Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float1Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float2Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float2, (int)2, (cudaTextureReadMode)0>  _Z7textureI6float2Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float2Li2EL19cudaTextureReadMode0EE _Z7textureI6float2Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float2Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float4Li2EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float4, (int)2, (cudaTextureReadMode)0>  _Z7textureI6float4Li2EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float4Li2EL19cudaTextureReadMode0EE _Z7textureI6float4Li2EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float4Li2EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char, (int)2, (cudaTextureReadMode)1>  _Z7textureIcLi2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIcLi2EL19cudaTextureReadMode1EE _Z7textureIcLi2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIcLi2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<signed char, (int)2, (cudaTextureReadMode)1>  _Z7textureIaLi2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIaLi2EL19cudaTextureReadMode1EE _Z7textureIaLi2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIaLi2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)2, (cudaTextureReadMode)1>  _Z7textureIhLi2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIhLi2EL19cudaTextureReadMode1EE _Z7textureIhLi2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIhLi2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char1, (int)2, (cudaTextureReadMode)1>  _Z7textureI5char1Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char1Li2EL19cudaTextureReadMode1EE _Z7textureI5char1Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char1Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)2, (cudaTextureReadMode)1>  _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char2, (int)2, (cudaTextureReadMode)1>  _Z7textureI5char2Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char2Li2EL19cudaTextureReadMode1EE _Z7textureI5char2Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char2Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)2, (cudaTextureReadMode)1>  _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char4, (int)2, (cudaTextureReadMode)1>  _Z7textureI5char4Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char4Li2EL19cudaTextureReadMode1EE _Z7textureI5char4Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char4Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)2, (cudaTextureReadMode)1>  _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short, (int)2, (cudaTextureReadMode)1>  _Z7textureIsLi2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIsLi2EL19cudaTextureReadMode1EE _Z7textureIsLi2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIsLi2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)2, (cudaTextureReadMode)1>  _Z7textureItLi2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureItLi2EL19cudaTextureReadMode1EE _Z7textureItLi2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureItLi2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short1, (int)2, (cudaTextureReadMode)1>  _Z7textureI6short1Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short1Li2EL19cudaTextureReadMode1EE _Z7textureI6short1Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short1Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)2, (cudaTextureReadMode)1>  _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short2, (int)2, (cudaTextureReadMode)1>  _Z7textureI6short2Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short2Li2EL19cudaTextureReadMode1EE _Z7textureI6short2Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short2Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)2, (cudaTextureReadMode)1>  _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short4, (int)2, (cudaTextureReadMode)1>  _Z7textureI6short4Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short4Li2EL19cudaTextureReadMode1EE _Z7textureI6short4Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short4Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)2, (cudaTextureReadMode)1>  _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char, (int)3, (cudaTextureReadMode)0>  _Z7textureIcLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIcLi3EL19cudaTextureReadMode0EE _Z7textureIcLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIcLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<signed char, (int)3, (cudaTextureReadMode)0>  _Z7textureIaLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIaLi3EL19cudaTextureReadMode0EE _Z7textureIaLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIaLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)3, (cudaTextureReadMode)0>  _Z7textureIhLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIhLi3EL19cudaTextureReadMode0EE _Z7textureIhLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIhLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char1, (int)3, (cudaTextureReadMode)0>  _Z7textureI5char1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char1Li3EL19cudaTextureReadMode0EE _Z7textureI5char1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)3, (cudaTextureReadMode)0>  _Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE _Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char2, (int)3, (cudaTextureReadMode)0>  _Z7textureI5char2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char2Li3EL19cudaTextureReadMode0EE _Z7textureI5char2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)3, (cudaTextureReadMode)0>  _Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE _Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<char4, (int)3, (cudaTextureReadMode)0>  _Z7textureI5char4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5char4Li3EL19cudaTextureReadMode0EE _Z7textureI5char4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5char4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)3, (cudaTextureReadMode)0>  _Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE _Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short, (int)3, (cudaTextureReadMode)0>  _Z7textureIsLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIsLi3EL19cudaTextureReadMode0EE _Z7textureIsLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIsLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)3, (cudaTextureReadMode)0>  _Z7textureItLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureItLi3EL19cudaTextureReadMode0EE _Z7textureItLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureItLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short1, (int)3, (cudaTextureReadMode)0>  _Z7textureI6short1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short1Li3EL19cudaTextureReadMode0EE _Z7textureI6short1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)3, (cudaTextureReadMode)0>  _Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE _Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short2, (int)3, (cudaTextureReadMode)0>  _Z7textureI6short2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short2Li3EL19cudaTextureReadMode0EE _Z7textureI6short2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)3, (cudaTextureReadMode)0>  _Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE _Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<short4, (int)3, (cudaTextureReadMode)0>  _Z7textureI6short4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6short4Li3EL19cudaTextureReadMode0EE _Z7textureI6short4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6short4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)3, (cudaTextureReadMode)0>  _Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE _Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIiLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int, (int)3, (cudaTextureReadMode)0>  _Z7textureIiLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIiLi3EL19cudaTextureReadMode0EE _Z7textureIiLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIiLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIjLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned int, (int)3, (cudaTextureReadMode)0>  _Z7textureIjLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIjLi3EL19cudaTextureReadMode0EE _Z7textureIjLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIjLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int1, (int)3, (cudaTextureReadMode)0>  _Z7textureI4int1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int1Li3EL19cudaTextureReadMode0EE _Z7textureI4int1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint1, (int)3, (cudaTextureReadMode)0>  _Z7textureI5uint1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint1Li3EL19cudaTextureReadMode0EE _Z7textureI5uint1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int2, (int)3, (cudaTextureReadMode)0>  _Z7textureI4int2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int2Li3EL19cudaTextureReadMode0EE _Z7textureI4int2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint2, (int)3, (cudaTextureReadMode)0>  _Z7textureI5uint2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint2Li3EL19cudaTextureReadMode0EE _Z7textureI5uint2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI4int4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<int4, (int)3, (cudaTextureReadMode)0>  _Z7textureI4int4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI4int4Li3EL19cudaTextureReadMode0EE _Z7textureI4int4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI4int4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5uint4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<uint4, (int)3, (cudaTextureReadMode)0>  _Z7textureI5uint4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5uint4Li3EL19cudaTextureReadMode0EE _Z7textureI5uint4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5uint4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIlLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long, (int)3, (cudaTextureReadMode)0>  _Z7textureIlLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIlLi3EL19cudaTextureReadMode0EE _Z7textureIlLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIlLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureImLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<unsigned long, (int)3, (cudaTextureReadMode)0>  _Z7textureImLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureImLi3EL19cudaTextureReadMode0EE _Z7textureImLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureImLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long1, (int)3, (cudaTextureReadMode)0>  _Z7textureI5long1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long1Li3EL19cudaTextureReadMode0EE _Z7textureI5long1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong1, (int)3, (cudaTextureReadMode)0>  _Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE _Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long2, (int)3, (cudaTextureReadMode)0>  _Z7textureI5long2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long2Li3EL19cudaTextureReadMode0EE _Z7textureI5long2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong2, (int)3, (cudaTextureReadMode)0>  _Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE _Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5long4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<long4, (int)3, (cudaTextureReadMode)0>  _Z7textureI5long4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI5long4Li3EL19cudaTextureReadMode0EE _Z7textureI5long4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI5long4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<ulong4, (int)3, (cudaTextureReadMode)0>  _Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE _Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIfLi3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float, (int)3, (cudaTextureReadMode)0>  _Z7textureIfLi3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureIfLi3EL19cudaTextureReadMode0EE _Z7textureIfLi3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureIfLi3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float1Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float1, (int)3, (cudaTextureReadMode)0>  _Z7textureI6float1Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float1Li3EL19cudaTextureReadMode0EE _Z7textureI6float1Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float1Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float2Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float2, (int)3, (cudaTextureReadMode)0>  _Z7textureI6float2Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float2Li3EL19cudaTextureReadMode0EE _Z7textureI6float2Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float2Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6float4Li3EL19cudaTextureReadMode0EE
#if defined(__cplusplus)
typedef texture<float4, (int)3, (cudaTextureReadMode)0>  _Z7textureI6float4Li3EL19cudaTextureReadMode0EE;
#else
typedef struct _Z7textureI6float4Li3EL19cudaTextureReadMode0EE _Z7textureI6float4Li3EL19cudaTextureReadMode0EE;
#endif
#define __stub_type__Z7textureI6float4Li3EL19cudaTextureReadMode0EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIcLi3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char, (int)3, (cudaTextureReadMode)1>  _Z7textureIcLi3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIcLi3EL19cudaTextureReadMode1EE _Z7textureIcLi3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIcLi3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIaLi3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<signed char, (int)3, (cudaTextureReadMode)1>  _Z7textureIaLi3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIaLi3EL19cudaTextureReadMode1EE _Z7textureIaLi3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIaLi3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIhLi3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned char, (int)3, (cudaTextureReadMode)1>  _Z7textureIhLi3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIhLi3EL19cudaTextureReadMode1EE _Z7textureIhLi3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIhLi3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char1Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char1, (int)3, (cudaTextureReadMode)1>  _Z7textureI5char1Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char1Li3EL19cudaTextureReadMode1EE _Z7textureI5char1Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char1Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar1, (int)3, (cudaTextureReadMode)1>  _Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE _Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char2Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char2, (int)3, (cudaTextureReadMode)1>  _Z7textureI5char2Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char2Li3EL19cudaTextureReadMode1EE _Z7textureI5char2Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char2Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar2, (int)3, (cudaTextureReadMode)1>  _Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE _Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI5char4Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<char4, (int)3, (cudaTextureReadMode)1>  _Z7textureI5char4Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI5char4Li3EL19cudaTextureReadMode1EE _Z7textureI5char4Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI5char4Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<uchar4, (int)3, (cudaTextureReadMode)1>  _Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE _Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureIsLi3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short, (int)3, (cudaTextureReadMode)1>  _Z7textureIsLi3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureIsLi3EL19cudaTextureReadMode1EE _Z7textureIsLi3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureIsLi3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureItLi3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<unsigned short, (int)3, (cudaTextureReadMode)1>  _Z7textureItLi3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureItLi3EL19cudaTextureReadMode1EE _Z7textureItLi3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureItLi3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short1Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short1, (int)3, (cudaTextureReadMode)1>  _Z7textureI6short1Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short1Li3EL19cudaTextureReadMode1EE _Z7textureI6short1Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short1Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort1, (int)3, (cudaTextureReadMode)1>  _Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE _Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short2Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short2, (int)3, (cudaTextureReadMode)1>  _Z7textureI6short2Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short2Li3EL19cudaTextureReadMode1EE _Z7textureI6short2Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short2Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort2, (int)3, (cudaTextureReadMode)1>  _Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE _Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI6short4Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<short4, (int)3, (cudaTextureReadMode)1>  _Z7textureI6short4Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI6short4Li3EL19cudaTextureReadMode1EE _Z7textureI6short4Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI6short4Li3EL19cudaTextureReadMode1EE
#endif
#line 95 "c:\\cuda\\include\\texture_types.h"
#ifndef __stub_type__Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE
#if defined(__cplusplus)
typedef texture<ushort4, (int)3, (cudaTextureReadMode)1>  _Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE;
#else
typedef struct _Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE _Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE;
#endif
#define __stub_type__Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE
#endif
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
struct _iobuf;
#line 65 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
enum CUTBoolean {

CUTFalse,
CUTTrue};
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef unsigned size_t;
#include "crt/host_runtime.h"
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
typedef char *va_list;
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef __int64 __time64_t;
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef __time64_t time_t;
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
typedef long clock_t;
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIfLi1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float1Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float2Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float4Li1EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li1EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIfLi2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float1Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float2Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float4Li2EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li2EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIiLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIjLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI4int4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5uint4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIlLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureImLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5long4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6ulong4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIfLi3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float1Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float2Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6float4Li3EL19cudaTextureReadMode0EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIcLi3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIaLi3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIhLi3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char1Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar1Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char2Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar2Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI5char4Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6uchar4Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureIsLi3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureItLi3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short1Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort1Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short2Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort2Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI6short4Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#if !defined(__cplusplus)
#line 95 "c:\\cuda\\include\\texture_types.h"
struct _Z7textureI7ushort4Li3EL19cudaTextureReadMode1EE { struct textureReference __b_16textureReference;};
#endif
#pragma pack(8)
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
struct _iobuf {
char *_ptr;
int _cnt;
char *_base;
int _flag;
int _file;
int _charbuf;
int _bufsiz;
char *_tmpfname;};
#pragma pack()
typedef struct _iobuf FILE;
void *memcpy(void*, const void*, size_t); void *memset(void*, int, size_t);
#line 101 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaMalloc(void **, size_t);



extern cudaError_t __stdcall cudaFree(void *);
#line 116 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaMemcpy(void *, const void *, size_t, enum cudaMemcpyKind);
#line 166 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaGetDeviceCount(int *);
extern cudaError_t __stdcall cudaGetDeviceProperties(struct cudaDeviceProp *, int);

extern cudaError_t __stdcall cudaSetDevice(int);
#line 178 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaBindTexture(size_t *, const struct textureReference *, const void *, const struct cudaChannelFormatDesc *, size_t);

extern cudaError_t __stdcall cudaUnbindTexture(const struct textureReference *);
#line 191 "c:\\cuda\\include\\cuda_runtime_api.h"
extern struct cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int, int, int, int, enum cudaChannelFormatKind);
#line 199 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaGetLastError(void);
extern const char *__stdcall cudaGetErrorString(cudaError_t);
#line 208 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaConfigureCall(dim3, dim3, size_t, cudaStream_t);
#line 252 "c:\\cuda\\include\\cuda_runtime_api.h"
extern cudaError_t __stdcall cudaThreadSynchronize(void);
#line 176 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern clock_t __cdecl clock(void);
#line 220 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern __time64_t __cdecl _time64(__time64_t *);
#line 53 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern void *__cdecl memcpy(void *, const void *, size_t);
#line 57 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern void *__cdecl memset(void *, int, size_t);
#line 65 "c:\\cuda\\include\\math_functions.h"
extern int __cdecl abs(int);

extern long __cdecl labs(long);

extern __int64 llabs(__int64);

extern double __cdecl fabs(double);




extern int min(int, int);

extern unsigned umin(unsigned, unsigned);

extern float fminf(float, float);

extern double fmin(double, double);


extern int max(int, int);

extern unsigned umax(unsigned, unsigned);

extern float fmaxf(float, float);

extern double fmax(double, double);


extern double __cdecl sin(double);




extern double __cdecl cos(double);




extern void sincos(double, double *, double *);

extern void sincosf(float, float *, float *);


extern double __cdecl tan(double);




extern double __cdecl sqrt(double);




extern double rsqrt(double);

extern float rsqrtf(float);


extern double exp2(double);

extern float exp2f(float);


extern double exp10(double);

extern float exp10f(float);


extern double expm1(double);

extern float expm1f(float);


extern double log2(double);

extern float log2f(float);


extern double __cdecl log10(double);




extern double __cdecl log(double);




extern double log1p(double);

extern float log1pf(float);


extern double __cdecl floor(double);




extern double __cdecl exp(double);




extern double __cdecl cosh(double);




extern double __cdecl sinh(double);




extern double __cdecl tanh(double);




extern double acosh(double);

extern float acoshf(float);


extern double asinh(double);

extern float asinhf(float);


extern double atanh(double);

extern float atanhf(float);


extern double __cdecl ldexp(double, int);




extern double logb(double);

extern float logbf(float);


extern int ilogb(double);

extern int ilogbf(float);


extern double scalbn(double, int);

extern float scalbnf(float, int);


extern double scalbln(double, long);

extern float scalblnf(float, long);


extern double __cdecl frexp(double, int *);




extern double round(double);

extern float roundf(float);


extern long lround(double);

extern long lroundf(float);


extern __int64 llround(double);

extern __int64 llroundf(float);


extern double rint(double);

extern float rintf(float);


extern long lrint(double);

extern long lrintf(float);


extern __int64 llrint(double);

extern __int64 llrintf(float);


extern double nearbyint(double);

extern float nearbyintf(float);


extern double __cdecl ceil(double);




extern double trunc(double);

extern float truncf(float);


extern double fdim(double, double);

extern float fdimf(float, float);


extern double __cdecl atan2(double, double);




extern double __cdecl atan(double);




extern double __cdecl asin(double);




extern double __cdecl acos(double);




extern double __cdecl hypot(double, double);

extern float hypotf(float, float);


extern double cbrt(double);

extern float cbrtf(float);


extern double __cdecl pow(double, double);




extern double __cdecl modf(double, double *);




extern double __cdecl fmod(double, double);




extern double remainder(double, double);

extern float remainderf(float, float);


extern double remquo(double, double, int *);

extern float remquof(float, float, int *);


extern double erf(double);

extern float erff(float);


extern double erfc(double);

extern float erfcf(float);


extern double lgamma(double);

extern float lgammaf(float);


extern double tgamma(double);

extern float tgammaf(float);


extern double copysign(double, double);

extern float copysignf(float, float);


extern double nextafter(double, double);

extern float nextafterf(float, float);


extern double nan(const char *);

extern float nanf(const char *);


extern int __isinf(double);

extern int __isinff(float);


extern int __isnan(double);

extern int __isnanf(float);
#line 390 "c:\\cuda\\include\\math_functions.h"
extern int __finite(double);

extern int __finitef(float);

extern int __signbit(double);
#line 399 "c:\\cuda\\include\\math_functions.h"
extern int __signbitf(float);


extern double fma(double, double, double);

extern float fmaf(float, float, float);
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern  /* COMDAT group: frexpf */ float frexpf(float, int *);



extern  /* COMDAT group: fabsf */ float fabsf(float);

extern  /* COMDAT group: ldexpf */ float ldexpf(float, int);


extern  /* COMDAT group: acosf */ float acosf(float);

extern  /* COMDAT group: asinf */ float asinf(float);

extern  /* COMDAT group: atanf */ float atanf(float);

extern  /* COMDAT group: atan2f */ float atan2f(float, float);

extern  /* COMDAT group: ceilf */ float ceilf(float);

extern  /* COMDAT group: cosf */ float cosf(float);

extern  /* COMDAT group: coshf */ float coshf(float);

extern  /* COMDAT group: expf */ float expf(float);

extern  /* COMDAT group: floorf */ float floorf(float);

extern  /* COMDAT group: fmodf */ float fmodf(float, float);

extern  /* COMDAT group: logf */ float logf(float);

extern  /* COMDAT group: log10f */ float log10f(float);

extern  /* COMDAT group: modff */ float modff(float, float *);



extern  /* COMDAT group: powf */ float powf(float, float);

extern  /* COMDAT group: sinf */ float sinf(float);

extern  /* COMDAT group: sinhf */ float sinhf(float);

extern  /* COMDAT group: sqrtf */ float sqrtf(float);

extern  /* COMDAT group: tanf */ float tanf(float);

extern  /* COMDAT group: tanhf */ float tanhf(float);
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern __declspec( noreturn ) void __cdecl exit(int);
#line 540 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern void __cdecl srand(unsigned);
#line 593 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern __declspec( noalias ) void __cdecl free(void *);
extern __declspec( restrict noalias ) void *__cdecl malloc(size_t);
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern FILE *__cdecl __iob_func(void);
#line 210 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl fflush(FILE *);
#line 238 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl fprintf(FILE *, const char *, ...);
#line 264 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl getchar(void);
#line 278 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl printf(const char *, ...);
#line 341 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern int __cdecl vsprintf_s(char *, size_t, const char *, va_list);
#line 462 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutCheckCmdLineFlag(const int, const char **, const char *);
#line 476 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutGetCmdLineArgumenti(const int, const char **, const char *, int *);
#line 558 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutComparei(const int *, const int *, const unsigned);
#line 627 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutCreateTimer(unsigned *);
#line 636 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutDeleteTimer(unsigned);
#line 644 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutStartTimer(const unsigned);
#line 652 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) enum CUTBoolean __stdcall cutStopTimer(const unsigned);
#line 669 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
extern __declspec( dllimport ) float __stdcall cutGetTimerValue(const unsigned);
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\Fibonacci_Heaps.h"
extern void _Z14computeGold_FHPjjPKjj(unsigned *, const unsigned, const unsigned *, const unsigned);
#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z9copiarH2DPvPKvj(void *, const void *, const unsigned);




extern void _Z9copiarD2HPvPKvj(void *, const void *, const unsigned);




extern void _Z25inicializar_Matriz_DevicePKjjRPj(const unsigned *, const unsigned, unsigned **);
#line 31 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z15inicializar_SolRPjS0_jjj(unsigned **, unsigned **, const unsigned, const unsigned, const unsigned);
#line 51 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z22inicializar_PendientesRPbS0_jj(char **, char **, const unsigned, const unsigned);
#line 70 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
extern void _Z20inicializar_FronteraRPbS0_jj(char **, char **, const unsigned, const unsigned);
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
extern char _Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, char *, char *, unsigned *, unsigned *, const unsigned *, char *, char *, unsigned *, unsigned *);
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
extern void _Z15testGraph_SSSP7jjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
extern char _Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, char *, char *, unsigned *, unsigned *, const unsigned *, char *, char *, unsigned *, unsigned *);
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
extern void _Z17testGraph_SSSP7_TjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 254 "C:\\CUDA\\include\\cuda_runtime.h"
extern  /* COMDAT group: _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj */ __inline cudaError_t _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(size_t *, const _Z7textureIiLi1EL19cudaTextureReadMode0EE *, const void *, size_t);
#line 254 "C:\\CUDA\\include\\cuda_runtime.h"
extern  /* COMDAT group: _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj */ __inline cudaError_t _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(size_t *, const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *, const void *, size_t);
#line 293 "C:\\CUDA\\include\\cuda_runtime.h"
extern  /* COMDAT group: _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE */ __inline cudaError_t _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(const _Z7textureIiLi1EL19cudaTextureReadMode0EE *);
#line 293 "C:\\CUDA\\include\\cuda_runtime.h"
extern  /* COMDAT group: _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE */ __inline cudaError_t _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *);
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
extern char _Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, char *, char *, unsigned *, unsigned *, const unsigned *, char *, char *, unsigned *, unsigned *);
#line 133 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
extern void _Z18testGraph_SSSP7_RTjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
extern char _Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, char *, char *, unsigned *, unsigned *, const unsigned *, char *, char *, unsigned *, unsigned *);
#line 135 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
extern void _Z15testGraph_SSSP9jjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
extern char _Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(const unsigned, const dim3, const dim3, const dim3, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, const unsigned, char *, char *, unsigned *, unsigned *, const unsigned *, char *, char *, unsigned *, unsigned *);
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
extern void _Z22testGraph_SSSP9_AtomicjjjjPKjS0_(const unsigned, const unsigned, const unsigned, unsigned, const unsigned *, const unsigned *);
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.h"
extern void _Z16computeGold_CPU7PjjPKjj(unsigned *, const unsigned, const unsigned *, const unsigned);




extern void _Z16computeGold_CPU9PjjPKjj(unsigned *, const unsigned, const unsigned *, const unsigned);
#line 6 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern void _Z19genera_M_AdyacenciajjjjRjRPj(const unsigned, const unsigned, const unsigned, const unsigned, unsigned *, unsigned **);




extern void _Z21guardaMatriz_FicheroBPKcjjPKj(const char *, const unsigned, const unsigned, const unsigned *);



extern void _Z18leeMatriz_FicheroBPKcRjS1_RPj(const char *, unsigned *, unsigned *, unsigned **);
#line 85 "template.cu"
extern int __cdecl main(int, char **);
#line 122 "template.cu"
extern void _Z27generar_Matrices_Adyacenciav(void);
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern  /* COMDAT group: _Z9sprintf_sILj100EEiRAT__cPKcz */ int __cdecl _Z9sprintf_sILj100EEiRAT__cPKcz(char (*)[100], const char *, ...);
#line 188 "template.cu"
extern void _Z7runTestv(void);
#line 274 "template.cu"
extern void _Z5runFHv(void);
static void __sti___16_template_cpp1_ii_a6b7a973(void);
#pragma section(".CRT$XCU",read,write)
__declspec(allocate(".CRT$XCU"))static void (__cdecl *__dummy_static_init__sti___16_template_cpp1_ii_a6b7a973[])(void) = {__sti___16_template_cpp1_ii_a6b7a973};
#line 30 "template.cu"
extern unsigned NUM_THREADS_IN_BLOCK;
#line 47 "template.cu"
__loc_sc__(__text__,) _Z7textureIiLi1EL19cudaTextureReadMode0EE textura_m;



__loc_sc__(__text__,) _Z7textureI5char1Li1EL19cudaTextureReadMode0EE textura_p;
__loc_sc__(__text__,) _Z7textureI5char1Li1EL19cudaTextureReadMode0EE textura_f;
#include "template.cudafe1.stub.h"
#line 30 "template.cu"
unsigned NUM_THREADS_IN_BLOCK = 256U;
#line 379 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
 /* COMDAT group: frexpf */ __inline float frexpf( float _X,  int *_Y)
{ return (float)(frexp(((double)_X), _Y)); }


 /* COMDAT group: fabsf */ __inline float fabsf( float _X)
{ return (float)(fabs(((double)_X))); }
 /* COMDAT group: ldexpf */ __inline float ldexpf( float _X,  int _Y)
{ return (float)(ldexp(((double)_X), _Y)); }

 /* COMDAT group: acosf */ __inline float acosf( float _X)
{ return (float)(acos(((double)_X))); }
 /* COMDAT group: asinf */ __inline float asinf( float _X)
{ return (float)(asin(((double)_X))); }
 /* COMDAT group: atanf */ __inline float atanf( float _X)
{ return (float)(atan(((double)_X))); }
 /* COMDAT group: atan2f */ __inline float atan2f( float _X,  float _Y)
{ return (float)(atan2(((double)_X), ((double)_Y))); }
 /* COMDAT group: ceilf */ __inline float ceilf( float _X)
{ return (float)(ceil(((double)_X))); }
 /* COMDAT group: cosf */ __inline float cosf( float _X)
{ return (float)(cos(((double)_X))); }
 /* COMDAT group: coshf */ __inline float coshf( float _X)
{ return (float)(cosh(((double)_X))); }
 /* COMDAT group: expf */ __inline float expf( float _X)
{ return (float)(exp(((double)_X))); }
 /* COMDAT group: floorf */ __inline float floorf( float _X)
{ return (float)(floor(((double)_X))); }
 /* COMDAT group: fmodf */ __inline float fmodf( float _X,  float _Y)
{ return (float)(fmod(((double)_X), ((double)_Y))); }
 /* COMDAT group: logf */ __inline float logf( float _X)
{ return (float)(log(((double)_X))); }
 /* COMDAT group: log10f */ __inline float log10f( float _X)
{ return (float)(log10(((double)_X))); }
 /* COMDAT group: modff */ __inline float modff( float _X,  float *_Y)
{ auto double _Di;
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
auto double _Df;
#line 413 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
_Df = (modf(((double)_X), (&_Di)));
(*_Y) = ((float)_Di);
return (float)_Df; }
 /* COMDAT group: powf */ __inline float powf( float _X,  float _Y)
{ return (float)(pow(((double)_X), ((double)_Y))); }
 /* COMDAT group: sinf */ __inline float sinf( float _X)
{ return (float)(sin(((double)_X))); }
 /* COMDAT group: sinhf */ __inline float sinhf( float _X)
{ return (float)(sinh(((double)_X))); }
 /* COMDAT group: sqrtf */ __inline float sqrtf( float _X)
{ return (float)(sqrt(((double)_X))); }
 /* COMDAT group: tanf */ __inline float tanf( float _X)
{ return (float)(tan(((double)_X))); }
 /* COMDAT group: tanhf */ __inline float tanhf( float _X)
{ return (float)(tanh(((double)_X))); }
#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void _Z9copiarH2DPvPKvj( void *v_d,  const void *v_h,  const unsigned mem_size) {
cudaMemcpy(v_d, v_h, mem_size, cudaMemcpyHostToDevice); 
}


void _Z9copiarD2HPvPKvj( void *v_h,  const void *v_d,  const unsigned mem_size) {
cudaMemcpy(v_h, v_d, mem_size, cudaMemcpyDeviceToHost); 
}


void _Z25inicializar_Matriz_DevicePKjjRPj( const unsigned *m_h,  const unsigned mem_size_M, 
unsigned **m_d) {

cudaMalloc(((void **)m_d), mem_size_M);
_Z9copiarH2DPvPKvj(((void *)((*m_d))), ((const void *)m_h), mem_size_M); 
}


void _Z15inicializar_SolRPjS0_jjj( unsigned **c_h,  unsigned **c_d, 
const unsigned nv,  const unsigned mem_size_V, 
const unsigned infinito) {

(*c_h) = ((unsigned *)(malloc(mem_size_V)));

(((*c_h))[0]) = 0U; {
auto unsigned i;
#line 38 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*c_h))[i]) = infinito; } }


cudaMalloc(((void **)c_d), mem_size_V);

_Z9copiarH2DPvPKvj(((void *)((*c_d))), ((const void *)((void *)((*c_h)))), mem_size_V); 



}



void _Z22inicializar_PendientesRPbS0_jj( char **p_h,  char **p_d, 
const unsigned nv,  const unsigned mem_size_F) {

(*p_h) = ((char *)(malloc(mem_size_F)));

(((*p_h))[0]) = ((char)0); {
auto unsigned i;
#line 57 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*p_h))[i]) = ((char)1); } }


cudaMalloc(((void **)p_d), mem_size_F);

_Z9copiarH2DPvPKvj(((void *)((*p_d))), ((const void *)((void *)((*p_h)))), mem_size_F); 




}


void _Z20inicializar_FronteraRPbS0_jj( char **f_h,  char **f_d, 
const unsigned nv,  const unsigned mem_size_F) {

(*f_h) = ((char *)(malloc(mem_size_F)));

(((*f_h))[0]) = ((char)1); {
auto unsigned i;
#line 76 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
i = 1U; for (; (i <= (nv - 1U)); i++) { (((*f_h))[i]) = ((char)0); } }


cudaMalloc(((void **)f_d), mem_size_F);

_Z9copiarH2DPvPKvj(((void *)((*f_d))), ((const void *)((void *)((*f_h)))), mem_size_F); 
#line 87 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
}
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
char _Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
char *p_h,  char *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
char *p_d,  char *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned shared_mem;
#line 79 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned min;
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
shared_mem = (((threads.x)) * 5U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(nv, m_d, ((const char *)p_d), ((const char *)f_d), c_d));


cudaThreadSynchronize();
#line 72 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(((const char *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 90 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned i;
#line 90 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 111 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 127 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
return (char)(min == infinito);
}


void _Z15testGraph_SSSP7jjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T216;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto char *f_h;
auto char *f_d;
auto unsigned mem_size_F;


auto char *p_h;
auto char *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto unsigned timer;





auto char ultima;
auto unsigned i;
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
auto enum CUTBoolean res;
#line 139 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T216 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T216; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 165 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((char)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z23ejecutarIteracion_SSSP7j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 201 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
char _Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
char *p_h,  char *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
char *p_d,  char *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned shared_mem;
#line 81 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned min;
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
shared_mem = (((threads.x)) * 5U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub___globfunc__Z15kernel1_SSSP7_TjPj(nv, c_d));



cudaThreadSynchronize();
#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(((const char *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned i;
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 129 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
return (char)(min == infinito);
}


void _Z17testGraph_SSSP7_TjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T217;

auto unsigned *m_d;
#line 145 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto char *f_h;
auto char *f_d;
auto unsigned mem_size_F;


auto char *p_h;
auto char *p_d;
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto unsigned timer;





auto char ultima;
auto unsigned i;
#line 242 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
auto enum CUTBoolean res;
#line 140 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));


_Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)), ((const void *)m_d), mem_size_M);



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)), ((const void *)p_d), mem_size_F);
_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)), ((const void *)f_d), mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T217 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T217; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 174 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((char)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z25ejecutarIteracion_SSSP7_Tj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);


_Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)));


cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));



_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)));
_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));


free(((void *)c_h)); 

}
#line 254 "C:\\CUDA\\include\\cuda_runtime.h"
 /* COMDAT group: _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj */ __inline cudaError_t _Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(
size_t *offset, 
const _Z7textureIiLi1EL19cudaTextureReadMode0EE *tex, 
const void *devPtr, 
size_t size)

{
return cudaBindTexture(offset, (&tex->__b_16textureReference), devPtr, (&(tex->__b_16textureReference).channelDesc), size);
}
#line 254 "C:\\CUDA\\include\\cuda_runtime.h"
 /* COMDAT group: _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj */ __inline cudaError_t _Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(
size_t *offset, 
const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *tex, 
const void *devPtr, 
size_t size)

{
return cudaBindTexture(offset, (&tex->__b_16textureReference), devPtr, (&(tex->__b_16textureReference).channelDesc), size);
}
#line 293 "C:\\CUDA\\include\\cuda_runtime.h"
 /* COMDAT group: _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE */ __inline cudaError_t _Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(
const _Z7textureIiLi1EL19cudaTextureReadMode0EE *tex)

{
return cudaUnbindTexture((&tex->__b_16textureReference));
}
#line 293 "C:\\CUDA\\include\\cuda_runtime.h"
 /* COMDAT group: _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE */ __inline cudaError_t _Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(
const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *tex)

{
return cudaUnbindTexture((&tex->__b_16textureReference));
}
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
char _Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
char *p_h,  char *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
char *p_d,  char *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned shared_mem;
#line 81 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned min;
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
shared_mem = (((threads.x)) * 21U);
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), shared_mem, 0))) ? ((void)0) : (__device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(nv, c_d));



cudaThreadSynchronize();
#line 74 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(((const char *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned i;
#line 92 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 129 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
return (char)(min == infinito);
}


void _Z18testGraph_SSSP7_RTjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T218;

auto unsigned *m_d;
#line 145 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto char *f_h;
auto char *f_d;
auto unsigned mem_size_F;


auto char *p_h;
auto char *p_d;
#line 166 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto unsigned timer;





auto char ultima;
auto unsigned i;
#line 242 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
auto enum CUTBoolean res;
#line 140 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));


_Z15cudaBindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)), ((const void *)m_d), mem_size_M);



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)), ((const void *)p_d), mem_size_F);
_Z15cudaBindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorPjRK7textureIT_XT0_EXT1_EEPKvj(((size_t *)0), ((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)), ((const void *)f_d), mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T218 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T218; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 174 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 190 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((char)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z26ejecutarIteracion_SSSP7_RTj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 211 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);


_Z17cudaUnbindTextureIiLi1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureIiLi1EL19cudaTextureReadMode0EE *)(&textura_m)));


cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));



_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_p)));
_Z17cudaUnbindTextureI5char1Li1EL19cudaTextureReadMode0EE9cudaErrorRK7textureIT_XT0_EXT1_EE(((const _Z7textureI5char1Li1EL19cudaTextureReadMode0EE *)(&textura_f)));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));


free(((void *)c_h)); 

}
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
char _Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
char *p_h,  char *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
char *p_d,  char *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 80 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned min;
#line 48 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), (((threads.x)) * 1U), 0))) ? ((void)0) : (__device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(nv, m_d, ((const char *)p_d), ((const char *)f_d), c_d));


cudaThreadSynchronize();
#line 73 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(((const char *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 91 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned i;
#line 91 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 131 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
return (char)(min == infinito);
}


void _Z15testGraph_SSSP9jjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T219;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto char *f_h;
auto char *f_d;
auto unsigned mem_size_F;


auto char *p_h;
auto char *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 185 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto unsigned timer;





auto char ultima;
auto unsigned i;
#line 229 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
auto enum CUTBoolean res;
#line 143 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T219 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T219; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 169 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 185 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((char)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z23ejecutarIteracion_SSSP9j4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 205 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
char _Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(
const unsigned nVuelta, 
const dim3 grid,  const dim3 threads,  const dim3 grid_minimizar, 
const unsigned nv,  const unsigned mem_size_M, 
const unsigned mem_size_C,  const unsigned mem_size_F,  const unsigned mem_size_Minimizar, 
const unsigned infinito, 
char *p_h,  char *f_h,  unsigned *c_h, 
unsigned *minimoDelBloque_h, 
const unsigned *m_d, 
char *p_d,  char *f_d,  unsigned *c_d, 
unsigned *minimoDelBloque_d) {
#line 78 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned min;
#line 47 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), (((threads.x)) * 1U), 0))) ? ((void)0) : (__device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(nv, m_d, ((const char *)p_d), ((const char *)f_d), c_d));


cudaThreadSynchronize();
#line 71 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid_minimizar)))), ((*((dim3 *)(&threads)))), (4U * ((threads.x))), 0))) ? ((void)0) : (__device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(((const char *)p_d), ((const unsigned *)c_d), infinito, minimoDelBloque_d));



cudaThreadSynchronize();

_Z9copiarD2HPvPKvj(((void *)minimoDelBloque_h), ((const void *)((void *)minimoDelBloque_d)), mem_size_Minimizar);
min = infinito; {
#line 89 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned i;
#line 89 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) {
if (min > (minimoDelBloque_h[i])) { min = (minimoDelBloque_h[i]); }
} }
#line 110 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
((int)(cudaConfigureCall(((*((dim3 *)(&grid)))), ((*((dim3 *)(&threads)))), 0U, 0))) ? ((void)0) : (__device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, ((const unsigned *)c_d), min));


cudaThreadSynchronize();
#line 126 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
return (char)(min == infinito);
}



void _Z22testGraph_SSSP9_AtomicjjjjPKjS0_( const unsigned nv,  const unsigned mem_size_M, 
const unsigned infinito,  unsigned num_threadsInBlock, 
const unsigned *m_h,  const unsigned *reference) { auto unsigned __T220;


auto unsigned *m_d;




auto unsigned *c_h;
auto unsigned *c_d;
auto unsigned mem_size_C;


auto char *f_h;
auto char *f_d;
auto unsigned mem_size_F;


auto char *p_h;
auto char *p_d;




auto unsigned num_blocksInGrid;
auto dim3 grid;
auto dim3 threads;
auto dim3 grid_minimizar;


auto unsigned mem_size_Minimizar;
auto unsigned *minimoDelBloque_h;

auto unsigned *minimoDelBloque_d;
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto unsigned timer;





auto char ultima;
auto unsigned i;
#line 225 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
auto enum CUTBoolean res;
#line 139 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
_Z25inicializar_Matriz_DevicePKjjRPj(m_h, mem_size_M, (&m_d));



mem_size_C = (nv * 4U);
_Z15inicializar_SolRPjS0_jjj((&c_h), (&c_d), nv, mem_size_C, infinito);



mem_size_F = (1U * nv);
_Z20inicializar_FronteraRPbS0_jj((&f_h), (&f_d), nv, mem_size_F);



_Z22inicializar_PendientesRPbS0_jj((&p_h), (&p_d), nv, mem_size_F);



num_blocksInGrid = (nv / num_threadsInBlock);
{ (grid.x) = num_blocksInGrid; (grid.y) = 1U; (grid.z) = 1U; }
{ (threads.x) = num_threadsInBlock; (threads.y) = 1U; (threads.z) = 1U; }
{ __T220 = (num_blocksInGrid / 2U); { (grid_minimizar.x) = __T220; (grid_minimizar.y) = 1U; (grid_minimizar.z) = 1U; } }


mem_size_Minimizar = (4U * ((grid_minimizar.x)));
minimoDelBloque_h = ((unsigned *)(malloc(mem_size_Minimizar))); {
auto unsigned i;
#line 165 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
i = 0U; for (; (i < ((grid_minimizar.x))); i++) { (minimoDelBloque_h[i]) = infinito; } }

cudaMalloc(((void **)(&minimoDelBloque_d)), mem_size_Minimizar);
_Z9copiarH2DPvPKvj(((void *)minimoDelBloque_d), ((const void *)((void *)minimoDelBloque_h)), mem_size_Minimizar);
#line 181 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);



ultima = ((char)0);
i = 0U;
while (!((int)ultima)) {
i++;
ultima = (_Z30ejecutarIteracion_SSSP9_Atomicj4dim3S_S_jjjjjjPbS0_PjS1_PKjS0_S0_S1_S1_(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, ((const unsigned *)m_d), p_d, f_d, c_d, minimoDelBloque_d));
#line 201 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
}

cutStopTimer(timer);
printf("%f\t%d\t", ((double)(cutGetTimerValue(timer))), i);
cutDeleteTimer(timer);

_Z9copiarD2HPvPKvj(((void *)c_h), ((const void *)((void *)c_d)), mem_size_C);



cudaFree(((void *)m_d));

free(((void *)f_h));
free(((void *)p_h));

cudaFree(((void *)c_d));
cudaFree(((void *)f_d));
cudaFree(((void *)p_d));

free(((void *)minimoDelBloque_h));

cudaFree(((void *)minimoDelBloque_d));


res = (cutComparei(((const int *)((int *)reference)), ((const int *)((int *)c_h)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));



free(((void *)c_h)); 

}
#line 85 "template.cu"
int __cdecl main( int argc,  char **argv)
{

{ auto int deviceCount;
#line 88 "template.cu"
auto int dev;
#line 88 "template.cu"
auto struct cudaDeviceProp deviceProp;
#line 88 "template.cu"
cudaGetDeviceCount((&deviceCount)); if (deviceCount == 0) { fprintf(((__iob_func()) + 2), "cutil error: no devices supporting CUDA.\n"); exit(1); } dev = 0; cutGetCmdLineArgumenti(argc, ((const char **)argv), "device", (&dev)); if (dev > (deviceCount - 1)) { dev = (deviceCount - 1); } cudaGetDeviceProperties((&deviceProp), dev); if (((deviceProp.major)) < 1) { fprintf(((__iob_func()) + 2), "cutil error: device does not support CUDA.\n"); exit(1); } if (((int)(cutCheckCmdLineFlag(argc, ((const char **)argv), "quiet"))) == 0) { fprintf(((__iob_func()) + 2), "Using device %d: %s\n", dev, ((char *)(&deviceProp.name))); } cudaSetDevice(dev); }

srand(((unsigned)(_time64(((time_t *)0)))));




_Z5runFHv();
#line 111 "template.cu"
printf("\n\n");
printf((cudaGetErrorString((cudaGetLastError()))));
printf("\n\n");

if (!((int)(cutCheckCmdLineFlag(argc, ((const char **)argv), "noprompt")))) { printf("\nPress ENTER to exit...\n"); fflush(((__iob_func()) + 1)); fflush(((__iob_func()) + 2)); getchar(); } exit(0); return 0;

}




void _Z27generar_Matrices_Adyacenciav(void) {

auto unsigned nv;
auto unsigned *m;
auto unsigned mem_size_M;

auto unsigned degree;
auto unsigned topeW;
auto unsigned infinito;


auto char s[100];

auto unsigned timer;
#line 129 "template.cu"
topeW = 10U;
#line 137 "template.cu"
printf("Generando y Guardando Matrices de Adyacencia\n"); {

auto unsigned k;
#line 139 "template.cu"
k = 1U; for (; (k <= 15U); k++) {
nv = (k * 1024U);
degree = (nv / 5U);
infinito = (nv * 10U);
printf("\n\nNODOS= %d * 1024\n", k);
printf("topeW= %i\n", 10);
printf("degree= nv/%i= %i\n", 5, degree);
printf("infinito= nv*%i= %i\n\n", 10, infinito);

printf("Matriz\t Generar\t Guardar\n"); {
auto unsigned i;
#line 149 "template.cu"
i = 1U; for (; (i <= 25U); i++) {

printf("%i\t", i);

if (i < 10U) { _Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else  {
_Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }



timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

_Z19genera_M_AdyacenciajjjjRjRPj(nv, degree, topeW, infinito, (&mem_size_M), (&m));

cutStopTimer(timer);
printf("%f\t", ((double)(cutGetTimerValue(timer))));
cutDeleteTimer(timer);

timer = 0U;
cutCreateTimer((&timer));
cutStartTimer(timer);

_Z21guardaMatriz_FicheroBPKcjjPKj(((const char *)((char *)s)), nv, mem_size_M, ((const unsigned *)m));

cutStopTimer(timer);
printf("%f\n", ((double)(cutGetTimerValue(timer))));
cutDeleteTimer(timer);


free(((void *)m));

} }

} } 

}
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
 /* COMDAT group: _Z9sprintf_sILj100EEiRAT__cPKcz */ __inline int __cdecl _Z9sprintf_sILj100EEiRAT__cPKcz( char (*_Dest)[100],  const char *_Format, ...) { auto va_list _ArgList;
#line 309 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
_ArgList = (((va_list)((const char *)(&_Format))) + 4U); return vsprintf_s(((char *)_Dest), 100U, _Format, _ArgList); }
#line 188 "template.cu"
void _Z7runTestv(void) {


auto unsigned nv;
auto unsigned *m;
auto unsigned mem_size_M;

auto unsigned topeW;
auto unsigned infinito;


auto unsigned *reference1;
auto unsigned *reference2;
#line 209 "template.cu"
auto char s[100];
#line 195 "template.cu"
topeW = 10U;
#line 204 "template.cu"
printf("TEST SSSP7, SSSP9\n\n");
printf("degree= nv/%i\n", 5);
printf("topeW= %i\n", topeW); {




auto unsigned t;
#line 211 "template.cu"
t = 1U; for (; (t <= 1U); t++) {

printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); {

auto unsigned k;
#line 215 "template.cu"
k = 7U; for (; (k <= 15U); k++) {
printf("\n\nNODOS= %i * 1024\n\n", k);
printf("Grafo\t CPU7\t\t\t CPU9\t\t\t SSSP7\t\t\t SSSP9_Atomic\t\t\t SSSP9\t\t\t SSSP7_T\t\t\t SSSP7_RT\n\n");
nv = (k * 1024U);
infinito = (nv * 10U); {

auto int i;
#line 221 "template.cu"
i = 1; for (; (i <= 25); i++) {
#line 242 "template.cu"
auto enum CUTBoolean res;
#line 223 "template.cu"
printf("%i\t", i);

if (i < 10) { _Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else  {
_Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }
#line 232 "template.cu"
_Z18leeMatriz_FicheroBPKcRjS1_RPj(((const char *)((char *)s)), (&nv), (&mem_size_M), (&m));


reference1 = ((unsigned *)(malloc((nv * 4U))));
_Z16computeGold_CPU7PjjPKjj(reference1, nv, ((const unsigned *)m), infinito);

reference2 = ((unsigned *)(malloc((nv * 4U))));
_Z16computeGold_CPU9PjjPKjj(reference2, nv, ((const unsigned *)m), infinito);


res = (cutComparei(((const int *)((int *)reference1)), ((const int *)((int *)reference2)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));

free(((void *)reference2));


_Z15testGraph_SSSP7jjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z22testGraph_SSSP9_AtomicjjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z15testGraph_SSSP9jjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z17testGraph_SSSP7_TjjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

_Z18testGraph_SSSP7_RTjjjjPKjS0_(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, ((const unsigned *)m), ((const unsigned *)reference1));

printf("\n");


free(((void *)m));
free(((void *)reference1));

} }

} }

NUM_THREADS_IN_BLOCK = (NUM_THREADS_IN_BLOCK * 2U);

} } 
}


void _Z5runFHv(void) {


auto unsigned nv;
auto unsigned *m;
auto unsigned mem_size_M;

auto unsigned topeW;
auto unsigned infinito;


auto unsigned *reference1;
auto unsigned *reference2;
#line 295 "template.cu"
auto char s[100];
#line 281 "template.cu"
topeW = 10U;
#line 290 "template.cu"
printf("TEST SSSP MATRICES\n\n");
printf("degree= nv/%i\n", 5);
printf("topeW= %i\n", topeW);




printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); {

auto unsigned k;
#line 299 "template.cu"
k = 1U; for (; (k <= 15U); k++) {
printf("\n\nNODOS= %i * 1024\n\n", k);
printf("Grafo\t CPU7\t\t\t FH\n\n");
nv = (k * 1024U);
infinito = (nv * 10U); {

auto int i;
#line 305 "template.cu"
i = 1; for (; (i <= 25); i++) {
#line 325 "template.cu"
auto enum CUTBoolean res;
#line 307 "template.cu"
printf("%i\t", i);

if (i < 10) { _Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else  {
_Z9sprintf_sILj100EEiRAT__cPKcz((&s), "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }



_Z18leeMatriz_FicheroBPKcRjS1_RPj(((const char *)((char *)s)), (&nv), (&mem_size_M), (&m));


reference1 = ((unsigned *)(malloc((nv * 4U))));
_Z16computeGold_CPU7PjjPKjj(reference1, nv, ((const unsigned *)m), infinito);

reference2 = ((unsigned *)(malloc((nv * 4U))));
_Z14computeGold_FHPjjPKjj(reference2, nv, ((const unsigned *)m), infinito);



res = (cutComparei(((const int *)((int *)reference1)), ((const int *)((int *)reference2)), nv));
printf("%s\t", ((1 == ((int)res)) ? "OK" : "FAILED"));

printf("\n");


free(((void *)m));
free(((void *)reference1));
free(((void *)reference2));


} }

} } 

}
static void __sti___16_template_cpp1_ii_a6b7a973(void) { auto int __T275;
auto int __T276;
auto int __T277;
#line 47 "template.cu"
{ ((textura_m.__b_16textureReference).normalized) = 0; ((textura_m.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_m.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_m.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_m.__b_16textureReference).addressMode))[2]) = cudaAddressModeClamp; ((textura_m.__b_16textureReference).channelDesc) = ((__T275 = 32) , (cudaCreateChannelDesc(__T275, 0, 0, 0, cudaChannelFormatKindSigned))); }



{ ((textura_p.__b_16textureReference).normalized) = 0; ((textura_p.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_p.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_p.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_p.__b_16textureReference).addressMode))[2]) = cudaAddressModeClamp; ((textura_p.__b_16textureReference).channelDesc) = ((__T276 = 8) , (cudaCreateChannelDesc(__T276, 0, 0, 0, cudaChannelFormatKindSigned))); }
{ ((textura_f.__b_16textureReference).normalized) = 0; ((textura_f.__b_16textureReference).filterMode) = cudaFilterModePoint; (((enum cudaTextureAddressMode *)(&(textura_f.__b_16textureReference).addressMode))[0]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_f.__b_16textureReference).addressMode))[1]) = cudaAddressModeClamp; (((enum cudaTextureAddressMode *)(&(textura_f.__b_16textureReference).addressMode))[2]) = cudaAddressModeClamp; ((textura_f.__b_16textureReference).channelDesc) = ((__T277 = 8) , (cudaCreateChannelDesc(__T277, 0, 0, 0, cudaChannelFormatKindSigned))); }  }

#include "template.cudafe1.stub.c"
