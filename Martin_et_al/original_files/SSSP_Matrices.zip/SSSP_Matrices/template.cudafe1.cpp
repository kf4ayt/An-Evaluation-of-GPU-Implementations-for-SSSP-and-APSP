#line 1 "template.cu"
#line 89 "c:\\cuda\\include\\host_config.h"
class type_info; 
#if 0
#line 46 "c:\\cuda\\include\\device_types.h"
enum cudaRoundMode { 
#line 48
cudaRoundNearest, 
#line 49
cudaRoundZero, 
#line 50
cudaRoundPosInf, 
#line 51
cudaRoundMinInf
#line 52
}; 
#endif
#line 147 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#pragma pack ( push, 8 )
#line 32 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
#pragma pack ( push, 8 )
#line 52 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
extern "C" { typedef unsigned __w64 uintptr_t; }
#line 61 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
extern "C" { typedef char *va_list; }
#line 151 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\vadefs.h"
#pragma pack ( pop )
#line 432 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
typedef unsigned size_t; 
#include "crt/host_runtime.h"
#line 439 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef size_t rsize_t; }
#line 448 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int __w64 intptr_t; }
#line 466 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int __w64 ptrdiff_t; }
#line 477 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef unsigned short wint_t; }
#line 478
extern "C" { typedef unsigned short wctype_t; }
#line 506 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int errcode; }
#line 511 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef int errno_t; }
#line 515 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef long __w64 __time32_t; }
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef __int64 __time64_t; }
#line 530 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef __time64_t time_t; }
#line 1702 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
struct threadlocaleinfostruct; 
#line 1703
struct threadmbcinfostruct; 
#line 1704
extern "C" { typedef threadlocaleinfostruct *pthreadlocinfo; }
#line 1705
extern "C" { typedef threadmbcinfostruct *pthreadmbcinfo; }
#line 1706
struct __lc_time_data; 
#line 1712
extern "C" { typedef 
#line 1708
struct localeinfo_struct { 
#line 1710
pthreadlocinfo locinfo; 
#line 1711
pthreadmbcinfo mbcinfo; 
#line 1712
} _locale_tstruct; }extern "C" { typedef localeinfo_struct *_locale_t; }
#line 1719
extern "C" { typedef 
#line 1715
struct tagLC_ID { 
#line 1716
unsigned short wLanguage; 
#line 1717
unsigned short wCountry; 
#line 1718
unsigned short wCodePage; 
#line 1719
} LC_ID; }extern "C" { typedef tagLC_ID *LPLC_ID; }
#line 1748 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
extern "C" { typedef 
#line 1724
struct threadlocaleinfostruct { 
#line 1725
int refcount; 
#line 1726
unsigned lc_codepage; 
#line 1727
unsigned lc_collate_cp; 
#line 1728
unsigned long lc_handle[6]; 
#line 1729
LC_ID lc_id[6]; 
#line 1730
struct { 
#line 1731
char *locale; 
#line 1732
__wchar_t *wlocale; 
#line 1733
int *refcount; 
#line 1734
int *wrefcount; 
#line 1735
} lc_category[6]; 
#line 1736
int lc_clike; 
#line 1737
int mb_cur_max; 
#line 1738
int *lconv_intl_refcount; 
#line 1739
int *lconv_num_refcount; 
#line 1740
int *lconv_mon_refcount; 
#line 1741
struct lconv *lconv; 
#line 1742
int *ctype1_refcount; 
#line 1743
unsigned short *ctype1; 
#line 1744
const unsigned short *pctype; 
#line 1745
const unsigned char *pclmap; 
#line 1746
const unsigned char *pcumap; 
#line 1747
__lc_time_data *lc_time_curr; 
#line 1748
} threadlocinfo; }
#line 1786 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\crtdefs.h"
#pragma pack ( pop )
#line 41 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern int *__cdecl _errno(); } 
#line 44
extern "C" { extern errno_t __cdecl _set_errno(int); } 
#line 45
extern "C" { extern errno_t __cdecl _get_errno(int *); } 
#line 68 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stddef.h"
extern "C" { extern unsigned long __cdecl __threadid(); } 
#line 70
extern "C" { extern uintptr_t __cdecl __threadhandle(); } 
#if 0
#line 59 "c:\\cuda\\include\\driver_types.h"
enum cudaError { 
#line 61
cudaSuccess, 
#line 62
cudaErrorMissingConfiguration, 
#line 63
cudaErrorMemoryAllocation, 
#line 64
cudaErrorInitializationError, 
#line 65
cudaErrorLaunchFailure, 
#line 66
cudaErrorPriorLaunchFailure, 
#line 67
cudaErrorLaunchTimeout, 
#line 68
cudaErrorLaunchOutOfResources, 
#line 69
cudaErrorInvalidDeviceFunction, 
#line 70
cudaErrorInvalidConfiguration, 
#line 71
cudaErrorInvalidDevice, 
#line 72
cudaErrorInvalidValue, 
#line 73
cudaErrorInvalidPitchValue, 
#line 74
cudaErrorInvalidSymbol, 
#line 75
cudaErrorMapBufferObjectFailed, 
#line 76
cudaErrorUnmapBufferObjectFailed, 
#line 77
cudaErrorInvalidHostPointer, 
#line 78
cudaErrorInvalidDevicePointer, 
#line 79
cudaErrorInvalidTexture, 
#line 80
cudaErrorInvalidTextureBinding, 
#line 81
cudaErrorInvalidChannelDescriptor, 
#line 82
cudaErrorInvalidMemcpyDirection, 
#line 83
cudaErrorAddressOfConstant, 
#line 84
cudaErrorTextureFetchFailed, 
#line 85
cudaErrorTextureNotBound, 
#line 86
cudaErrorSynchronizationError, 
#line 87
cudaErrorInvalidFilterSetting, 
#line 88
cudaErrorInvalidNormSetting, 
#line 89
cudaErrorMixedDeviceExecution, 
#line 90
cudaErrorCudartUnloading, 
#line 91
cudaErrorUnknown, 
#line 92
cudaErrorNotYetImplemented, 
#line 93
cudaErrorMemoryValueTooLarge, 
#line 94
cudaErrorInvalidResourceHandle, 
#line 95
cudaErrorNotReady, 
#line 96
cudaErrorStartupFailure = 127, 
#line 97
cudaErrorApiFailureBase = 10000
#line 98
}; 
#endif
#if 0
enum cudaChannelFormatKind { 
#line 103
cudaChannelFormatKindSigned, 
#line 104
cudaChannelFormatKindUnsigned, 
#line 105
cudaChannelFormatKindFloat
#line 106
}; 
#endif
#if 0
struct cudaChannelFormatDesc { 
#line 111
int x; 
#line 112
int y; 
#line 113
int z; 
#line 114
int w; 
#line 115
cudaChannelFormatKind f; 
#line 116
}; 
#endif
#if 0
struct cudaArray; 
#endif
#if 0
enum cudaMemcpyKind { 
#line 124
cudaMemcpyHostToHost, 
#line 125
cudaMemcpyHostToDevice, 
#line 126
cudaMemcpyDeviceToHost, 
#line 127
cudaMemcpyDeviceToDevice
#line 128
}; 
#endif
#if 0
struct cudaPitchedPtr { 
#line 133
void *ptr; 
#line 134
size_t pitch; 
#line 135
size_t xsize; 
#line 136
size_t ysize; 
#line 137
}; 
#endif
#if 0
struct cudaExtent { 
#line 142
size_t width; 
#line 143
size_t height; 
#line 144
size_t depth; 
#line 145
}; 
#endif
#if 0
struct cudaPos { 
#line 150
size_t x; 
#line 151
size_t y; 
#line 152
size_t z; 
#line 153
}; 
#endif
#if 0
struct cudaMemcpy3DParms { 
#line 158
cudaArray *srcArray; 
#line 159
cudaPos srcPos; 
#line 160
cudaPitchedPtr srcPtr; 
#line 162
cudaArray *dstArray; 
#line 163
cudaPos dstPos; 
#line 164
cudaPitchedPtr dstPtr; 
#line 166
cudaExtent extent; 
#line 167
cudaMemcpyKind kind; 
#line 168
}; 
#endif
#if 0
struct cudaDeviceProp { 
#line 173
char name[256]; 
#line 174
size_t totalGlobalMem; 
#line 175
size_t sharedMemPerBlock; 
#line 176
int regsPerBlock; 
#line 177
int warpSize; 
#line 178
size_t memPitch; 
#line 179
int maxThreadsPerBlock; 
#line 180
int maxThreadsDim[3]; 
#line 181
int maxGridSize[3]; 
#line 182
int clockRate; 
#line 183
size_t totalConstMem; 
#line 184
int major; 
#line 185
int minor; 
#line 186
size_t textureAlignment; 
#line 187
int deviceOverlap; 
#line 188
int multiProcessorCount; 
#line 189
int __cudaReserved[40]; 
#line 190
}; 
#endif
#if 0
#line 219
typedef cudaError cudaError_t; 
#endif
#if 0
typedef int cudaStream_t; 
#endif
#if 0
typedef int cudaEvent_t; 
#endif
#if 0
#line 46 "c:\\cuda\\include\\texture_types.h"
enum cudaTextureAddressMode { 
#line 48
cudaAddressModeWrap, 
#line 49
cudaAddressModeClamp
#line 50
}; 
#endif
#if 0
enum cudaTextureFilterMode { 
#line 55
cudaFilterModePoint, 
#line 56
cudaFilterModeLinear
#line 57
}; 
#endif
#if 0
enum cudaTextureReadMode { 
#line 62
cudaReadModeElementType, 
#line 63
cudaReadModeNormalizedFloat
#line 64
}; 
#endif
#if 0
struct textureReference { 
#line 69
int normalized; 
#line 70
cudaTextureFilterMode filterMode; 
#line 71
cudaTextureAddressMode addressMode[3]; 
#line 72
cudaChannelFormatDesc channelDesc; 
#line 73
int __cudaReserved[16]; 
#line 74
}; 
#endif
#if 0
#line 54 "c:\\cuda\\include\\vector_types.h"
struct char1 { 
#line 56
signed char x; 
#line 57
}; 
#endif
#if 0
struct uchar1 { 
#line 62
unsigned char x; 
#line 63
}; 
#endif
#if 0
struct __declspec(align(2)) char2 { 
#line 68
signed char x; signed char y; 
#line 69
}; 
#endif
#if 0
struct __declspec(align(2)) uchar2 { 
#line 74
unsigned char x; unsigned char y; 
#line 75
}; 
#endif
#if 0
struct char3 { 
#line 80
signed char x; signed char y; signed char z; 
#line 81
}; 
#endif
#if 0
struct uchar3 { 
#line 86
unsigned char x; unsigned char y; unsigned char z; 
#line 87
}; 
#endif
#if 0
struct __declspec(align(4)) char4 { 
#line 92
signed char x; signed char y; signed char z; signed char w; 
#line 93
}; 
#endif
#if 0
struct __declspec(align(4)) uchar4 { 
#line 98
unsigned char x; unsigned char y; unsigned char z; unsigned char w; 
#line 99
}; 
#endif
#if 0
struct short1 { 
#line 104
short x; 
#line 105
}; 
#endif
#if 0
struct ushort1 { 
#line 110
unsigned short x; 
#line 111
}; 
#endif
#if 0
struct __declspec(align(4)) short2 { 
#line 116
short x; short y; 
#line 117
}; 
#endif
#if 0
struct __declspec(align(4)) ushort2 { 
#line 122
unsigned short x; unsigned short y; 
#line 123
}; 
#endif
#if 0
struct short3 { 
#line 128
short x; short y; short z; 
#line 129
}; 
#endif
#if 0
struct ushort3 { 
#line 134
unsigned short x; unsigned short y; unsigned short z; 
#line 135
}; 
#endif
#if 0
struct __declspec(align(8)) short4 { 
#line 140
short x; short y; short z; short w; 
#line 141
}; 
#endif
#if 0
struct __declspec(align(8)) ushort4 { 
#line 146
unsigned short x; unsigned short y; unsigned short z; unsigned short w; 
#line 147
}; 
#endif
#if 0
struct int1 { 
#line 152
int x; 
#line 153
}; 
#endif
#if 0
struct uint1 { 
#line 158
unsigned x; 
#line 159
}; 
#endif
#if 0
struct __declspec(align(8)) int2 { 
#line 164
int x; int y; 
#line 165
}; 
#endif
#if 0
struct __declspec(align(8)) uint2 { 
#line 170
unsigned x; unsigned y; 
#line 171
}; 
#endif
#if 0
struct int3 { 
#line 176
int x; int y; int z; 
#line 177
}; 
#endif
#if 0
struct uint3 { 
#line 182
unsigned x; unsigned y; unsigned z; 
#line 183
}; 
#endif
#if 0
struct __declspec(align(16)) int4 { 
#line 188
int x; int y; int z; int w; 
#line 189
}; 
#endif
#if 0
struct __declspec(align(16)) uint4 { 
#line 194
unsigned x; unsigned y; unsigned z; unsigned w; 
#line 195
}; 
#endif
#if 0
struct long1 { 
#line 200
long x; 
#line 201
}; 
#endif
#if 0
struct ulong1 { 
#line 206
unsigned long x; 
#line 207
}; 
#endif
#if 0
#line 216 "c:\\cuda\\include\\vector_types.h"
struct __declspec(align(8)) long2 { 
#line 218
long x; long y; 
#line 219
}; 
#endif
#if 0
#line 228 "c:\\cuda\\include\\vector_types.h"
struct __declspec(align(8)) ulong2 { 
#line 230
unsigned long x; unsigned long y; 
#line 231
}; 
#endif
#if 0
#line 236
struct long3 { 
#line 238
long x; long y; long z; 
#line 239
}; 
#endif
#if 0
struct ulong3 { 
#line 244
unsigned long x; unsigned long y; unsigned long z; 
#line 245
}; 
#endif
#if 0
struct __declspec(align(16)) long4 { 
#line 250
long x; long y; long z; long w; 
#line 251
}; 
#endif
#if 0
struct __declspec(align(16)) ulong4 { 
#line 256
unsigned long x; unsigned long y; unsigned long z; unsigned long w; 
#line 257
}; 
#endif
#if 0
#line 262 "c:\\cuda\\include\\vector_types.h"
struct float1 { 
#line 264
float x; 
#line 265
}; 
#endif
#if 0
struct __declspec(align(8)) float2 { 
#line 270
float x; float y; 
#line 271
}; 
#endif
#if 0
struct float3 { 
#line 276
float x; float y; float z; 
#line 277
}; 
#endif
#if 0
struct __declspec(align(16)) float4 { 
#line 282
float x; float y; float z; float w; 
#line 283
}; 
#endif
#if 0
struct double1 { 
#line 288
double x; 
#line 289
}; 
#endif
#if 0
struct __declspec(align(16)) double2 { 
#line 294
double x; double y; 
#line 295
}; 
#endif
#if 0
#line 304
typedef char1 char1; 
#endif
#if 0
#line 306
typedef uchar1 uchar1; 
#endif
#if 0
#line 308
typedef char2 char2; 
#endif
#if 0
#line 310
typedef uchar2 uchar2; 
#endif
#if 0
#line 312
typedef char3 char3; 
#endif
#if 0
#line 314
typedef uchar3 uchar3; 
#endif
#if 0
#line 316
typedef char4 char4; 
#endif
#if 0
#line 318
typedef uchar4 uchar4; 
#endif
#if 0
#line 320
typedef short1 short1; 
#endif
#if 0
#line 322
typedef ushort1 ushort1; 
#endif
#if 0
#line 324
typedef short2 short2; 
#endif
#if 0
#line 326
typedef ushort2 ushort2; 
#endif
#if 0
#line 328
typedef short3 short3; 
#endif
#if 0
#line 330
typedef ushort3 ushort3; 
#endif
#if 0
#line 332
typedef short4 short4; 
#endif
#if 0
#line 334
typedef ushort4 ushort4; 
#endif
#if 0
#line 336
typedef int1 int1; 
#endif
#if 0
#line 338
typedef uint1 uint1; 
#endif
#if 0
#line 340
typedef int2 int2; 
#endif
#if 0
#line 342
typedef uint2 uint2; 
#endif
#if 0
#line 344
typedef int3 int3; 
#endif
#if 0
#line 346
typedef uint3 uint3; 
#endif
#if 0
#line 348
typedef int4 int4; 
#endif
#if 0
#line 350
typedef uint4 uint4; 
#endif
#if 0
#line 352
typedef long1 long1; 
#endif
#if 0
#line 354
typedef ulong1 ulong1; 
#endif
#if 0
#line 356
typedef long2 long2; 
#endif
#if 0
#line 358
typedef ulong2 ulong2; 
#endif
#if 0
#line 360
typedef long3 long3; 
#endif
#if 0
#line 362
typedef ulong3 ulong3; 
#endif
#if 0
#line 364
typedef long4 long4; 
#endif
#if 0
#line 366
typedef ulong4 ulong4; 
#endif
#if 0
#line 368
typedef float1 float1; 
#endif
#if 0
#line 370
typedef float2 float2; 
#endif
#if 0
#line 372
typedef float3 float3; 
#endif
#if 0
#line 374
typedef float4 float4; 
#endif
#if 0
#line 376
typedef double1 double1; 
#endif
#if 0
#line 378
typedef double2 double2; 
#endif
#if 0
#endif
#if 0
#line 387
typedef struct dim3 dim3; 
#endif
#if 0
struct dim3 { 
#line 392
unsigned x; unsigned y; unsigned z; 
#line 398 "c:\\cuda\\include\\vector_types.h"
}; 
#endif
#line 88 "c:\\cuda\\include\\cuda_runtime_api.h"
extern "C" { extern cudaError_t __stdcall cudaMalloc3D(cudaPitchedPtr *, cudaExtent); } 
#line 89
extern "C" { extern cudaError_t __stdcall cudaMalloc3DArray(cudaArray **, const cudaChannelFormatDesc *, cudaExtent); } 
#line 90
extern "C" { extern cudaError_t __stdcall cudaMemset3D(cudaPitchedPtr, int, cudaExtent); } 
#line 91
extern "C" { extern cudaError_t __stdcall cudaMemcpy3D(const cudaMemcpy3DParms *); } 
#line 92
extern "C" { extern cudaError_t __stdcall cudaMemcpy3DAsync(const cudaMemcpy3DParms *, cudaStream_t); } 
#line 101
extern "C" { extern cudaError_t __stdcall cudaMalloc(void **, size_t); } 
#line 102
extern "C" { extern cudaError_t __stdcall cudaMallocHost(void **, size_t); } 
#line 103
extern "C" { extern cudaError_t __stdcall cudaMallocPitch(void **, size_t *, size_t, size_t); } 
#line 104
extern "C" { extern cudaError_t __stdcall cudaMallocArray(cudaArray **, const cudaChannelFormatDesc *, size_t, size_t = (1)); } 
#line 105
extern "C" { extern cudaError_t __stdcall cudaFree(void *); } 
#line 106
extern "C" { extern cudaError_t __stdcall cudaFreeHost(void *); } 
#line 107
extern "C" { extern cudaError_t __stdcall cudaFreeArray(cudaArray *); } 
#line 116
extern "C" { extern cudaError_t __stdcall cudaMemcpy(void *, const void *, size_t, cudaMemcpyKind); } 
#line 117
extern "C" { extern cudaError_t __stdcall cudaMemcpyToArray(cudaArray *, size_t, size_t, const void *, size_t, cudaMemcpyKind); } 
#line 118
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromArray(void *, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 119
extern "C" { extern cudaError_t __stdcall cudaMemcpyArrayToArray(cudaArray *, size_t, size_t, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind = cudaMemcpyDeviceToDevice); } 
#line 120
extern "C" { extern cudaError_t __stdcall cudaMemcpy2D(void *, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 121
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DToArray(cudaArray *, size_t, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 122
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DFromArray(void *, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind); } 
#line 123
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DArrayToArray(cudaArray *, size_t, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind = cudaMemcpyDeviceToDevice); } 
#line 124
extern "C" { extern cudaError_t __stdcall cudaMemcpyToSymbol(const char *, const void *, size_t, size_t = (0), cudaMemcpyKind = cudaMemcpyHostToDevice); } 
#line 125
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromSymbol(void *, const char *, size_t, size_t = (0), cudaMemcpyKind = cudaMemcpyDeviceToHost); } 
#line 133
extern "C" { extern cudaError_t __stdcall cudaMemcpyAsync(void *, const void *, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 134
extern "C" { extern cudaError_t __stdcall cudaMemcpyToArrayAsync(cudaArray *, size_t, size_t, const void *, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 135
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromArrayAsync(void *, const cudaArray *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 136
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DAsync(void *, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 137
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DToArrayAsync(cudaArray *, size_t, size_t, const void *, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 138
extern "C" { extern cudaError_t __stdcall cudaMemcpy2DFromArrayAsync(void *, size_t, const cudaArray *, size_t, size_t, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 139
extern "C" { extern cudaError_t __stdcall cudaMemcpyToSymbolAsync(const char *, const void *, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 140
extern "C" { extern cudaError_t __stdcall cudaMemcpyFromSymbolAsync(void *, const char *, size_t, size_t, cudaMemcpyKind, cudaStream_t); } 
#line 148
extern "C" { extern cudaError_t __stdcall cudaMemset(void *, int, size_t); } 
#line 149
extern "C" { extern cudaError_t __stdcall cudaMemset2D(void *, size_t, int, size_t, size_t); } 
#line 157
extern "C" { extern cudaError_t __stdcall cudaGetSymbolAddress(void **, const char *); } 
#line 158
extern "C" { extern cudaError_t __stdcall cudaGetSymbolSize(size_t *, const char *); } 
#line 166
extern "C" { extern cudaError_t __stdcall cudaGetDeviceCount(int *); } 
#line 167
extern "C" { extern cudaError_t __stdcall cudaGetDeviceProperties(cudaDeviceProp *, int); } 
#line 168
extern "C" { extern cudaError_t __stdcall cudaChooseDevice(int *, const cudaDeviceProp *); } 
#line 169
extern "C" { extern cudaError_t __stdcall cudaSetDevice(int); } 
#line 170
extern "C" { extern cudaError_t __stdcall cudaGetDevice(int *); } 
#line 178
extern "C" { extern cudaError_t __stdcall cudaBindTexture(size_t *, const textureReference *, const void *, const cudaChannelFormatDesc *, size_t = (4294967295U)); } 
#line 179
extern "C" { extern cudaError_t __stdcall cudaBindTextureToArray(const textureReference *, const cudaArray *, const cudaChannelFormatDesc *); } 
#line 180
extern "C" { extern cudaError_t __stdcall cudaUnbindTexture(const textureReference *); } 
#line 181
extern "C" { extern cudaError_t __stdcall cudaGetTextureAlignmentOffset(size_t *, const textureReference *); } 
#line 182
extern "C" { extern cudaError_t __stdcall cudaGetTextureReference(const textureReference **, const char *); } 
#line 190
extern "C" { extern cudaError_t __stdcall cudaGetChannelDesc(cudaChannelFormatDesc *, const cudaArray *); } 
#line 191
extern "C" { extern cudaChannelFormatDesc __stdcall cudaCreateChannelDesc(int, int, int, int, cudaChannelFormatKind); } 
#line 199
extern "C" { extern cudaError_t __stdcall cudaGetLastError(); } 
#line 200
extern "C" { extern const char *__stdcall cudaGetErrorString(cudaError_t); } 
#line 208
extern "C" { extern cudaError_t __stdcall cudaConfigureCall(dim3, dim3, size_t = (0), cudaStream_t = (0)); } 
#line 209
extern "C" { extern cudaError_t __stdcall cudaSetupArgument(const void *, size_t, size_t); } 
#line 210
extern "C" { extern cudaError_t __stdcall cudaLaunch(const char *); } 
#line 218
extern "C" { extern cudaError_t __stdcall cudaStreamCreate(cudaStream_t *); } 
#line 219
extern "C" { extern cudaError_t __stdcall cudaStreamDestroy(cudaStream_t); } 
#line 220
extern "C" { extern cudaError_t __stdcall cudaStreamSynchronize(cudaStream_t); } 
#line 221
extern "C" { extern cudaError_t __stdcall cudaStreamQuery(cudaStream_t); } 
#line 229
extern "C" { extern cudaError_t __stdcall cudaEventCreate(cudaEvent_t *); } 
#line 230
extern "C" { extern cudaError_t __stdcall cudaEventRecord(cudaEvent_t, cudaStream_t); } 
#line 231
extern "C" { extern cudaError_t __stdcall cudaEventQuery(cudaEvent_t); } 
#line 232
extern "C" { extern cudaError_t __stdcall cudaEventSynchronize(cudaEvent_t); } 
#line 233
extern "C" { extern cudaError_t __stdcall cudaEventDestroy(cudaEvent_t); } 
#line 234
extern "C" { extern cudaError_t __stdcall cudaEventElapsedTime(float *, cudaEvent_t, cudaEvent_t); } 
#line 242
extern "C" { extern cudaError_t __stdcall cudaSetDoubleForDevice(double *); } 
#line 243
extern "C" { extern cudaError_t __stdcall cudaSetDoubleForHost(double *); } 
#line 251
extern "C" { extern cudaError_t __stdcall cudaThreadExit(); } 
#line 252
extern "C" { extern cudaError_t __stdcall cudaThreadSynchronize(); } 
#line 57 "c:\\cuda\\include\\channel_descriptor.h"
template<class T> __inline cudaChannelFormatDesc cudaCreateChannelDesc() 
#line 58
{ 
#line 59
return cudaCreateChannelDesc(0, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 60
} 
#line 62
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char> () 
#line 63
{ 
#line 64
auto int e = (((int)sizeof(char)) * 8); 
#line 69 "c:\\cuda\\include\\channel_descriptor.h"
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 71 "c:\\cuda\\include\\channel_descriptor.h"
} 
#line 73
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< signed char> () 
#line 74
{ 
#line 75
auto int e = (((int)sizeof(signed char)) * 8); 
#line 77
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 78
} 
#line 80
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned char> () 
#line 81
{ 
#line 82
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 84
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 85
} 
#line 87
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char1> () 
#line 88
{ 
#line 89
auto int e = (((int)sizeof(signed char)) * 8); 
#line 91
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 92
} 
#line 94
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar1> () 
#line 95
{ 
#line 96
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 98
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 99
} 
#line 101
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char2> () 
#line 102
{ 
#line 103
auto int e = (((int)sizeof(signed char)) * 8); 
#line 105
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 106
} 
#line 108
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar2> () 
#line 109
{ 
#line 110
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 112
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 113
} 
#line 115
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< char4> () 
#line 116
{ 
#line 117
auto int e = (((int)sizeof(signed char)) * 8); 
#line 119
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 120
} 
#line 122
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uchar4> () 
#line 123
{ 
#line 124
auto int e = (((int)sizeof(unsigned char)) * 8); 
#line 126
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 127
} 
#line 129
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short> () 
#line 130
{ 
#line 131
auto int e = (((int)sizeof(short)) * 8); 
#line 133
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 134
} 
#line 136
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned short> () 
#line 137
{ 
#line 138
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 140
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 141
} 
#line 143
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short1> () 
#line 144
{ 
#line 145
auto int e = (((int)sizeof(short)) * 8); 
#line 147
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 148
} 
#line 150
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort1> () 
#line 151
{ 
#line 152
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 154
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 155
} 
#line 157
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short2> () 
#line 158
{ 
#line 159
auto int e = (((int)sizeof(short)) * 8); 
#line 161
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 162
} 
#line 164
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort2> () 
#line 165
{ 
#line 166
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 168
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 169
} 
#line 171
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< short4> () 
#line 172
{ 
#line 173
auto int e = (((int)sizeof(short)) * 8); 
#line 175
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 176
} 
#line 178
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ushort4> () 
#line 179
{ 
#line 180
auto int e = (((int)sizeof(unsigned short)) * 8); 
#line 182
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 183
} 
#line 185
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int> () 
#line 186
{ 
#line 187
auto int e = (((int)sizeof(int)) * 8); 
#line 189
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 190
} 
#line 192
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned> () 
#line 193
{ 
#line 194
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 196
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 197
} 
#line 199
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int1> () 
#line 200
{ 
#line 201
auto int e = (((int)sizeof(int)) * 8); 
#line 203
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 204
} 
#line 206
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint1> () 
#line 207
{ 
#line 208
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 210
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 211
} 
#line 213
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int2> () 
#line 214
{ 
#line 215
auto int e = (((int)sizeof(int)) * 8); 
#line 217
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 218
} 
#line 220
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint2> () 
#line 221
{ 
#line 222
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 224
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 225
} 
#line 227
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< int4> () 
#line 228
{ 
#line 229
auto int e = (((int)sizeof(int)) * 8); 
#line 231
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 232
} 
#line 234
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< uint4> () 
#line 235
{ 
#line 236
auto int e = (((int)sizeof(unsigned)) * 8); 
#line 238
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 239
} 
#line 243
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long> () 
#line 244
{ 
#line 245
auto int e = (((int)sizeof(long)) * 8); 
#line 247
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 248
} 
#line 250
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< unsigned long> () 
#line 251
{ 
#line 252
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 254
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 255
} 
#line 257
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long1> () 
#line 258
{ 
#line 259
auto int e = (((int)sizeof(long)) * 8); 
#line 261
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindSigned); 
#line 262
} 
#line 264
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong1> () 
#line 265
{ 
#line 266
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 268
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindUnsigned); 
#line 269
} 
#line 271
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long2> () 
#line 272
{ 
#line 273
auto int e = (((int)sizeof(long)) * 8); 
#line 275
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindSigned); 
#line 276
} 
#line 278
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong2> () 
#line 279
{ 
#line 280
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 282
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindUnsigned); 
#line 283
} 
#line 285
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< long4> () 
#line 286
{ 
#line 287
auto int e = (((int)sizeof(long)) * 8); 
#line 289
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindSigned); 
#line 290
} 
#line 292
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< ulong4> () 
#line 293
{ 
#line 294
auto int e = (((int)sizeof(unsigned long)) * 8); 
#line 296
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindUnsigned); 
#line 297
} 
#line 301 "c:\\cuda\\include\\channel_descriptor.h"
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float> () 
#line 302
{ 
#line 303
auto int e = (((int)sizeof(float)) * 8); 
#line 305
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindFloat); 
#line 306
} 
#line 308
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float1> () 
#line 309
{ 
#line 310
auto int e = (((int)sizeof(float)) * 8); 
#line 312
return cudaCreateChannelDesc(e, 0, 0, 0, cudaChannelFormatKindFloat); 
#line 313
} 
#line 315
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float2> () 
#line 316
{ 
#line 317
auto int e = (((int)sizeof(float)) * 8); 
#line 319
return cudaCreateChannelDesc(e, e, 0, 0, cudaChannelFormatKindFloat); 
#line 320
} 
#line 322
template<> __inline cudaChannelFormatDesc cudaCreateChannelDesc< float4> () 
#line 323
{ 
#line 324
auto int e = (((int)sizeof(float)) * 8); 
#line 326
return cudaCreateChannelDesc(e, e, e, e, cudaChannelFormatKindFloat); 
#line 327
} 
#line 94 "c:\\cuda\\include\\texture_types.h"
template<class T, int dim = 1, cudaTextureReadMode  = cudaReadModeElementType> 
#line 95
struct texture : public textureReference { 
#line 97
texture(int norm = 0, cudaTextureFilterMode 
#line 98
fMode = cudaFilterModePoint, cudaTextureAddressMode 
#line 99
aMode = cudaAddressModeClamp) 
#line 100
{ 
#line 101
(this->normalized) = norm; 
#line 102
(this->filterMode) = fMode; 
#line 103
((this->addressMode)[0]) = aMode; 
#line 104
((this->addressMode)[1]) = aMode; 
#line 105
((this->addressMode)[2]) = aMode; 
#line 106
(this->channelDesc) = cudaCreateChannelDesc< T> (); 
#line 107
} 
#line 109
texture(int norm, cudaTextureFilterMode 
#line 110
fMode, cudaTextureAddressMode 
#line 111
aMode, cudaChannelFormatDesc 
#line 112
desc) 
#line 113
{ 
#line 114
(this->normalized) = norm; 
#line 115
(this->filterMode) = fMode; 
#line 116
((this->addressMode)[0]) = aMode; 
#line 117
((this->addressMode)[1]) = aMode; 
#line 118
((this->addressMode)[2]) = aMode; 
#line 119
(this->channelDesc) = desc; 
#line 120
} 
#line 121
}; 
#line 54 "c:\\cuda\\include\\driver_functions.h"
static __inline cudaPitchedPtr make_cudaPitchedPtr(void *d, size_t p, size_t xsz, size_t ysz) 
#line 55
{ 
#line 56
auto cudaPitchedPtr s; 
#line 58
(s.ptr) = d; 
#line 59
(s.pitch) = p; 
#line 60
(s.xsize) = xsz; 
#line 61
(s.ysize) = ysz; 
#line 63
return s; 
#line 64
} 
#line 66
static __inline cudaPos make_cudaPos(size_t x, size_t y, size_t z) 
#line 67
{ 
#line 68
auto cudaPos p; 
#line 70
(p.x) = x; 
#line 71
(p.y) = y; 
#line 72
(p.z) = z; 
#line 74
return p; 
#line 75
} 
#line 77
static __inline cudaExtent make_cudaExtent(size_t w, size_t h, size_t d) 
#line 78
{ 
#line 79
auto cudaExtent e; 
#line 81
(e.width) = w; 
#line 82
(e.height) = h; 
#line 83
(e.depth) = d; 
#line 85
return e; 
#line 86
} 
#line 54 "c:\\cuda\\include\\vector_functions.h"
static __inline char1 make_char1(signed char x) 
#line 55
{ 
#line 56
auto char1 t; (t.x) = x; return t; 
#line 57
} 
#line 59
static __inline uchar1 make_uchar1(unsigned char x) 
#line 60
{ 
#line 61
auto uchar1 t; (t.x) = x; return t; 
#line 62
} 
#line 64
static __inline char2 make_char2(signed char x, signed char y) 
#line 65
{ 
#line 66
auto char2 t; (t.x) = x; (t.y) = y; return t; 
#line 67
} 
#line 69
static __inline uchar2 make_uchar2(unsigned char x, unsigned char y) 
#line 70
{ 
#line 71
auto uchar2 t; (t.x) = x; (t.y) = y; return t; 
#line 72
} 
#line 74
static __inline char3 make_char3(signed char x, signed char y, signed char z) 
#line 75
{ 
#line 76
auto char3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 77
} 
#line 79
static __inline uchar3 make_uchar3(unsigned char x, unsigned char y, unsigned char z) 
#line 80
{ 
#line 81
auto uchar3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 82
} 
#line 84
static __inline char4 make_char4(signed char x, signed char y, signed char z, signed char w) 
#line 85
{ 
#line 86
auto char4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 87
} 
#line 89
static __inline uchar4 make_uchar4(unsigned char x, unsigned char y, unsigned char z, unsigned char w) 
#line 90
{ 
#line 91
auto uchar4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 92
} 
#line 94
static __inline short1 make_short1(short x) 
#line 95
{ 
#line 96
auto short1 t; (t.x) = x; return t; 
#line 97
} 
#line 99
static __inline ushort1 make_ushort1(unsigned short x) 
#line 100
{ 
#line 101
auto ushort1 t; (t.x) = x; return t; 
#line 102
} 
#line 104
static __inline short2 make_short2(short x, short y) 
#line 105
{ 
#line 106
auto short2 t; (t.x) = x; (t.y) = y; return t; 
#line 107
} 
#line 109
static __inline ushort2 make_ushort2(unsigned short x, unsigned short y) 
#line 110
{ 
#line 111
auto ushort2 t; (t.x) = x; (t.y) = y; return t; 
#line 112
} 
#line 114
static __inline short3 make_short3(short x, short y, short z) 
#line 115
{ 
#line 116
auto short3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 117
} 
#line 119
static __inline ushort3 make_ushort3(unsigned short x, unsigned short y, unsigned short z) 
#line 120
{ 
#line 121
auto ushort3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 122
} 
#line 124
static __inline short4 make_short4(short x, short y, short z, short w) 
#line 125
{ 
#line 126
auto short4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 127
} 
#line 129
static __inline ushort4 make_ushort4(unsigned short x, unsigned short y, unsigned short z, unsigned short w) 
#line 130
{ 
#line 131
auto ushort4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 132
} 
#line 134
static __inline int1 make_int1(int x) 
#line 135
{ 
#line 136
auto int1 t; (t.x) = x; return t; 
#line 137
} 
#line 139
static __inline uint1 make_uint1(unsigned x) 
#line 140
{ 
#line 141
auto uint1 t; (t.x) = x; return t; 
#line 142
} 
#line 144
static __inline int2 make_int2(int x, int y) 
#line 145
{ 
#line 146
auto int2 t; (t.x) = x; (t.y) = y; return t; 
#line 147
} 
#line 149
static __inline uint2 make_uint2(unsigned x, unsigned y) 
#line 150
{ 
#line 151
auto uint2 t; (t.x) = x; (t.y) = y; return t; 
#line 152
} 
#line 154
static __inline int3 make_int3(int x, int y, int z) 
#line 155
{ 
#line 156
auto int3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 157
} 
#line 159
static __inline uint3 make_uint3(unsigned x, unsigned y, unsigned z) 
#line 160
{ 
#line 161
auto uint3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 162
} 
#line 164
static __inline int4 make_int4(int x, int y, int z, int w) 
#line 165
{ 
#line 166
auto int4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 167
} 
#line 169
static __inline uint4 make_uint4(unsigned x, unsigned y, unsigned z, unsigned w) 
#line 170
{ 
#line 171
auto uint4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 172
} 
#line 174
static __inline long1 make_long1(long x) 
#line 175
{ 
#line 176
auto long1 t; (t.x) = x; return t; 
#line 177
} 
#line 179
static __inline ulong1 make_ulong1(unsigned long x) 
#line 180
{ 
#line 181
auto ulong1 t; (t.x) = x; return t; 
#line 182
} 
#line 184
static __inline long2 make_long2(long x, long y) 
#line 185
{ 
#line 186
auto long2 t; (t.x) = x; (t.y) = y; return t; 
#line 187
} 
#line 189
static __inline ulong2 make_ulong2(unsigned long x, unsigned long y) 
#line 190
{ 
#line 191
auto ulong2 t; (t.x) = x; (t.y) = y; return t; 
#line 192
} 
#line 196
static __inline long3 make_long3(long x, long y, long z) 
#line 197
{ 
#line 198
auto long3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 199
} 
#line 201
static __inline ulong3 make_ulong3(unsigned long x, unsigned long y, unsigned long z) 
#line 202
{ 
#line 203
auto ulong3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 204
} 
#line 206
static __inline long4 make_long4(long x, long y, long z, long w) 
#line 207
{ 
#line 208
auto long4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 209
} 
#line 211
static __inline ulong4 make_ulong4(unsigned long x, unsigned long y, unsigned long z, unsigned long w) 
#line 212
{ 
#line 213
auto ulong4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 214
} 
#line 218 "c:\\cuda\\include\\vector_functions.h"
static __inline float1 make_float1(float x) 
#line 219
{ 
#line 220
auto float1 t; (t.x) = x; return t; 
#line 221
} 
#line 223
static __inline float2 make_float2(float x, float y) 
#line 224
{ 
#line 225
auto float2 t; (t.x) = x; (t.y) = y; return t; 
#line 226
} 
#line 228
static __inline float3 make_float3(float x, float y, float z) 
#line 229
{ 
#line 230
auto float3 t; (t.x) = x; (t.y) = y; (t.z) = z; return t; 
#line 231
} 
#line 233
static __inline float4 make_float4(float x, float y, float z, float w) 
#line 234
{ 
#line 235
auto float4 t; (t.x) = x; (t.y) = y; (t.z) = z; (t.w) = w; return t; 
#line 236
} 
#line 238
static __inline double1 make_double1(double x) 
#line 239
{ 
#line 240
auto double1 t; (t.x) = x; return t; 
#line 241
} 
#line 243
static __inline double2 make_double2(double x, double y) 
#line 244
{ 
#line 245
auto double2 t; (t.x) = x; (t.y) = y; return t; 
#line 246
} 
#line 35 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
#pragma pack ( push, 8 )
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { typedef long clock_t; }
#line 119 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { struct tm { 
#line 120
int tm_sec; 
#line 121
int tm_min; 
#line 122
int tm_hour; 
#line 123
int tm_mday; 
#line 124
int tm_mon; 
#line 125
int tm_year; 
#line 126
int tm_wday; 
#line 127
int tm_yday; 
#line 128
int tm_isdst; 
#line 129
}; }
#line 144 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_daylight instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int *__cdecl __daylight(); } 
#line 148
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_dstbias instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long *__cdecl __dstbias(); } 
#line 152
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_timezone instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long *__cdecl __timezone(); } 
#line 156
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _get_tzname instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char **__cdecl __tzname(); } 
#line 159
extern "C" { extern errno_t __cdecl _get_daylight(int *); } 
#line 160
extern "C" { extern errno_t __cdecl _get_dstbias(long *); } 
#line 161
extern "C" { extern errno_t __cdecl _get_timezone(long *); } 
#line 162
extern "C" { extern errno_t __cdecl _get_tzname(size_t *, char *, size_t, int); } 
#line 166
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using asctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl asctime(const tm *); } 
#line 168
extern "C" { extern errno_t __cdecl asctime_s(char *, size_t, const tm *); } 
#line 170 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
template<size_t _Size> inline errno_t __cdecl asctime_s(char (&_Buffer)[_Size], const tm *_Time) { return asctime_s(_Buffer, _Size, _Time); } 
#line 172
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ctime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ctime32(const __time32_t *); } 
#line 173
extern "C" { extern errno_t __cdecl _ctime32_s(char *, size_t, const __time32_t *); } 
#line 174
template<size_t _Size> inline errno_t __cdecl _ctime32_s(char (&_Buffer)[_Size], const __time32_t *_Time) { return _ctime32_s(_Buffer, _Size, _Time); } 
#line 176
extern "C" { extern clock_t __cdecl clock(); } 
#line 177
extern "C" { extern double __cdecl _difftime32(__time32_t, __time32_t); } 
#line 179
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gmtime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _gmtime32(const __time32_t *); } 
#line 180
extern "C" { extern errno_t __cdecl _gmtime32_s(tm *, const __time32_t *); } 
#line 182
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _localtime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _localtime32(const __time32_t *); } 
#line 183
extern "C" { extern errno_t __cdecl _localtime32_s(tm *, const __time32_t *); } 
#line 185
extern "C" { extern size_t __cdecl strftime(char *, size_t, const char *, const tm *); } 
#line 186
extern "C" { extern size_t __cdecl _strftime_l(char *, size_t, const char *, const tm *, _locale_t); } 
#line 188
extern "C" { extern errno_t __cdecl _strdate_s(char *, size_t); } 
#line 189
template<size_t _Size> inline errno_t __cdecl _strdate_s(char (&_Buffer)[_Size]) { return _strdate_s(_Buffer, _Size); } 
#line 190
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strdate_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strdate(char *); } 
#line 192
extern "C" { extern errno_t __cdecl _strtime_s(char *, size_t); } 
#line 193
template<size_t _Size> inline errno_t __cdecl _strtime_s(char (&_Buffer)[_Size]) { return _strtime_s(_Buffer, _Size); } 
#line 194
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strtime(char *); } 
#line 196
extern "C" { extern __time32_t __cdecl _time32(__time32_t *); } 
#line 197
extern "C" { extern __time32_t __cdecl _mktime32(tm *); } 
#line 198
extern "C" { extern __time32_t __cdecl _mkgmtime32(tm *); } 
#line 203
extern "C" { extern void __cdecl _tzset(); } 
#line 207 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern double __cdecl _difftime64(__time64_t, __time64_t); } 
#line 208
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ctime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ctime64(const __time64_t *); } 
#line 209
extern "C" { extern errno_t __cdecl _ctime64_s(char *, size_t, const __time64_t *); } 
#line 210
template<size_t _Size> inline errno_t __cdecl _ctime64_s(char (&_Buffer)[_Size], const __time64_t *_Time) { return _ctime64_s(_Buffer, _Size, _Time); } 
#line 212
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gmtime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _gmtime64(const __time64_t *); } 
#line 213
extern "C" { extern errno_t __cdecl _gmtime64_s(tm *, const __time64_t *); } 
#line 215
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _localtime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl _localtime64(const __time64_t *); } 
#line 216
extern "C" { extern errno_t __cdecl _localtime64_s(tm *, const __time64_t *); } 
#line 218
extern "C" { extern __time64_t __cdecl _mktime64(tm *); } 
#line 219
extern "C" { extern __time64_t __cdecl _mkgmtime64(tm *); } 
#line 220
extern "C" { extern __time64_t __cdecl _time64(__time64_t *); } 
#line 224 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetLocalTimeinstead. See online help for details.")) unsigned __cdecl _getsystime(tm *); } 
#line 225
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSetLocalTimeinstead. See online help for details.")) unsigned __cdecl _setsystime(tm *, unsigned); } 
#line 237
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wasctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wasctime(const tm *); } 
#line 238
extern "C" { extern errno_t __cdecl _wasctime_s(__wchar_t *, size_t, const tm *); } 
#line 239
template<size_t _Size> inline errno_t __cdecl _wasctime_s(__wchar_t (&_Buffer)[_Size], const tm *_Time) { return _wasctime_s(_Buffer, _Size, _Time); } 
#line 241
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctime32_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wctime32(const __time32_t *); } 
#line 242
extern "C" { extern errno_t __cdecl _wctime32_s(__wchar_t *, size_t, const __time32_t *); } 
#line 243
template<size_t _Size> inline errno_t __cdecl _wctime32_s(__wchar_t (&_Buffer)[_Size], const __time32_t *_Time) { return _wctime32_s(_Buffer, _Size, _Time); } 
#line 245
extern "C" { extern size_t __cdecl wcsftime(__wchar_t *, size_t, const __wchar_t *, const tm *); } 
#line 246
extern "C" { extern size_t __cdecl _wcsftime_l(__wchar_t *, size_t, const __wchar_t *, const tm *, _locale_t); } 
#line 248
extern "C" { extern errno_t __cdecl _wstrdate_s(__wchar_t *, size_t); } 
#line 249
template<size_t _Size> inline errno_t __cdecl _wstrdate_s(__wchar_t (&_Buffer)[_Size]) { return _wstrdate_s(_Buffer, _Size); } 
#line 250
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wstrdate_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wstrdate(__wchar_t *); } 
#line 252
extern "C" { extern errno_t __cdecl _wstrtime_s(__wchar_t *, size_t); } 
#line 253
template<size_t _Size> inline errno_t __cdecl _wstrtime_s(__wchar_t (&_Buffer)[_Size]) { return _wstrtime_s(_Buffer, _Size); } 
#line 254
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wstrtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wstrtime(__wchar_t *); } 
#line 257
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctime64_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wctime64(const __time64_t *); } 
#line 258
extern "C" { extern errno_t __cdecl _wctime64_s(__wchar_t *, size_t, const __time64_t *); } 
#line 259
template<size_t _Size> inline errno_t __cdecl _wctime64_s(__wchar_t (&_Buffer)[_Size], const __time64_t *_Time) { return _wctime64_s(_Buffer, _Size, _Time); } 
#line 29 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(push)
#pragma warning(disable:4996)
#line 46
extern "C" { static __inline __wchar_t *__cdecl _wctime(const time_t *_Time) 
#line 47
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _wctime64(_Time); 
#pragma warning( pop )
} } 
#line 54
extern "C" { static __inline errno_t __cdecl _wctime_s(__wchar_t *_Buffer, size_t _SizeInWords, const time_t *_Time) 
#line 55
{ 
#line 56
return _wctime64_s(_Buffer, _SizeInWords, _Time); 
#line 57
} } 
#line 60 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\wtime.inl"
#pragma warning(pop)
#line 84 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline double __cdecl difftime(time_t _Time1, time_t _Time2) 
#line 85
{ 
#line 86
return _difftime64(_Time1, _Time2); 
#line 87
} } 
#line 88
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using ctime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ctime(const time_t *_Time) 
#line 89
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _ctime64(_Time); 
#pragma warning( pop )
} } 
#line 96
extern "C" { static __inline errno_t __cdecl ctime_s(char *_Buffer, size_t _SizeInBytes, const time_t *_Time) 
#line 97
{ 
#line 98
return _ctime64_s(_Buffer, _SizeInBytes, _Time); 
#line 99
} } 
#line 101 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using gmtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl gmtime(const time_t *_Time) 
#line 102
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _gmtime64(_Time); 
#pragma warning( pop )
} } 
#line 109
extern "C" { static __inline errno_t __cdecl gmtime_s(tm *_Tm, const time_t *_Time) 
#line 110
{ 
#line 111
return _gmtime64_s(_Tm, _Time); 
#line 112
} } 
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.inl"
extern "C" { static __inline __declspec(deprecated("This function or variable may be unsafe. Consider using localtime_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) tm *__cdecl localtime(const time_t *_Time) 
#line 115
{ 
#pragma warning( push )
#pragma warning( disable : 4996 )
return _localtime64(_Time); 
#pragma warning( pop )
} } 
#line 121
extern "C" { static __inline errno_t __cdecl localtime_s(tm *_Tm, const time_t *_Time) 
#line 122
{ 
#line 123
return _localtime64_s(_Tm, _Time); 
#line 124
} } 
#line 125
extern "C" { static __inline time_t __cdecl mktime(tm *_Tm) 
#line 126
{ 
#line 127
return _mktime64(_Tm); 
#line 128
} } 
#line 129
extern "C" { static __inline time_t __cdecl _mkgmtime(tm *_Tm) 
#line 130
{ 
#line 131
return _mkgmtime64(_Tm); 
#line 132
} } 
#line 133
extern "C" { static __inline time_t __cdecl time(time_t *_Time) 
#line 134
{ 
#line 135
return _time64(_Time); 
#line 136
} } 
#line 285 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_daylight instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int daylight; 
#line 286
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_timezone instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) long timezone; 
#line 287
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_tzname instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *tzname[2]; 
#line 290 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _tzset. See online help for details.")) void __cdecl tzset(); } 
#line 300 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\time.h"
#pragma pack ( pop )
#line 48 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl _memccpy(void *, const void *, int, size_t); } 
#line 49
extern "C" { extern const void *__cdecl memchr(const void *, int, size_t); } 
#line 50
extern "C" { extern int __cdecl _memicmp(const void *, const void *, size_t); } 
#line 51
extern "C" { extern int __cdecl _memicmp_l(const void *, const void *, size_t, _locale_t); } 
#line 52
extern "C" { extern int __cdecl memcmp(const void *, const void *, size_t); } 
#line 53
extern "C" { extern void *__cdecl memcpy(void *, const void *, size_t); } 
#line 55
extern "C" { extern errno_t __cdecl memcpy_s(void *, rsize_t, const void *, rsize_t); } 
#line 57 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl memset(void *, int, size_t); } 
#line 61
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _memccpy. See online help for details.")) void *__cdecl memccpy(void *, const void *, int, size_t); } 
#line 62
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _memicmp. See online help for details.")) int __cdecl memicmp(const void *, const void *, size_t); } 
#line 67 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strset(char *, int); } 
#line 68
extern "C" { extern errno_t __cdecl _strset_s(char *, size_t, int); } 
#line 70
extern "C" { extern errno_t __cdecl strcpy_s(char *, rsize_t, const char *); } 
#line 72 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strcpy_s(char (&_Dest)[_Size], const char *_Source) { return strcpy_s(_Dest, _Size, _Source); } 
#line 73
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strcpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strcpy(char *, const char *); } 
#line 75
extern "C" { extern errno_t __cdecl strcat_s(char *, rsize_t, const char *); } 
#line 77 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strcat_s(char (&_Dest)[_Size], const char *_Source) { return strcat_s(_Dest, _Size, _Source); } 
#line 78
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strcat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strcat(char *, const char *); } 
#line 79
extern "C" { extern int __cdecl strcmp(const char *, const char *); } 
#line 80
extern "C" { extern size_t __cdecl strlen(const char *); } 
#line 81
extern "C" { extern size_t __cdecl strnlen(const char *, size_t); } 
#line 83
extern "C" { static __inline size_t __cdecl strnlen_s(const char *_Str, size_t _MaxCount) 
#line 84
{ 
#line 85
return strnlen(_Str, _MaxCount); 
#line 86
} } 
#line 89 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl memmove_s(void *, rsize_t, const void *, rsize_t); } 
#line 95 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern void *__cdecl memmove(void *, const void *, size_t); } 
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern char *__cdecl _strdup(const char *); } 
#line 109 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern const char *__cdecl strchr(const char *, int); } 
#line 110
extern "C" { extern int __cdecl _stricmp(const char *, const char *); } 
#line 111
extern "C" { extern int __cdecl _strcmpi(const char *, const char *); } 
#line 112
extern "C" { extern int __cdecl _stricmp_l(const char *, const char *, _locale_t); } 
#line 113
extern "C" { extern int __cdecl strcoll(const char *, const char *); } 
#line 114
extern "C" { extern int __cdecl _strcoll_l(const char *, const char *, _locale_t); } 
#line 115
extern "C" { extern int __cdecl _stricoll(const char *, const char *); } 
#line 116
extern "C" { extern int __cdecl _stricoll_l(const char *, const char *, _locale_t); } 
#line 117
extern "C" { extern int __cdecl _strncoll(const char *, const char *, size_t); } 
#line 118
extern "C" { extern int __cdecl _strncoll_l(const char *, const char *, size_t, _locale_t); } 
#line 119
extern "C" { extern int __cdecl _strnicoll(const char *, const char *, size_t); } 
#line 120
extern "C" { extern int __cdecl _strnicoll_l(const char *, const char *, size_t, _locale_t); } 
#line 121
extern "C" { extern size_t __cdecl strcspn(const char *, const char *); } 
#line 122
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strerror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strerror(const char *); } 
#line 123
extern "C" { extern errno_t __cdecl _strerror_s(char *, size_t, const char *); } 
#line 124
template<size_t _Size> inline errno_t __cdecl _strerror_s(char (&_Buffer)[_Size], const char *_ErrorMessage) { return _strerror_s(_Buffer, _Size, _ErrorMessage); } 
#line 125
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strerror(int); } 
#line 127
extern "C" { extern errno_t __cdecl strerror_s(char *, size_t, int); } 
#line 129 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strerror_s(char (&_Buffer)[_Size], int _ErrorMessage) { return strerror_s(_Buffer, _Size, _ErrorMessage); } 
#line 130
extern "C" { extern errno_t __cdecl _strlwr_s(char *, size_t); } 
#line 131
template<size_t _Size> inline errno_t __cdecl _strlwr_s(char (&_String)[_Size]) { return _strlwr_s(_String, _Size); } 
#line 132
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strlwr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strlwr(char *); } 
#line 133
extern "C" { extern errno_t __cdecl _strlwr_s_l(char *, size_t, _locale_t); } 
#line 134
template<size_t _Size> inline errno_t __cdecl _strlwr_s_l(char (&_String)[_Size], _locale_t _Locale) { return _strlwr_s_l(_String, _Size, _Locale); } 
#line 135
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strlwr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strlwr_l(char *, _locale_t); } 
#line 137
extern "C" { extern errno_t __cdecl strncat_s(char *, rsize_t, const char *, rsize_t); } 
#line 139 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strncat_s(char (&_Dest)[_Size], const char *_Source, size_t _Count) { return strncat_s(_Dest, _Size, _Source, _Count); } 
#pragma warning(push)
#pragma warning(disable:4609 6059)
#line 143
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strncat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strncat(char *, const char *, size_t); } 
#pragma warning(pop)
#line 148 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl strncmp(const char *, const char *, size_t); } 
#line 150 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern int __cdecl _strnicmp(const char *, const char *, size_t); } 
#line 151
extern "C" { extern int __cdecl _strnicmp_l(const char *, const char *, size_t, _locale_t); } 
#line 153
extern "C" { extern errno_t __cdecl strncpy_s(char *, rsize_t, const char *, rsize_t); } 
#line 155 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl strncpy_s(char (&_Dest)[_Size], const char *_Source, size_t _Count) { return strncpy_s(_Dest, _Size, _Source, _Count); } 
#line 156
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strncpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strncpy(char *, const char *, size_t); } 
#line 157
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strnset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strnset(char *, int, size_t); } 
#line 158
extern "C" { extern errno_t __cdecl _strnset_s(char *, size_t, int, size_t); } 
#line 159
extern "C" { extern const char *__cdecl strpbrk(const char *, const char *); } 
#line 160
extern "C" { extern const char *__cdecl strrchr(const char *, int); } 
#line 161
extern "C" { extern char *__cdecl _strrev(char *); } 
#line 162
extern "C" { extern size_t __cdecl strspn(const char *, const char *); } 
#line 163
extern "C" { extern const char *__cdecl strstr(const char *, const char *); } 
#line 164
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strtok_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl strtok(char *, const char *); } 
#line 166
extern "C" { extern char *__cdecl strtok_s(char *, const char *, char **); } 
#line 168 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl _strupr_s(char *, size_t); } 
#line 169
template<size_t _Size> inline errno_t __cdecl _strupr_s(char (&_String)[_Size]) { return _strupr_s(_String, _Size); } 
#line 170
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strupr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strupr(char *); } 
#line 171
extern "C" { extern errno_t __cdecl _strupr_s_l(char *, size_t, _locale_t); } 
#line 172
template<size_t _Size> inline errno_t __cdecl _strupr_s_l(char (&_String)[_Size], _locale_t _Locale) { return _strupr_s_l(_String, _Size, _Locale); } 
#line 173
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _strupr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _strupr_l(char *, _locale_t); } 
#line 174
extern "C" { extern size_t __cdecl strxfrm(char *, const char *, size_t); } 
#line 175
extern "C" { extern size_t __cdecl _strxfrm_l(char *, const char *, size_t, _locale_t); } 
#line 181
inline char *__cdecl strchr(char *_Str, int _Ch) 
#line 182
{ return (char *)strchr((const char *)_Str, _Ch); } 
#line 183
inline char *__cdecl strpbrk(char *_Str, const char *_Control) 
#line 184
{ return (char *)strpbrk((const char *)_Str, _Control); } 
#line 185
inline char *__cdecl strrchr(char *_Str, int _Ch) 
#line 186
{ return (char *)strrchr((const char *)_Str, _Ch); } 
#line 187
inline char *__cdecl strstr(char *_Str, const char *_SubStr) 
#line 188
{ return (char *)strstr((const char *)_Str, _SubStr); } 
#line 192 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
inline void *__cdecl memchr(void *_Pv, int _C, size_t _N) 
#line 193
{ return (void *)memchr((const void *)_Pv, _C, _N); } 
#line 205 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strdup. See online help for details.")) char *__cdecl strdup(const char *); } 
#line 212 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strcmpi. See online help for details.")) int __cdecl strcmpi(const char *, const char *); } 
#line 213
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _stricmp. See online help for details.")) int __cdecl stricmp(const char *, const char *); } 
#line 214
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strlwr. See online help for details.")) char *__cdecl strlwr(char *); } 
#line 215
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strnicmp. See online help for details.")) int __cdecl strnicmp(const char *, const char *, size_t); } 
#line 216
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strnset. See online help for details.")) char *__cdecl strnset(char *, int, size_t); } 
#line 217
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strrev. See online help for details.")) char *__cdecl strrev(char *); } 
#line 218
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strset. See online help for details.")) char *__cdecl strset(char *, int); } 
#line 219
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strupr. See online help for details.")) char *__cdecl strupr(char *); } 
#line 233 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __wchar_t *__cdecl _wcsdup(const __wchar_t *); } 
#line 240 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcscat_s(__wchar_t *, rsize_t, const __wchar_t *); } 
#line 242 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcscat_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source) { return wcscat_s(_Dest, _Size, _Source); } 
#line 243
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcscat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcscat(__wchar_t *, const __wchar_t *); } 
#line 244
extern "C" { extern const __wchar_t *__cdecl wcschr(const __wchar_t *, __wchar_t); } 
#line 245
extern "C" { extern int __cdecl wcscmp(const __wchar_t *, const __wchar_t *); } 
#line 247
extern "C" { extern errno_t __cdecl wcscpy_s(__wchar_t *, rsize_t, const __wchar_t *); } 
#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcscpy_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source) { return wcscpy_s(_Dest, _Size, _Source); } 
#line 250
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcscpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcscpy(__wchar_t *, const __wchar_t *); } 
#line 251
extern "C" { extern size_t __cdecl wcscspn(const __wchar_t *, const __wchar_t *); } 
#line 252
extern "C" { extern size_t __cdecl wcslen(const __wchar_t *); } 
#line 253
extern "C" { extern size_t __cdecl wcsnlen(const __wchar_t *, size_t); } 
#line 255
extern "C" { static __inline size_t __cdecl wcsnlen_s(const __wchar_t *_Src, size_t _MaxCount) 
#line 256
{ 
#line 257
return wcsnlen(_Src, _MaxCount); 
#line 258
} } 
#line 261 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern errno_t __cdecl wcsncat_s(__wchar_t *, rsize_t, const __wchar_t *, rsize_t); } 
#line 263 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcsncat_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source, size_t _Count) { return wcsncat_s(_Dest, _Size, _Source, _Count); } 
#line 264
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcsncat_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcsncat(__wchar_t *, const __wchar_t *, size_t); } 
#line 265
extern "C" { extern int __cdecl wcsncmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 267
extern "C" { extern errno_t __cdecl wcsncpy_s(__wchar_t *, rsize_t, const __wchar_t *, rsize_t); } 
#line 269 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
template<size_t _Size> inline errno_t __cdecl wcsncpy_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Source, size_t _Count) { return wcsncpy_s(_Dest, _Size, _Source, _Count); } 
#line 270
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcsncpy_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcsncpy(__wchar_t *, const __wchar_t *, size_t); } 
#line 271
extern "C" { extern const __wchar_t *__cdecl wcspbrk(const __wchar_t *, const __wchar_t *); } 
#line 272
extern "C" { extern const __wchar_t *__cdecl wcsrchr(const __wchar_t *, __wchar_t); } 
#line 273
extern "C" { extern size_t __cdecl wcsspn(const __wchar_t *, const __wchar_t *); } 
#line 274
extern "C" { extern const __wchar_t *__cdecl wcsstr(const __wchar_t *, const __wchar_t *); } 
#line 275
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcstok_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl wcstok(__wchar_t *, const __wchar_t *); } 
#line 276
extern "C" { extern __wchar_t *__cdecl wcstok_s(__wchar_t *, const __wchar_t *, __wchar_t **); } 
#line 277
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcserror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcserror(int); } 
#line 278
extern "C" { extern errno_t __cdecl _wcserror_s(__wchar_t *, size_t, int); } 
#line 279
template<size_t _Size> inline errno_t __cdecl _wcserror_s(__wchar_t (&_Buffer)[_Size], int _Error) { return _wcserror_s(_Buffer, _Size, _Error); } 
#line 280
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using __wcserror_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl __wcserror(const __wchar_t *); } 
#line 281
extern "C" { extern errno_t __cdecl __wcserror_s(__wchar_t *, size_t, const __wchar_t *); } 
#line 282
template<size_t _Size> inline errno_t __cdecl __wcserror_s(__wchar_t (&_Buffer)[_Size], const __wchar_t *_ErrorMessage) { return __wcserror_s(_Buffer, _Size, _ErrorMessage); } 
#line 284
extern "C" { extern int __cdecl _wcsicmp(const __wchar_t *, const __wchar_t *); } 
#line 285
extern "C" { extern int __cdecl _wcsicmp_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 286
extern "C" { extern int __cdecl _wcsnicmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 287
extern "C" { extern int __cdecl _wcsnicmp_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 288
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsnset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsnset(__wchar_t *, __wchar_t, size_t); } 
#line 289
extern "C" { extern errno_t __cdecl _wcsnset_s(__wchar_t *, size_t, __wchar_t, size_t); } 
#line 290
extern "C" { extern __wchar_t *__cdecl _wcsrev(__wchar_t *); } 
#line 291
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsset_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsset(__wchar_t *, __wchar_t); } 
#line 292
extern "C" { extern errno_t __cdecl _wcsset_s(__wchar_t *, size_t, __wchar_t); } 
#line 294
extern "C" { extern errno_t __cdecl _wcslwr_s(__wchar_t *, size_t); } 
#line 295
template<size_t _Size> inline errno_t __cdecl _wcslwr_s(__wchar_t (&_String)[_Size]) { return _wcslwr_s(_String, _Size); } 
#line 296
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcslwr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcslwr(__wchar_t *); } 
#line 297
extern "C" { extern errno_t __cdecl _wcslwr_s_l(__wchar_t *, size_t, _locale_t); } 
#line 298
template<size_t _Size> inline errno_t __cdecl _wcslwr_s_l(__wchar_t (&_String)[_Size], _locale_t _Locale) { return _wcslwr_s_l(_String, _Size, _Locale); } 
#line 299
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcslwr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcslwr_l(__wchar_t *, _locale_t); } 
#line 300
extern "C" { extern errno_t __cdecl _wcsupr_s(__wchar_t *, size_t); } 
#line 301
template<size_t _Size> inline errno_t __cdecl _wcsupr_s(__wchar_t (&_String)[_Size]) { return _wcsupr_s(_String, _Size); } 
#line 302
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsupr_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsupr(__wchar_t *); } 
#line 303
extern "C" { extern errno_t __cdecl _wcsupr_s_l(__wchar_t *, size_t, _locale_t); } 
#line 304
template<size_t _Size> inline errno_t __cdecl _wcsupr_s_l(__wchar_t (&_String)[_Size], _locale_t _Locale) { return _wcsupr_s_l(_String, _Size, _Locale); } 
#line 305
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcsupr_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wcsupr_l(__wchar_t *, _locale_t); } 
#line 306
extern "C" { extern size_t __cdecl wcsxfrm(__wchar_t *, const __wchar_t *, size_t); } 
#line 307
extern "C" { extern size_t __cdecl _wcsxfrm_l(__wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 308
extern "C" { extern int __cdecl wcscoll(const __wchar_t *, const __wchar_t *); } 
#line 309
extern "C" { extern int __cdecl _wcscoll_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 310
extern "C" { extern int __cdecl _wcsicoll(const __wchar_t *, const __wchar_t *); } 
#line 311
extern "C" { extern int __cdecl _wcsicoll_l(const __wchar_t *, const __wchar_t *, _locale_t); } 
#line 312
extern "C" { extern int __cdecl _wcsncoll(const __wchar_t *, const __wchar_t *, size_t); } 
#line 313
extern "C" { extern int __cdecl _wcsncoll_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 314
extern "C" { extern int __cdecl _wcsnicoll(const __wchar_t *, const __wchar_t *, size_t); } 
#line 315
extern "C" { extern int __cdecl _wcsnicoll_l(const __wchar_t *, const __wchar_t *, size_t, _locale_t); } 
#line 321
inline __wchar_t *__cdecl wcschr(__wchar_t *_Str, __wchar_t _Ch) 
#line 322
{ return (__wchar_t *)wcschr((const __wchar_t *)_Str, _Ch); } 
#line 323
inline __wchar_t *__cdecl wcspbrk(__wchar_t *_Str, const __wchar_t *_Control) 
#line 324
{ return (__wchar_t *)wcspbrk((const __wchar_t *)_Str, _Control); } 
#line 325
inline __wchar_t *__cdecl wcsrchr(__wchar_t *_Str, __wchar_t _Ch) 
#line 326
{ return (__wchar_t *)wcsrchr((const __wchar_t *)_Str, _Ch); } 
#line 327
inline __wchar_t *__cdecl wcsstr(__wchar_t *_Str, const __wchar_t *_SubStr) 
#line 328
{ return (__wchar_t *)wcsstr((const __wchar_t *)_Str, _SubStr); } 
#line 340 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsdup. See online help for details.")) __wchar_t *__cdecl wcsdup(const __wchar_t *); } 
#line 350 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\string.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsicmp. See online help for details.")) int __cdecl wcsicmp(const __wchar_t *, const __wchar_t *); } 
#line 351
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsnicmp. See online help for details.")) int __cdecl wcsnicmp(const __wchar_t *, const __wchar_t *, size_t); } 
#line 352
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsnset. See online help for details.")) __wchar_t *__cdecl wcsnset(__wchar_t *, __wchar_t, size_t); } 
#line 353
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsrev. See online help for details.")) __wchar_t *__cdecl wcsrev(__wchar_t *); } 
#line 354
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsset. See online help for details.")) __wchar_t *__cdecl wcsset(__wchar_t *, __wchar_t); } 
#line 355
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcslwr. See online help for details.")) __wchar_t *__cdecl wcslwr(__wchar_t *); } 
#line 356
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsupr. See online help for details.")) __wchar_t *__cdecl wcsupr(__wchar_t *); } 
#line 357
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _wcsicoll. See online help for details.")) int __cdecl wcsicoll(const __wchar_t *, const __wchar_t *); } 
#line 56 "c:\\cuda\\include\\common_functions.h"
extern "C" { extern clock_t clock(); } 
#line 59
extern "C" { extern void *memset(void *, int, size_t); } 
#line 62
extern "C" { extern void *memcpy(void *, const void *, size_t); } 
#line 65 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int abs(int); } 
#line 67
extern "C" { extern long labs(long); } 
#line 69
extern "C" { extern __int64 llabs(__int64); } 
#line 71
extern "C" { extern double fabs(double); } 
#line 73
extern "C" { inline float fabsf(float); } 
#line 76
extern "C" { extern int min(int, int); } 
#line 78
extern "C" { extern unsigned umin(unsigned, unsigned); } 
#line 80
extern "C" { extern float fminf(float, float); } 
#line 82
extern "C" { extern double fmin(double, double); } 
#line 85
extern "C" { extern int max(int, int); } 
#line 87
extern "C" { extern unsigned umax(unsigned, unsigned); } 
#line 89
extern "C" { extern float fmaxf(float, float); } 
#line 91
extern "C" { extern double fmax(double, double); } 
#line 94
extern "C" { extern double sin(double); } 
#line 96
extern "C" { inline float sinf(float); } 
#line 99
extern "C" { extern double cos(double); } 
#line 101
extern "C" { inline float cosf(float); } 
#line 104
extern "C" { extern void sincos(double, double *, double *); } 
#line 106
extern "C" { extern void sincosf(float, float *, float *); } 
#line 109
extern "C" { extern double tan(double); } 
#line 111
extern "C" { inline float tanf(float); } 
#line 114
extern "C" { extern double sqrt(double); } 
#line 116
extern "C" { inline float sqrtf(float); } 
#line 119
extern "C" { extern double rsqrt(double); } 
#line 121
extern "C" { extern float rsqrtf(float); } 
#line 124
extern "C" { extern double exp2(double); } 
#line 126
extern "C" { extern float exp2f(float); } 
#line 129
extern "C" { extern double exp10(double); } 
#line 131
extern "C" { extern float exp10f(float); } 
#line 134
extern "C" { extern double expm1(double); } 
#line 136
extern "C" { extern float expm1f(float); } 
#line 139
extern "C" { extern double log2(double); } 
#line 141
extern "C" { extern float log2f(float); } 
#line 144
extern "C" { extern double log10(double); } 
#line 146
extern "C" { inline float log10f(float); } 
#line 149
extern "C" { extern double log(double); } 
#line 151
extern "C" { inline float logf(float); } 
#line 154
extern "C" { extern double log1p(double); } 
#line 156
extern "C" { extern float log1pf(float); } 
#line 159
extern "C" { extern double floor(double); } 
#line 161
extern "C" { inline float floorf(float); } 
#line 164
extern "C" { extern double exp(double); } 
#line 166
extern "C" { inline float expf(float); } 
#line 169
extern "C" { extern double cosh(double); } 
#line 171
extern "C" { inline float coshf(float); } 
#line 174
extern "C" { extern double sinh(double); } 
#line 176
extern "C" { inline float sinhf(float); } 
#line 179
extern "C" { extern double tanh(double); } 
#line 181
extern "C" { inline float tanhf(float); } 
#line 184
extern "C" { extern double acosh(double); } 
#line 186
extern "C" { extern float acoshf(float); } 
#line 189
extern "C" { extern double asinh(double); } 
#line 191
extern "C" { extern float asinhf(float); } 
#line 194
extern "C" { extern double atanh(double); } 
#line 196
extern "C" { extern float atanhf(float); } 
#line 199
extern "C" { extern double ldexp(double, int); } 
#line 201
extern "C" { inline float ldexpf(float, int); } 
#line 204
extern "C" { extern double logb(double); } 
#line 206
extern "C" { extern float logbf(float); } 
#line 209
extern "C" { extern int ilogb(double); } 
#line 211
extern "C" { extern int ilogbf(float); } 
#line 214
extern "C" { extern double scalbn(double, int); } 
#line 216
extern "C" { extern float scalbnf(float, int); } 
#line 219
extern "C" { extern double scalbln(double, long); } 
#line 221
extern "C" { extern float scalblnf(float, long); } 
#line 224
extern "C" { extern double frexp(double, int *); } 
#line 226
extern "C" { inline float frexpf(float, int *); } 
#line 229
extern "C" { extern double round(double); } 
#line 231
extern "C" { extern float roundf(float); } 
#line 234
extern "C" { extern long lround(double); } 
#line 236
extern "C" { extern long lroundf(float); } 
#line 239
extern "C" { extern __int64 llround(double); } 
#line 241
extern "C" { extern __int64 llroundf(float); } 
#line 244
extern "C" { extern double rint(double); } 
#line 246
extern "C" { extern float rintf(float); } 
#line 249
extern "C" { extern long lrint(double); } 
#line 251
extern "C" { extern long lrintf(float); } 
#line 254
extern "C" { extern __int64 llrint(double); } 
#line 256
extern "C" { extern __int64 llrintf(float); } 
#line 259
extern "C" { extern double nearbyint(double); } 
#line 261
extern "C" { extern float nearbyintf(float); } 
#line 264
extern "C" { extern double ceil(double); } 
#line 266
extern "C" { inline float ceilf(float); } 
#line 269
extern "C" { extern double trunc(double); } 
#line 271
extern "C" { extern float truncf(float); } 
#line 274
extern "C" { extern double fdim(double, double); } 
#line 276
extern "C" { extern float fdimf(float, float); } 
#line 279
extern "C" { extern double atan2(double, double); } 
#line 281
extern "C" { inline float atan2f(float, float); } 
#line 284
extern "C" { extern double atan(double); } 
#line 286
extern "C" { inline float atanf(float); } 
#line 289
extern "C" { extern double asin(double); } 
#line 291
extern "C" { inline float asinf(float); } 
#line 294
extern "C" { extern double acos(double); } 
#line 296
extern "C" { inline float acosf(float); } 
#line 299
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _hypot. See online help for details.")) double hypot(double, double); } 
#line 301
extern "C" { extern float hypotf(float, float); } 
#line 304
extern "C" { extern double cbrt(double); } 
#line 306
extern "C" { extern float cbrtf(float); } 
#line 309
extern "C" { extern double pow(double, double); } 
#line 311
extern "C" { inline float powf(float, float); } 
#line 314
extern "C" { extern double modf(double, double *); } 
#line 316
extern "C" { inline float modff(float, float *); } 
#line 319
extern "C" { extern double fmod(double, double); } 
#line 321
extern "C" { inline float fmodf(float, float); } 
#line 324
extern "C" { extern double remainder(double, double); } 
#line 326
extern "C" { extern float remainderf(float, float); } 
#line 329
extern "C" { extern double remquo(double, double, int *); } 
#line 331
extern "C" { extern float remquof(float, float, int *); } 
#line 334
extern "C" { extern double erf(double); } 
#line 336
extern "C" { extern float erff(float); } 
#line 339
extern "C" { extern double erfc(double); } 
#line 341
extern "C" { extern float erfcf(float); } 
#line 344
extern "C" { extern double lgamma(double); } 
#line 346
extern "C" { extern float lgammaf(float); } 
#line 349
extern "C" { extern double tgamma(double); } 
#line 351
extern "C" { extern float tgammaf(float); } 
#line 354
extern "C" { extern double copysign(double, double); } 
#line 356
extern "C" { extern float copysignf(float, float); } 
#line 359
extern "C" { extern double nextafter(double, double); } 
#line 361
extern "C" { extern float nextafterf(float, float); } 
#line 364
extern "C" { extern double nan(const char *); } 
#line 366
extern "C" { extern float nanf(const char *); } 
#line 369
extern "C" { extern int __isinf(double); } 
#line 371
extern "C" { extern int __isinff(float); } 
#line 374
extern "C" { extern int __isnan(double); } 
#line 376
extern "C" { extern int __isnanf(float); } 
#line 390
extern "C" { extern int __finite(double); } 
#line 392
extern "C" { extern int __finitef(float); } 
#line 394
extern "C" { extern int __signbit(double); } 
#line 399 "c:\\cuda\\include\\math_functions.h"
extern "C" { extern int __signbitf(float); } 
#line 402
extern "C" { extern double fma(double, double, double); } 
#line 404
extern "C" { extern float fmaf(float, float, float); } 
#line 25 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
#pragma pack ( push, 8 )
#line 39 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { struct _exception { 
#line 40
int type; 
#line 41
char *name; 
#line 42
double arg1; 
#line 43
double arg2; 
#line 44
double retval; 
#line 45
}; }
#line 56 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { struct _complex { 
#line 57
double x; double y; 
#line 58
}; }
#line 90 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" double _HUGE; 
#line 103 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern int __cdecl abs(int); } 
#line 104
extern "C" { extern long __cdecl labs(long); } 
#line 107 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl acos(double); } 
#line 108
extern "C" { extern double __cdecl asin(double); } 
#line 109
extern "C" { extern double __cdecl atan(double); } 
#line 110
extern "C" { extern double __cdecl atan2(double, double); } 
#line 112
extern "C" { extern double __cdecl _copysign(double, double); } 
#line 113
extern "C" { extern double __cdecl _chgsign(double); } 
#line 116 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl cos(double); } 
#line 117
extern "C" { extern double __cdecl cosh(double); } 
#line 118
extern "C" { extern double __cdecl exp(double); } 
#line 119
extern "C" { extern double __cdecl fabs(double); } 
#line 120
extern "C" { extern double __cdecl fmod(double, double); } 
#line 121
extern "C" { extern double __cdecl log(double); } 
#line 122
extern "C" { extern double __cdecl log10(double); } 
#line 123
extern "C" { extern double __cdecl pow(double, double); } 
#line 124
extern "C" { extern double __cdecl sin(double); } 
#line 125
extern "C" { extern double __cdecl sinh(double); } 
#line 126
extern "C" { extern double __cdecl tan(double); } 
#line 127
extern "C" { extern double __cdecl tanh(double); } 
#line 128
extern "C" { extern double __cdecl sqrt(double); } 
#line 131
extern "C" { extern double __cdecl atof(const char *); } 
#line 132
extern "C" { extern double __cdecl _atof_l(const char *, _locale_t); } 
#line 135 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl _cabs(_complex); } 
#line 136
extern "C" { extern double __cdecl ceil(double); } 
#line 137
extern "C" { extern double __cdecl floor(double); } 
#line 138
extern "C" { extern double __cdecl frexp(double, int *); } 
#line 139
extern "C" { extern double __cdecl _hypot(double, double); } 
#line 140
extern "C" { extern double __cdecl _j0(double); } 
#line 141
extern "C" { extern double __cdecl _j1(double); } 
#line 142
extern "C" { extern double __cdecl _jn(int, double); } 
#line 143
extern "C" { extern double __cdecl ldexp(double, int); } 
#line 149 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern int __cdecl _matherr(_exception *); } 
#line 152 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern double __cdecl modf(double, double *); } 
#line 154
extern "C" { extern double __cdecl _y0(double); } 
#line 155
extern "C" { extern double __cdecl _y1(double); } 
#line 156
extern "C" { extern double __cdecl _yn(int, double); } 
#line 161
extern "C" { extern int __cdecl _set_SSE2_enable(int); } 
#line 162
extern "C" { extern float __cdecl _hypotf(float, float); } 
#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double acosl(long double _X) 
#line 318
{ return acos((double)_X); } } 
#line 319
extern "C" { inline long double asinl(long double _X) 
#line 320
{ return asin((double)_X); } } 
#line 321
extern "C" { inline long double atanl(long double _X) 
#line 322
{ return atan((double)_X); } } 
#line 323
extern "C" { inline long double atan2l(long double _X, long double _Y) 
#line 324
{ return atan2((double)_X, (double)_Y); } } 
#line 325
extern "C" { inline long double ceill(long double _X) 
#line 326
{ return ceil((double)_X); } } 
#line 327
extern "C" { inline long double cosl(long double _X) 
#line 328
{ return cos((double)_X); } } 
#line 329
extern "C" { inline long double coshl(long double _X) 
#line 330
{ return cosh((double)_X); } } 
#line 331
extern "C" { inline long double expl(long double _X) 
#line 332
{ return exp((double)_X); } } 
#line 333
extern "C" { inline long double fabsl(long double _X) 
#line 334
{ return fabs((double)_X); } } 
#line 335
extern "C" { inline long double floorl(long double _X) 
#line 336
{ return floor((double)_X); } } 
#line 337
extern "C" { inline long double fmodl(long double _X, long double _Y) 
#line 338
{ return fmod((double)_X, (double)_Y); } } 
#line 339
extern "C" { inline long double frexpl(long double _X, int *_Y) 
#line 340
{ return frexp((double)_X, _Y); } } 
#line 341
extern "C" { inline long double ldexpl(long double _X, int _Y) 
#line 342
{ return ldexp((double)_X, _Y); } } 
#line 343
extern "C" { inline long double logl(long double _X) 
#line 344
{ return log((double)_X); } } 
#line 345
extern "C" { inline long double log10l(long double _X) 
#line 346
{ return log10((double)_X); } } 
#line 347
extern "C" { inline long double modfl(long double _X, long double *_Y) 
#line 348
{ auto double _Di; auto double _Df = modf((double)_X, &_Di); 
#line 349
(*_Y) = (long double)_Di; 
#line 350
return _Df; } } 
#line 351
extern "C" { inline long double powl(long double _X, long double _Y) 
#line 352
{ return pow((double)_X, (double)_Y); } } 
#line 353
extern "C" { inline long double sinl(long double _X) 
#line 354
{ return sin((double)_X); } } 
#line 355
extern "C" { inline long double sinhl(long double _X) 
#line 356
{ return sinh((double)_X); } } 
#line 357
extern "C" { inline long double sqrtl(long double _X) 
#line 358
{ return sqrt((double)_X); } } 
#line 360
extern "C" { inline long double tanl(long double _X) 
#line 361
{ return tan((double)_X); } } 
#line 366 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { inline long double tanhl(long double _X) 
#line 367
{ return tanh((double)_X); } } 
#line 369
extern "C" { inline long double _chgsignl(long double _Number) 
#line 370
{ 
#line 371
return _chgsign(static_cast< double>(_Number)); 
#line 372
} } 
#line 374
extern "C" { inline long double _copysignl(long double _Number, long double _Sign) 
#line 375
{ 
#line 376
return _copysign(static_cast< double>(_Number), static_cast< double>(_Sign)); 
#line 377
} } 
#line 379
extern "C" { inline float frexpf(float _X, int *_Y) 
#line 380
{ return (float)frexp((double)_X, _Y); } } 
#line 383
extern "C" { inline float fabsf(float _X) 
#line 384
{ return (float)fabs((double)_X); } } 
#line 385
extern "C" { inline float ldexpf(float _X, int _Y) 
#line 386
{ return (float)ldexp((double)_X, _Y); } } 
#line 388
extern "C" { inline float acosf(float _X) 
#line 389
{ return (float)acos((double)_X); } } 
#line 390
extern "C" { inline float asinf(float _X) 
#line 391
{ return (float)asin((double)_X); } } 
#line 392
extern "C" { inline float atanf(float _X) 
#line 393
{ return (float)atan((double)_X); } } 
#line 394
extern "C" { inline float atan2f(float _X, float _Y) 
#line 395
{ return (float)atan2((double)_X, (double)_Y); } } 
#line 396
extern "C" { inline float ceilf(float _X) 
#line 397
{ return (float)ceil((double)_X); } } 
#line 398
extern "C" { inline float cosf(float _X) 
#line 399
{ return (float)cos((double)_X); } } 
#line 400
extern "C" { inline float coshf(float _X) 
#line 401
{ return (float)cosh((double)_X); } } 
#line 402
extern "C" { inline float expf(float _X) 
#line 403
{ return (float)exp((double)_X); } } 
#line 404
extern "C" { inline float floorf(float _X) 
#line 405
{ return (float)floor((double)_X); } } 
#line 406
extern "C" { inline float fmodf(float _X, float _Y) 
#line 407
{ return (float)fmod((double)_X, (double)_Y); } } 
#line 408
extern "C" { inline float logf(float _X) 
#line 409
{ return (float)log((double)_X); } } 
#line 410
extern "C" { inline float log10f(float _X) 
#line 411
{ return (float)log10((double)_X); } } 
#line 412
extern "C" { inline float modff(float _X, float *_Y) 
#line 413
{ auto double _Di; auto double _Df = modf((double)_X, &_Di); 
#line 414
(*_Y) = (float)_Di; 
#line 415
return (float)_Df; } } 
#line 416
extern "C" { inline float powf(float _X, float _Y) 
#line 417
{ return (float)pow((double)_X, (double)_Y); } } 
#line 418
extern "C" { inline float sinf(float _X) 
#line 419
{ return (float)sin((double)_X); } } 
#line 420
extern "C" { inline float sinhf(float _X) 
#line 421
{ return (float)sinh((double)_X); } } 
#line 422
extern "C" { inline float sqrtf(float _X) 
#line 423
{ return (float)sqrt((double)_X); } } 
#line 424
extern "C" { inline float tanf(float _X) 
#line 425
{ return (float)tan((double)_X); } } 
#line 426
extern "C" { inline float tanhf(float _X) 
#line 427
{ return (float)tanh((double)_X); } } 
#line 449 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" double HUGE; 
#line 454 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _cabs. See online help for details.")) double __cdecl cabs(_complex); } 
#line 455
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _hypot. See online help for details.")) double __cdecl hypot(double, double); } 
#line 456
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _j0. See online help for details.")) double __cdecl j0(double); } 
#line 457
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _j1. See online help for details.")) double __cdecl j1(double); } 
#line 458
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _jn. See online help for details.")) double __cdecl jn(int, double); } 
#line 459
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _y0. See online help for details.")) double __cdecl y0(double); } 
#line 460
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _y1. See online help for details.")) double __cdecl y1(double); } 
#line 461
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _yn. See online help for details.")) double __cdecl yn(int, double); } 
#line 472 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
template<class _Ty> inline _Ty 
#line 473
_Pow_int(_Ty _X, int _Y) 
#line 474
{ auto unsigned _N; 
#line 475
if (_Y >= 0) { 
#line 476
_N = (unsigned)_Y; } else { 
#line 478
_N = (unsigned)(-_Y); }  
#line 479
for (_Ty _Z = ((_Ty)(1)); ; _X *= _X) 
#line 480
{ if ((_N & (1)) != (0)) { 
#line 481
_Z *= _X; }  
#line 482
if ((_N >>= 1) == (0)) { 
#line 483
return (_Y < 0) ? (((_Ty)(1)) / _Z) : _Z; }  }  } 
#line 485
inline long __cdecl abs(long _X) 
#line 486
{ return labs(_X); } 
#line 487
inline double __cdecl abs(double _X) 
#line 488
{ return fabs(_X); } 
#line 489
inline double __cdecl pow(double _X, int _Y) 
#line 490
{ return _Pow_int(_X, _Y); } 
#line 491
inline float __cdecl abs(float _X) 
#line 492
{ return fabsf(_X); } 
#line 493
inline float __cdecl acos(float _X) 
#line 494
{ return acosf(_X); } 
#line 495
inline float __cdecl asin(float _X) 
#line 496
{ return asinf(_X); } 
#line 497
inline float __cdecl atan(float _X) 
#line 498
{ return atanf(_X); } 
#line 499
inline float __cdecl atan2(float _Y, float _X) 
#line 500
{ return atan2f(_Y, _X); } 
#line 501
inline float __cdecl ceil(float _X) 
#line 502
{ return ceilf(_X); } 
#line 503
inline float __cdecl cos(float _X) 
#line 504
{ return cosf(_X); } 
#line 505
inline float __cdecl cosh(float _X) 
#line 506
{ return coshf(_X); } 
#line 507
inline float __cdecl exp(float _X) 
#line 508
{ return expf(_X); } 
#line 509
inline float __cdecl fabs(float _X) 
#line 510
{ return fabsf(_X); } 
#line 511
inline float __cdecl floor(float _X) 
#line 512
{ return floorf(_X); } 
#line 513
inline float __cdecl fmod(float _X, float _Y) 
#line 514
{ return fmodf(_X, _Y); } 
#line 515
inline float __cdecl frexp(float _X, int *_Y) 
#line 516
{ return frexpf(_X, _Y); } 
#line 517
inline float __cdecl ldexp(float _X, int _Y) 
#line 518
{ return ldexpf(_X, _Y); } 
#line 519
inline float __cdecl log(float _X) 
#line 520
{ return logf(_X); } 
#line 521
inline float __cdecl log10(float _X) 
#line 522
{ return log10f(_X); } 
#line 523
inline float __cdecl modf(float _X, float *_Y) 
#line 524
{ return modff(_X, _Y); } 
#line 525
inline float __cdecl pow(float _X, float _Y) 
#line 526
{ return powf(_X, _Y); } 
#line 527
inline float __cdecl pow(float _X, int _Y) 
#line 528
{ return _Pow_int(_X, _Y); } 
#line 529
inline float __cdecl sin(float _X) 
#line 530
{ return sinf(_X); } 
#line 531
inline float __cdecl sinh(float _X) 
#line 532
{ return sinhf(_X); } 
#line 533
inline float __cdecl sqrt(float _X) 
#line 534
{ return sqrtf(_X); } 
#line 535
inline float __cdecl tan(float _X) 
#line 536
{ return tanf(_X); } 
#line 537
inline float __cdecl tanh(float _X) 
#line 538
{ return tanhf(_X); } 
#line 539
inline long double __cdecl abs(long double _X) 
#line 540
{ return fabsl(_X); } 
#line 541
inline long double __cdecl acos(long double _X) 
#line 542
{ return acosl(_X); } 
#line 543
inline long double __cdecl asin(long double _X) 
#line 544
{ return asinl(_X); } 
#line 545
inline long double __cdecl atan(long double _X) 
#line 546
{ return atanl(_X); } 
#line 547
inline long double __cdecl atan2(long double _Y, long double _X) 
#line 548
{ return atan2l(_Y, _X); } 
#line 549
inline long double __cdecl ceil(long double _X) 
#line 550
{ return ceill(_X); } 
#line 551
inline long double __cdecl cos(long double _X) 
#line 552
{ return cosl(_X); } 
#line 553
inline long double __cdecl cosh(long double _X) 
#line 554
{ return coshl(_X); } 
#line 555
inline long double __cdecl exp(long double _X) 
#line 556
{ return expl(_X); } 
#line 557
inline long double __cdecl fabs(long double _X) 
#line 558
{ return fabsl(_X); } 
#line 559
inline long double __cdecl floor(long double _X) 
#line 560
{ return floorl(_X); } 
#line 561
inline long double __cdecl fmod(long double _X, long double _Y) 
#line 562
{ return fmodl(_X, _Y); } 
#line 563
inline long double __cdecl frexp(long double _X, int *_Y) 
#line 564
{ return frexpl(_X, _Y); } 
#line 565
inline long double __cdecl ldexp(long double _X, int _Y) 
#line 566
{ return ldexpl(_X, _Y); } 
#line 567
inline long double __cdecl log(long double _X) 
#line 568
{ return logl(_X); } 
#line 569
inline long double __cdecl log10(long double _X) 
#line 570
{ return log10l(_X); } 
#line 571
inline long double __cdecl modf(long double _X, long double *_Y) 
#line 572
{ return modfl(_X, _Y); } 
#line 573
inline long double __cdecl pow(long double _X, long double _Y) 
#line 574
{ return powl(_X, _Y); } 
#line 575
inline long double __cdecl pow(long double _X, int _Y) 
#line 576
{ return _Pow_int(_X, _Y); } 
#line 577
inline long double __cdecl sin(long double _X) 
#line 578
{ return sinl(_X); } 
#line 579
inline long double __cdecl sinh(long double _X) 
#line 580
{ return sinhl(_X); } 
#line 581
inline long double __cdecl sqrt(long double _X) 
#line 582
{ return sqrtl(_X); } 
#line 583
inline long double __cdecl tan(long double _X) 
#line 584
{ return tanl(_X); } 
#line 585
inline long double __cdecl tanh(long double _X) 
#line 586
{ return tanhl(_X); } 
#line 592 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\math.h"
#pragma pack ( pop )
#line 31 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( push, 8 )
#line 56 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef int (__cdecl *_onexit_t)(void); }
#line 82 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 79
struct _div_t { 
#line 80
int quot; 
#line 81
int rem; 
#line 82
} div_t; }
#line 87
extern "C" { typedef 
#line 84
struct _ldiv_t { 
#line 85
long quot; 
#line 86
long rem; 
#line 87
} ldiv_t; }
#line 101 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( 4 )
#line 104
extern "C" { typedef 
#line 102
struct _LDOUBLE { 
#line 103
unsigned char ld[10]; 
#line 104
} _LDOUBLE; }
#pragma pack ( )
#line 123 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef 
#line 121
struct _CRT_DOUBLE { 
#line 122
double x; 
#line 123
} _CRT_DOUBLE; }
#line 127
extern "C" { typedef 
#line 125
struct _CRT_FLOAT { 
#line 126
float f; 
#line 127
} _CRT_FLOAT; }
#line 138
extern "C" { typedef 
#line 133
struct _LONGDOUBLE { 
#line 137
long double x; 
#line 138
} _LONGDOUBLE; }
#line 142
#pragma pack ( 4 )
#line 145
extern "C" { typedef 
#line 143
struct _LDBL12 { 
#line 144
unsigned char ld12[12]; 
#line 145
} _LDBL12; }
#pragma pack ( )
#line 166 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" int __mb_cur_max; 
#line 171 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl ___mb_cur_max_func(); } 
#line 172
extern "C" { extern int __cdecl ___mb_cur_max_l_func(_locale_t); } 
#line 211 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef void (__cdecl *_purecall_handler)(void); }
#line 214
extern "C" { extern _purecall_handler __cdecl _set_purecall_handler(_purecall_handler); } 
#line 215
extern "C" { extern _purecall_handler __cdecl _get_purecall_handler(); } 
#line 239 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { typedef void (__cdecl *_invalid_parameter_handler)(const __wchar_t *, const __wchar_t *, const __wchar_t *, unsigned, uintptr_t); }
#line 242
extern "C" { extern _invalid_parameter_handler __cdecl _set_invalid_parameter_handler(_invalid_parameter_handler); } 
#line 243
extern "C" { extern _invalid_parameter_handler __cdecl _get_invalid_parameter_handler(); } 
#line 274 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned long *__cdecl __doserrno(); } 
#line 277
extern "C" { extern errno_t __cdecl _set_doserrno(unsigned long); } 
#line 278
extern "C" { extern errno_t __cdecl _get_doserrno(unsigned long *); } 
#line 281
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char **__cdecl __sys_errlist(); } 
#line 284
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using strerror instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int *__cdecl __sys_nerr(); } 
#line 301 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" int __argc; 
#line 302
extern "C" char **__argv; 
#line 303
extern "C" __wchar_t **__wargv; 
#line 317 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" char **_environ; 
#line 318
extern "C" __wchar_t **_wenviron; 
#line 321 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_pgmptr instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *_pgmptr; 
#line 322
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_wpgmptr instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *_wpgmptr; 
#line 339 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _get_pgmptr(char **); } 
#line 340
extern "C" { extern errno_t __cdecl _get_wpgmptr(__wchar_t **); } 
#line 344
extern "C" __declspec(deprecated("This function or variable may be unsafe. Consider using _get_fmode instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int _fmode; 
#line 350 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _set_fmode(int); } 
#line 351
extern "C" { extern errno_t __cdecl _get_fmode(int *); } 
#line 355
#pragma warning(push)
#pragma warning(disable:4141)
#line 359
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _osplatform; 
#line 360
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _osver; 
#line 361
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winver; 
#line 362
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winmajor; 
#line 363
extern "C" __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) unsigned _winminor; 
#line 380 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(pop)
#line 382
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_osplatform(unsigned *); } 
#line 383
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_osver(unsigned *); } 
#line 384
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winver(unsigned *); } 
#line 385
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winmajor(unsigned *); } 
#line 386
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingGetVersionExinstead. See online help for details.")) errno_t __cdecl _get_winminor(unsigned *); } 
#line 395 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<class _CountofType, size_t _SizeOfArray> extern char (*__countof_helper(_CountofType (&)[_SizeOfArray]))[_SizeOfArray]; 
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec( noreturn ) void __cdecl exit(int); } 
#line 407
extern "C" { extern __declspec( noreturn ) void __cdecl _exit(int); } 
#line 408
extern "C" { extern void __cdecl abort(); } 
#line 411 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __cdecl _set_abort_behavior(unsigned, unsigned); } 
#line 420
extern "C" { extern __int64 __cdecl _abs64(__int64); } 
#line 446 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl atexit(void (__cdecl *)(void)); } 
#line 453 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl atoi(const char *); } 
#line 454
extern "C" { extern int __cdecl _atoi_l(const char *, _locale_t); } 
#line 455
extern "C" { extern long __cdecl atol(const char *); } 
#line 456
extern "C" { extern long __cdecl _atol_l(const char *, _locale_t); } 
#line 460
extern "C" { extern void *__cdecl bsearch_s(const void *, const void *, rsize_t, rsize_t, int (__cdecl *)(void *, const void *, const void *), void *); } 
#line 464 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl bsearch(const void *, const void *, size_t, size_t, int (__cdecl *)(const void *, const void *)); } 
#line 469
extern "C" { extern void __cdecl qsort_s(void *, rsize_t, rsize_t, int (__cdecl *)(void *, const void *, const void *), void *); } 
#line 473 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl qsort(void *, size_t, size_t, int (__cdecl *)(const void *, const void *)); } 
#line 477 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned short __cdecl _byteswap_ushort(unsigned short); } 
#line 478
extern "C" { extern unsigned long __cdecl _byteswap_ulong(unsigned long); } 
#line 480
extern "C" { extern unsigned __int64 __cdecl _byteswap_uint64(unsigned __int64); } 
#line 482 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern div_t __cdecl div(int, int); } 
#line 483
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _dupenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl getenv(const char *); } 
#line 485
extern "C" { extern errno_t __cdecl getenv_s(size_t *, char *, rsize_t, const char *); } 
#line 487 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
template<size_t _Size> inline errno_t __cdecl getenv_s(size_t *_ReturnSize, char (&_Dest)[_Size], const char *_VarName) { return getenv_s(_ReturnSize, _Dest, _Size, _VarName); } 
#line 488
extern "C" { extern errno_t __cdecl _dupenv_s(char **, size_t *, const char *); } 
#line 489
extern "C" { extern errno_t __cdecl _itoa_s(int, char *, size_t, int); } 
#line 490
template<size_t _Size> inline errno_t __cdecl _itoa_s(int _Value, char (&_Dest)[_Size], int _Radix) { return _itoa_s(_Value, _Dest, _Size, _Radix); } 
#line 491
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _itoa(int, char *, int); } 
#line 493
extern "C" { extern errno_t __cdecl _i64toa_s(__int64, char *, size_t, int); } 
#line 494
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _i64toa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _i64toa(__int64, char *, int); } 
#line 495
extern "C" { extern errno_t __cdecl _ui64toa_s(unsigned __int64, char *, size_t, int); } 
#line 496
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ui64toa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ui64toa(unsigned __int64, char *, int); } 
#line 497
extern "C" { extern __int64 __cdecl _atoi64(const char *); } 
#line 498
extern "C" { extern __int64 __cdecl _atoi64_l(const char *, _locale_t); } 
#line 499
extern "C" { extern __int64 __cdecl _strtoi64(const char *, char **, int); } 
#line 500
extern "C" { extern __int64 __cdecl _strtoi64_l(const char *, char **, int, _locale_t); } 
#line 501
extern "C" { extern unsigned __int64 __cdecl _strtoui64(const char *, char **, int); } 
#line 502
extern "C" { extern unsigned __int64 __cdecl _strtoui64_l(const char *, char **, int, _locale_t); } 
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern ldiv_t __cdecl ldiv(long, long); } 
#line 508
inline ldiv_t div(long _A1, long _A2) 
#line 509
{ 
#line 510
return ldiv(_A1, _A2); 
#line 511
} 
#line 514 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ltoa_s(long, char *, size_t, int); } 
#line 515
template<size_t _Size> inline errno_t __cdecl _ltoa_s(long _Value, char (&_Dest)[_Size], int _Radix) { return _ltoa_s(_Value, _Dest, _Size, _Radix); } 
#line 516
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ltoa(long, char *, int); } 
#line 517
extern "C" { extern int __cdecl mblen(const char *, size_t); } 
#line 518
extern "C" { extern int __cdecl _mblen_l(const char *, size_t, _locale_t); } 
#line 519
extern "C" { extern size_t __cdecl _mbstrlen(const char *); } 
#line 520
extern "C" { extern size_t __cdecl _mbstrlen_l(const char *, _locale_t); } 
#line 521
extern "C" { extern size_t __cdecl _mbstrnlen(const char *, size_t); } 
#line 522
extern "C" { extern size_t __cdecl _mbstrnlen_l(const char *, size_t, _locale_t); } 
#line 523
extern "C" { extern int __cdecl mbtowc(__wchar_t *, const char *, size_t); } 
#line 524
extern "C" { extern int __cdecl _mbtowc_l(__wchar_t *, const char *, size_t, _locale_t); } 
#line 525
extern "C" { extern errno_t __cdecl mbstowcs_s(size_t *, __wchar_t *, size_t, const char *, size_t); } 
#line 526
template<size_t _Size> inline errno_t __cdecl mbstowcs_s(size_t *_PtNumOfCharConverted, __wchar_t (&_Dest)[_Size], const char *_Source, size_t _MaxCount) { return mbstowcs_s(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount); } 
#line 527
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using mbstowcs_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl mbstowcs(__wchar_t *, const char *, size_t); } 
#line 529
extern "C" { extern errno_t __cdecl _mbstowcs_s_l(size_t *, __wchar_t *, size_t, const char *, size_t, _locale_t); } 
#line 530
template<size_t _Size> inline errno_t __cdecl _mbstowcs_s_l(size_t *_PtNumOfCharConverted, __wchar_t (&_Dest)[_Size], const char *_Source, size_t _MaxCount, _locale_t _Locale) { return _mbstowcs_s_l(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount, _Locale); } 
#line 531
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _mbstowcs_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl _mbstowcs_l(__wchar_t *, const char *, size_t, _locale_t); } 
#line 533
extern "C" { extern int __cdecl rand(); } 
#line 538 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _set_error_mode(int); } 
#line 540
extern "C" { extern void __cdecl srand(unsigned); } 
#line 541
extern "C" { extern double __cdecl strtod(const char *, char **); } 
#line 542
extern "C" { extern double __cdecl _strtod_l(const char *, char **, _locale_t); } 
#line 543
extern "C" { extern long __cdecl strtol(const char *, char **, int); } 
#line 544
extern "C" { extern long __cdecl _strtol_l(const char *, char **, int, _locale_t); } 
#line 545
extern "C" { extern unsigned long __cdecl strtoul(const char *, char **, int); } 
#line 546
extern "C" { extern unsigned long __cdecl _strtoul_l(const char *, char **, int, _locale_t); } 
#line 549
extern "C" { extern int __cdecl system(const char *); } 
#line 551 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ultoa_s(unsigned long, char *, size_t, int); } 
#line 552
template<size_t _Size> inline errno_t __cdecl _ultoa_s(unsigned long _Value, char (&_Dest)[_Size], int _Radix) { return _ultoa_s(_Value, _Dest, _Size, _Radix); } 
#line 553
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ultoa(unsigned long, char *, int); } 
#line 554
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wctomb_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl wctomb(char *, __wchar_t); } 
#line 555
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wctomb_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _wctomb_l(char *, __wchar_t, _locale_t); } 
#line 557
extern "C" { extern errno_t __cdecl wctomb_s(int *, char *, rsize_t, __wchar_t); } 
#line 559 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wctomb_s_l(int *, char *, size_t, __wchar_t, _locale_t); } 
#line 560
extern "C" { extern errno_t __cdecl wcstombs_s(size_t *, char *, size_t, const __wchar_t *, size_t); } 
#line 561
template<size_t _Size> inline errno_t __cdecl wcstombs_s(size_t *_PtNumOfCharConverted, char (&_Dest)[_Size], const __wchar_t *_Source, size_t _MaxCount) { return wcstombs_s(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount); } 
#line 562
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wcstombs_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl wcstombs(char *, const __wchar_t *, size_t); } 
#line 563
extern "C" { extern errno_t __cdecl _wcstombs_s_l(size_t *, char *, size_t, const __wchar_t *, size_t, _locale_t); } 
#line 564
template<size_t _Size> inline errno_t __cdecl _wcstombs_s_l(size_t *_PtNumOfCharConverted, char (&_Dest)[_Size], const __wchar_t *_Source, size_t _MaxCount, _locale_t _Locale) { return _wcstombs_s_l(_PtNumOfCharConverted, _Dest, _Size, _Source, _MaxCount, _Locale); } 
#line 565
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wcstombs_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) size_t __cdecl _wcstombs_l(char *, const __wchar_t *, size_t, _locale_t); } 
#line 592 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void *__cdecl calloc(size_t, size_t); } 
#line 593
extern "C" { extern void __cdecl free(void *); } 
#line 594
extern "C" { extern void *__cdecl malloc(size_t); } 
#line 595
extern "C" { extern void *__cdecl realloc(void *, size_t); } 
#line 596
extern "C" { extern void *__cdecl _recalloc(void *, size_t, size_t); } 
#line 597
extern "C" { extern void __cdecl _aligned_free(void *); } 
#line 598
extern "C" { extern void *__cdecl _aligned_malloc(size_t, size_t); } 
#line 599
extern "C" { extern void *__cdecl _aligned_offset_malloc(size_t, size_t, size_t); } 
#line 600
extern "C" { extern void *__cdecl _aligned_realloc(void *, size_t, size_t); } 
#line 601
extern "C" { extern void *__cdecl _aligned_recalloc(void *, size_t, size_t, size_t); } 
#line 602
extern "C" { extern void *__cdecl _aligned_offset_realloc(void *, size_t, size_t, size_t); } 
#line 603
extern "C" { extern void *__cdecl _aligned_offset_recalloc(void *, size_t, size_t, size_t, size_t); } 
#line 610 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _itow_s(int, __wchar_t *, size_t, int); } 
#line 611
template<size_t _Size> inline errno_t __cdecl _itow_s(int _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _itow_s(_Value, _Dest, _Size, _Radix); } 
#line 612
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _itow(int, __wchar_t *, int); } 
#line 613
extern "C" { extern errno_t __cdecl _ltow_s(long, __wchar_t *, size_t, int); } 
#line 614
template<size_t _Size> inline errno_t __cdecl _ltow_s(long _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _ltow_s(_Value, _Dest, _Size, _Radix); } 
#line 615
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ltow(long, __wchar_t *, int); } 
#line 616
extern "C" { extern errno_t __cdecl _ultow_s(unsigned long, __wchar_t *, size_t, int); } 
#line 617
template<size_t _Size> inline errno_t __cdecl _ultow_s(unsigned long _Value, __wchar_t (&_Dest)[_Size], int _Radix) { return _ultow_s(_Value, _Dest, _Size, _Radix); } 
#line 618
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ultow(unsigned long, __wchar_t *, int); } 
#line 619
extern "C" { extern double __cdecl wcstod(const __wchar_t *, __wchar_t **); } 
#line 620
extern "C" { extern double __cdecl _wcstod_l(const __wchar_t *, __wchar_t **, _locale_t); } 
#line 621
extern "C" { extern long __cdecl wcstol(const __wchar_t *, __wchar_t **, int); } 
#line 622
extern "C" { extern long __cdecl _wcstol_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 623
extern "C" { extern unsigned long __cdecl wcstoul(const __wchar_t *, __wchar_t **, int); } 
#line 624
extern "C" { extern unsigned long __cdecl _wcstoul_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 625
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wdupenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wgetenv(const __wchar_t *); } 
#line 626
extern "C" { extern errno_t __cdecl _wgetenv_s(size_t *, __wchar_t *, size_t, const __wchar_t *); } 
#line 627
template<size_t _Size> inline errno_t __cdecl _wgetenv_s(size_t *_ReturnSize, __wchar_t (&_Dest)[_Size], const __wchar_t *_VarName) { return _wgetenv_s(_ReturnSize, _Dest, _Size, _VarName); } 
#line 628
extern "C" { extern errno_t __cdecl _wdupenv_s(__wchar_t **, size_t *, const __wchar_t *); } 
#line 631
extern "C" { extern int __cdecl _wsystem(const __wchar_t *); } 
#line 633 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern double __cdecl _wtof(const __wchar_t *); } 
#line 634
extern "C" { extern double __cdecl _wtof_l(const __wchar_t *, _locale_t); } 
#line 635
extern "C" { extern int __cdecl _wtoi(const __wchar_t *); } 
#line 636
extern "C" { extern int __cdecl _wtoi_l(const __wchar_t *, _locale_t); } 
#line 637
extern "C" { extern long __cdecl _wtol(const __wchar_t *); } 
#line 638
extern "C" { extern long __cdecl _wtol_l(const __wchar_t *, _locale_t); } 
#line 641
extern "C" { extern errno_t __cdecl _i64tow_s(__int64, __wchar_t *, size_t, int); } 
#line 642
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _i65tow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _i64tow(__int64, __wchar_t *, int); } 
#line 643
extern "C" { extern errno_t __cdecl _ui64tow_s(unsigned __int64, __wchar_t *, size_t, int); } 
#line 644
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ui64tow_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _ui64tow(unsigned __int64, __wchar_t *, int); } 
#line 645
extern "C" { extern __int64 __cdecl _wtoi64(const __wchar_t *); } 
#line 646
extern "C" { extern __int64 __cdecl _wtoi64_l(const __wchar_t *, _locale_t); } 
#line 647
extern "C" { extern __int64 __cdecl _wcstoi64(const __wchar_t *, __wchar_t **, int); } 
#line 648
extern "C" { extern __int64 __cdecl _wcstoi64_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 649
extern "C" { extern unsigned __int64 __cdecl _wcstoui64(const __wchar_t *, __wchar_t **, int); } 
#line 650
extern "C" { extern unsigned __int64 __cdecl _wcstoui64_l(const __wchar_t *, __wchar_t **, int, _locale_t); } 
#line 669 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern char *__cdecl _fullpath(char *, const char *, size_t); } 
#line 675 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _ecvt_s(char *, size_t, double, int, int *, int *); } 
#line 676
template<size_t _Size> inline errno_t __cdecl _ecvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits, int *_PtDec, int *_PtSign) { return _ecvt_s(_Dest, _Size, _Value, _NumOfDigits, _PtDec, _PtSign); } 
#line 677
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ecvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _ecvt(double, int, int *, int *); } 
#line 678
extern "C" { extern errno_t __cdecl _fcvt_s(char *, size_t, double, int, int *, int *); } 
#line 679
template<size_t _Size> inline errno_t __cdecl _fcvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits, int *_PtDec, int *_PtSign) { return _fcvt_s(_Dest, _Size, _Value, _NumOfDigits, _PtDec, _PtSign); } 
#line 680
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _fcvt(double, int, int *, int *); } 
#line 681
extern "C" { extern errno_t __cdecl _gcvt_s(char *, size_t, double, int); } 
#line 682
template<size_t _Size> inline errno_t __cdecl _gcvt_s(char (&_Dest)[_Size], double _Value, int _NumOfDigits) { return _gcvt_s(_Dest, _Size, _Value, _NumOfDigits); } 
#line 683
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _gcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl _gcvt(double, int, char *); } 
#line 685
extern "C" { extern int __cdecl _atodbl(_CRT_DOUBLE *, char *); } 
#line 686
extern "C" { extern int __cdecl _atoldbl(_LDOUBLE *, char *); } 
#line 687
extern "C" { extern int __cdecl _atoflt(_CRT_FLOAT *, char *); } 
#line 688
extern "C" { extern int __cdecl _atodbl_l(_CRT_DOUBLE *, char *, _locale_t); } 
#line 689
extern "C" { extern int __cdecl _atoldbl_l(_LDOUBLE *, char *, _locale_t); } 
#line 690
extern "C" { extern int __cdecl _atoflt_l(_CRT_FLOAT *, char *, _locale_t); } 
#line 691
extern "C" { extern unsigned long __cdecl _lrotl(unsigned long, int); } 
#line 692
extern "C" { extern unsigned long __cdecl _lrotr(unsigned long, int); } 
#line 693
extern "C" { extern errno_t __cdecl _makepath_s(char *, size_t, const char *, const char *, const char *, const char *); } 
#line 695
template<size_t _Size> inline errno_t __cdecl _makepath_s(char (&_Path)[_Size], const char *_Drive, const char *_Dir, const char *_Filename, const char *_Ext) { return _makepath_s(_Path, _Size, _Drive, _Dir, _Filename, _Ext); } 
#line 696
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _makepath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _makepath(char *, const char *, const char *, const char *, const char *); } 
#line 723 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern _onexit_t __cdecl _onexit(_onexit_t); } 
#line 728 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern void __cdecl perror(const char *); } 
#line 730 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _putenv(const char *); } 
#line 731
extern "C" { extern errno_t __cdecl _putenv_s(const char *, const char *); } 
#line 732
extern "C" { extern unsigned __cdecl _rotl(unsigned, int); } 
#line 734
extern "C" { extern unsigned __int64 __cdecl _rotl64(unsigned __int64, int); } 
#line 736 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern unsigned __cdecl _rotr(unsigned, int); } 
#line 738
extern "C" { extern unsigned __int64 __cdecl _rotr64(unsigned __int64, int); } 
#line 740 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _searchenv_s(const char *, const char *, char *, size_t); } 
#line 741
template<size_t _Size> inline errno_t __cdecl _searchenv_s(const char *_Filename, const char *_EnvVar, char (&_ResultPath)[_Size]) { return _searchenv_s(_Filename, _EnvVar, _ResultPath, _Size); } 
#line 742
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _searchenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _searchenv(const char *, const char *, char *); } 
#line 744
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _splitpath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _splitpath(const char *, char *, char *, char *, char *); } 
#line 745
extern "C" { extern errno_t __cdecl _splitpath_s(const char *, char *, size_t, char *, size_t, char *, size_t, char *, size_t); } 
#line 750
template<size_t _DriveSize, size_t _DirSize, size_t _NameSize, size_t _ExtSize> inline errno_t __cdecl _splitpath_s(const char *_Dest, char (&_Drive)[_DriveSize], char (&_Dir)[_DirSize], char (&_Name)[_NameSize], char (&_Ext)[_ExtSize]) { return _splitpath_s(_Dest, _Drive, _DriveSize, _Dir, _DirSize, _Name, _NameSize, _Ext, _ExtSize); } 
#line 752
extern "C" { extern void __cdecl _swab(char *, char *, int); } 
#line 763 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __wchar_t *__cdecl _wfullpath(__wchar_t *, const __wchar_t *, size_t); } 
#line 769 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern errno_t __cdecl _wmakepath_s(__wchar_t *, size_t, const __wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *); } 
#line 771
template<size_t _Size> inline errno_t __cdecl _wmakepath_s(__wchar_t (&_ResultPath)[_Size], const __wchar_t *_Drive, const __wchar_t *_Dir, const __wchar_t *_Filename, const __wchar_t *_Ext) { return _wmakepath_s(_ResultPath, _Size, _Drive, _Dir, _Filename, _Ext); } 
#line 772
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wmakepath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wmakepath(__wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *, const __wchar_t *); } 
#line 775
extern "C" { extern void __cdecl _wperror(const __wchar_t *); } 
#line 777 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern int __cdecl _wputenv(const __wchar_t *); } 
#line 778
extern "C" { extern errno_t __cdecl _wputenv_s(const __wchar_t *, const __wchar_t *); } 
#line 779
extern "C" { extern errno_t __cdecl _wsearchenv_s(const __wchar_t *, const __wchar_t *, __wchar_t *, size_t); } 
#line 780
template<size_t _Size> inline errno_t __cdecl _wsearchenv_s(const __wchar_t *_Filename, const __wchar_t *_EnvVar, __wchar_t (&_ResultPath)[_Size]) { return _wsearchenv_s(_Filename, _EnvVar, _ResultPath, _Size); } 
#line 781
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wsearchenv_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wsearchenv(const __wchar_t *, const __wchar_t *, __wchar_t *); } 
#line 782
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wsplitpath_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl _wsplitpath(const __wchar_t *, __wchar_t *, __wchar_t *, __wchar_t *, __wchar_t *); } 
#line 783
extern "C" { extern errno_t __cdecl _wsplitpath_s(const __wchar_t *, __wchar_t *, size_t, __wchar_t *, size_t, __wchar_t *, size_t, __wchar_t *, size_t); } 
#line 788
template<size_t _DriveSize, size_t _DirSize, size_t _NameSize, size_t _ExtSize> inline errno_t __cdecl _wsplitpath_s(const __wchar_t *_Path, __wchar_t (&_Drive)[_DriveSize], __wchar_t (&_Dir)[_DirSize], __wchar_t (&_Name)[_NameSize], __wchar_t (&_Ext)[_ExtSize]) { return _wsplitpath_s(_Path, _Drive, _DriveSize, _Dir, _DirSize, _Name, _NameSize, _Ext, _ExtSize); } 
#line 794 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSetErrorModeinstead. See online help for details.")) void __cdecl _seterrormode(int); } 
#line 795
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingBeepinstead. See online help for details.")) void __cdecl _beep(unsigned, unsigned); } 
#line 796
extern "C" { extern __declspec(deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider usingSleepinstead. See online help for details.")) void __cdecl _sleep(unsigned long); } 
#line 815 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma warning(push)
#pragma warning(disable: 4141)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ecvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ecvt(double, int, int *, int *); } 
#line 818
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl fcvt(double, int, int *, int *); } 
#line 819
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fcvt_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl gcvt(double, int, char *); } 
#line 820
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _itoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl itoa(int, char *, int); } 
#line 821
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ltoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ltoa(long, char *, int); } 
#line 822
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _putenv. See online help for details.")) int __cdecl putenv(const char *); } 
#line 823
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _swab. See online help for details.")) void __cdecl swab(char *, char *, int); } 
#line 824
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _ultoa_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl ultoa(unsigned long, char *, int); } 
#pragma warning(pop)
extern "C" { extern _onexit_t __cdecl onexit(_onexit_t); } 
#line 114 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\use_ansi.h"
#pragma comment(lib,"libcpmt")
#line 838 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdlib.h"
#pragma pack ( pop )
#line 9 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
#pragma pack ( push, 8 )
#line 480 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
namespace std { 
#line 481
typedef bool _Bool; 
#line 482
}
#line 498 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
typedef __int64 _Longlong; 
#line 499
typedef unsigned __int64 _ULonglong; 
#line 521 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
namespace std { 
#line 525
#pragma warning(push)
#pragma warning(disable:4412)
class _Lockit { 
#line 547 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: explicit __thiscall _Lockit(); 
#line 548
explicit __thiscall _Lockit(int); 
#line 549
__thiscall ~_Lockit(); 
#line 552 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
static void __cdecl _Lockit_ctor(int); 
#line 553
static void __cdecl _Lockit_dtor(int); 
#line 556
private: static void __cdecl _Lockit_ctor(_Lockit *); 
#line 557
static void __cdecl _Lockit_ctor(_Lockit *, int); 
#line 558
static void __cdecl _Lockit_dtor(_Lockit *); 
#line 560
_Lockit(const _Lockit &); 
#line 561
_Lockit &operator=(const _Lockit &); 
#line 563
int _Locktype; 
#line 580 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#line 674 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
class _Mutex { 
#line 698 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: __thiscall _Mutex(); 
#line 699
__thiscall ~_Mutex(); 
#line 700
void __thiscall _Lock(); 
#line 701
void __thiscall _Unlock(); 
#line 705 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
private: static void __cdecl _Mutex_ctor(_Mutex *); 
#line 706
static void __cdecl _Mutex_dtor(_Mutex *); 
#line 707
static void __cdecl _Mutex_Lock(_Mutex *); 
#line 708
static void __cdecl _Mutex_Unlock(_Mutex *); 
#line 710
_Mutex(const _Mutex &); 
#line 711
_Mutex &operator=(const _Mutex &); 
#line 712
void *_Mtx; 
#line 724 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#line 726
class _Init_locks { 
#line 742 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
public: __thiscall _Init_locks(); 
#line 743
__thiscall ~_Init_locks(); 
#line 747 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
private: static void __cdecl _Init_locks_ctor(_Init_locks *); 
#line 748
static void __cdecl _Init_locks_dtor(_Init_locks *); 
#line 760 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
}; 
#pragma warning(pop)
}
#line 771 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\yvals.h"
extern void __cdecl _Atexit(void (__cdecl *)(void)); 
#line 773
typedef int _Mbstatet; 
#line 783
#pragma pack ( pop )
#line 17 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cmath"
namespace std { 
#line 18
using ::acosf;using ::asinf;
#line 19
using ::atanf;using ::atan2f;using ::ceilf;
#line 20
using ::cosf;using ::coshf;using ::expf;
#line 21
using ::fabsf;using ::floorf;using ::fmodf;
#line 22
using ::frexpf;using ::ldexpf;using ::logf;
#line 23
using ::log10f;using ::modff;using ::powf;
#line 24
using ::sinf;using ::sinhf;using ::sqrtf;
#line 25
using ::tanf;using ::tanhf;
#line 27
using ::acosl;using ::asinl;
#line 28
using ::atanl;using ::atan2l;using ::ceill;
#line 29
using ::cosl;using ::coshl;using ::expl;
#line 30
using ::fabsl;using ::floorl;using ::fmodl;
#line 31
using ::frexpl;using ::ldexpl;using ::logl;
#line 32
using ::log10l;using ::modfl;using ::powl;
#line 33
using ::sinl;using ::sinhl;using ::sqrtl;
#line 34
using ::tanl;using ::tanhl;
#line 36
using ::abs;
#line 37
using ::acos;using ::asin;
#line 38
using ::atan;using ::atan2;using ::ceil;
#line 39
using ::cos;using ::cosh;using ::exp;
#line 40
using ::fabs;using ::floor;using ::fmod;
#line 41
using ::frexp;using ::ldexp;using ::log;
#line 42
using ::log10;using ::modf;using ::pow;
#line 43
using ::sin;using ::sinh;using ::sqrt;
#line 44
using ::tan;using ::tanh;
#line 46
}
#line 17 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\cstdlib"
namespace std { 
#line 18
using ::size_t;using ::div_t;using ::ldiv_t;
#line 20
using ::abort;using ::atexit;
#line 21
using ::atof;using ::atoi;using ::atol;
#line 22
using ::bsearch;using ::calloc;using ::div;
#line 23
using ::exit;using ::free;using ::getenv;
#line 24
using ::labs;using ::ldiv;using ::malloc;
#line 25
using ::mblen;using ::mbstowcs;using ::mbtowc;
#line 26
using ::qsort;using ::rand;using ::realloc;
#line 27
using ::srand;using ::strtod;using ::strtol;
#line 28
using ::strtoul;using ::system;
#line 29
using ::wcstombs;using ::wctomb;
#line 30
}
#line 413 "c:\\cuda\\include\\math_functions.h"
using namespace std;
#line 484 "c:\\cuda\\include\\math_functions.h"
static __inline __int64 abs(__int64 a) 
#line 485
{ 
#line 486
return llabs(a); 
#line 487
} 
#line 489
static __inline int signbit(double a) 
#line 490
{ 
#line 491
return __signbit(a); 
#line 492
} 
#line 494
static __inline int signbit(float a) 
#line 495
{ 
#line 496
return __signbitf(a); 
#line 497
} 
#line 499
static __inline int isinf(double a) 
#line 500
{ 
#line 501
return __isinf(a); 
#line 502
} 
#line 504
static __inline int isinf(float a) 
#line 505
{ 
#line 506
return __isinff(a); 
#line 507
} 
#line 509
static __inline int isnan(double a) 
#line 510
{ 
#line 511
return __isnan(a); 
#line 512
} 
#line 514
static __inline int isnan(float a) 
#line 515
{ 
#line 516
return __isnanf(a); 
#line 517
} 
#line 519
static __inline int isfinite(double a) 
#line 520
{ 
#line 521
return __finite(a); 
#line 522
} 
#line 524
static __inline int isfinite(float a) 
#line 525
{ 
#line 526
return __finitef(a); 
#line 527
} 
#line 532
template<class T> inline T _Pow_int(T, int); 
#line 538 "c:\\cuda\\include\\math_functions.h"
inline long abs(long); 
#line 539
inline float abs(float); 
#line 540
inline double abs(double); 
#line 541
inline float fabs(float); 
#line 542
inline float ceil(float); 
#line 543
inline float floor(float); 
#line 544
inline float sqrt(float); 
#line 545
inline float pow(float, float); 
#line 546
inline float pow(float, int); 
#line 547
inline double pow(double, int); 
#line 548
inline float log(float); 
#line 549
inline float log10(float); 
#line 550
inline float fmod(float, float); 
#line 551
inline float modf(float, float *); 
#line 552
inline float exp(float); 
#line 553
inline float frexp(float, int *); 
#line 554
inline float ldexp(float, int); 
#line 555
inline float asin(float); 
#line 556
inline float sin(float); 
#line 557
inline float sinh(float); 
#line 558
inline float acos(float); 
#line 559
inline float cos(float); 
#line 560
inline float cosh(float); 
#line 561
inline float atan(float); 
#line 562
inline float atan2(float, float); 
#line 563
inline float tan(float); 
#line 564
inline float tanh(float); 
#line 568
static __inline float logb(float a) 
#line 569
{ 
#line 570
return logbf(a); 
#line 571
} 
#line 573
static __inline int ilogb(float a) 
#line 574
{ 
#line 575
return ilogbf(a); 
#line 576
} 
#line 578
static __inline float scalbn(float a, int b) 
#line 579
{ 
#line 580
return scalbnf(a, b); 
#line 581
} 
#line 583
static __inline float scalbln(float a, long b) 
#line 584
{ 
#line 585
return scalblnf(a, b); 
#line 586
} 
#line 588
static __inline float exp2(float a) 
#line 589
{ 
#line 590
return exp2f(a); 
#line 591
} 
#line 593
static __inline float exp10(float a) 
#line 594
{ 
#line 595
return exp10f(a); 
#line 596
} 
#line 598
static __inline float expm1(float a) 
#line 599
{ 
#line 600
return expm1f(a); 
#line 601
} 
#line 603
static __inline float log2(float a) 
#line 604
{ 
#line 605
return log2f(a); 
#line 606
} 
#line 608
static __inline float log1p(float a) 
#line 609
{ 
#line 610
return log1pf(a); 
#line 611
} 
#line 613
static __inline float rsqrt(float a) 
#line 614
{ 
#line 615
return rsqrtf(a); 
#line 616
} 
#line 618
static __inline float acosh(float a) 
#line 619
{ 
#line 620
return acoshf(a); 
#line 621
} 
#line 623
static __inline float asinh(float a) 
#line 624
{ 
#line 625
return asinhf(a); 
#line 626
} 
#line 628
static __inline float atanh(float a) 
#line 629
{ 
#line 630
return atanhf(a); 
#line 631
} 
#line 633
static __inline float hypot(float a, float b) 
#line 634
{ 
#line 635
return hypotf(a, b); 
#line 636
} 
#line 638
static __inline float cbrt(float a) 
#line 639
{ 
#line 640
return cbrtf(a); 
#line 641
} 
#line 643
static __inline void sincos(float a, float *sptr, float *cptr) 
#line 644
{ 
#line 645
sincosf(a, sptr, cptr); 
#line 646
} 
#line 648
static __inline float erf(float a) 
#line 649
{ 
#line 650
return erff(a); 
#line 651
} 
#line 653
static __inline float erfc(float a) 
#line 654
{ 
#line 655
return erfcf(a); 
#line 656
} 
#line 658
static __inline float lgamma(float a) 
#line 659
{ 
#line 660
return lgammaf(a); 
#line 661
} 
#line 663
static __inline float tgamma(float a) 
#line 664
{ 
#line 665
return tgammaf(a); 
#line 666
} 
#line 668
static __inline float copysign(float a, float b) 
#line 669
{ 
#line 670
return copysignf(a, b); 
#line 671
} 
#line 673
static __inline double copysign(double a, float b) 
#line 674
{ 
#line 675
return copysign(a, (double)b); 
#line 676
} 
#line 678
static __inline float copysign(float a, double b) 
#line 679
{ 
#line 680
return copysignf(a, (float)b); 
#line 681
} 
#line 683
static __inline float nextafter(float a, float b) 
#line 684
{ 
#line 685
return nextafterf(a, b); 
#line 686
} 
#line 688
static __inline float remainder(float a, float b) 
#line 689
{ 
#line 690
return remainderf(a, b); 
#line 691
} 
#line 693
static __inline float remquo(float a, float b, int *quo) 
#line 694
{ 
#line 695
return remquof(a, b, quo); 
#line 696
} 
#line 698
static __inline float round(float a) 
#line 699
{ 
#line 700
return roundf(a); 
#line 701
} 
#line 703
static __inline long lround(float a) 
#line 704
{ 
#line 705
return lroundf(a); 
#line 706
} 
#line 708
static __inline __int64 llround(float a) 
#line 709
{ 
#line 710
return llroundf(a); 
#line 711
} 
#line 713
static __inline float trunc(float a) 
#line 714
{ 
#line 715
return truncf(a); 
#line 716
} 
#line 718
static __inline float rint(float a) 
#line 719
{ 
#line 720
return rintf(a); 
#line 721
} 
#line 723
static __inline long lrint(float a) 
#line 724
{ 
#line 725
return lrintf(a); 
#line 726
} 
#line 728
static __inline __int64 llrint(float a) 
#line 729
{ 
#line 730
return llrintf(a); 
#line 731
} 
#line 733
static __inline float nearbyint(float a) 
#line 734
{ 
#line 735
return nearbyintf(a); 
#line 736
} 
#line 738
static __inline float fdim(float a, float b) 
#line 739
{ 
#line 740
return fdimf(a, b); 
#line 741
} 
#line 743
static __inline float fma(float a, float b, float c) 
#line 744
{ 
#line 745
return fmaf(a, b, c); 
#line 746
} 
#line 748
static __inline unsigned min(unsigned a, unsigned b) 
#line 749
{ 
#line 750
return umin(a, b); 
#line 751
} 
#line 753
static __inline unsigned min(int a, unsigned b) 
#line 754
{ 
#line 755
return umin((unsigned)a, b); 
#line 756
} 
#line 758
static __inline unsigned min(unsigned a, int b) 
#line 759
{ 
#line 760
return umin(a, (unsigned)b); 
#line 761
} 
#line 763
static __inline float min(float a, float b) 
#line 764
{ 
#line 765
return fminf(a, b); 
#line 766
} 
#line 768
static __inline double min(double a, double b) 
#line 769
{ 
#line 770
return fmin(a, b); 
#line 771
} 
#line 773
static __inline double min(float a, double b) 
#line 774
{ 
#line 775
return fmin((double)a, b); 
#line 776
} 
#line 778
static __inline double min(double a, float b) 
#line 779
{ 
#line 780
return fmin(a, (double)b); 
#line 781
} 
#line 783
static __inline unsigned max(unsigned a, unsigned b) 
#line 784
{ 
#line 785
return umax(a, b); 
#line 786
} 
#line 788
static __inline unsigned max(int a, unsigned b) 
#line 789
{ 
#line 790
return umax((unsigned)a, b); 
#line 791
} 
#line 793
static __inline unsigned max(unsigned a, int b) 
#line 794
{ 
#line 795
return umax(a, (unsigned)b); 
#line 796
} 
#line 798
static __inline float max(float a, float b) 
#line 799
{ 
#line 800
return fmaxf(a, b); 
#line 801
} 
#line 803
static __inline double max(double a, double b) 
#line 804
{ 
#line 805
return fmax(a, b); 
#line 806
} 
#line 808
static __inline double max(float a, double b) 
#line 809
{ 
#line 810
return fmax((double)a, b); 
#line 811
} 
#line 813
static __inline double max(double a, float b) 
#line 814
{ 
#line 815
return fmax(a, (double)b); 
#line 816
} 
#if 0
#endif
#if 0
#endif
#if 0
#endif
#if 0
#endif
#if 0
#endif
#if 0
#endif
#if 0
#line 53 "c:\\cuda\\include\\device_launch_parameters.h"
extern "C" const uint3 threadIdx; 
#endif
#if 0
#line 55
extern "C" const uint3 blockIdx; 
#endif
#if 0
#line 57
extern "C" const dim3 blockDim; 
#endif
#if 0
#line 59
extern "C" const dim3 gridDim; 
#endif
#if 0
#line 61
extern "C" const int warpSize; 
#endif
#line 76 "C:\\CUDA\\include\\cuda_runtime.h"
template<class T> __inline cudaError_t 
#line 77
cudaSetupArgument(T 
#line 78
arg, size_t 
#line 79
offset) 
#line 81
{ 
#line 82
return cudaSetupArgument((const void *)(&arg), sizeof(T), offset); 
#line 83
} 
#line 93
static __inline cudaError_t cudaMemcpyToSymbol(char *
#line 94
symbol, const void *
#line 95
src, size_t 
#line 96
count, size_t 
#line 97
offset = (0), cudaMemcpyKind 
#line 98
kind = cudaMemcpyHostToDevice) 
#line 100
{ 
#line 101
return cudaMemcpyToSymbol((const char *)symbol, src, count, offset, kind); 
#line 102
} 
#line 104
template<class T> __inline cudaError_t 
#line 105
cudaMemcpyToSymbol(const T &
#line 106
symbol, const void *
#line 107
src, size_t 
#line 108
count, size_t 
#line 109
offset = (0), cudaMemcpyKind 
#line 110
kind = cudaMemcpyHostToDevice) 
#line 112
{ 
#line 113
return cudaMemcpyToSymbol((const char *)(&symbol), src, count, offset, kind); 
#line 114
} 
#line 116
static __inline cudaError_t cudaMemcpyToSymbolAsync(char *
#line 117
symbol, const void *
#line 118
src, size_t 
#line 119
count, size_t 
#line 120
offset, cudaMemcpyKind 
#line 121
kind, cudaStream_t 
#line 122
stream) 
#line 124
{ 
#line 125
return cudaMemcpyToSymbolAsync((const char *)symbol, src, count, offset, kind, stream); 
#line 126
} 
#line 128
template<class T> __inline cudaError_t 
#line 129
cudaMemcpyToSymbolAsync(const T &
#line 130
symbol, const void *
#line 131
src, size_t 
#line 132
count, size_t 
#line 133
offset, cudaMemcpyKind 
#line 134
kind, cudaStream_t 
#line 135
stream) 
#line 137
{ 
#line 138
return cudaMemcpyToSymbolAsync((const char *)(&symbol), src, count, offset, kind, stream); 
#line 139
} 
#line 147
static __inline cudaError_t cudaMemcpyFromSymbol(void *
#line 148
dst, char *
#line 149
symbol, size_t 
#line 150
count, size_t 
#line 151
offset = (0), cudaMemcpyKind 
#line 152
kind = cudaMemcpyDeviceToHost) 
#line 154
{ 
#line 155
return cudaMemcpyFromSymbol(dst, (const char *)symbol, count, offset, kind); 
#line 156
} 
#line 158
template<class T> __inline cudaError_t 
#line 159
cudaMemcpyFromSymbol(void *
#line 160
dst, const T &
#line 161
symbol, size_t 
#line 162
count, size_t 
#line 163
offset = (0), cudaMemcpyKind 
#line 164
kind = cudaMemcpyDeviceToHost) 
#line 166
{ 
#line 167
return cudaMemcpyFromSymbol(dst, (const char *)(&symbol), count, offset, kind); 
#line 168
} 
#line 170
static __inline cudaError_t cudaMemcpyFromSymbolAsync(void *
#line 171
dst, char *
#line 172
symbol, size_t 
#line 173
count, size_t 
#line 174
offset, cudaMemcpyKind 
#line 175
kind, cudaStream_t 
#line 176
stream) 
#line 178
{ 
#line 179
return cudaMemcpyFromSymbolAsync(dst, (const char *)symbol, count, offset, kind, stream); 
#line 180
} 
#line 182
template<class T> __inline cudaError_t 
#line 183
cudaMemcpyFromSymbolAsync(void *
#line 184
dst, const T &
#line 185
symbol, size_t 
#line 186
count, size_t 
#line 187
offset, cudaMemcpyKind 
#line 188
kind, cudaStream_t 
#line 189
stream) 
#line 191
{ 
#line 192
return cudaMemcpyFromSymbolAsync(dst, (const char *)(&symbol), count, offset, kind, stream); 
#line 193
} 
#line 195
static __inline cudaError_t cudaGetSymbolAddress(void **
#line 196
devPtr, char *
#line 197
symbol) 
#line 199
{ 
#line 200
return cudaGetSymbolAddress(devPtr, (const char *)symbol); 
#line 201
} 
#line 203
template<class T> __inline cudaError_t 
#line 204
cudaGetSymbolAddress(void **
#line 205
devPtr, const T &
#line 206
symbol) 
#line 208
{ 
#line 209
return cudaGetSymbolAddress(devPtr, (const char *)(&symbol)); 
#line 210
} 
#line 218
static __inline cudaError_t cudaGetSymbolSize(size_t *
#line 219
size, char *
#line 220
symbol) 
#line 222
{ 
#line 223
return cudaGetSymbolSize(size, (const char *)symbol); 
#line 224
} 
#line 226
template<class T> __inline cudaError_t 
#line 227
cudaGetSymbolSize(size_t *
#line 228
size, const T &
#line 229
symbol) 
#line 231
{ 
#line 232
return cudaGetSymbolSize(size, (const char *)(&symbol)); 
#line 233
} 
#line 241
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 242
cudaBindTexture(size_t *
#line 243
offset, const texture< T, dim, readMode>  &
#line 244
tex, const void *
#line 245
devPtr, const cudaChannelFormatDesc &
#line 246
desc, size_t 
#line 247
size = (4294967295U)) 
#line 249
{ 
#line 250
return cudaBindTexture(offset, &tex, devPtr, (&desc), size); 
#line 251
} 
#line 253
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 254
cudaBindTexture(size_t *
#line 255
offset, const texture< T, dim, readMode>  &
#line 256
tex, const void *
#line 257
devPtr, size_t 
#line 258
size = (4294967295U)) 
#line 260
{ 
#line 261
return cudaBindTexture(offset, tex, devPtr, (tex.channelDesc), size); 
#line 262
} 
#line 264
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 265
cudaBindTextureToArray(const texture< T, dim, readMode>  &
#line 266
tex, const cudaArray *
#line 267
array, const cudaChannelFormatDesc &
#line 268
desc) 
#line 270
{ 
#line 271
return cudaBindTextureToArray(&tex, array, (&desc)); 
#line 272
} 
#line 274
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 275
cudaBindTextureToArray(const texture< T, dim, readMode>  &
#line 276
tex, const cudaArray *
#line 277
array) 
#line 279
{ 
#line 280
auto cudaChannelFormatDesc desc; 
#line 281
auto cudaError_t err = cudaGetChannelDesc(&desc, array); 
#line 283
return (err == (cudaSuccess)) ? (cudaBindTextureToArray(tex, array, desc)) : err; 
#line 284
} 
#line 292
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 293
cudaUnbindTexture(const texture< T, dim, readMode>  &
#line 294
tex) 
#line 296
{ 
#line 297
return cudaUnbindTexture(&tex); 
#line 298
} 
#line 306
template<class T, int dim, cudaTextureReadMode readMode> __inline cudaError_t 
#line 307
cudaGetTextureAlignmentOffset(size_t *
#line 308
offset, const texture< T, dim, readMode>  &
#line 309
tex) 
#line 311
{ 
#line 312
return cudaGetTextureAlignmentOffset(offset, &tex); 
#line 313
} 
#line 321
template<class T> __inline cudaError_t 
#line 322
cudaLaunch(T *
#line 323
symbol) 
#line 325
{ 
#line 326
return cudaLaunch((const char *)symbol); 
#line 327
} 
#line 28 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma pack ( push, 8 )
#line 59 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { struct _iobuf { 
#line 60
char *_ptr; 
#line 61
int _cnt; 
#line 62
char *_base; 
#line 63
int _flag; 
#line 64
int _file; 
#line 65
int _charbuf; 
#line 66
int _bufsiz; 
#line 67
char *_tmpfname; 
#line 68
}; }
#line 69
extern "C" { typedef _iobuf FILE; }
#line 131 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl __iob_func(); } 
#line 147 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { typedef __int64 fpos_t; }
#line 188 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _filbuf(FILE *); } 
#line 189
extern "C" { extern int __cdecl _flsbuf(int, FILE *); } 
#line 194
extern "C" { extern FILE *__cdecl _fsopen(const char *, const char *, int); } 
#line 197 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl clearerr(FILE *); } 
#line 198
extern "C" { extern errno_t __cdecl clearerr_s(FILE *); } 
#line 199
extern "C" { extern int __cdecl fclose(FILE *); } 
#line 200
extern "C" { extern int __cdecl _fcloseall(); } 
#line 205
extern "C" { extern FILE *__cdecl _fdopen(int, const char *); } 
#line 208 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl feof(FILE *); } 
#line 209
extern "C" { extern int __cdecl ferror(FILE *); } 
#line 210
extern "C" { extern int __cdecl fflush(FILE *); } 
#line 211
extern "C" { extern int __cdecl fgetc(FILE *); } 
#line 212
extern "C" { extern int __cdecl _fgetchar(); } 
#line 213
extern "C" { extern int __cdecl fgetpos(FILE *, fpos_t *); } 
#line 214
extern "C" { extern char *__cdecl fgets(char *, int, FILE *); } 
#line 219
extern "C" { extern int __cdecl _fileno(FILE *); } 
#line 227 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern char *__cdecl _tempnam(const char *, const char *); } 
#line 233 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _flushall(); } 
#line 234
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl fopen(const char *, const char *); } 
#line 236
extern "C" { extern errno_t __cdecl fopen_s(FILE **, const char *, const char *); } 
#line 238 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl fprintf(FILE *, const char *, ...); } 
#line 239
extern "C" { extern int __cdecl fprintf_s(FILE *, const char *, ...); } 
#line 240
extern "C" { extern int __cdecl fputc(int, FILE *); } 
#line 241
extern "C" { extern int __cdecl _fputchar(int); } 
#line 242
extern "C" { extern int __cdecl fputs(const char *, FILE *); } 
#line 243
extern "C" { extern size_t __cdecl fread(void *, size_t, size_t, FILE *); } 
#line 244
extern "C" { extern size_t __cdecl fread_s(void *, size_t, size_t, size_t, FILE *); } 
#line 245
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using freopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl freopen(const char *, const char *, FILE *); } 
#line 247
extern "C" { extern errno_t __cdecl freopen_s(FILE **, const char *, const char *, FILE *); } 
#line 249 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl fscanf(FILE *, const char *, ...); } 
#line 250
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _fscanf_l(FILE *, const char *, _locale_t, ...); } 
#line 252
extern "C" { extern int __cdecl fscanf_s(FILE *, const char *, ...); } 
#line 254 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fscanf_s_l(FILE *, const char *, _locale_t, ...); } 
#line 255
extern "C" { extern int __cdecl fsetpos(FILE *, const fpos_t *); } 
#line 256
extern "C" { extern int __cdecl fseek(FILE *, long, int); } 
#line 257
extern "C" { extern long __cdecl ftell(FILE *); } 
#line 259
extern "C" { extern int __cdecl _fseeki64(FILE *, __int64, int); } 
#line 260
extern "C" { extern __int64 __cdecl _ftelli64(FILE *); } 
#line 262
extern "C" { extern size_t __cdecl fwrite(const void *, size_t, size_t, FILE *); } 
#line 263
extern "C" { extern int __cdecl getc(FILE *); } 
#line 264
extern "C" { extern int __cdecl getchar(); } 
#line 265
extern "C" { extern int __cdecl _getmaxstdio(); } 
#line 267
extern "C" { extern char *__cdecl gets_s(char *, rsize_t); } 
#line 269 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline char *__cdecl gets_s(char (&_Buffer)[_Size]) { return gets_s(_Buffer, _Size); } 
#line 270
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using gets_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl gets(char *); } 
#line 271
extern "C" { extern int __cdecl _getw(FILE *); } 
#line 276
extern "C" { extern int __cdecl _pclose(FILE *); } 
#line 277
extern "C" { extern FILE *__cdecl _popen(const char *, const char *); } 
#line 278
extern "C" { extern int __cdecl printf(const char *, ...); } 
#line 279
extern "C" { extern int __cdecl printf_s(const char *, ...); } 
#line 280
extern "C" { extern int __cdecl putc(int, FILE *); } 
#line 281
extern "C" { extern int __cdecl putchar(int); } 
#line 282
extern "C" { extern int __cdecl puts(const char *); } 
#line 283
extern "C" { extern int __cdecl _putw(int, FILE *); } 
#line 286
extern "C" { extern int __cdecl remove(const char *); } 
#line 287
extern "C" { extern int __cdecl rename(const char *, const char *); } 
#line 288
extern "C" { extern int __cdecl _unlink(const char *); } 
#line 290
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _unlink. See online help for details.")) int __cdecl unlink(const char *); } 
#line 293 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl rewind(FILE *); } 
#line 294
extern "C" { extern int __cdecl _rmtmp(); } 
#line 295
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using scanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl scanf(const char *, ...); } 
#line 296
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _scanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _scanf_l(const char *, _locale_t, ...); } 
#line 298
extern "C" { extern int __cdecl scanf_s(const char *, ...); } 
#line 300 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _scanf_s_l(const char *, _locale_t, ...); } 
#line 301
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using setvbuf instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) void __cdecl setbuf(FILE *, char *); } 
#line 302
extern "C" { extern int __cdecl _setmaxstdio(int); } 
#line 303
extern "C" { extern unsigned __cdecl _set_output_format(unsigned); } 
#line 304
extern "C" { extern unsigned __cdecl _get_output_format(); } 
#line 305
extern "C" { extern int __cdecl setvbuf(FILE *, char *, int, size_t); } 
#line 306
extern "C" { extern int __cdecl _snprintf_s(char *, size_t, size_t, const char *, ...); } 
#line 307
__pragma( warning(push)) __pragma( warning(disable: 4793)) template<size_t _Size> inline int __cdecl _snprintf_s(char (&_Dest)[_Size], size_t _Size, const char *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return _vsnprintf_s(_Dest, _Size, _Size, _Format, _ArgList); } __pragma( warning(pop)) 
#line 308
extern "C" { extern int __cdecl sprintf_s(char *, size_t, const char *, ...); } 
#line 309
__pragma( warning(push)) __pragma( warning(disable: 4793)) template < size_t _Size > inline int __cdecl sprintf_s ( char ( & _Dest ) [ _Size ], const char * _Format, ... ) { va_list _ArgList; ( _ArgList = ( va_list ) ( & reinterpret_cast < const char & > ( _Format ) ) + ( ( sizeof ( _Format ) + sizeof ( int ) - 1 ) & ~ ( sizeof ( int ) - 1 ) ) ); return vsprintf_s ( _Dest, _Size, _Format, _ArgList ); }__pragma( warning(pop)) 
#line 310
extern "C" { extern int __cdecl _scprintf(const char *, ...); } 
#line 311
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using sscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl sscanf(const char *, const char *, ...); } 
#line 312
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _sscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _sscanf_l(const char *, const char *, _locale_t, ...); } 
#line 314
extern "C" { extern int __cdecl sscanf_s(const char *, const char *, ...); } 
#line 316 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _sscanf_s_l(const char *, const char *, _locale_t, ...); } 
#line 317
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snscanf(const char *, size_t, const char *, ...); } 
#line 318
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snscanf_l(const char *, size_t, const char *, _locale_t, ...); } 
#line 319
extern "C" { extern int __cdecl _snscanf_s(const char *, size_t, const char *, ...); } 
#line 320
extern "C" { extern int __cdecl _snscanf_s_l(const char *, size_t, const char *, _locale_t, ...); } 
#line 321
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using tmpfile_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl tmpfile(); } 
#line 323
extern "C" { extern errno_t __cdecl tmpfile_s(FILE **); } 
#line 324
extern "C" { extern errno_t __cdecl tmpnam_s(char *, rsize_t); } 
#line 326 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
template<size_t _Size> inline errno_t __cdecl tmpnam_s(char (&_Buf)[_Size]) { return tmpnam_s(_Buf, _Size); } 
#line 327
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using tmpnam_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) char *__cdecl tmpnam(char *); } 
#line 328
extern "C" { extern int __cdecl ungetc(int, FILE *); } 
#line 329
extern "C" { extern int __cdecl vfprintf(FILE *, const char *, va_list); } 
#line 330
extern "C" { extern int __cdecl vfprintf_s(FILE *, const char *, va_list); } 
#line 331
extern "C" { extern int __cdecl vprintf(const char *, va_list); } 
#line 332
extern "C" { extern int __cdecl vprintf_s(const char *, va_list); } 
#line 333
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using vsnprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vsnprintf(char *, size_t, const char *, va_list); } 
#line 334
extern "C" { extern int __cdecl vsnprintf_s(char *, size_t, size_t, const char *, va_list); } 
#line 335
extern "C" { extern int __cdecl _vsnprintf_s(char *, size_t, size_t, const char *, va_list); } 
#line 336
template<size_t _Size> inline int __cdecl _vsnprintf_s(char (&_Dest)[_Size], size_t _Size, const char *_Format, va_list _Args) { return _vsnprintf_s(_Dest, _Size, _Size, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snprintf(char *, size_t, const char *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnprintf(char *, size_t, const char *, va_list); } 
#pragma warning(pop)
extern "C" { extern int __cdecl vsprintf_s(char *, size_t, const char *, va_list); } 
#line 342
template<size_t _Size> inline int __cdecl vsprintf_s(char (&_Dest)[_Size], const char *_Format, va_list _Args) { return vsprintf_s(_Dest, _Size, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using sprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl sprintf(char *, const char *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using vsprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vsprintf(char *, const char *, va_list); } 
#pragma warning(pop)
extern "C" { extern int __cdecl _vscprintf(const char *, va_list); } 
#line 348
extern "C" { extern int __cdecl _snprintf_c(char *, size_t, const char *, ...); } 
#line 349
extern "C" { extern int __cdecl _vsnprintf_c(char *, size_t, const char *, va_list); } 
#line 351
extern "C" { extern int __cdecl _fprintf_p(FILE *, const char *, ...); } 
#line 352
extern "C" { extern int __cdecl _printf_p(const char *, ...); } 
#line 353
extern "C" { extern int __cdecl _sprintf_p(char *, size_t, const char *, ...); } 
#line 354
extern "C" { extern int __cdecl _vfprintf_p(FILE *, const char *, va_list); } 
#line 355
extern "C" { extern int __cdecl _vprintf_p(const char *, va_list); } 
#line 356
extern "C" { extern int __cdecl _vsprintf_p(char *, size_t, const char *, va_list); } 
#line 357
extern "C" { extern int __cdecl _scprintf_p(const char *, ...); } 
#line 358
extern "C" { extern int __cdecl _vscprintf_p(const char *, va_list); } 
#line 359
extern "C" { extern int __cdecl _set_printf_count_output(int); } 
#line 360
extern "C" { extern int __cdecl _get_printf_count_output(); } 
#line 362
extern "C" { extern int __cdecl _printf_l(const char *, _locale_t, ...); } 
#line 363
extern "C" { extern int __cdecl _printf_p_l(const char *, _locale_t, ...); } 
#line 364
extern "C" { extern int __cdecl _printf_s_l(const char *, _locale_t, ...); } 
#line 365
extern "C" { extern int __cdecl _vprintf_l(const char *, _locale_t, va_list); } 
#line 366
extern "C" { extern int __cdecl _vprintf_p_l(const char *, _locale_t, va_list); } 
#line 367
extern "C" { extern int __cdecl _vprintf_s_l(const char *, _locale_t, va_list); } 
#line 369
extern "C" { extern int __cdecl _fprintf_l(FILE *, const char *, _locale_t, ...); } 
#line 370
extern "C" { extern int __cdecl _fprintf_p_l(FILE *, const char *, _locale_t, ...); } 
#line 371
extern "C" { extern int __cdecl _fprintf_s_l(FILE *, const char *, _locale_t, ...); } 
#line 372
extern "C" { extern int __cdecl _vfprintf_l(FILE *, const char *, _locale_t, va_list); } 
#line 373
extern "C" { extern int __cdecl _vfprintf_p_l(FILE *, const char *, _locale_t, va_list); } 
#line 374
extern "C" { extern int __cdecl _vfprintf_s_l(FILE *, const char *, _locale_t, va_list); } 
#line 376
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _sprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _sprintf_l(char *, const char *, _locale_t, ...); } 
#line 377
extern "C" { extern int __cdecl _sprintf_p_l(char *, size_t, const char *, _locale_t, ...); } 
#line 378
extern "C" { extern int __cdecl _sprintf_s_l(char *, size_t, const char *, _locale_t, ...); } 
#line 379
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsprintf_l(char *, const char *, _locale_t, va_list); } 
#line 380
extern "C" { extern int __cdecl _vsprintf_p_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 381
extern "C" { extern int __cdecl _vsprintf_s_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 383
extern "C" { extern int __cdecl _scprintf_l(const char *, _locale_t, ...); } 
#line 384
extern "C" { extern int __cdecl _scprintf_p_l(const char *, _locale_t, ...); } 
#line 385
extern "C" { extern int __cdecl _vscprintf_l(const char *, _locale_t, va_list); } 
#line 386
extern "C" { extern int __cdecl _vscprintf_p_l(const char *, _locale_t, va_list); } 
#line 388
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snprintf_l(char *, size_t, const char *, _locale_t, ...); } 
#line 389
extern "C" { extern int __cdecl _snprintf_c_l(char *, size_t, const char *, _locale_t, ...); } 
#line 390
extern "C" { extern int __cdecl _snprintf_s_l(char *, size_t, size_t, const char *, _locale_t, ...); } 
#line 391
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnprintf_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 392
extern "C" { extern int __cdecl _vsnprintf_c_l(char *, size_t, const char *, _locale_t, va_list); } 
#line 393
extern "C" { extern int __cdecl _vsnprintf_s_l(char *, size_t, size_t, const char *, _locale_t, va_list); } 
#line 406 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern FILE *__cdecl _wfsopen(const __wchar_t *, const __wchar_t *, int); } 
#line 409 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern wint_t __cdecl fgetwc(FILE *); } 
#line 410
extern "C" { extern wint_t __cdecl _fgetwchar(); } 
#line 411
extern "C" { extern wint_t __cdecl fputwc(__wchar_t, FILE *); } 
#line 412
extern "C" { extern wint_t __cdecl _fputwchar(__wchar_t); } 
#line 413
extern "C" { extern wint_t __cdecl getwc(FILE *); } 
#line 414
extern "C" { inline wint_t __cdecl getwchar(); } 
#line 415
extern "C" { extern wint_t __cdecl putwc(__wchar_t, FILE *); } 
#line 416
extern "C" { inline wint_t __cdecl putwchar(__wchar_t); } 
#line 417
extern "C" { extern wint_t __cdecl ungetwc(wint_t, FILE *); } 
#line 419
extern "C" { extern __wchar_t *__cdecl fgetws(__wchar_t *, int, FILE *); } 
#line 420
extern "C" { extern int __cdecl fputws(const __wchar_t *, FILE *); } 
#line 421
extern "C" { extern __wchar_t *__cdecl _getws_s(__wchar_t *, size_t); } 
#line 422
template<size_t _Size> inline __wchar_t *__cdecl _getws_s(__wchar_t (&_String)[_Size]) { return _getws_s(_String, _Size); } 
#line 423
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _getws_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _getws(__wchar_t *); } 
#line 424
extern "C" { extern int __cdecl _putws(const __wchar_t *); } 
#line 426
extern "C" { extern int __cdecl fwprintf(FILE *, const __wchar_t *, ...); } 
#line 427
extern "C" { extern int __cdecl fwprintf_s(FILE *, const __wchar_t *, ...); } 
#line 428
extern "C" { extern int __cdecl wprintf(const __wchar_t *, ...); } 
#line 429
extern "C" { extern int __cdecl wprintf_s(const __wchar_t *, ...); } 
#line 430
extern "C" { extern int __cdecl _scwprintf(const __wchar_t *, ...); } 
#line 431
extern "C" { extern int __cdecl vfwprintf(FILE *, const __wchar_t *, va_list); } 
#line 432
extern "C" { extern int __cdecl vfwprintf_s(FILE *, const __wchar_t *, va_list); } 
#line 433
extern "C" { extern int __cdecl vwprintf(const __wchar_t *, va_list); } 
#line 434
extern "C" { extern int __cdecl vwprintf_s(const __wchar_t *, va_list); } 
#line 436
extern "C" { extern int __cdecl swprintf_s(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 437
__pragma( warning(push)) __pragma( warning(disable: 4793)) template<size_t _Size> inline int __cdecl swprintf_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return vswprintf_s(_Dest, _Size, _Format, _ArgList); } __pragma( warning(pop)) 
#line 438
extern "C" { extern int __cdecl vswprintf_s(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 439
template<size_t _Size> inline int __cdecl vswprintf_s(__wchar_t (&_Dest)[_Size], const __wchar_t *_Format, va_list _Args) { return vswprintf_s(_Dest, _Size, _Format, _Args); } 
#line 441
extern "C" { extern int __cdecl _swprintf_c(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 442
extern "C" { extern int __cdecl _vswprintf_c(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 444
extern "C" { extern int __cdecl _snwprintf_s(__wchar_t *, size_t, size_t, const __wchar_t *, ...); } 
#line 445
__pragma( warning(push)) __pragma( warning(disable: 4793)) template<size_t _Size> inline int __cdecl _snwprintf_s(__wchar_t (&_Dest)[_Size], size_t _Count, const __wchar_t *_Format, ...) { auto va_list _ArgList; _ArgList = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); return _vsnwprintf_s(_Dest, _Size, _Count, _Format, _ArgList); } __pragma( warning(pop)) 
#line 446
extern "C" { extern int __cdecl _vsnwprintf_s(__wchar_t *, size_t, size_t, const __wchar_t *, va_list); } 
#line 447
template<size_t _Size> inline int __cdecl _vsnwprintf_s(__wchar_t (&_Dest)[_Size], size_t _Count, const __wchar_t *_Format, va_list _Args) { return _vsnwprintf_s(_Dest, _Size, _Count, _Format, _Args); } 
#pragma warning(push)
#pragma warning(disable:4793)
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwprintf(__wchar_t *, size_t, const __wchar_t *, ...); } extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnwprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnwprintf(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#pragma warning(pop)
#line 453
extern "C" { extern int __cdecl _fwprintf_p(FILE *, const __wchar_t *, ...); } 
#line 454
extern "C" { extern int __cdecl _wprintf_p(const __wchar_t *, ...); } 
#line 455
extern "C" { extern int __cdecl _vfwprintf_p(FILE *, const __wchar_t *, va_list); } 
#line 456
extern "C" { extern int __cdecl _vwprintf_p(const __wchar_t *, va_list); } 
#line 457
extern "C" { extern int __cdecl _swprintf_p(__wchar_t *, size_t, const __wchar_t *, ...); } 
#line 458
extern "C" { extern int __cdecl _vswprintf_p(__wchar_t *, size_t, const __wchar_t *, va_list); } 
#line 459
extern "C" { extern int __cdecl _scwprintf_p(const __wchar_t *, ...); } 
#line 460
extern "C" { extern int __cdecl _vscwprintf_p(const __wchar_t *, va_list); } 
#line 462
extern "C" { extern int __cdecl _wprintf_l(const __wchar_t *, _locale_t, ...); } 
#line 463
extern "C" { extern int __cdecl _wprintf_p_l(const __wchar_t *, _locale_t, ...); } 
#line 464
extern "C" { extern int __cdecl _wprintf_s_l(const __wchar_t *, _locale_t, ...); } 
#line 465
extern "C" { extern int __cdecl _vwprintf_l(const __wchar_t *, _locale_t, va_list); } 
#line 466
extern "C" { extern int __cdecl _vwprintf_p_l(const __wchar_t *, _locale_t, va_list); } 
#line 467
extern "C" { extern int __cdecl _vwprintf_s_l(const __wchar_t *, _locale_t, va_list); } 
#line 469
extern "C" { extern int __cdecl _fwprintf_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 470
extern "C" { extern int __cdecl _fwprintf_p_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 471
extern "C" { extern int __cdecl _fwprintf_s_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 472
extern "C" { extern int __cdecl _vfwprintf_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 473
extern "C" { extern int __cdecl _vfwprintf_p_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 474
extern "C" { extern int __cdecl _vfwprintf_s_l(FILE *, const __wchar_t *, _locale_t, va_list); } 
#line 476
extern "C" { extern int __cdecl _swprintf_c_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 477
extern "C" { extern int __cdecl _swprintf_p_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 478
extern "C" { extern int __cdecl _swprintf_s_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 479
extern "C" { extern int __cdecl _vswprintf_c_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 480
extern "C" { extern int __cdecl _vswprintf_p_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 481
extern "C" { extern int __cdecl _vswprintf_s_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 483
extern "C" { extern int __cdecl _scwprintf_l(const __wchar_t *, _locale_t, ...); } 
#line 484
extern "C" { extern int __cdecl _scwprintf_p_l(const __wchar_t *, _locale_t, ...); } 
#line 485
extern "C" { extern int __cdecl _vscwprintf_p_l(const __wchar_t *, _locale_t, va_list); } 
#line 487
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwprintf_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 488
extern "C" { extern int __cdecl _snwprintf_s_l(__wchar_t *, size_t, size_t, const __wchar_t *, _locale_t, ...); } 
#line 489
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _vsnwprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vsnwprintf_l(__wchar_t *, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 490
extern "C" { extern int __cdecl _vsnwprintf_s_l(__wchar_t *, size_t, size_t, const __wchar_t *, _locale_t, va_list); } 
#line 504 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma warning(push)
#pragma warning(disable:4141 4996 4793)
extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl _swprintf(__wchar_t *, const __wchar_t *, ...); } extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl _vswprintf(__wchar_t *, const __wchar_t *, va_list); } 
#line 507
extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl __swprintf_l(__wchar_t *, const __wchar_t *, _locale_t, ...); } extern "C" { extern __declspec(deprecated("swprintf has been changed to conform with the ISO C standard, adding an extra character count parameter. To use traditional Microsoft swprintf, set _CRT_NON_CONFORMING_SWPRINTFS.")) int __cdecl __vswprintf_l(__wchar_t *, const __wchar_t *, _locale_t, va_list); } 
#pragma warning(pop)
#line 34 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
extern "C" { static __inline int swprintf(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, ...) 
#line 37
{ 
#line 38
auto va_list _Arglist; 
#line 39
auto int _Ret; 
#line 40
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 41
_Ret = _vswprintf_c_l(_String, _Count, _Format, 0, _Arglist); 
#line 42
_Arglist = ((va_list)0); 
#line 43
return _Ret; 
#line 44
} } 
#pragma warning( pop )
#line 47
#pragma warning( push )
#pragma warning( disable : 4412 )
extern "C" { static __inline int __cdecl vswprintf(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, va_list _Ap) 
#line 50
{ 
#line 51
return _vswprintf_c_l(_String, _Count, _Format, 0, _Ap); 
#line 52
} } 
#pragma warning( pop )
#line 58 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\swprintf.inl"
#pragma warning( push )
#pragma warning( disable : 4793 4412 )
extern "C" { static __inline int _swprintf_l(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, _locale_t _Plocinfo, ...) 
#line 61
{ 
#line 62
auto va_list _Arglist; 
#line 63
auto int _Ret; 
#line 64
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Plocinfo))) + (((sizeof(_Plocinfo) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 65
_Ret = _vswprintf_c_l(_String, _Count, _Format, _Plocinfo, _Arglist); 
#line 66
_Arglist = ((va_list)0); 
#line 67
return _Ret; 
#line 68
} } 
#pragma warning( pop )
#line 71
#pragma warning( push )
#pragma warning( disable : 4412 )
extern "C" { static __inline int __cdecl _vswprintf_l(__wchar_t *_String, size_t _Count, const __wchar_t *_Format, _locale_t _Plocinfo, va_list _Ap) 
#line 74
{ 
#line 75
return _vswprintf_c_l(_String, _Count, _Format, _Plocinfo, _Ap); 
#line 76
} } 
#pragma warning( pop )
#line 80
#pragma warning( push )
#pragma warning( disable : 4996 )
#line 83
#pragma warning( push )
#pragma warning( disable : 4793 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using swprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int swprintf(__wchar_t *_String, const __wchar_t *_Format, ...) 
#line 86
{ 
#line 87
auto va_list _Arglist; 
#line 88
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Format))) + (((sizeof(_Format) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 89
auto int _Ret = _vswprintf(_String, _Format, _Arglist); 
#line 90
_Arglist = ((va_list)0); 
#line 91
return _Ret; 
#line 92
} 
#pragma warning( pop )
#line 95
#pragma warning( push )
#pragma warning( disable : 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using vswprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl vswprintf(__wchar_t *_String, const __wchar_t *_Format, va_list _Ap) 
#line 98
{ 
#line 99
return _vswprintf(_String, _Format, _Ap); 
#line 100
} 
#pragma warning( pop )
#line 103
#pragma warning( push )
#pragma warning( disable : 4793 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using _swprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int _swprintf_l(__wchar_t *_String, const __wchar_t *_Format, _locale_t _Plocinfo, ...) 
#line 106
{ 
#line 107
auto va_list _Arglist; 
#line 108
_Arglist = (va_list)(&(reinterpret_cast< const char &>(_Plocinfo))) + (((sizeof(_Plocinfo) + sizeof(int)) - (1)) & (~(sizeof(int) - (1)))); 
#line 109
auto int _Ret = __vswprintf_l(_String, _Format, _Plocinfo, _Arglist); 
#line 110
_Arglist = ((va_list)0); 
#line 111
return _Ret; 
#line 112
} 
#pragma warning( pop )
#line 115
#pragma warning( push )
#pragma warning( disable : 4141 )
__inline __declspec(deprecated("This function or variable may be unsafe. Consider using _vswprintf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _vswprintf_l(__wchar_t *_String, const __wchar_t *_Format, _locale_t _Plocinfo, va_list _Ap) 
#line 118
{ 
#line 119
return __vswprintf_l(_String, _Format, _Plocinfo, _Ap); 
#line 120
} 
#pragma warning( pop )
#line 123
#pragma warning( pop )
#line 528 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __wchar_t *__cdecl _wtempnam(const __wchar_t *, const __wchar_t *); } 
#line 534 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _vscwprintf(const __wchar_t *, va_list); } 
#line 535
extern "C" { extern int __cdecl _vscwprintf_l(const __wchar_t *, _locale_t, va_list); } 
#line 536
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using fwscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl fwscanf(FILE *, const __wchar_t *, ...); } 
#line 537
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _fwscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _fwscanf_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 539
extern "C" { extern int __cdecl fwscanf_s(FILE *, const __wchar_t *, ...); } 
#line 541 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fwscanf_s_l(FILE *, const __wchar_t *, _locale_t, ...); } 
#line 542
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using swscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl swscanf(const __wchar_t *, const __wchar_t *, ...); } 
#line 543
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _swscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _swscanf_l(const __wchar_t *, const __wchar_t *, _locale_t, ...); } 
#line 545
extern "C" { extern int __cdecl swscanf_s(const __wchar_t *, const __wchar_t *, ...); } 
#line 547 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _swscanf_s_l(const __wchar_t *, const __wchar_t *, _locale_t, ...); } 
#line 548
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwscanf(const __wchar_t *, size_t, const __wchar_t *, ...); } 
#line 549
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _snwscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _snwscanf_l(const __wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 550
extern "C" { extern int __cdecl _snwscanf_s(const __wchar_t *, size_t, const __wchar_t *, ...); } 
#line 551
extern "C" { extern int __cdecl _snwscanf_s_l(const __wchar_t *, size_t, const __wchar_t *, _locale_t, ...); } 
#line 552
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using wscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl wscanf(const __wchar_t *, ...); } 
#line 553
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wscanf_s_l instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) int __cdecl _wscanf_l(const __wchar_t *, _locale_t, ...); } 
#line 555
extern "C" { extern int __cdecl wscanf_s(const __wchar_t *, ...); } 
#line 557 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _wscanf_s_l(const __wchar_t *, _locale_t, ...); } 
#line 559
extern "C" { extern FILE *__cdecl _wfdopen(int, const __wchar_t *); } 
#line 560
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wfopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl _wfopen(const __wchar_t *, const __wchar_t *); } 
#line 561
extern "C" { extern errno_t __cdecl _wfopen_s(FILE **, const __wchar_t *, const __wchar_t *); } 
#line 562
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wfreopen_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) FILE *__cdecl _wfreopen(const __wchar_t *, const __wchar_t *, FILE *); } 
#line 563
extern "C" { extern errno_t __cdecl _wfreopen_s(FILE **, const __wchar_t *, const __wchar_t *, FILE *); } 
#line 569
extern "C" { extern FILE *__cdecl _wpopen(const __wchar_t *, const __wchar_t *); } 
#line 570
extern "C" { extern int __cdecl _wremove(const __wchar_t *); } 
#line 571
extern "C" { extern errno_t __cdecl _wtmpnam_s(__wchar_t *, size_t); } 
#line 572
template<size_t _Size> inline errno_t __cdecl _wtmpnam_s(__wchar_t (&_Buffer)[_Size]) { return _wtmpnam_s(_Buffer, _Size); } 
#line 573
extern "C" { extern __declspec(deprecated("This function or variable may be unsafe. Consider using _wtmpnam_s instead. To disable deprecation, use _CRT_SECURE_NO_DEPRECATE. See online help for details.")) __wchar_t *__cdecl _wtmpnam(__wchar_t *); } 
#line 575
extern "C" { extern wint_t __cdecl _fgetwc_nolock(FILE *); } 
#line 576
extern "C" { extern wint_t __cdecl _fputwc_nolock(__wchar_t, FILE *); } 
#line 577
extern "C" { extern wint_t __cdecl _ungetwc_nolock(wint_t, FILE *); } 
#line 585 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { inline wint_t __cdecl getwchar() 
#line 586
{ return fgetwc(__iob_func() + 0); } } 
#line 587
extern "C" { inline wint_t __cdecl putwchar(__wchar_t _C) 
#line 588
{ return fputwc(_C, __iob_func() + 1); } } 
#line 635 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern void __cdecl _lock_file(FILE *); } 
#line 636
extern "C" { extern void __cdecl _unlock_file(FILE *); } 
#line 643 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern int __cdecl _fclose_nolock(FILE *); } 
#line 644
extern "C" { extern int __cdecl _fflush_nolock(FILE *); } 
#line 645
extern "C" { extern size_t __cdecl _fread_nolock(void *, size_t, size_t, FILE *); } 
#line 646
extern "C" { extern size_t __cdecl _fread_nolock_s(void *, size_t, size_t, size_t, FILE *); } 
#line 647
extern "C" { extern int __cdecl _fseek_nolock(FILE *, long, int); } 
#line 648
extern "C" { extern long __cdecl _ftell_nolock(FILE *); } 
#line 649
extern "C" { extern int __cdecl _fseeki64_nolock(FILE *, __int64, int); } 
#line 650
extern "C" { extern __int64 __cdecl _ftelli64_nolock(FILE *); } 
#line 651
extern "C" { extern size_t __cdecl _fwrite_nolock(const void *, size_t, size_t, FILE *); } 
#line 652
extern "C" { extern int __cdecl _ungetc_nolock(int, FILE *); } 
#line 679 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _tempnam. See online help for details.")) char *__cdecl tempnam(const char *, const char *); } 
#line 685 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fcloseall. See online help for details.")) int __cdecl fcloseall(); } 
#line 686
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fdopen. See online help for details.")) FILE *__cdecl fdopen(int, const char *); } 
#line 687
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fgetchar. See online help for details.")) int __cdecl fgetchar(); } 
#line 688
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fileno. See online help for details.")) int __cdecl fileno(FILE *); } 
#line 689
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _flushall. See online help for details.")) int __cdecl flushall(); } 
#line 690
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _fputchar. See online help for details.")) int __cdecl fputchar(int); } 
#line 691
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _getw. See online help for details.")) int __cdecl getw(FILE *); } 
#line 692
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _putw. See online help for details.")) int __cdecl putw(int, FILE *); } 
#line 693
extern "C" { extern __declspec(deprecated("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _rmtmp. See online help for details.")) int __cdecl rmtmp(); } 
#line 37 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
#pragma warning( disable : 4996 )
#line 702 "C:\\Archivos de programa\\Microsoft Visual Studio 8\\VC\\INCLUDE\\stdio.h"
#pragma pack ( pop )
#line 65 "c:\\Documents and Settings\\user\\Mis documentos\\NVIDIA Corporation\\NVIDIA CUDA SDK\\common\\inc\\cutil.h"
enum CUTBoolean { 
#line 67
CUTFalse, 
#line 68
CUTTrue
#line 69
}; 
#line 77
extern "C" { extern __declspec( dllimport ) void __stdcall cutFree(void *); } 
#line 95
extern "C" { extern __declspec( dllimport ) void __stdcall cutCheckBankAccess(unsigned, unsigned, unsigned, unsigned, unsigned, unsigned, const char *, const int, const char *, const int); } 
#line 108
extern "C" { extern __declspec( dllimport ) char *__stdcall cutFindFilePath(const char *, const char *); } 
#line 123
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFilef(const char *, float **, unsigned *, bool = false); } 
#line 139
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFiled(const char *, double **, unsigned *, bool = false); } 
#line 155
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFilei(const char *, int **, unsigned *, bool = false); } 
#line 170
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileui(const char *, unsigned **, unsigned *, bool = false); } 
#line 186
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileb(const char *, char **, unsigned *, bool = false); } 
#line 202
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutReadFileub(const char *, unsigned char **, unsigned *, bool = false); } 
#line 216
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFilef(const char *, const float *, unsigned, const float, bool = false); } 
#line 230
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFiled(const char *, const float *, unsigned, const double, bool = false); } 
#line 242
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFilei(const char *, const int *, unsigned, bool = false); } 
#line 254
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileui(const char *, const unsigned *, unsigned, bool = false); } 
#line 266
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileb(const char *, const char *, unsigned, bool = false); } 
#line 278
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutWriteFileub(const char *, const unsigned char *, unsigned, bool = false); } 
#line 294
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 307
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPPMub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 321
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPPM4ub(const char *, unsigned char **, unsigned *, unsigned *); } 
#line 337
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMi(const char *, unsigned **, unsigned *, unsigned *); } 
#line 353
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMs(const char *, unsigned short **, unsigned *, unsigned *); } 
#line 368
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutLoadPGMf(const char *, float **, unsigned *, unsigned *); } 
#line 380
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMub(const char *, unsigned char *, unsigned, unsigned); } 
#line 392
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePPMub(const char *, unsigned char *, unsigned, unsigned); } 
#line 405
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePPM4ub(const char *, unsigned char *, unsigned, unsigned); } 
#line 417
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMi(const char *, unsigned *, unsigned, unsigned); } 
#line 429
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMs(const char *, unsigned short *, unsigned, unsigned); } 
#line 441
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutSavePGMf(const char *, float *, unsigned, unsigned); } 
#line 462
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCheckCmdLineFlag(const int, const char **, const char *); } 
#line 476
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumenti(const int, const char **, const char *, int *); } 
#line 490
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentf(const int, const char **, const char *, float *); } 
#line 504
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentstr(const int, const char **, const char *, char **); } 
#line 519
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutGetCmdLineArgumentListstr(const int, const char **, const char *, char **, unsigned *); } 
#line 533
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCheckCondition(int, const char *, const int); } 
#line 545
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparef(const float *, const float *, const unsigned); } 
#line 558
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparei(const int *, const int *, const unsigned); } 
#line 571
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareub(const unsigned char *, const unsigned char *, const unsigned); } 
#line 585
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareube(const unsigned char *, const unsigned char *, const unsigned, const int); } 
#line 599
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutComparefe(const float *, const float *, const unsigned, const float); } 
#line 614
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCompareL2fe(const float *, const float *, const unsigned, const float); } 
#line 627
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutCreateTimer(unsigned *); } 
#line 636
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutDeleteTimer(unsigned); } 
#line 644
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutStartTimer(const unsigned); } 
#line 652
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutStopTimer(const unsigned); } 
#line 660
extern "C" { extern __declspec( dllimport ) CUTBoolean __stdcall cutResetTimer(const unsigned); } 
#line 669
extern "C" { extern __declspec( dllimport ) float __stdcall cutGetTimerValue(const unsigned); } 
#line 680
extern "C" { extern __declspec( dllimport ) float __stdcall cutGetAverageTimerValue(const unsigned); } 
#line 30 "template.cu"
unsigned NUM_THREADS_IN_BLOCK = (256); 
#line 47
__loc_sc__(__text__,) texture< int, 1, cudaReadModeElementType>  textura_m; 
#line 51
__loc_sc__(__text__,) texture< char1, 1, cudaReadModeElementType>  textura_p; 
#line 52
__loc_sc__(__text__,) texture< char1, 1, cudaReadModeElementType>  textura_f; 
#define __include___device_stub___globfunc__Z7kernel3PbS_PKjj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z7kernel3PbS_PKjj
#define __include___device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj
#define __include___device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj
#define __include___device_stub___globfunc__Z15kernel1_SSSP7_TjPj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z15kernel1_SSSP7_TjPj
#define __include___device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z15kernel1_SSSP7_1jPKjPKbS2_Pj
#define __include___device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj
#define __include___device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj
#define __include___device_stub___globfunc__Z16kernel1_SSSP7_RTjPj 1
#include "template.cudafe1.stub.h"
#undef __include___device_stub___globfunc__Z16kernel1_SSSP7_RTjPj
#line 4 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\tools.h"
extern void mostrarB(const bool *, const unsigned, const char *); 
#line 5
extern void mostrarI(const int *, const unsigned, const char *); 
#line 6
extern void mostrarUI(const unsigned *, const unsigned, const char *); 
#line 8
extern unsigned minimo(const unsigned, const unsigned); 
#line 12
extern void mostrarUI_M_Adyacencia(const unsigned *, const unsigned, const char *); 
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\Fibonacci_Heaps.h"
extern void computeGold_FH(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 13 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\comun.cu"
void copiarH2D(void *v_d, const void *v_h, const unsigned mem_size) { 
#line 14
cudaMemcpy(v_d, v_h, mem_size, cudaMemcpyHostToDevice); 
#line 15
} 
#line 18
void copiarD2H(void *v_h, const void *v_d, const unsigned mem_size) { 
#line 19
cudaMemcpy(v_h, v_d, mem_size, cudaMemcpyDeviceToHost); 
#line 20
} 
#line 23
void inicializar_Matriz_Device(const unsigned *m_h, const unsigned mem_size_M, unsigned *&
#line 24
m_d) { 
#line 26
cudaMalloc((void **)(&m_d), mem_size_M); 
#line 27
copiarH2D(m_d, m_h, mem_size_M); 
#line 28
} 
#line 31
void inicializar_Sol(unsigned *&c_h, unsigned *&c_d, const unsigned 
#line 32
nv, const unsigned mem_size_V, const unsigned 
#line 33
infinito) { 
#line 35
c_h = (unsigned *)malloc(mem_size_V); 
#line 37
((c_h)[0]) = (0); 
#line 38
for (unsigned i = (1); i <= nv - (1); i++) { ((c_h)[i]) = infinito; }  
#line 41
cudaMalloc((void **)(&c_d), mem_size_V); 
#line 43
copiarH2D((void *)(c_d), (void *)(c_h), mem_size_V); 
#line 47
} 
#line 51
void inicializar_Pendientes(bool *&p_h, bool *&p_d, const unsigned 
#line 52
nv, const unsigned mem_size_F) { 
#line 54
p_h = (bool *)malloc(mem_size_F); 
#line 56
((p_h)[0]) = false; 
#line 57
for (unsigned i = (1); i <= nv - (1); i++) { ((p_h)[i]) = true; }  
#line 60
cudaMalloc((void **)(&p_d), mem_size_F); 
#line 62
copiarH2D((void *)(p_d), (void *)(p_h), mem_size_F); 
#line 67
} 
#line 70
void inicializar_Frontera(bool *&f_h, bool *&f_d, const unsigned 
#line 71
nv, const unsigned mem_size_F) { 
#line 73
f_h = (bool *)malloc(mem_size_F); 
#line 75
((f_h)[0]) = true; 
#line 76
for (unsigned i = (1); i <= nv - (1); i++) { ((f_h)[i]) = false; }  
#line 79
cudaMalloc((void **)(&f_d), mem_size_F); 
#line 81
copiarH2D((void *)(f_d), (void *)(f_h), mem_size_F); 
#line 87
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
bool ejecutarIteracion_SSSP7(const unsigned 
#line 19
nVuelta, const dim3 
#line 20
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21
nv, const unsigned mem_size_M, const unsigned 
#line 22
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23
infinito, bool *
#line 24
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25
minimoDelBloque_h, const unsigned *
#line 26
m_d, bool *
#line 27
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28
minimoDelBloque_d) { 
#line 47
auto unsigned shared_mem = (threads.x * (sizeof(unsigned) + sizeof(bool))); 
#line 48
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z13kernel1_SSSP7jPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 50
; 
#line 51
cudaThreadSynchronize(); 
#line 72
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 75
; 
#line 76
cudaThreadSynchronize(); 
#line 78
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 79
auto unsigned min = infinito; 
#line 90
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 91
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 92
}  
#line 111 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 113
; 
#line 114
cudaThreadSynchronize(); 
#line 127
return min == infinito; 
#line 128
} 
#line 131
void testGraph_SSSP7(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 132
infinito, unsigned num_threadsInBlock, const unsigned *
#line 133
m_h, const unsigned *reference) { 
#line 136
auto unsigned *m_d; 
#line 139
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 141
auto unsigned *c_h; 
#line 142
auto unsigned *c_d; 
#line 143
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 144
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 146
auto bool *f_h; 
#line 147
auto bool *f_d; 
#line 148
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 149
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 151
auto bool *p_h; 
#line 152
auto bool *p_d; 
#line 153
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 157
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 158
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 159
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 160
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 163
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 164
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 165
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 166
auto unsigned *minimoDelBloque_d; 
#line 167
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 168
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 181
auto unsigned timer = (0); 
#line 182
cutCreateTimer(&timer); 
#line 183
cutStartTimer(timer); 
#line 187
auto bool ultima = false; 
#line 188
auto unsigned i = (0); 
#line 189
while (!ultima) { 
#line 190
i++; 
#line 191
ultima = ejecutarIteracion_SSSP7(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 201
}  
#line 203
cutStopTimer(timer); 
#line 204
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 205
cutDeleteTimer(timer); 
#line 207
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 211
cudaFree(m_d); 
#line 213
free(f_h); 
#line 214
free(p_h); 
#line 216
cudaFree(c_d); 
#line 217
cudaFree(f_d); 
#line 218
cudaFree(p_d); 
#line 220
free(minimoDelBloque_h); 
#line 222
cudaFree(minimoDelBloque_d); 
#line 225
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 226
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 230
free(c_h); 
#line 232
} 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
bool ejecutarIteracion_SSSP7_T(const unsigned 
#line 20
nVuelta, const dim3 
#line 21
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 22
nv, const unsigned mem_size_M, const unsigned 
#line 23
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 24
infinito, bool *
#line 25
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 26
minimoDelBloque_h, const unsigned *
#line 27
m_d, bool *
#line 28
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 29
minimoDelBloque_d) { 
#line 48
auto unsigned shared_mem = (threads.x * (sizeof(unsigned) + sizeof(bool))); 
#line 49
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z15kernel1_SSSP7_TjPj(nv, c_d); 
#line 52
; 
#line 53
cudaThreadSynchronize(); 
#line 74
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 77
; 
#line 78
cudaThreadSynchronize(); 
#line 80
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 81
auto unsigned min = infinito; 
#line 92
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 93
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 94
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_T.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115
; 
#line 116
cudaThreadSynchronize(); 
#line 129
return min == infinito; 
#line 130
} 
#line 133
void testGraph_SSSP7_T(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 134
infinito, unsigned num_threadsInBlock, const unsigned *
#line 135
m_h, const unsigned *reference) { 
#line 137
auto unsigned *m_d; 
#line 140
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 143
cudaBindTexture(0, textura_m, m_d, mem_size_M); 
#line 145
auto unsigned *c_h; 
#line 146
auto unsigned *c_d; 
#line 147
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150
auto bool *f_h; 
#line 151
auto bool *f_d; 
#line 152
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155
auto bool *p_h; 
#line 156
auto bool *p_d; 
#line 157
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161
cudaBindTexture(0, textura_p, p_d, mem_size_F); 
#line 162
cudaBindTexture(0, textura_f, f_d, mem_size_F); 
#line 166
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 167
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 168
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 169
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 172
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 173
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 174
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 175
auto unsigned *minimoDelBloque_d; 
#line 176
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 177
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 190
auto unsigned timer = (0); 
#line 191
cutCreateTimer(&timer); 
#line 192
cutStartTimer(timer); 
#line 196
auto bool ultima = false; 
#line 197
auto unsigned i = (0); 
#line 198
while (!ultima) { 
#line 199
i++; 
#line 200
ultima = ejecutarIteracion_SSSP7_T(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 211
}  
#line 213
cutStopTimer(timer); 
#line 214
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 215
cutDeleteTimer(timer); 
#line 217
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 220
cudaUnbindTexture(textura_m); 
#line 223
cudaFree(m_d); 
#line 225
free(f_h); 
#line 226
free(p_h); 
#line 230
cudaUnbindTexture(textura_p); 
#line 231
cudaUnbindTexture(textura_f); 
#line 233
cudaFree(c_d); 
#line 234
cudaFree(f_d); 
#line 235
cudaFree(p_d); 
#line 237
free(minimoDelBloque_h); 
#line 239
cudaFree(minimoDelBloque_d); 
#line 242
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 243
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 246
free(c_h); 
#line 248
} 
#line 19 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
bool ejecutarIteracion_SSSP7_RT(const unsigned 
#line 20
nVuelta, const dim3 
#line 21
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 22
nv, const unsigned mem_size_M, const unsigned 
#line 23
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 24
infinito, bool *
#line 25
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 26
minimoDelBloque_h, const unsigned *
#line 27
m_d, bool *
#line 28
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 29
minimoDelBloque_d) { 
#line 48
auto unsigned shared_mem = (threads.x * ((((4) * sizeof(unsigned)) + sizeof(unsigned)) + sizeof(bool))); 
#line 49
cudaConfigureCall(grid, threads, shared_mem) ? ((void)0) : __device_stub___globfunc__Z16kernel1_SSSP7_RTjPj(nv, c_d); 
#line 52
; 
#line 53
cudaThreadSynchronize(); 
#line 74
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 77
; 
#line 78
cudaThreadSynchronize(); 
#line 80
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 81
auto unsigned min = infinito; 
#line 92
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 93
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 94
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP7_RT.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115
; 
#line 116
cudaThreadSynchronize(); 
#line 129
return min == infinito; 
#line 130
} 
#line 133
void testGraph_SSSP7_RT(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 134
infinito, unsigned num_threadsInBlock, const unsigned *
#line 135
m_h, const unsigned *reference) { 
#line 137
auto unsigned *m_d; 
#line 140
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 143
cudaBindTexture(0, textura_m, m_d, mem_size_M); 
#line 145
auto unsigned *c_h; 
#line 146
auto unsigned *c_d; 
#line 147
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150
auto bool *f_h; 
#line 151
auto bool *f_d; 
#line 152
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155
auto bool *p_h; 
#line 156
auto bool *p_d; 
#line 157
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161
cudaBindTexture(0, textura_p, p_d, mem_size_F); 
#line 162
cudaBindTexture(0, textura_f, f_d, mem_size_F); 
#line 166
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 167
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 168
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 169
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 172
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 173
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 174
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 175
auto unsigned *minimoDelBloque_d; 
#line 176
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 177
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 190
auto unsigned timer = (0); 
#line 191
cutCreateTimer(&timer); 
#line 192
cutStartTimer(timer); 
#line 196
auto bool ultima = false; 
#line 197
auto unsigned i = (0); 
#line 198
while (!ultima) { 
#line 199
i++; 
#line 200
ultima = ejecutarIteracion_SSSP7_RT(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 211
}  
#line 213
cutStopTimer(timer); 
#line 214
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 215
cutDeleteTimer(timer); 
#line 217
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 220
cudaUnbindTexture(textura_m); 
#line 223
cudaFree(m_d); 
#line 225
free(f_h); 
#line 226
free(p_h); 
#line 230
cudaUnbindTexture(textura_p); 
#line 231
cudaUnbindTexture(textura_f); 
#line 233
cudaFree(c_d); 
#line 234
cudaFree(f_d); 
#line 235
cudaFree(p_d); 
#line 237
free(minimoDelBloque_h); 
#line 239
cudaFree(minimoDelBloque_d); 
#line 242
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 243
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 246
free(c_h); 
#line 248
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
bool ejecutarIteracion_SSSP9(const unsigned 
#line 19
nVuelta, const dim3 
#line 20
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21
nv, const unsigned mem_size_M, const unsigned 
#line 22
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23
infinito, bool *
#line 24
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25
minimoDelBloque_h, const unsigned *
#line 26
m_d, bool *
#line 27
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28
minimoDelBloque_d) { 
#line 48
cudaConfigureCall(grid, threads, threads.x * sizeof(bool)) ? ((void)0) : __device_stub___globfunc__Z13kernel1_SSSP9jPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 50
; 
#line 51
cudaThreadSynchronize(); 
#line 73
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 76
; 
#line 77
cudaThreadSynchronize(); 
#line 79
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 80
auto unsigned min = infinito; 
#line 91
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 92
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 93
}  
#line 113 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 115
; 
#line 116
cudaThreadSynchronize(); 
#line 131
return min == infinito; 
#line 132
} 
#line 135
void testGraph_SSSP9(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 136
infinito, unsigned num_threadsInBlock, const unsigned *
#line 137
m_h, const unsigned *reference) { 
#line 140
auto unsigned *m_d; 
#line 143
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 145
auto unsigned *c_h; 
#line 146
auto unsigned *c_d; 
#line 147
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 148
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 150
auto bool *f_h; 
#line 151
auto bool *f_d; 
#line 152
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 153
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 155
auto bool *p_h; 
#line 156
auto bool *p_d; 
#line 157
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 161
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 162
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 163
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 164
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 167
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 168
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 169
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 170
auto unsigned *minimoDelBloque_d; 
#line 171
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 172
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 185
auto unsigned timer = (0); 
#line 186
cutCreateTimer(&timer); 
#line 187
cutStartTimer(timer); 
#line 191
auto bool ultima = false; 
#line 192
auto unsigned i = (0); 
#line 193
while (!ultima) { 
#line 194
i++; 
#line 195
ultima = ejecutarIteracion_SSSP9(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 205
}  
#line 207
cutStopTimer(timer); 
#line 208
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 209
cutDeleteTimer(timer); 
#line 211
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 215
cudaFree(m_d); 
#line 217
free(f_h); 
#line 218
free(p_h); 
#line 220
cudaFree(c_d); 
#line 221
cudaFree(f_d); 
#line 222
cudaFree(p_d); 
#line 224
free(minimoDelBloque_h); 
#line 226
cudaFree(minimoDelBloque_d); 
#line 229
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 230
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 234
free(c_h); 
#line 236
} 
#line 18 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
bool ejecutarIteracion_SSSP9_Atomic(const unsigned 
#line 19
nVuelta, const dim3 
#line 20
grid, const dim3 threads, const dim3 grid_minimizar, const unsigned 
#line 21
nv, const unsigned mem_size_M, const unsigned 
#line 22
mem_size_C, const unsigned mem_size_F, const unsigned mem_size_Minimizar, const unsigned 
#line 23
infinito, bool *
#line 24
p_h, bool *f_h, unsigned *c_h, unsigned *
#line 25
minimoDelBloque_h, const unsigned *
#line 26
m_d, bool *
#line 27
p_d, bool *f_d, unsigned *c_d, unsigned *
#line 28
minimoDelBloque_d) { 
#line 47
cudaConfigureCall(grid, threads, threads.x * sizeof(bool)) ? ((void)0) : __device_stub___globfunc__Z20kernel1_SSSP9_AtomicjPKjPKbS2_Pj(nv, m_d, p_d, f_d, c_d); 
#line 49
; 
#line 50
cudaThreadSynchronize(); 
#line 71
cudaConfigureCall(grid_minimizar, threads, sizeof(unsigned) * threads.x) ? ((void)0) : __device_stub___globfunc__Z17kernel_minimizar1PKbPKjjPj(p_d, c_d, infinito, minimoDelBloque_d); 
#line 74
; 
#line 75
cudaThreadSynchronize(); 
#line 77
copiarD2H((void *)minimoDelBloque_h, (void *)minimoDelBloque_d, mem_size_Minimizar); 
#line 78
auto unsigned min = infinito; 
#line 89
for (unsigned i = (0); i < grid_minimizar.x; i++) { 
#line 90
if (min > minimoDelBloque_h[i]) { min = minimoDelBloque_h[i]; }  
#line 91
}  
#line 110 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\SSSP9_Atomic.cu"
cudaConfigureCall(grid, threads) ? ((void)0) : __device_stub___globfunc__Z7kernel3PbS_PKjj(p_d, f_d, c_d, min); 
#line 112
; 
#line 113
cudaThreadSynchronize(); 
#line 126
return min == infinito; 
#line 127
} 
#line 131
void testGraph_SSSP9_Atomic(const unsigned nv, const unsigned mem_size_M, const unsigned 
#line 132
infinito, unsigned num_threadsInBlock, const unsigned *
#line 133
m_h, const unsigned *reference) { 
#line 136
auto unsigned *m_d; 
#line 139
inicializar_Matriz_Device(m_h, mem_size_M, m_d); 
#line 141
auto unsigned *c_h; 
#line 142
auto unsigned *c_d; 
#line 143
auto unsigned mem_size_C = (nv * sizeof(unsigned)); 
#line 144
inicializar_Sol(c_h, c_d, nv, mem_size_C, infinito); 
#line 146
auto bool *f_h; 
#line 147
auto bool *f_d; 
#line 148
auto unsigned mem_size_F = (sizeof(bool) * nv); 
#line 149
inicializar_Frontera(f_h, f_d, nv, mem_size_F); 
#line 151
auto bool *p_h; 
#line 152
auto bool *p_d; 
#line 153
inicializar_Pendientes(p_h, p_d, nv, mem_size_F); 
#line 157
auto unsigned num_blocksInGrid = (nv / num_threadsInBlock); 
#line 158
auto dim3 grid(num_blocksInGrid, 1, 1); 
#line 159
auto dim3 threads(num_threadsInBlock, 1, 1); 
#line 160
auto dim3 grid_minimizar(num_blocksInGrid / (2), 1, 1); 
#line 163
auto unsigned mem_size_Minimizar = (sizeof(unsigned) * grid_minimizar.x); 
#line 164
auto unsigned *minimoDelBloque_h = ((unsigned *)malloc(mem_size_Minimizar)); 
#line 165
for (unsigned i = (0); i < grid_minimizar.x; i++) { (minimoDelBloque_h[i]) = infinito; }  
#line 166
auto unsigned *minimoDelBloque_d; 
#line 167
cudaMalloc((void **)(&minimoDelBloque_d), mem_size_Minimizar); 
#line 168
copiarH2D((void *)minimoDelBloque_d, (void *)minimoDelBloque_h, mem_size_Minimizar); 
#line 181
auto unsigned timer = (0); 
#line 182
cutCreateTimer(&timer); 
#line 183
cutStartTimer(timer); 
#line 187
auto bool ultima = false; 
#line 188
auto unsigned i = (0); 
#line 189
while (!ultima) { 
#line 190
i++; 
#line 191
ultima = ejecutarIteracion_SSSP9_Atomic(i, grid, threads, grid_minimizar, nv, mem_size_M, mem_size_C, mem_size_F, mem_size_Minimizar, infinito, p_h, f_h, c_h, minimoDelBloque_h, m_d, p_d, f_d, c_d, minimoDelBloque_d); 
#line 201
}  
#line 203
cutStopTimer(timer); 
#line 204
printf("%f\t%d\t", cutGetTimerValue(timer), i); 
#line 205
cutDeleteTimer(timer); 
#line 207
copiarD2H((void *)c_h, (void *)c_d, mem_size_C); 
#line 211
cudaFree(m_d); 
#line 213
free(f_h); 
#line 214
free(p_h); 
#line 216
cudaFree(c_d); 
#line 217
cudaFree(f_d); 
#line 218
cudaFree(p_d); 
#line 220
free(minimoDelBloque_h); 
#line 222
cudaFree(minimoDelBloque_d); 
#line 225
auto CUTBoolean res = cutComparei((int *)reference, (int *)c_h, nv); 
#line 226
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 230
free(c_h); 
#line 232
} 
#line 71 "template.cu"
extern void runTest(); 
#line 72
extern void generar_Matrices_Adyacencia(); 
#line 73
extern void runFH(); 
#line 5 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\template_gold.h"
extern void computeGold_CPU7(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 10
extern void computeGold_CPU9(unsigned *, const unsigned, const unsigned *, const unsigned); 
#line 6 "c:\\documents and settings\\user\\mis documentos\\nvidia corporation\\nvidia cuda sdk\\projects\\sssp_matrices\\GeneradorGrafos.h"
extern void genera_M_Adyacencia(const unsigned, const unsigned, const unsigned, const unsigned, unsigned &, unsigned *&); 
#line 11
extern void guardaMatriz_FicheroB(const char *, const unsigned, const unsigned, const unsigned *); 
#line 15
extern void leeMatriz_FicheroB(const char *, unsigned &, unsigned &, unsigned *&); 
#line 18
extern unsigned RangedRand(unsigned, unsigned); 
#line 85 "template.cu"
int __cdecl main(int argc, char **argv) 
#line 86
{ 
#line 88
{ auto int deviceCount; cudaGetDeviceCount(&deviceCount); if (deviceCount == 0) { fprintf(__iob_func() + 2, "cutil error: no devices supporting CUDA.\n"); exit(1); }  auto int dev = 0; cutGetCmdLineArgumenti(argc, (const char **)argv, "device", &dev); if (dev > deviceCount - 1) { dev = deviceCount - 1; }  auto cudaDeviceProp deviceProp; cudaGetDeviceProperties(&deviceProp, dev); if (deviceProp.major < 1) { fprintf(__iob_func() + 2, "cutil error: device does not support CUDA.\n"); exit(1); }  if (cutCheckCmdLineFlag(argc, (const char **)argv, "quiet") == (CUTFalse)) { fprintf(__iob_func() + 2, "Using device %d: %s\n", dev, deviceProp.name); }  cudaSetDevice(dev); } ; 
#line 90
srand(time(0)); 
#line 95
runFH(); 
#line 111
printf("\n\n"); 
#line 112
printf(cudaGetErrorString(cudaGetLastError())); 
#line 113
printf("\n\n"); 
#line 115
if (!(cutCheckCmdLineFlag(argc, (const char **)argv, "noprompt"))) { printf("\nPress ENTER to exit...\n"); fflush(__iob_func() + 1); fflush(__iob_func() + 2); getchar(); }  exit(0); ; return 0; 
#line 117
} 
#line 122
void generar_Matrices_Adyacencia() { 
#line 124
auto unsigned nv; 
#line 125
auto unsigned *m; 
#line 126
auto unsigned mem_size_M; 
#line 128
auto unsigned degree; 
#line 129
auto unsigned topeW = (10); 
#line 130
auto unsigned infinito; 
#line 133
auto char s[100]; 
#line 135
auto unsigned timer; 
#line 137
printf("Generando y Guardando Matrices de Adyacencia\n"); 
#line 139
for (unsigned k = (1); k <= (15); k++) { 
#line 140
nv = k * (1024); 
#line 141
degree = nv / (5); 
#line 142
infinito = nv * (10); 
#line 143
printf("\n\nNODOS= %d * 1024\n", k); 
#line 144
printf("topeW= %i\n", 10); 
#line 145
printf("degree= nv/%i= %i\n", 5, degree); 
#line 146
printf("infinito= nv*%i= %i\n\n", 10, infinito); 
#line 148
printf("Matriz\t Generar\t Guardar\n"); 
#line 149
for (unsigned i = (1); i <= (25); i++) { 
#line 151
printf("%i\t", i); 
#line 153
if (i < (10)) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 154
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 158
timer = (0); 
#line 159
cutCreateTimer(&timer); 
#line 160
cutStartTimer(timer); 
#line 162
genera_M_Adyacencia(nv, degree, topeW, infinito, mem_size_M, m); 
#line 164
cutStopTimer(timer); 
#line 165
printf("%f\t", cutGetTimerValue(timer)); 
#line 166
cutDeleteTimer(timer); 
#line 168
timer = (0); 
#line 169
cutCreateTimer(&timer); 
#line 170
cutStartTimer(timer); 
#line 172
guardaMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 174
cutStopTimer(timer); 
#line 175
printf("%f\n", cutGetTimerValue(timer)); 
#line 176
cutDeleteTimer(timer); 
#line 179
free(m); 
#line 181
}  
#line 183
}  
#line 185
} 
#line 188
void runTest() { 
#line 191
auto unsigned nv; 
#line 192
auto unsigned *m; 
#line 193
auto unsigned mem_size_M; 
#line 195
auto unsigned topeW = (10); 
#line 196
auto unsigned infinito; 
#line 199
auto unsigned *reference1; 
#line 200
auto unsigned *reference2; 
#line 204
printf("TEST SSSP7, SSSP9\n\n"); 
#line 205
printf("degree= nv/%i\n", 5); 
#line 206
printf("topeW= %i\n", topeW); 
#line 209
auto char s[100]; 
#line 211
for (unsigned t = (1); t <= (1); t++) { 
#line 213
printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); 
#line 215
for (unsigned k = (7); k <= (15); k++) { 
#line 216
printf("\n\nNODOS= %i * 1024\n\n", k); 
#line 217
printf("Grafo\t CPU7\t\t\t CPU9\t\t\t SSSP7\t\t\t SSSP9_Atomic\t\t\t SSSP9\t\t\t SSSP7_T\t\t\t SSSP7_RT\n\n"); 
#line 218
nv = k * (1024); 
#line 219
infinito = nv * (10); 
#line 221
for (int i = 1; i <= 25; i++) { 
#line 223
printf("%i\t", i); 
#line 225
if (i < 10) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 226
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 232
leeMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 235
reference1 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 236
computeGold_CPU7(reference1, nv, m, infinito); 
#line 238
reference2 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 239
computeGold_CPU9(reference2, nv, m, infinito); 
#line 242
auto CUTBoolean res = cutComparei((int *)reference1, (int *)reference2, nv); 
#line 243
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 245
free(reference2); 
#line 248
testGraph_SSSP7(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 250
testGraph_SSSP9_Atomic(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 252
testGraph_SSSP9(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 254
testGraph_SSSP7_T(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 256
testGraph_SSSP7_RT(nv, mem_size_M, infinito, NUM_THREADS_IN_BLOCK, m, reference1); 
#line 258
printf("\n"); 
#line 261
free(m); 
#line 262
free(reference1); 
#line 264
}  
#line 266
}  
#line 268
NUM_THREADS_IN_BLOCK = NUM_THREADS_IN_BLOCK * (2); 
#line 270
}  
#line 271
} 
#line 274
void runFH() { 
#line 277
auto unsigned nv; 
#line 278
auto unsigned *m; 
#line 279
auto unsigned mem_size_M; 
#line 281
auto unsigned topeW = (10); 
#line 282
auto unsigned infinito; 
#line 285
auto unsigned *reference1; 
#line 286
auto unsigned *reference2; 
#line 290
printf("TEST SSSP MATRICES\n\n"); 
#line 291
printf("degree= nv/%i\n", 5); 
#line 292
printf("topeW= %i\n", topeW); 
#line 295
auto char s[100]; 
#line 297
printf("\n\nHilos por bloque= %i\n\n", NUM_THREADS_IN_BLOCK); 
#line 299
for (unsigned k = (1); k <= (15); k++) { 
#line 300
printf("\n\nNODOS= %i * 1024\n\n", k); 
#line 301
printf("Grafo\t CPU7\t\t\t FH\n\n"); 
#line 302
nv = k * (1024); 
#line 303
infinito = nv * (10); 
#line 305
for (int i = 1; i <= 25; i++) { 
#line 307
printf("%i\t", i); 
#line 309
if (i < 10) { sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz0%d.gr", k, i); } else { 
#line 310
sprintf_s(s, "E:/CHUS/DATA/MATRICES/%d/matriz%d.gr", k, i); }  
#line 314
leeMatriz_FicheroB(s, nv, mem_size_M, m); 
#line 317
reference1 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 318
computeGold_CPU7(reference1, nv, m, infinito); 
#line 320
reference2 = (unsigned *)malloc(nv * sizeof(unsigned)); 
#line 321
computeGold_FH(reference2, nv, m, infinito); 
#line 325
auto CUTBoolean res = cutComparei((int *)reference1, (int *)reference2, nv); 
#line 326
printf("%s\t", (1 == res) ? ("OK") : ("FAILED")); 
#line 328
printf("\n"); 
#line 331
free(m); 
#line 332
free(reference1); 
#line 333
free(reference2); 
#line 336
}  
#line 338
}  
#line 340
} 

#include "template.cudafe1.stub.c"
