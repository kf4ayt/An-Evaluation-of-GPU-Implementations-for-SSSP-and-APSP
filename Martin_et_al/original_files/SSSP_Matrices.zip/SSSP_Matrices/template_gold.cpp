/*
MATRIZ DE ADYACENCIA -> Cooperaci�n de los hilos de un bloque

SOLUCIONES CPU
*/

#include "template_gold.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <cutil.h>
#include "tools.h"


////////////////////////////////////////////////////////////////////////////////
//! Compute reference data set
//! Each element is multiplied with the number of threads / array length
//! @param reference  reference data, computed but preallocated
//! @param idata      input data as provided to device
//! @param len        number of elements in reference / idata
////////////////////////////////////////////////////////////////////////////////


bool ejecutarIteracion_CPU7( const unsigned int nVuelta,
							 unsigned int* reference, 
 							 const unsigned int nv, const unsigned int* m, 
 							 const unsigned int infinito,
							 bool* f, bool* p){
/*
#ifdef _DEBUG    
    printf("\n\n*******************\n");    
    printf("\nVUELTA %i\n",nVuelta);
    mostrarUI(reference, nv, "reference");    
    mostrarB(f, nv, "f_h");    
    mostrarB(p, nv, "p_h");    
#endif //_DEBUG
*/
					   
	unsigned int tid;
	unsigned int pid;

	//ACTUALIZACION DE REFERENCE USANDO LA FRONTERA
	for(tid=0; tid<nv; tid++){
		if(p[tid]){ //El nodo est� pendiente
			for(pid=0; pid<nv; pid++){ //visitando los predecesores de tid
				if(f[pid]){ //pid pertenece a la frontera
					reference[tid]= minimo(reference[pid]+ MATRIX(m, pid, tid), reference[tid]);
				}//if 
			}//for
		}//if
       
	}//for   


	//MINIMIZANDO LOS COSTES RECIEN ACTUALIZADOS
	unsigned int minimo= infinito;
	for(tid=0; tid<nv; tid++){
		if(p[tid] && (minimo>reference[tid])){
			minimo= reference[tid];
		}//if
	}//for

	//ACTUALIZANDO LA FRONTERA
	for(tid=0; tid<nv; tid++){
		f[tid]= false;  
        if(p[tid] && (reference[tid]==minimo)){
			f[tid]= true;
			p[tid]= false;
		}//if
	}//for

	return (minimo==infinito);

}//ejecutarIteracion

void computeGold_CPU7(unsigned int* reference, 
					          const unsigned int nv, const unsigned int* m, 
							  const unsigned int infinito){

    unsigned int mem_size_F= sizeof(bool) * nv;
	bool* p= (bool*) malloc( mem_size_F);
	bool* f= (bool*) malloc( mem_size_F);

	reference[0]= 0;
    p[0]= false;
    f[0]= true;
	for(unsigned int i= 1; i<nv; i++){
		reference[i]= infinito;
		p[i]= true;
	    f[i]= false;
	}

    unsigned int timer = 0;
    CUT_SAFE_CALL( cutCreateTimer( &timer));
    CUT_SAFE_CALL( cutStartTimer( timer));

    bool ultima= false;
    unsigned int i= 0;
    while((!ultima)){
        i++;
		ultima= ejecutarIteracion_CPU7(i, reference, 
									   nv, m, infinito,
								       f, p);
	}//while

	
	CUT_SAFE_CALL( cutStopTimer( timer));
    printf( "%f\t %d\t", cutGetTimerValue( timer), i);
    CUT_SAFE_CALL( cutDeleteTimer( timer));

	//destrucci�n de arrays
	free(p);
	free(f);
}


bool ejecutarIteracion_CPU9( const unsigned int nVuelta,
							 unsigned int* reference, 
 							 const unsigned int nv, const unsigned int* m, 
 							 const unsigned int infinito,
							 bool* f, bool* p){

#ifdef _DEBUG    
    printf("\n\n*******************\n");    
    printf("\nVUELTA %i\n",nVuelta);
    mostrarUI(reference, nv, "reference");    
    mostrarB(f, nv, "f_h");    
    mostrarB(p, nv, "p_h");    
#endif //_DEBUG

					   
	unsigned int tid;
	unsigned int sid;

	//ACTUALIZACION DE REFERENCE USANDO LA FRONTERA
	for(tid=0; tid<nv; tid++){
		if(f[tid]){ //El nodo est� en la frontera
			for(sid=0; sid<nv; sid++){ //visitando los sucesores de tid
				if(p[sid]){ //pid est� pendiente
					reference[sid]= minimo(reference[sid], MATRIX(m, tid, sid) + reference[tid]);
				}//if 
			}//for
		}//if
       
	}//for   


	//MINIMIZANDO LOS COSTES RECIEN ACTUALIZADOS
	unsigned int minimo= infinito;
	for(tid=0; tid<nv; tid++){
		if(p[tid] && (minimo>reference[tid])){
			minimo= reference[tid];
		}//if
	}//for

	//ACTUALIZANDO LA FRONTERA
	for(tid=0; tid<nv; tid++){
		f[tid]= false;  
        if(p[tid] && (reference[tid]==minimo)){
			f[tid]= true;
			p[tid]= false;
		}//if
	}//for

	return (minimo==infinito);

}//ejecutarIteracion

void computeGold_CPU9(unsigned int* reference, 
					          const unsigned int nv, const unsigned int* m, 
							  const unsigned int infinito){

    unsigned int mem_size_F= sizeof(bool) * nv;
	bool* p= (bool*) malloc( mem_size_F);
	bool* f= (bool*) malloc( mem_size_F);

	reference[0]= 0;
    p[0]= false;
    f[0]= true;
	for(unsigned int i= 1; i<nv; i++){
		reference[i]= infinito;
		p[i]= true;
	    f[i]= false;
	}

    unsigned int timer = 0;
    CUT_SAFE_CALL( cutCreateTimer( &timer));
    CUT_SAFE_CALL( cutStartTimer( timer));

    bool ultima= false;
    unsigned int i= 0;
    while((!ultima)){
        i++;
		ultima= ejecutarIteracion_CPU9(i, reference, 
									   nv, m, infinito,
								       f, p);
	}//while

	
	CUT_SAFE_CALL( cutStopTimer( timer));
    printf( "%f\t %d\t", cutGetTimerValue( timer), i);
    CUT_SAFE_CALL( cutDeleteTimer( timer));

	//destrucci�n de arrays
	free(p);
	free(f);
}
