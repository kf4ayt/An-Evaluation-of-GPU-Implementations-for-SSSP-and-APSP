#include "GeneradorGrafos.h"


//generaci�n de n�meros aleatorios
#define _CRT_RAND_S

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>  //buscar otro fichero .h que haga lo corresponde
using namespace std;

#include <cutil.h>
#include "tools.h"
#include "template_gold.h"

#include <limits.h>

// export C interface
//#include "GeneradorGrafos1.h"


//////////////////////IMPLEMENTATION

unsigned int RangedRand( unsigned int range_min, unsigned int range_max){
   // Generate random numbers in the closed interval
   // [range_min, range_max]. In other words,
   // range_min <= random number <= range_max

	unsigned int n;

	errno_t err = rand_s(&n);
    if (err != 0) printf("\n\nThe rand_s function failed!\n\n");
	unsigned int u= unsigned int (((double) n/ (double) UINT_MAX) * (range_max +1 - range_min)) + range_min;
 
	while((u<range_min)||(u>range_max)){
		printf("\n\nFallo en la generaci�n: %u\t%u\n\n", n, u);
		err = rand_s(&n);
		if (err != 0) printf("\n\nThe rand_s function failed!\n\n");
 		u= unsigned int (((double) n/ (double) UINT_MAX) * (range_max +1 - range_min)) + range_min;
	}

	return u;
}


void barajar(const unsigned int nv, unsigned int* nodo){
	unsigned int nodo_aux;
	unsigned int aux;
	for(unsigned int i=0; i<nv; i++){
		nodo_aux= RangedRand(0, nv-1);
		//intercambio
		aux= nodo[i];
		nodo[i]= nodo[nodo_aux];
		nodo[nodo_aux]= aux;
	}

}

////////////////////////////////////////////////
void genera_M_Adyacencia( const unsigned int nv, const unsigned int degree, 
						  const unsigned int topeW, const unsigned int infinito,
						  unsigned int& mem_size_M, unsigned int* &m){

	mem_size_M= nv*nv* sizeof(unsigned int);
	m= (unsigned int*) malloc(mem_size_M);


	unsigned int origen;
	unsigned int destino;
	unsigned int k;


#ifdef _DEBUG
    printf( "Generando= ");
	unsigned int timer = 0;
    CUT_SAFE_CALL( cutCreateTimer( &timer));
    CUT_SAFE_CALL( cutStartTimer( timer));
#endif   


	unsigned int* nodo=  (unsigned int*) malloc(nv*sizeof(unsigned int));
	for(unsigned int i=0; i<nv; i++) nodo[i]= i;

	for(origen=0; origen<nv; origen++){
		barajar(nv, nodo);
		for(destino=0; destino<nv; destino++){
			MATRIX(m, origen, destino)= infinito;
		}//for
		for(k=0; k<degree; k++){
			MATRIX(m, origen, nodo[k])= RangedRand(1,topeW);
		}//for
	}//for


#ifdef _DEBUG
	CUT_SAFE_CALL( cutStopTimer( timer));
    printf( "%f\n\n", cutGetTimerValue( timer));
    CUT_SAFE_CALL( cutDeleteTimer( timer));

	printf("nv= %i\n", nv);
	printf("degree= %i\n", degree);
	printf("mem_size_M= %i\n", mem_size_M);
	//MOSTRAR GRAFO
	mostrarUI_M_Adyacencia(m, nv, "m");
#endif   

	free(nodo);
}


void guardaMatriz_FicheroB(const char* filename, const unsigned int nv, 
						   const unsigned int mem_size_M, const unsigned int* m){
	ofstream salida;
	salida.open(filename, ios::binary);
	if(salida.fail()) printf("\nProblemas con el archivo\n");
    else{
		salida.write((char*)& nv, sizeof(unsigned int));
		salida.write((char*)m, mem_size_M);
		salida.close();
    }//else
}



void leeMatriz_FicheroB(const char* filename, unsigned int& nv,
						unsigned int& mem_size_M, unsigned int*& m){
	m= NULL;
	ifstream entrada;
    entrada.open(filename, ios::binary);
	if(entrada.fail()) printf("\nProblemas con el archivo\n");
    else{
		entrada.read((char*)& nv, sizeof(unsigned int));
		mem_size_M= nv*nv* sizeof(unsigned int);

		m= (unsigned int*) malloc(mem_size_M);
		entrada.read((char*)m, mem_size_M);

/*
#ifdef _DEBUG
		printf("nv= %i\n", nv);
		printf("mem_size_M= %i\n", mem_size_M);
		//MOSTRAR GRAFO
	    mostrarUI_M_Adyacencia(m, nv, "m");
#endif //_DEBUG
*/

		entrada.close();
    }
}



