#if defined(__cplusplus)
extern "C" {
#endif
#include "template.fatbin.c"
#include "crt/host_runtime.h"
#if defined(__cplusplus)
}
#endif
