
#include "Fibonacci_Heaps.h"
//#include "Fibonacci_Heaps1.h"

#include "tools.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <cutil.h>

/*******************   functions for F-heap  *****************/

typedef  /* heap_node */
   struct heap_node_st
{
   unsigned int			  vertex_index;	   //�ndice al v�rtice
   struct heap_node_st   *heap_parent;     /* heap parent pointer */
   struct heap_node_st   *son;             /* heap successor */
   struct heap_node_st   *next;            /* next brother */
   struct heap_node_st   *prev;            /* previous brother */
   unsigned int           deg;             /* number of children */
   unsigned int           status;          /* status of node */
} heap_node;

#define HNNULL	        (heap_node*)NULL

typedef /* F-heap */
   struct fheap_st
{
   heap_node            *min;        /* the minimal node */
   unsigned int         dist;        /* tentative distance of min. node */
   unsigned int            n;        /* number of nodes in the heap */
   heap_node   **deg_pointer;        /* pointer to the node with given degree */
   unsigned int      deg_max;        /* maximal degree */

   const unsigned int*    reference; //La actual estimacion de todos los v�rtices
}
   f_heap;

f_heap fh;

heap_node    *after, *before, *father, *child, *first, *last,
	         *node_c, *node_s, *node_r, *node_n, *node_l;

unsigned int  dg;

#define BASE           1.61803 //N�mero de oro
#define NOT_ENOUGH_MEM 2

#define OUT_OF_HEAP    0
#define IN_HEAP        1
#define MARKED         2


void Init_fheap( const unsigned int nv, const unsigned int* reference1){
	fh.deg_max = (unsigned int) ( log ( (double) nv ) / log ( BASE ) + 1 );

	if (
	 ( fh.deg_pointer = (heap_node**) calloc ( fh.deg_max, sizeof(heap_node*) ) )
	   ==
	   (heap_node**)NULL
	   )
	   exit ( NOT_ENOUGH_MEM );

	  for ( dg = 0; dg < fh.deg_max; dg ++ )
		 fh.deg_pointer[dg] = HNNULL;

	fh.n  = 0;
	fh.min = HNNULL;
	fh.reference= reference1;
}

void Check_min( heap_node* nd){
	if( fh.reference[nd->vertex_index] < fh.dist ){ //reference
		fh.dist = fh.reference[nd->vertex_index];   //reference
		fh.min  = nd;
	}
}

void Insert_after_min( heap_node* nd){
	after = fh.min -> next;
	nd    -> next = after;
	after   -> prev = nd;
	fh.min  -> next = nd;
	nd    -> prev = fh.min;

	Check_min(nd);
}

void Insert_to_root( heap_node* nd){
	nd -> heap_parent = HNNULL;
	nd -> status      = IN_HEAP; //status

	Insert_after_min(nd);
}

void Insert_to_fheap( heap_node* nd){
	nd -> heap_parent = HNNULL;
	nd -> son         = HNNULL;
	nd -> status      = IN_HEAP; //status
	nd -> deg         = 0;

	if ( fh.min == HNNULL ){
		nd -> prev    =  nd -> next  =  nd;
        fh.min        =  nd;
		fh.dist       =  fh.reference[nd->vertex_index]; //reference
	}
    else
		Insert_after_min(nd);
    fh.n ++;
}

void Cut_node( heap_node* nd, heap_node* father){
	after = nd -> next;
	if( after != nd ){ 
		before = nd -> prev;
		before -> next = after;
		after  -> prev = before;
	}

	if ( father -> son == nd ) father -> son = after;
	( father -> deg ) --;
	if ( father -> deg == 0 ) father -> son = HNNULL;
}

void Fheap_decrease_key( heap_node* nd){
	if (
		( father = nd -> heap_parent )
        ==
        HNNULL
		)
		Check_min ( nd );
	else{/* node isn't in the root */ 
		if ( fh.reference[nd->vertex_index] < fh.reference[father->vertex_index] ){ //reference
			node_c = nd;
			while ( father != HNNULL ){
				Cut_node ( node_c, father );
                Insert_to_root (node_c);
                if ( father -> status == IN_HEAP ){
					father -> status = MARKED;
					break;
				}//if
				node_c = father;
				father =  father -> heap_parent;
			}//while
		}//if
	}//else
}

heap_node* Extract_min( const unsigned int infinito){
	heap_node *nd;
	nd = fh.min;
	if ( fh.n > 0 ){
		fh.n --;
		fh.min -> status = OUT_OF_HEAP; //status

		/* connecting root-list and sons-of-min-list */ 
		first = fh.min -> prev;
		child = fh.min -> son;
		if ( first == fh.min )
			first = child;
		else{
			after = fh.min -> next;
			if ( child == HNNULL ){
				first -> next = after;
				after -> prev = first;
			}//if
			else{
				before = child -> prev;
				first  -> next = child;
				child  -> prev = first;

				before -> next = after;
				after  -> prev = before;
			}//else
		}//else
		
		if ( first != HNNULL ){ /* heap is not empty */ 
			/* squeezing root */ 
			node_c = first;
			last   = first -> prev;
			while(1){
				node_l = node_c;
				node_n = node_c -> next;
				/*    printf ( "node_c=%ld  node_n=%ld\n", nod(node_c), nod(node_n) );*/
				while(1){
					dg = node_c -> deg;
					node_r = fh.deg_pointer[dg];
					/*
					printf ( "dg=%ld  node_r=%ld\n", dg, nod(node_r) );
					for ( dgx = 0; dgx < fh.deg_max; dgx ++ )
						printf (" %ld ", nod(fh.deg_pointer[dgx]) );
					printf ("\n");
					*/
					if( node_r == HNNULL ){
						fh.deg_pointer[dg] = node_c;
						break;
					}//if
					else{
						if(fh.reference[node_c->vertex_index] < fh.reference[node_r->vertex_index]){
							node_s = node_r;
							node_r = node_c;
						}//if
						else
							node_s = node_c;

						/*    printf ( "node_r=%ld  node_s=%ld\n", nod(node_r), nod(node_s) );*/
						/* detach node_s from root */ 
						after  = node_s -> next;
						before = node_s -> prev;

						after  -> prev = before;
						before -> next = after;

						/* attach node_s to node_r */ 
						node_r -> deg ++;
						node_s -> heap_parent = node_r;
						node_s -> status = IN_HEAP;

						child = node_r -> son;

						if ( child == HNNULL )
							node_r -> son = node_s -> next = node_s -> prev = node_s;
						else{
							after = child -> next;
							child  -> next = node_s;
							node_s -> prev = child;
							node_s -> next = after;
							after  -> prev = node_s;
						}//else
					} 
					
					/* node_r now is father of node_s */ 
					node_c = node_r;
					fh.deg_pointer[dg] = HNNULL;
					/*
					printf ( "INHEAP node  dist parent  son next prev deg status\n" );
					for ( i = nodes; i != node_last; i ++ ){
						if ( i -> status > OUT_OF_HEAP )
							printf (" %ld %ld %ld %ld  %ld %ld %ld %d\n",
									nod(i), i->dist, nod(i->heap_parent), nod(i->son), nod(i->next),
									nod(i->prev), i->deg, i->status );
					}
					fgetc(inp);
					*/

				}//while
				
				if ( node_l == last ) break;
				node_c = node_n;
			}//while
			
			/* finding minimum */ 
			fh.dist = infinito;

		    for ( dg = 0; dg < fh.deg_max; dg ++ ){
				if ( fh.deg_pointer[dg] != HNNULL ){
					node_r = fh.deg_pointer[dg];
					fh.deg_pointer[dg] = HNNULL;
					Check_min ( node_r );
					node_r -> heap_parent = HNNULL;
				}//if
			}//for
		}//if
		else /* heap is empty */ 
			fh.min = HNNULL;
	}//if
	return nd;
}


/**************   end of heap functions   ****************/

#define NODE_IN_FHEAP( node ) ( node -> status > OUT_OF_HEAP )

void init_HN(heap_node* nd, const unsigned int index){
	nd->vertex_index= index;
	nd->heap_parent= HNNULL;
	nd->son= HNNULL;
	nd->next= HNNULL;
	nd->prev= HNNULL;
	nd->deg= 0;
	nd->status= OUT_OF_HEAP;
}

void computeGold_FH( unsigned int* reference,
					 const unsigned int nv, const unsigned int* m, 
					 const unsigned int infinito){

	//INICIALIZACION
	heap_node** hn;
	if ( (hn= (heap_node**) calloc ( nv, sizeof(heap_node*) ) )
	     ==
	     (heap_node**)NULL
	   )
	   exit ( NOT_ENOUGH_MEM );	
	
	//POR AQUI

	unsigned int i;
	hn[0]= new heap_node;
	init_HN(hn[0], 0);
	reference[0]= 0;
	for(i= 1; i<nv; i++){
		hn[i]= new heap_node;
		init_HN(hn[i], i);
		reference[i]= infinito;
	}	

    unsigned int timer = 0;
    CUT_SAFE_CALL( cutCreateTimer( &timer));
    CUT_SAFE_CALL( cutStartTimer( timer));

	//Bucle
	Init_fheap (nv, reference);
	Insert_to_fheap (hn[0]);
    unsigned int nVueltas= 0;
	heap_node* nd;
	unsigned int frontera;
	unsigned int dist_new;
	unsigned int sid;
    while(true){
        nVueltas++;		
		
		//C�lculo de la frontera
		nd= Extract_min (infinito);

		if( nd == HNNULL ) break;

		frontera= nd->vertex_index;

		//Relajamos
		for(sid= 1; sid<nv; sid++){
            dist_new= reference[frontera]+ MATRIX(m, frontera, sid);

			if(dist_new < reference[sid]) {
				reference[sid]= dist_new;
				if(NODE_IN_FHEAP(hn[sid])){
					Fheap_decrease_key(hn[sid]);
				}
				else{
					Insert_to_fheap (hn[sid]);
				}
			}//if
		}//for
	}//while
	
	CUT_SAFE_CALL( cutStopTimer( timer));
    printf( "%f\t %d\t", cutGetTimerValue( timer), nVueltas);
    CUT_SAFE_CALL( cutDeleteTimer( timer));

	//destrucci�n de array de hn
	for(i= 0; i<nv; i++) free(hn[i]);
	free(hn);
	free(fh.deg_pointer);
	fh.deg_pointer= NULL;

#ifdef _DEBUG
		mostrarUI(reference,nv,"reference FH");
#endif //_DEBUG

}