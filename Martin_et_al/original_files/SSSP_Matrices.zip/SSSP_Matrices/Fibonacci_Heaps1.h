// export C interface

extern "C" 
void computeGold_FH( unsigned int* reference,
					 const unsigned int nv, const unsigned int* m, 
					 const unsigned int infinito);